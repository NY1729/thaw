module.exports = (function(require) {
if (typeof require !== 'function') require = function(name) { var error = new Error('Cannot find module ' + name); error.code = 'MODULE_NOT_FOUND'; throw error; };
var __thaw_bundle_exports = globalThis.__thaw_bundle_exports || (globalThis.__thaw_bundle_exports = {});
var __thaw_bundle_builtin_names = Object.freeze(["_http_agent","_http_client","_http_common","_http_incoming","_http_outgoing","_http_server","_stream_duplex","_stream_passthrough","_stream_readable","_stream_transform","_stream_wrap","_stream_writable","_tls_common","_tls_wrap","assert","assert/strict","async_hooks","buffer","child_process","cluster","console","constants","crypto","dgram","diagnostics_channel","dns","dns/promises","domain","events","fs","fs/promises","http","http2","https","inspector","inspector/promises","module","net","os","path","path/posix","path/win32","perf_hooks","process","punycode","querystring","readline","readline/promises","repl","stream","stream/consumers","stream/promises","stream/web","string_decoder","sys","test","test/reporters","timers","timers/promises","tls","trace_events","tty","url","util","util/types","v8","vm","wasi","worker_threads","zlib"]);
var __thaw_bundle_cache = {};
var __thaw_bundle_async_keys = JSON.parse("{}");
var __thaw_bundle_edges = Object.create(null);
var __thaw_bundle_star_linkers = Object.create(null);
var __thaw_bundle_edge_version = 0;
var __thaw_bundle_factories = {
"better-sqlite3/lib/index.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
module.exports = require('./database');
module.exports.SqliteError = require('./sqlite-error');

},
"better-sqlite3/lib/sqlite-error.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const descriptor = { value: 'SqliteError', writable: true, enumerable: false, configurable: true };

function SqliteError(message, code) {
	if (new.target !== SqliteError) {
		return new SqliteError(message, code);
	}
	if (typeof code !== 'string') {
		throw new TypeError('Expected second argument to be a string');
	}
	Error.call(this, message);
	descriptor.value = '' + message;
	Object.defineProperty(this, 'message', descriptor);
	Error.captureStackTrace(this, SqliteError);
	this.code = code;
}
Object.setPrototypeOf(SqliteError, Error);
Object.setPrototypeOf(SqliteError.prototype, Error.prototype);
Object.defineProperty(SqliteError.prototype, 'name', descriptor);
module.exports = SqliteError;

},
"node:stream": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var defaultByteHighWaterMark = 16384, defaultObjectHighWaterMark = 16; function getDefaultHighWaterMark(objectMode) { return objectMode ? defaultObjectHighWaterMark : defaultByteHighWaterMark; } function setDefaultHighWaterMark(objectMode, value) { value = Number(value); if (!Number.isInteger(value) || value < 0) throw new RangeError('highWaterMark must be a non-negative integer'); if (objectMode) defaultObjectHighWaterMark = value; else defaultByteHighWaterMark = value; } function resolveHighWaterMark(options, objectMode, sideKey) { var configured = options.highWaterMark === undefined && sideKey ? options[sideKey] : options.highWaterMark; var value = configured === undefined ? getDefaultHighWaterMark(objectMode) : Number(configured); if (!Number.isInteger(value) || value < 0) throw new RangeError('highWaterMark must be a non-negative integer'); return value; } function normalizeStreamEncoding(encoding) { var value = String(encoding || 'utf8').toLowerCase().replace(/[-_]/g, ''); if (!globalThis.Buffer.isEncoding(value)) throw new TypeError('Unknown encoding: ' + encoding); return value; } function streamUtf8CompleteLength(buffer) { var index = buffer.length - 1; while (index >= 0 && (buffer[index] & 192) === 128) index--; if (index < 0) return Math.max(0, buffer.length - Math.min(buffer.length, 3)); var lead = buffer[index], expected = lead >= 240 && lead <= 247 ? 4 : lead >= 224 && lead <= 239 ? 3 : lead >= 192 && lead <= 223 ? 2 : 1; return buffer.length - index < expected ? index : buffer.length; } function StreamStringDecoder(encoding) { this.encoding = normalizeStreamEncoding(encoding); this.pending = globalThis.Buffer.alloc(0); } StreamStringDecoder.prototype.write = function(value) { var input = globalThis.Buffer.from(value), combined = this.pending.length ? globalThis.Buffer.concat([this.pending, input]) : input, complete = combined.length; if (this.encoding === 'utf8' || this.encoding === 'utf') complete = streamUtf8CompleteLength(combined); else if (this.encoding === 'utf16le' || this.encoding === 'ucs2') { complete -= complete % 2; if (complete >= 2) { var unit = combined[complete - 2] | combined[complete - 1] << 8; if (unit >= 55296 && unit <= 56319) complete -= 2; } } else if (this.encoding === 'base64' || this.encoding === 'base64url') complete -= complete % 3; this.pending = globalThis.Buffer.from(combined.subarray(complete)); return combined.subarray(0, complete).toString(this.encoding); }; StreamStringDecoder.prototype.end = function() { var output = this.pending.length ? this.pending.toString(this.encoding) : ''; this.pending = globalThis.Buffer.alloc(0); return output; }; function Stream() { this._events = Object.create(null); this.destroyed = false; this.closed = false; this.errored = null; this._readableDidRead = false; this._constructState = 'ready'; this._constructWaiters = []; this._destroyWaiters = []; this._destroyFinished = false; this._autoDestroy = true; this._emitClose = true; this._endEmitted = false; } function configureConstruct(stream, options) { if (stream._constructConfigured) return; if (typeof options.construct === 'function') stream._construct = options.construct; if (typeof stream._construct !== 'function') return; stream._constructConfigured = true; stream._constructState = 'pending'; queueMicrotask(function() { var completed = false; function finish(error) { if (completed) return; completed = true; if (error) { stream._constructState = 'failed'; stream._constructWaiters = []; stream.destroy(error); return; } stream._constructState = 'ready'; if (stream.destroyed) { stream._constructWaiters.length = 0; stream._runDestroy(); return; } var waiters = stream._constructWaiters.splice(0); waiters.forEach(function(waiter) { waiter(); }); } try { stream._construct(finish); } catch (error) { finish(error); } }); } function afterConstruct(stream, action) { if (stream._constructState === 'ready') action(); else if (stream._constructState === 'pending') stream._constructWaiters.push(action); } function maybeAutoDestroy(stream) { if (!stream._autoDestroy || stream.destroyed) return; var readableDone = stream.readableEnded === undefined || stream.readableEnded, writableDone = stream.writableFinished === undefined || stream.writableFinished; if (readableDone && writableDone) queueMicrotask(function() { if (!stream.destroyed) stream.destroy(); }); } function emitReadableEnd(stream) { if (!stream._endEmitted && stream._readableEof && stream._chunks.length === 0) { stream.readableEnded = true; stream._endEmitted = true; stream.emit('end'); maybeAutoDestroy(stream); } }
function addStreamListener(stream, name, listener, once, prepend) { if ((stream._events.newListener || []).length) stream.emit('newListener', name, listener); var entry = { listener: listener, once: once, wrapper: null }; if (once) { entry.wrapper = function() { var list = stream._events[name] || [], index = list.indexOf(entry); if (index >= 0) { list.splice(index, 1); if ((stream._events.removeListener || []).length) stream.emit('removeListener', name, listener); } return listener.apply(this, arguments); }; entry.wrapper.listener = listener; } if (prepend) (stream._events[name] || (stream._events[name] = [])).unshift(entry); else (stream._events[name] || (stream._events[name] = [])).push(entry); if (name === 'readable' && stream._drainReadable && !stream._readableListening) { stream._readableListening = true; stream.readableFlowing = false; stream._paused = true; if (stream._chunks.length && !stream._readableScheduled) { stream._readableScheduled = true; globalThis.process.nextTick(function() { stream._readableScheduled = false; if (!stream.destroyed) stream.emit('readable'); }); } } if (name === 'data' && stream._drainReadable && stream.readableFlowing !== false) { stream._deferDrain = true; try { stream.resume(); } finally { stream._deferDrain = false; } } return stream; } Stream.prototype.on = Stream.prototype.addListener = function(event, listener) { return addStreamListener(this, event, listener, false, false); };Stream.prototype.once = function(event, listener) { return addStreamListener(this, event, listener, true, false); };Stream.prototype.prependListener = function(event, listener) { return addStreamListener(this, event, listener, false, true); }; Stream.prototype.prependOnceListener = function(event, listener) { return addStreamListener(this, event, listener, true, true); };Stream.prototype.off = Stream.prototype.removeListener = function(event, listener) { var name = event, list = this._events[name] || []; for (var index = list.length - 1; index >= 0; index--) { if (list[index].listener === listener || list[index].wrapper === listener) { var original = list[index].listener; list.splice(index, 1); if ((this._events.removeListener || []).length) this.emit('removeListener', name, original); break; } } return this; }; Stream.prototype.removeAllListeners = function(event) { var names = arguments.length ? [event] : Reflect.ownKeys(this._events); names.forEach(function(name) { if (name === 'removeListener') return; var list = (this._events[name] || []).slice().reverse(); delete this._events[name]; list.forEach(function(entry) { if ((this._events.removeListener || []).length) this.emit('removeListener', name, entry.listener); }, this); }, this); if (!arguments.length || event === 'removeListener') delete this._events.removeListener; return this; }; Stream.prototype.listeners = function(event) { return (this._events[event] || []).map(function(entry) { return entry.listener; }); }; Stream.prototype.rawListeners = function(event) { return (this._events[event] || []).map(function(entry) { return entry.wrapper || entry.listener; }); }; Stream.prototype.listenerCount = function(event, listener) { return (this._events[event] || []).filter(function(entry) { return !listener || entry.listener === listener || entry.wrapper === listener; }).length; }; Stream.prototype.eventNames = function() { return Reflect.ownKeys(this._events).filter(function(name) { return (this._events[name] || []).length > 0; }, this); }; Stream.prototype.setMaxListeners = function(value) { this._maxListeners = Number(value); return this; }; Stream.prototype.getMaxListeners = function() { return this._maxListeners === undefined ? 10 : this._maxListeners; };Stream.prototype.emit = function(event) { var name = event; if (name === 'data') this._readableDidRead = true; var entries = (this._events[name] || []).slice(); var args = Array.prototype.slice.call(arguments, 1); if (name === 'error' && entries.length === 0) { if (args[0] instanceof Error) throw args[0]; var unhandled = new Error('Unhandled error' + (args.length ? ': ' + String(args[0]) : '')); unhandled.code = 'ERR_UNHANDLED_ERROR'; unhandled.context = args[0]; throw unhandled; } entries.forEach(function(entry) { (entry.wrapper || entry.listener).apply(this, args); }, this); return entries.length > 0; };
Stream.prototype.destroy = function(error) { if (this.destroyed) { if (error && !this.errored && !this._destroyStarted) { this.errored = error; this._pendingDestroyError = error; } if (this._constructState !== 'pending' && !this._destroyStarted) this._runDestroy(); return this; } this.destroyed = true; if (this.readable === true && !this.readableEnded) this.readableAborted = true; if (this.writable === true && !this.writableFinished) this.writableAborted = true; this.readable = false; this.writable = false; if (error) this.errored = error; this._pendingDestroyError = error || null; var self = this; this._runDestroy = function() { if (self._destroyStarted) return; self._destroyStarted = true; var completed = false; function finish(finalError) { if (completed) return; completed = true; self._destroyFinished = true; self.closed = true; var cycleError = finalError || self._pendingDestroyError || null; self._destroyFinalError = cycleError; if (cycleError) self.errored = cycleError; queueMicrotask(function() { if (cycleError) self.emit('error', cycleError); if (self._emitClose) self.emit('close'); }); var observerError; self._destroyWaiters.splice(0).forEach(function(waiter) { try { waiter(cycleError); } catch (error) { observerError = observerError || error; } }); if (observerError) throw observerError; } if (typeof self._destroy === 'function') { try { self._destroy(self._pendingDestroyError, finish); } catch (destroyError) { if (!completed) finish(destroyError); else throw destroyError; } } else finish(self._pendingDestroyError); }; if (this._constructState === 'pending') return this; this._runDestroy(); return this; };Stream.prototype._undestroy = function() { this.destroyed = false; this.closed = false; this.errored = null; this._destroyStarted = false; this._destroyFinished = false; this._destroyFinalError = null; this._pendingDestroyError = null; this._destroyWaiters = []; if (this.readableEnded !== undefined) { this.readableAborted = false; this.readable = !this.readableEnded; } if (this.writableEnded !== undefined) { this.writableAborted = false; this.writable = !this.writableEnded; this._destroyError = null; } return this; };Stream.prototype.pipe = function(destination, options) { var source = this, ended = false; function onData(chunk) { if (destination.writable === false) return; if (destination.write(chunk) === false && source.pause) source.pause(); } function onDrain() { if (source.resume) source.resume(); } function onEnd() { if (ended) return; ended = true; cleanup(); if (!options || options.end !== false) destination.end(); } function onClose() { if (ended) return; ended = true; cleanup(); if (destination.destroy) destination.destroy(); } function onError(error) { cleanup(); if (destination.destroy) destination.destroy(error); } function cleanup() { source.removeListener('data', onData); source.removeListener('end', onEnd); source.removeListener('close', onClose); source.removeListener('error', onError); destination.removeListener('drain', onDrain); } source.on('data', onData); source.once('end', onEnd); source.once('close', onClose); source.once('error', onError); destination.on('drain', onDrain); destination.emit('pipe', source); return destination; };function inherit(child, parent) { child.prototype = Object.create(parent.prototype); child.prototype.constructor = child; }
function Readable(options) { Stream.call(this); options = options || {}; if (options.signal !== undefined) validateStreamSignal(options.signal); this._autoDestroy = options.autoDestroy !== false; this._emitClose = options.emitClose !== false; this.readable = true; this.readableEnded = false; this._readableEof = false; this.readableAborted = false; this.readableFlowing = null; this.readableEncoding = null; this._decoder = null; this._readableObjectMode = Boolean(options.objectMode || options.readableObjectMode); this.readableObjectMode = this._readableObjectMode; this.readableHighWaterMark = resolveHighWaterMark(options, this._readableObjectMode, 'readableHighWaterMark'); this.readableLength = 0; this._paused = false; this._chunks = []; if (typeof options.read === 'function') this._read = options.read; if (typeof options.destroy === 'function') this._destroy = options.destroy; configureConstruct(this, options); if (options.encoding) this.setEncoding(options.encoding); if (options.signal && !this._deferStreamSignal) addAbortSignal(options.signal, this); }inherit(Readable, Stream);
Object.defineProperty(Readable.prototype, '_readableState', { get: function() { return { endEmitted: Boolean(this.readableEnded), length: this.readableLength, errorEmitted: this.errored !== null }; } });
Readable.prototype._read = function() {}; Readable.prototype._destroy = function(error, callback) { callback(error); };Readable.prototype.setEncoding = function(encoding) { if (this._readableObjectMode) return this; this._decoder = new StreamStringDecoder(encoding); this.readableEncoding = this._decoder.encoding; var decoded = [], decoder = this._decoder; this._chunks.forEach(function(chunk) { var value = typeof chunk === 'string' ? chunk : decoder.write(chunk); if (value.length) decoded.push(value); }); this._chunks = decoded; this.readableLength = decoded.reduce(function(total, chunk) { return total + chunk.length; }, 0); return this; };
function transformDrained(stream) { var wait = stream._transformWait; if (wait && stream.readableLength < stream.readableHighWaterMark) { stream._transformWait = null; wait(); } } function readableChunkLength(stream, chunk) { return stream._readableObjectMode ? 1 : typeof chunk === 'string' ? (stream.readableEncoding ? chunk.length : Buffer.byteLength(chunk)) : chunk.length; } function enqueueReadableChunk(stream, value) { if (value === '' && !stream._readableObjectMode) return; if (!stream._paused && stream.readableFlowing === true) stream.emit('data', value); else { stream._chunks.push(value); stream.readableLength += readableChunkLength(stream, value); stream.emit('readable'); } } function readableInputError(stream, error) { stream.errored = error; stream.readableAborted = true; if (stream._autoDestroy) stream.destroy(error); else stream.emit('error', error); return false; } Readable.prototype.push = function(chunk, encoding) { this._reading = false; if (this.destroyed) return false; if (chunk === null) { if (this._readableEof) return false; this._readableEof = true; if (this._decoder) enqueueReadableChunk(this, this._decoder.end()); this.readable = false; emitReadableEnd(this); return false; } if (this._readableEof) { var eofError = new Error('stream.push() after EOF'); eofError.code = 'ERR_STREAM_PUSH_AFTER_EOF'; return readableInputError(this, eofError); } if (chunk === undefined) return true; var value; if (this._readableObjectMode) value = chunk; else if (typeof chunk === 'string') value = globalThis.Buffer.from(chunk, encoding); else if (globalThis.ArrayBuffer.isView(chunk)) value = globalThis.Buffer.from(chunk.buffer, chunk.byteOffset, chunk.byteLength); else { var typeError = new TypeError('The chunk argument must be of type string or an instance of Buffer, TypedArray, or DataView'); typeError.code = 'ERR_INVALID_ARG_TYPE'; return readableInputError(this, typeError); } if (this._decoder && !this._readableObjectMode) value = this._decoder.write(value); enqueueReadableChunk(this, value); return this.readableLength < this.readableHighWaterMark; };Readable.prototype._drainReadable = function() { while (!this._paused && this._chunks.length) { var value = this._chunks.shift(); this.readableLength -= readableChunkLength(this, value); if ((this._events.data || []).length) this.emit('data', value); } transformDrained(this); if (!this._paused) emitReadableEnd(this); }; Readable.prototype.pause = function() { this._paused = true; this.readableFlowing = false; this.emit('pause'); return this; }; Readable.prototype.resume = function() { this._paused = false; this.readableFlowing = true; this.emit('resume'); var self = this; if (!this._chunks.length && !this._readableEof) afterConstruct(this, function() { if (!self._readableEof) self._read(self.readableHighWaterMark); }); this._drainReadable(); return this; }; Readable.prototype.isPaused = function() { return this._paused; };Readable.prototype.read = function(size) { this._readableDidRead = true; if (this._chunks.length === 0) { if (!this.readableEnded) { var self = this; afterConstruct(this, function() { self._read(size); }); } if (this._chunks.length === 0) return null; } if (size === undefined) { if (this._chunks.length === 1) { var only = this._chunks.shift(); this.readableLength = 0; return only; } if (this._readableObjectMode) { this.readableLength--; return this._chunks.shift(); } if (this.readableEncoding) { var text = this._chunks.join(''); this._chunks = []; this.readableLength = 0; return text; } var complete = globalThis.Buffer.concat(this._chunks); this._chunks = []; this.readableLength = 0; return complete; } if (this._readableObjectMode) { this.readableLength--; return this._chunks.shift(); } if (this.readableEncoding) { var joinedText = this._chunks.join(''), characterCount = Math.max(0, Math.min(Number(size), joinedText.length)), textResult = joinedText.slice(0, characterCount), textRemainder = joinedText.slice(characterCount); this._chunks = textRemainder ? [textRemainder] : []; this.readableLength = textRemainder.length; return textResult; } var joined = globalThis.Buffer.concat(this._chunks), count = Math.max(0, Math.min(Number(size), joined.length)), result = joined.subarray(0, count), remainder = joined.subarray(count); this._chunks = remainder.length ? [remainder] : []; this.readableLength = remainder.length; return result; };Readable.prototype.read = function(size) { this._readableDidRead = true; var numericSize = Number(size), requested = size === undefined || !Number.isFinite(numericSize) ? undefined : Math.floor(numericSize), pulled = false; if (requested !== undefined && requested < 0) requested = 0; if (requested === 0) { if (!this._readableEof && this._chunks.length === 0) { var zeroStream = this; afterConstruct(this, function() { zeroStream._read(0); }); } emitReadableEnd(this); return null; } if (this._chunks.length === 0 && !this._readableEof && !this._reading) { var stream = this; pulled = true; this._reading = true; afterConstruct(this, function() { stream._read(requested); }); } if (this._chunks.length === 0) { emitReadableEnd(this); return null; } if (this._readableObjectMode) { this.readableLength--; var object = this._chunks.shift(); if (!this._readableListening) emitReadableEnd(this); transformDrained(this); return object; } var joined = this.readableEncoding ? this._chunks.join('') : globalThis.Buffer.concat(this._chunks), available = joined.length; if (requested !== undefined && requested > available && !this._readableEof) { if (!pulled) { var waitingStream = this; afterConstruct(this, function() { waitingStream._read(requested); }); joined = this.readableEncoding ? this._chunks.join('') : globalThis.Buffer.concat(this._chunks); available = joined.length; } if (requested > available && !this._readableEof) return null; } var count = requested === undefined ? available : Math.min(requested, available), result = this.readableEncoding ? joined.slice(0, count) : joined.subarray(0, count), remainder = this.readableEncoding ? joined.slice(count) : joined.subarray(count); this._chunks = remainder.length ? [remainder] : []; this.readableLength = remainder.length; if (!this._readableListening) emitReadableEnd(this); transformDrained(this); if (!this.destroyed && (this._events.data || []).length) this.emit('data', result); return result; };
function createReadableIterator(source, destroyOnReturn) { var finished = false, returned = false; source.pause(); function take() { if (returned) return Promise.resolve({ value: undefined, done: true }); if (source._chunks.length) { var value = source._chunks.shift(); source.readableLength -= readableChunkLength(source, value); source._readableDidRead = true; emitReadableEnd(source); return Promise.resolve({ value: value, done: false }); } if (source.destroyed && !source.readableEnded && !finished) { finished = true; if (source.errored) return Promise.reject(source.errored); var closed = new Error('Premature close'); closed.code = 'ERR_STREAM_PREMATURE_CLOSE'; return Promise.reject(closed); } if (finished || source.readableEnded || source.destroyed) { emitReadableEnd(source); return Promise.resolve({ value: undefined, done: true }); } return new Promise(function(resolve, reject) { function cleanup() { source.removeListener('readable', readable); source.removeListener('end', end); source.removeListener('error', error); source.removeListener('close', close); } function close() { cleanup(); take().then(resolve, reject); } function readable() { cleanup(); take().then(resolve, reject); } function end() { cleanup(); finished = true; resolve({ value: undefined, done: true }); } function error(reason) { cleanup(); finished = true; reject(reason); } source.once('readable', readable); source.once('end', end); source.once('error', error); source.once('close', close); if (!source._readableEof) { source._readableDidRead = true; afterConstruct(source, function() { if (!source._readableEof && !source.destroyed && !source._chunks.length) source._read(source.readableHighWaterMark); }); } }); } return { next: take, return: function() { finished = true; returned = true; if (destroyOnReturn) source.destroy(); return Promise.resolve({ value: undefined, done: true }); }, throw: function(error) { finished = true; source.destroy(error); return Promise.reject(error); }, [Symbol.asyncIterator]: function() { return this; } }; } Readable.prototype[Symbol.asyncIterator] = function() { return createReadableIterator(this, true); }; Readable.prototype.iterator = function(options) { return createReadableIterator(this, !options || options.destroyOnReturn !== false); }; function disposeStream(stream, readable, abortError) { return new Promise(function(resolve, reject) { var settled = false, destroyed = false, finalError, publicError; function cleanup() { stream.removeListener('error', onError); var index = stream._destroyWaiters.indexOf(done); if (index >= 0) stream._destroyWaiters.splice(index, 1); } function settle(error) { if (settled) return; settled = true; cleanup(); var resolvesAbort = readable ? error === abortError : Boolean(error && error.name === 'AbortError'); if (error && !resolvesAbort) reject(error); else resolve(); } function onError(error) { publicError = error; if (destroyed && finalError && publicError === finalError) settle(finalError); } function done(error) { destroyed = true; finalError = error; if (!error || publicError === error) settle(error); } stream.on('error', onError); if (stream._destroyFinished) { destroyed = true; finalError = stream._destroyFinalError; queueMicrotask(function() { if (!settled) settle(finalError); }); return; } stream._destroyWaiters.push(done); if (!stream.destroyed) { var naturallyComplete = readable ? (stream.readableEnded || stream.readable === undefined) : (stream.writableFinished || stream.writable === undefined); stream.destroy(naturallyComplete ? null : abortError); } else if (!stream._destroyStarted && stream._constructState !== 'pending') stream._runDestroy(); }); } function asyncDisposeReadable() { return disposeStream(this, true, streamAbortError()); } function asyncDisposeWritable() { return disposeStream(this, false, streamAbortError()); } Readable.prototype[Symbol.asyncDispose] = asyncDisposeReadable; Readable.prototype.pipe = function(destination, options) { var source = this; this.on('data', function(chunk) { if (!destination.write(chunk)) { source.pause(); destination.once('drain', function() { source.resume(); }); } }); if (!options || options.end !== false) this.once('end', function() { destination.end(); }); this.once('error', function(error) { destination.destroy(error); }); destination.emit('pipe', this); return destination; };Readable.prototype.pipe = function(destination, options) { var source = this, entry = { destination: destination, cleaned: false }, endDestination = !options || options.end !== false; this._pipeEntries = this._pipeEntries || []; this._awaitDrainWriters = this._awaitDrainWriters || new Set(); function cleanup(emitUnpipe) { if (entry.cleaned) return; entry.cleaned = true; source.removeListener('data', onData); source.removeListener('end', onEnd); source.removeListener('close', onClose); source.removeListener('error', onError); destination.removeListener('drain', onDrain); destination.removeListener('close', onDestinationDone); destination.removeListener('finish', onDestinationDone); source._awaitDrainWriters.delete(destination); var index = source._pipeEntries.indexOf(entry); if (index >= 0) source._pipeEntries.splice(index, 1); if (source._pipeEntries.length === 0 && (source._events.data || []).length === 0) source.readableFlowing = false; if (emitUnpipe) destination.emit('unpipe', source, { hasUnpiped: false }); if (source._awaitDrainWriters.size === 0 && source._paused && !source.destroyed) source.resume(); } function onData(chunk) { if (destination.writable === false || destination.destroyed) return; if (destination.write(chunk) === false) { source._awaitDrainWriters.add(destination); source.pause(); } } function onDrain() { source._awaitDrainWriters.delete(destination); if (source._awaitDrainWriters.size === 0) source.resume(); } function onEnd() { cleanup(true); if (endDestination) destination.end(); } function onClose() { cleanup(true); } function onDestinationDone() { cleanup(true); } function onError(error) { cleanup(true); if (destination.destroy) destination.destroy(error); } entry.cleanup = cleanup; this._pipeEntries.push(entry); this.once('end', onEnd); this.once('close', onClose); this.once('error', onError); destination.on('drain', onDrain); destination.once('close', onDestinationDone); destination.once('finish', onDestinationDone); this.on('data', onData); destination.emit('pipe', this); return destination; }; Readable.prototype.unpipe = function(destination) { var entries = (this._pipeEntries || []).slice(); entries.forEach(function(entry) { if (!destination || entry.destination === destination) entry.cleanup(true); }); return this; };
Readable.prototype.unshift = function(chunk, encoding) { if (chunk === null) return this.push(null); if (this.destroyed) return false; if (this._endEmitted) { var endError = new Error('stream.unshift() after end event'); endError.code = 'ERR_STREAM_UNSHIFT_AFTER_END_EVENT'; return readableInputError(this, endError); } if (chunk === undefined) return true; var value; if (this._readableObjectMode) value = chunk; else if (typeof chunk === 'string') value = globalThis.Buffer.from(chunk, encoding); else if (globalThis.ArrayBuffer.isView(chunk)) value = globalThis.Buffer.from(chunk.buffer, chunk.byteOffset, chunk.byteLength); else { var typeError = new TypeError('The chunk argument must be of type string or an instance of Buffer, TypedArray, or DataView'); typeError.code = 'ERR_INVALID_ARG_TYPE'; return readableInputError(this, typeError); } if (this._decoder && !this._readableObjectMode) value = typeof chunk === 'string' ? chunk : new StreamStringDecoder(this.readableEncoding).write(value); if ((typeof value === 'string' || value.length !== undefined) && value.length === 0 && !this._readableObjectMode) return this.readableLength < this.readableHighWaterMark; this._chunks.unshift(value); this.readableLength += readableChunkLength(this, value); this.emit('readable'); return this.readableLength < this.readableHighWaterMark; }; Readable.prototype.wrap = function(source) { var output = this; source.on('data', function(chunk) { if (!output.push(chunk) && source.pause) source.pause(); }); source.once('end', function() { output.push(null); }); source.once('error', function(error) { output.destroy(error); }); this._read = function() { if (source.resume) source.resume(); }; return this; };
var unshiftReadable = Readable.prototype.unshift; Readable.prototype.unshift = function() { var result = unshiftReadable.apply(this, arguments); return this._readableEof || this.readableEnded ? false : result; }; Readable.prototype.compose = function(destination, options) { var output = compose(this, destination); if (options && options.signal) addAbortSignal(options.signal, output); return output; }; Object.defineProperties(Readable.prototype, { readableDidRead: { get: function() { return this._readableDidRead; } }, readableBuffer: { get: function() { return this._chunks; } } });
Readable.from = function(iterable, options) { var iterator; if (typeof iterable === 'string' || globalThis.Buffer.isBuffer(iterable)) iterator = [iterable][Symbol.iterator](); else { if (iterable === null || iterable === undefined || (typeof iterable[Symbol.asyncIterator] !== 'function' && typeof iterable[Symbol.iterator] !== 'function')) { var typeError = new TypeError('The "iterable" argument must be an instance of Iterable'); typeError.code = 'ERR_INVALID_ARG_TYPE'; throw typeError; } iterator = typeof iterable[Symbol.asyncIterator] === 'function' ? iterable[Symbol.asyncIterator]() : iterable[Symbol.iterator](); } var stream = new Readable(Object.assign({ objectMode: true }, options || {})); var pulling = false, returned = false; function closeIterator() { if (returned || !iterator.return) return; returned = true; try { var closing = iterator.return(); if (closing && closing.then) closing.then(null, function() {}); } catch (_) {} } stream._destroy = function(error, callback) { closeIterator(); callback(error); }; stream._read = function() { if (pulling || stream.destroyed) return; pulling = true; (async function() { try { while (!stream.destroyed) { var item = await iterator.next(); if (item.done) { stream.push(null); return; } var value = await item.value; if (value === null) { var nullError = new TypeError('May not write null values to stream'); nullError.code = 'ERR_STREAM_NULL_VALUES'; throw nullError; } if (!stream.push(value)) break; } } catch (error) { stream.destroy(error); } finally { pulling = false; if (stream.destroyed) closeIterator(); } })(); }; queueMicrotask(function() { if (stream.destroyed) closeIterator(); else stream._read(); }); return stream; }; function readableOperationOptions(options) { options = options || {}; if (options.signal && options.signal.aborted) throw options.signal.reason || new DOMException('The operation was aborted', 'AbortError'); return options; } function checkReadableOperation(options) { if (options.signal && options.signal.aborted) throw options.signal.reason || new DOMException('The operation was aborted', 'AbortError'); } Readable.prototype.map = function(mapper, options) { var source = this; options = readableOperationOptions(options); return Readable.from((async function*() { var index = 0; for await (var value of source) { checkReadableOperation(options); yield await mapper(value, { signal: options.signal, index: index++ }); } })()); }; Readable.prototype.filter = function(predicate, options) { var source = this; options = readableOperationOptions(options); return Readable.from((async function*() { var index = 0; for await (var value of source) { checkReadableOperation(options); if (await predicate(value, { signal: options.signal, index: index++ })) yield value; } })()); }; Readable.prototype.flatMap = function(mapper, options) { var source = this; options = readableOperationOptions(options); return Readable.from((async function*() { var index = 0; for await (var value of source) { checkReadableOperation(options); var mapped = await mapper(value, { signal: options.signal, index: index++ }); if (mapped && (mapped[Symbol.asyncIterator] || mapped[Symbol.iterator])) { for await (var child of mapped) yield child; } else yield mapped; } })()); }; Readable.prototype.drop = function(limit, options) { var source = this; options = readableOperationOptions(options); limit = Math.max(0, Number(limit)); return Readable.from((async function*() { var index = 0; for await (var value of source) { checkReadableOperation(options); if (index++ >= limit) yield value; } })()); }; Readable.prototype.take = function(limit, options) { var source = this; options = readableOperationOptions(options); limit = Math.max(0, Number(limit)); return Readable.from((async function*() { if (limit === 0) return; var index = 0; for await (var value of source) { checkReadableOperation(options); yield value; if (++index >= limit) break; } })()); }; Readable.prototype.toArray = async function(options) { options = readableOperationOptions(options); var values = []; for await (var value of this) { checkReadableOperation(options); values.push(value); } return values; }; Readable.prototype.forEach = async function(callback, options) { options = readableOperationOptions(options); var index = 0; for await (var value of this) { checkReadableOperation(options); await callback(value, { signal: options.signal, index: index++ }); } }; Readable.prototype.some = async function(predicate, options) { options = readableOperationOptions(options); var index = 0; for await (var value of this) { checkReadableOperation(options); if (await predicate(value, { signal: options.signal, index: index++ })) return true; } return false; }; Readable.prototype.every = async function(predicate, options) { options = readableOperationOptions(options); var index = 0; for await (var value of this) { checkReadableOperation(options); if (!await predicate(value, { signal: options.signal, index: index++ })) return false; } return true; }; Readable.prototype.find = async function(predicate, options) { options = readableOperationOptions(options); var index = 0; for await (var value of this) { checkReadableOperation(options); if (await predicate(value, { signal: options.signal, index: index++ })) return value; } return undefined; }; Readable.prototype.reduce = async function(reducer, initial, options) { var hasInitial = arguments.length >= 2; options = readableOperationOptions(options); var accumulator = initial, index = 0; for await (var value of this) { checkReadableOperation(options); if (!hasInitial) { accumulator = value; hasInitial = true; } else accumulator = await reducer(accumulator, value, { signal: options.signal, index: index }); index++; } if (!hasInitial) throw new TypeError('Reduce of an empty stream requires an initial value'); return accumulator; };
function readableConcurrency(options) { var concurrency = options.concurrency === undefined ? 1 : Number(options.concurrency); if (!Number.isInteger(concurrency) || concurrency < 1) throw new RangeError('concurrency must be a positive integer'); return concurrency; } function concurrentReadableResults(source, operation, options) { var concurrency = readableConcurrency(options); return (async function*() { var iterator = source[Symbol.asyncIterator](), pending = [], index = 0, inputDone = false, pulling = false, active = 0, failure, failed = false, wake = null; function notify() { var resume = wake; wake = null; if (resume) resume(); } function pull() { if (pulling || inputDone || failed || active >= concurrency || pending.length >= concurrency) return; try { checkReadableOperation(options); } catch (error) { failed = true; failure = error; notify(); return; } pulling = true; iterator.next().then(function(item) { pulling = false; if (item.done) inputDone = true; else { var itemIndex = index++, value = item.value; active++; var settle = function() { active--; pull(); notify(); }; var started = Promise.resolve().then(function() { return operation(value, { signal: options.signal, index: itemIndex }); }); started.then(settle, settle); pending.push(started); pull(); } notify(); }, function(error) { pulling = false; failed = true; failure = error; notify(); }); } try { while (true) { pull(); if (pending.length) { checkReadableOperation(options); var next = pending.shift(); yield await next; continue; } if (failed) throw failure; if (inputDone) break; await new Promise(function(resolve) { wake = resolve; }); } } finally { if (!inputDone && !pulling && iterator.return) await iterator.return(); } })(); } Readable.prototype.map = function(mapper, options) { options = readableOperationOptions(options); return Readable.from(concurrentReadableResults(this, mapper, options)); }; Readable.prototype.filter = function(predicate, options) { options = readableOperationOptions(options); return Readable.from((async function*(results) { for await (var result of results) if (result.keep) yield result.value; })(concurrentReadableResults(this, async function(value, context) { return { value: value, keep: await predicate(value, context) }; }, options))); }; Readable.prototype.flatMap = function(mapper, options) { options = readableOperationOptions(options); return Readable.from((async function*(results) { for await (var mapped of results) { if (mapped && (mapped[Symbol.asyncIterator] || mapped[Symbol.iterator])) { for await (var child of mapped) yield child; } else yield mapped; } })(concurrentReadableResults(this, mapper, options))); }; Readable.prototype.forEach = async function(callback, options) { await this.map(async function(value, context) { await callback(value, context); }, options).toArray({ signal: options && options.signal }); };
Readable.prototype.asIndexedPairs = function(options) { return this.map(function(value, context) { return [context.index, value]; }, options); };
var pipelineImplementation = pipeline; pipeline = function() { var args = Array.prototype.slice.call(arguments), callback = args[args.length - 1]; if (typeof callback !== 'function') { var callbackError = new TypeError('The callback argument must be of type function'); callbackError.code = 'ERR_INVALID_ARG_TYPE'; throw callbackError; } var stages = args.slice(0, -1), count = stages.length === 1 && Array.isArray(stages[0]) ? stages[0].length : stages.length; if (count < 2) { var missing = new TypeError('The streams argument must be specified'); missing.code = 'ERR_MISSING_ARGS'; throw missing; } return pipelineImplementation.apply(this, args); }; var finishedImplementation = finished; finished = function(stream, options, callback) { if (typeof options === 'function') callback = options; if (typeof callback !== 'function') { var callbackError = new TypeError('The callback argument must be of type function'); callbackError.code = 'ERR_INVALID_ARG_TYPE'; throw callbackError; } if (!stream || typeof stream.once !== 'function' || typeof stream.removeListener !== 'function') { var streamError = new TypeError('The stream argument must be an instance of Stream'); streamError.code = 'ERR_INVALID_ARG_TYPE'; throw streamError; } return finishedImplementation.apply(this, arguments); };
pipelineImplementation = function() { var streams = Array.prototype.slice.call(arguments), callback = streams.pop(), options = streams.length && streams[streams.length - 1] && typeof streams[streams.length - 1].on !== 'function' && (streams[streams.length - 1].signal !== undefined || streams[streams.length - 1].end !== undefined) ? streams.pop() : {}; if (streams.length === 1 && Array.isArray(streams[0])) streams = streams[0]; var functional = streams.some(function(item) { return typeof item === 'function'; }) || !streams[0] || typeof streams[0].on !== 'function'; if (functional) { if (!options.signal) { var controller = new AbortController(); options = Object.assign({}, options, { signal: controller.signal, controller: controller }); } runFunctionalPipeline(streams, options).then(function(value) { callback(null, value); }, callback); return streams[streams.length - 1]; } var settled = false, listeners = [], abort, lastIndex = streams.length - 1, leaveOpen = options.end === false; function listen(stream, event, listener) { stream.once(event, listener); listeners.push({ stream: stream, event: event, listener: listener }); } function cleanup() { listeners.forEach(function(entry) { entry.stream.removeListener(entry.event, entry.listener); }); if (options.signal && abort) options.signal.removeEventListener('abort', abort); } function finish(error) { if (settled) return; settled = true; cleanup(); if (error) { protectPipelineErrors(streams); streams.forEach(function(item) { if (item.destroy) item.destroy(error); }); } callback(error); } streams.forEach(function(item, index) { listen(item, 'error', function(error) { finish(error); }); listen(item, 'close', function() { var readableIncomplete = index < lastIndex && item.readableEnded !== true, writableIncomplete = index > 0 && !(leaveOpen && index === lastIndex) && item.writableFinished !== true; if (readableIncomplete || writableIncomplete) { var error = new Error('Premature close'); error.code = 'ERR_STREAM_PREMATURE_CLOSE'; finish(error); } }); }); for (var index = 0; index < lastIndex; index++) streams[index].pipe(streams[index + 1], leaveOpen && index + 1 === lastIndex ? { end: false } : undefined); if (leaveOpen) listen(streams[lastIndex - 1], 'end', function() { finish(); }); else listen(streams[lastIndex], 'finish', function() { finish(); }); abort = function() { finish(pipelineAbortError(options.signal)); }; if (options.signal) { if (options.signal.aborted) abort(); else options.signal.addEventListener('abort', abort, { once: true }); } return streams[lastIndex]; };
var composeImplementation = compose; compose = function() { var stages = Array.prototype.slice.call(arguments); if (!stages.length) { var missing = new TypeError('The streams argument must be specified'); missing.code = 'ERR_MISSING_ARGS'; throw missing; } if (stages.length > 1) stages.forEach(function(stage, index) { var needsReadable = index < stages.length - 1, needsWritable = index > 0; if (!stage || (typeof stage !== 'function' && ((needsReadable && (stage.readable !== true || typeof stage.pipe !== 'function')) || (needsWritable && (stage.writable !== true || typeof stage.write !== 'function'))))) { var invalid = new TypeError('Invalid stream stage at index ' + index); invalid.code = 'ERR_INVALID_ARG_VALUE'; throw invalid; } }); stages = stages.map(function(stage) { return typeof stage === 'function' ? Duplex.from(stage) : stage; }); if (stages.length > 1 && stages[stages.length - 1].readable === false) return writableComposition(stages); return composeImplementation.apply(this, stages); };
function initWritableState(target, options) { options = options || {}; target._autoDestroy = options.autoDestroy !== false; target._emitClose = options.emitClose !== false; target._decodeStrings = options.decodeStrings !== false; target.writable = true; target.writableEnded = false; target.writableFinished = false; target.writableAborted = false; target._writableObjectMode = Boolean(options.objectMode || options.writableObjectMode); target.writableObjectMode = target._writableObjectMode; target.writableHighWaterMark = resolveHighWaterMark(options, target._writableObjectMode, 'writableHighWaterMark'); target.writableLength = 0; target.writableNeedDrain = false; target._writeQueue = []; target._writing = false; target._ending = false; target._finishing = false; target._needsDrain = false; target._constructPumpQueued = false; target._defaultEncoding = options.defaultEncoding || 'utf8'; target._corked = 0; target.writableCorked = 0; target._endCallbacks = []; if (typeof options.write === 'function') target._write = options.write; if (typeof options.writev === 'function') target._writev = options.writev; if (typeof options.final === 'function') target._final = options.final; if (typeof options.destroy === 'function') target._destroy = options.destroy; configureConstruct(target, options); } function Writable(options) { options = options || {}; if (options.signal !== undefined) validateStreamSignal(options.signal); Stream.call(this); initWritableState(this, options); if (options.signal && !options._deferStreamSignal) addAbortSignal(options.signal, this); }
inherit(Writable, Stream); Writable.prototype[Symbol.asyncDispose] = Readable.prototype[Symbol.asyncDispose];
Object.defineProperty(Writable.prototype, '_writableState', { get: function() { return { finished: Boolean(this.writableFinished), ended: Boolean(this.writableEnded), length: this.writableLength, errorEmitted: this.errored !== null, corked: this._corked }; } });
Writable.prototype._write = function(chunk, encoding, callback) { if (this._writev) { this._writev([{ chunk: chunk, encoding: encoding }], callback); return; } var error = new Error('The _write() method is not implemented'); error.code = 'ERR_METHOD_NOT_IMPLEMENTED'; callback(error); }; Writable.prototype._destroy = function(error, callback) { callback(error); };Writable.prototype._pumpWrites = function() { var self = this; if (this._constructState !== 'ready') { if (this._constructState === 'pending' && !this._constructPumpQueued) { this._constructPumpQueued = true; afterConstruct(this, function() { self._constructPumpQueued = false; self._pumpWrites(); }); } return; } if (this._writing || this._corked) return; if (!this._writeQueue.length) { if (this._ending) this._finishWrites(); return; } this._writing = true; var entries = this._writev && this._writeQueue.length > 1 ? this._writeQueue.splice(0) : [this._writeQueue.shift()], total = entries.reduce(function(sum, entry) { return sum + entry.length; }, 0), complete = function(error) { self._writing = false; self.writableLength -= total; var finalError = error || self._destroyError; entries.forEach(function(entry) { if (entry.callback) entry.callback(finalError); }); if (self.destroyed) return; if (error) { self.destroy(error); return; } if (self._needsDrain && !self._ending && self.writableLength === 0) { self._needsDrain = false; self.writableNeedDrain = false; self.emit('drain'); } self._pumpWrites(); }; if (this._writev && entries.length > 1) this._writev(entries.map(function(entry) { return { chunk: entry.chunk, encoding: entry.encoding }; }), complete); else this._write(entries[0].chunk, entries[0].encoding, complete); }; Writable.prototype._finishWrites = function() { if (this._finishing || this.writableFinished) return; this._finishing = true; var self = this, finish = function(error) { if (error) { self.destroy(error); return; } self.writable = false; self.writableFinished = true; self.writableNeedDrain = false; self.emit('finish'); self._endCallbacks.splice(0).forEach(function(callback) { callback(); }); }; if (this._final) this._final(finish); else finish(); }; Writable.prototype.write = function(chunk, encoding, callback) { if (typeof encoding === 'function') { callback = encoding; encoding = undefined; } if (this.writableEnded) { var error = new Error('write after end'); error.code = 'ERR_STREAM_WRITE_AFTER_END'; throw error; } encoding = encoding || this._defaultEncoding; var value = this._writableObjectMode ? chunk : typeof chunk === 'string' ? globalThis.Buffer.from(chunk, encoding) : globalThis.Buffer.from(chunk), length = this._writableObjectMode ? 1 : value.length; this._writeQueue.push({ chunk: value, encoding: this._writableObjectMode ? this._defaultEncoding : typeof chunk === 'string' ? encoding : 'buffer', callback: callback, length: length }); this.writableLength += length; var available = this.writableLength < this.writableHighWaterMark; if (!available) { this._needsDrain = true; this.writableNeedDrain = true; } this._pumpWrites(); return available; }; Writable.prototype.setDefaultEncoding = function(encoding) { encoding = String(encoding).toLowerCase(); if (!/^(utf8|utf-8|utf16le|utf-16le|ucs2|ucs-2|latin1|binary|ascii|base64|base64url|hex)$/.test(encoding)) throw new TypeError('Unknown encoding: ' + encoding); this._defaultEncoding = encoding; return this; };
Writable.prototype.end = function(chunk, encoding, callback) { if (typeof chunk === 'function') { callback = chunk; chunk = undefined; } else if (typeof encoding === 'function') { callback = encoding; encoding = undefined; } if (chunk !== undefined) this.write(chunk, encoding); if (callback) this._endCallbacks.push(callback); this.writableEnded = true; this._ending = true; this._corked = 0; this.writableCorked = 0; this._pumpWrites(); return this; }; Writable.prototype.destroy = function(error) { if (this.destroyed) return Stream.prototype.destroy.call(this, error); var callbackError = error || new Error('Cannot call write after a stream was destroyed'); if (!callbackError.code) callbackError.code = 'ERR_STREAM_DESTROYED'; this._destroyError = callbackError; this._ending = false; this.writableNeedDrain = false; var pending = this._writeQueue.splice(0), self = this; this.writableLength -= pending.reduce(function(total, entry) { return total + entry.length; }, 0); queueMicrotask(function() { pending.forEach(function(entry) { if (entry.callback) entry.callback(callbackError); }); self._endCallbacks.splice(0).forEach(function(callback) { callback(callbackError); }); }); return Stream.prototype.destroy.call(this, error); }; Writable.prototype.cork = function() { this._corked++; this.writableCorked = this._corked; }; Writable.prototype.uncork = function() { if (this._corked > 0) this._corked--; this.writableCorked = this._corked; if (!this._corked) this._pumpWrites(); };Writable.prototype.write = function(chunk, encoding, callback) { if (typeof encoding === 'function') { callback = encoding; encoding = undefined; } if (chunk === null) { var nullError = new TypeError('May not write null values to stream'); nullError.code = 'ERR_STREAM_NULL_VALUES'; throw nullError; } if (this.writableEnded) { var endedStream = this, endedError = new Error('write after end'); endedError.code = 'ERR_STREAM_WRITE_AFTER_END'; queueMicrotask(function() { if (callback) callback(endedError); endedStream.errored = endedError; endedStream.emit('error', endedError); }); return false; } if (this.destroyed) { var destroyedError = new Error('Cannot call write after a stream was destroyed'); destroyedError.code = 'ERR_STREAM_DESTROYED'; if (callback) queueMicrotask(function() { callback(destroyedError); }); return false; } encoding = encoding || this._defaultEncoding; var value, length; if (this._writableObjectMode) { value = chunk; length = 1; } else if (typeof chunk === 'string') { value = this._decodeStrings ? globalThis.Buffer.from(chunk, encoding) : chunk; length = this._decodeStrings ? globalThis.Buffer.byteLength(chunk, encoding) : chunk.length; if (this._decodeStrings) encoding = 'buffer'; } else if (globalThis.ArrayBuffer.isView(chunk)) { value = globalThis.Buffer.from(chunk.buffer, chunk.byteOffset, chunk.byteLength); length = value.length; encoding = 'buffer'; } else { var typeError = new TypeError('The chunk argument must be of type string or an instance of Buffer, TypedArray, or DataView'); typeError.code = 'ERR_INVALID_ARG_TYPE'; throw typeError; } this._writeQueue.push({ chunk: value, encoding: this._writableObjectMode ? this._defaultEncoding : encoding, callback: callback, length: length }); this.writableLength += length; this._pumpWrites(); var available = this.writableLength < this.writableHighWaterMark || this.writableLength === 0; if (!available) { this._needsDrain = true; this.writableNeedDrain = true; } return available; }; Writable.prototype._finishWrites = function() { if (this._finishing || this.writableFinished) return; this._finishing = true; var self = this, finish = function(error) { if (error) { self.destroy(error); return; } queueMicrotask(function() { if (self.destroyed) return; self.writable = false; self.writableFinished = true; self.writableNeedDrain = false; self._endCallbacks.splice(0).forEach(function(callback) { callback(); }); self.emit('finish'); }); }; if (this._final) this._final(finish); else finish(); }; Writable.prototype.end = function(chunk, encoding, callback) { if (typeof chunk === 'function') { callback = chunk; chunk = undefined; encoding = undefined; } else if (typeof encoding === 'function') { callback = encoding; encoding = undefined; } if (this.writableEnded) { if (chunk !== undefined) this.write(chunk, encoding, callback); else if (callback) { if (this.writableFinished) queueMicrotask(callback); else this._endCallbacks.push(callback); } return this; } var self = this; this.once('finish', function() { maybeAutoDestroy(self); }); if (chunk !== undefined) this.write(chunk, encoding); if (callback) this._endCallbacks.push(callback); this.writableEnded = true; this._ending = true; this._corked = 0; this.writableCorked = 0; this._pumpWrites(); return this; }; Writable.prototype.destroySoon = Writable.prototype.end; Writable.prototype[Symbol.asyncDispose] = asyncDisposeWritable;var destroyWritable = Writable.prototype.destroy; Writable.prototype.destroy = function(error) { var originalCode = error && error.code, result = destroyWritable.call(this, error); if (error && !originalCode) delete error.code; this._destroyError = null; return result; };
var writeWritable = Writable.prototype.write; Writable.prototype.write = function() { var result = writeWritable.apply(this, arguments); return this.destroyed ? false : result; };
function pumpWritesOnce() { var self = this; if (this._constructState !== 'ready') { if (this._constructState === 'pending' && !this._constructPumpQueued) { this._constructPumpQueued = true; afterConstruct(this, function() { self._constructPumpQueued = false; self._pumpWrites(); }); } return; } if (this._writing || this._corked) return; if (!this._writeQueue.length) { if (this._ending) this._finishWrites(); return; } this._writing = true; var entries = this._writev && this._writeQueue.length > 1 ? this._writeQueue.splice(0) : [this._writeQueue.shift()], total = entries.reduce(function(sum, entry) { return sum + entry.length; }, 0), synchronous = true, completed = false; function complete(error) { if (completed) { var repeated = new Error('Callback called multiple times'); repeated.code = 'ERR_MULTIPLE_CALLBACK'; self.destroy(repeated); return; } completed = true; self._writing = false; self.writableLength -= total; var callbacks = function() { entries.forEach(function(entry) { if (entry.callback) entry.callback(error); }); }, deliver = function() { var run = function() { if (!error && !self.destroyed && self._needsDrain && !self._ending && self.writableLength === 0) { self._needsDrain = false; self.writableNeedDrain = false; self.emit('drain'); } callbacks(); }; if (synchronous) queueMicrotask(run); else run(); }; if (self.destroyed) { deliver(); return; } if (error) { deliver(); failStream(self, error); return; } self._pumpWrites(); deliver(); } if (this._writev && entries.length > 1) this._writev(entries.map(function(entry) { return { chunk: entry.chunk, encoding: entry.encoding }; }), complete); else this._write(entries[0].chunk, entries[0].encoding, complete); synchronous = false; }
Writable.prototype._pumpWrites = function() { if (this._pumpActive) { this._pumpAgain = true; return; } this._pumpActive = true; try { do { this._pumpAgain = false; pumpWritesOnce.call(this); } while (this._pumpAgain); } finally { this._pumpActive = false; } };
function failStream(stream, error) { if (stream._autoDestroy) stream.destroy(error); else { stream.errored = error; queueMicrotask(function() { stream.emit('error', error); }); } }
Writable.prototype._finishWrites = function() { if (this._finishing || this.writableFinished) return; this._finishing = true; var self = this, completed = false; function fail(error) { var callbacks = self._endCallbacks.splice(0), notify = function() { callbacks.forEach(function(callback) { callback(error); }); }; failStream(self, error); if (self._autoDestroy && self._emitClose) self.once('close', notify); else queueMicrotask(notify); } function finish(error) { if (completed) { var repeated = new Error('Callback called multiple times'); repeated.code = 'ERR_MULTIPLE_CALLBACK'; fail(repeated); return; } completed = true; if (error) { fail(error); return; } queueMicrotask(function() { if (self.destroyed) return; self.writable = false; self.writableFinished = true; self.writableNeedDrain = false; self._endCallbacks.splice(0).forEach(function(callback) { callback(); }); self.emit('finish'); }); } if (this._final) { try { this._final(finish); } catch (error) { finish(error); } } else finish(); };
Writable.prototype.pipe = function(destination) { var source = this; queueMicrotask(function() { if (source.destroyed) return; var error = new Error('Cannot pipe, not readable'); error.code = 'ERR_STREAM_CANNOT_PIPE'; source.destroy(error); }); return destination; };Readable.prototype.pause = function() { if (this._paused) return this; this._paused = true; this.readableFlowing = false; this.emit('pause'); return this; }; Readable.prototype.resume = function() { if (!this._paused && this.readableFlowing === true) return this; this._paused = false; this.readableFlowing = true; if (!this._resumeScheduled) { var resumeStream = this; this._resumeScheduled = true; queueMicrotask(function() { resumeStream._resumeScheduled = false; if (!resumeStream.destroyed) resumeStream.emit('resume'); }); } var self = this; if (!this._chunks.length && !this._readableEof) afterConstruct(this, function() { if (!self._readableEof) self._read(self.readableHighWaterMark); }); if (this._deferDrain) { if (!this._drainScheduled) { this._drainScheduled = true; queueMicrotask(function() { self._drainScheduled = false; if (!self.destroyed && self.readableFlowing !== false) self._drainReadable(); }); } } else this._drainReadable(); return this; }; Object.defineProperty(Writable.prototype, 'writableBuffer', { get: function() { return this._writeQueue; } });function Duplex(options) { options = options || {}; if (options.signal !== undefined) validateStreamSignal(options.signal); var deferSignal = Boolean(this._deferStreamSignal); this._deferStreamSignal = true; Readable.call(this, options); this._deferStreamSignal = deferSignal; initWritableState(this, options); if (options.readable === false) { this.readable = false; this._readableEof = true; this.readableEnded = true; this._endEmitted = true; } if (options.writable === false) { this.writable = false; this.writableEnded = true; this.writableFinished = true; } this.allowHalfOpen = options.allowHalfOpen !== false; if (!this.allowHalfOpen) { var self = this; this.once('end', function() { if (!self.writableEnded) self.end(); }); } if (options.signal && !this._deferStreamSignal) addAbortSignal(options.signal, this); maybeAutoDestroy(this); }inherit(Duplex, Readable); Duplex.prototype.write = Writable.prototype.write; Duplex.prototype.end = Writable.prototype.end; Duplex.prototype._write = Writable.prototype._write; Duplex.prototype._pumpWrites = Writable.prototype._pumpWrites; Duplex.prototype._finishWrites = Writable.prototype._finishWrites; Duplex.prototype.cork = Writable.prototype.cork; Duplex.prototype.uncork = Writable.prototype.uncork; Duplex.prototype.destroy = Writable.prototype.destroy;function Transform(options) { options = options || {}; if (options.signal !== undefined) validateStreamSignal(options.signal); this._deferStreamSignal = true; Duplex.call(this, options); this._deferStreamSignal = false; if (typeof options.transform === 'function') this._transform = options.transform; if (typeof options.flush === 'function') this._flush = options.flush; var self = this; this._write = function(chunk, encoding, callback) { self._transform(chunk, encoding, function(error, output) { if (!error && output !== undefined && output !== null) self.push(output); if (error || self.destroyed || self.readableLength < self.readableHighWaterMark) callback(error); else self._transformWait = callback; }); }; this._final = function(callback) { function finish(error, output) { if (!error && output !== undefined && output !== null) self.push(output); if (!error) self.push(null); callback(error); } if (self._flush) self._flush(finish); else finish(); }; if (options.signal) addAbortSignal(options.signal, this); }inherit(Transform, Duplex); Transform.prototype.write = Writable.prototype.write; Transform.prototype.end = Writable.prototype.end; Transform.prototype._pumpWrites = Writable.prototype._pumpWrites; Transform.prototype._finishWrites = Writable.prototype._finishWrites; Transform.prototype.cork = Writable.prototype.cork; Transform.prototype.uncork = Writable.prototype.uncork; Transform.prototype.destroy = Writable.prototype.destroy;Transform.prototype._transform = function(chunk, encoding, callback) { var error = new Error('The _transform() method is not implemented'); error.code = 'ERR_METHOD_NOT_IMPLEMENTED'; callback(error); };function PassThrough(options) { Transform.call(this, options); } inherit(PassThrough, Transform); Object.defineProperty(Writable, Symbol.hasInstance, { configurable: true, value: function(object) { var ordinary = Function.prototype[Symbol.hasInstance]; return ordinary.call(this, object) || (this === Writable && object !== null && typeof object === 'object' && ordinary.call(Duplex, object)); } }); PassThrough.prototype._transform = function(chunk, encoding, callback) { callback(null, chunk); };
function finished(stream, options, callback) { if (typeof options === 'function') { callback = options; options = {}; } options = options || {}; var settled = false, watchReadable = options.readable !== false && stream.readable !== undefined, watchWritable = options.writable !== false && stream.writable !== undefined, readableDone = !watchReadable || stream.readableEnded, writableDone = !watchWritable || stream.writableFinished, abort; function cleanup() { stream.removeListener('end', onEnd); stream.removeListener('finish', onFinish); stream.removeListener('error', onError); stream.removeListener('close', onClose); if (stream._destroyWaiters) { var index = stream._destroyWaiters.indexOf(onDestroyed); if (index >= 0) stream._destroyWaiters.splice(index, 1); } if (options.signal && abort) options.signal.removeEventListener('abort', abort); } function complete(error) { if (settled) return; settled = true; queueMicrotask(function() { callback(error); }); if (options.cleanup) queueMicrotask(cleanup); } function maybeComplete() { if (readableDone && writableDone) complete(); } function onEnd() { readableDone = true; maybeComplete(); } function onFinish() { writableDone = true; maybeComplete(); } function onError(error) { complete(error); } function onClose() { if (options.error === false && stream.errored) { readableDone = true; writableDone = true; complete(); } else if (!readableDone || !writableDone) { var error = new Error('Premature close'); error.code = 'ERR_STREAM_PREMATURE_CLOSE'; complete(error); } else maybeComplete(); } function onDestroyed(error) { if (options.error === false && error) { readableDone = true; writableDone = true; complete(); } else if (error) complete(error); else onClose(); } stream.on('end', onEnd); stream.on('finish', onFinish); if (options.error !== false) stream.on('error', onError); stream.on('close', onClose); if (stream._destroyWaiters) { if (stream._destroyFinished) onDestroyed(stream._destroyFinalError); else stream._destroyWaiters.push(onDestroyed); } abort = function() { complete(pipelineAbortError(options.signal)); }; if (options.signal) { if (options.signal.aborted) abort(); else options.signal.addEventListener('abort', abort, { once: true }); } if (stream.closed) { if (options.error === false && stream.errored) { readableDone = true; writableDone = true; maybeComplete(); } else if (stream.errored) complete(stream.errored); else if (!readableDone || !writableDone) { var premature = new Error('Premature close'); premature.code = 'ERR_STREAM_PREMATURE_CLOSE'; complete(premature); } } queueMicrotask(maybeComplete); return cleanup; }
function streamAbortError() { var error = new Error('The operation was aborted'); error.name = 'AbortError'; error.code = 'ABORT_ERR'; return error; } function pipelineAbortError(signal) { var error = new Error('The operation was aborted'); error.name = 'AbortError'; error.code = 'ABORT_ERR'; error.cause = signal.reason; return error; } function protectPipelineErrors(resources) { resources.forEach(function(resource) { if (resource && resource.on) resource.on('error', function() {}); }); } async function runFunctionalPipeline(stages, options) { var resources = [], abort, abortPromise; if (options.signal) abortPromise = new Promise(function(resolve, reject) { abort = function() { var error = pipelineAbortError(options.signal); protectPipelineErrors(resources); resources.forEach(function(resource) { if (resource.destroy && !resource.destroyed) resource.destroy(error); }); reject(error); }; if (options.signal.aborted) abort(); else options.signal.addEventListener('abort', abort, { once: true }); }); async function execute() { var first = stages[0], current = typeof first === 'function' ? await first({ signal: options.signal }) : first; if (!current || typeof current.on !== 'function') current = Readable.from(current); resources.push(current); for (var index = 1; index < stages.length; index++) { var stage = stages[index], last = index === stages.length - 1; if (typeof stage === 'function') { var produced = stage(current, { signal: options.signal }); if (last) return await produced; current = Readable.from(await produced); resources.push(current); } else { current.pipe(stage, last ? { end: options.end !== false } : undefined); current = stage; resources.push(current); } } if (current.writableFinished || current.readableEnded) return current; await new Promise(function(resolve, reject) { current.once('error', reject); if (current.writable !== undefined) current.once('finish', resolve); else current.once('end', resolve); }); return current; } try { return await (abortPromise ? Promise.race([execute(), abortPromise]) : execute()); } catch (error) { protectPipelineErrors(resources); resources.forEach(function(resource) { if (resource.destroy && !resource.destroyed) resource.destroy(error); else if (resource.destroyed && !resource.errored) resource.errored = error; }); if (options.controller && !options.controller.signal.aborted) options.controller.abort(error); throw error; } finally { if (options.signal && abort) options.signal.removeEventListener('abort', abort); } } function pipeline() { var streams = Array.prototype.slice.call(arguments), callback = typeof streams[streams.length - 1] === 'function' ? streams.pop() : function(error) { if (error) throw error; }, options = streams.length && streams[streams.length - 1] && typeof streams[streams.length - 1].on !== 'function' && (streams[streams.length - 1].signal !== undefined || streams[streams.length - 1].end !== undefined) ? streams.pop() : {}; if (streams.length === 1 && Array.isArray(streams[0])) streams = streams[0]; var functional = streams.some(function(item) { return typeof item === 'function'; }) || !streams[0] || typeof streams[0].on !== 'function'; if (functional) { if (!options.signal) { var controller = new AbortController(); options = Object.assign({}, options, { signal: controller.signal, controller: controller }); } runFunctionalPipeline(streams, options).then(function(value) { callback(null, value); }, callback); return streams[streams.length - 1]; } var settled = false, listeners = [], abort; function cleanup() { listeners.forEach(function(entry) { entry.stream.removeListener(entry.event, entry.listener); }); if (options.signal && abort) options.signal.removeEventListener('abort', abort); } function finish(error) { if (settled) return; settled = true; cleanup(); if (error) { protectPipelineErrors(streams); streams.forEach(function(item) { if (item.destroy) item.destroy(error); }); } callback(error); } streams.forEach(function(item) { var listener = function(error) { finish(error); }; item.once('error', listener); listeners.push({ stream: item, event: 'error', listener: listener }); }); for (var index = 0; index + 1 < streams.length; index++) streams[index].pipe(streams[index + 1]); var last = streams[streams.length - 1], completed = function() { finish(); }; last.once('finish', completed); listeners.push({ stream: last, event: 'finish', listener: completed }); abort = function() { finish(pipelineAbortError(options.signal)); }; if (options.signal) { if (options.signal.aborted) abort(); else options.signal.addEventListener('abort', abort, { once: true }); } return last; }function pipeline() { var streams = Array.prototype.slice.call(arguments), callback = typeof streams[streams.length - 1] === 'function' ? streams.pop() : function(error) { if (error) throw error; }, options = streams.length && streams[streams.length - 1] && typeof streams[streams.length - 1].on !== 'function' && (streams[streams.length - 1].signal !== undefined || streams[streams.length - 1].end !== undefined) ? streams.pop() : {}; if (streams.length === 1 && Array.isArray(streams[0])) streams = streams[0]; var functional = streams.some(function(item) { return typeof item === 'function'; }) || !streams[0] || typeof streams[0].on !== 'function'; if (functional) { if (!options.signal) { var controller = new AbortController(); options = Object.assign({}, options, { signal: controller.signal, controller: controller }); } runFunctionalPipeline(streams, options).then(function(value) { callback(null, value); }, callback); return streams[streams.length - 1]; } var settled = false, listeners = [], abort, lastIndex = streams.length - 1; function listen(stream, event, listener) { stream.once(event, listener); listeners.push({ stream: stream, event: event, listener: listener }); } function cleanup() { listeners.forEach(function(entry) { entry.stream.removeListener(entry.event, entry.listener); }); if (options.signal && abort) options.signal.removeEventListener('abort', abort); } function finish(error) { if (settled) return; settled = true; cleanup(); if (error) { protectPipelineErrors(streams); streams.forEach(function(item) { if (item.destroy) item.destroy(error); }); } callback(error); } streams.forEach(function(item, index) { listen(item, 'error', function(error) { finish(error); }); listen(item, 'close', function() { var readableIncomplete = index < lastIndex && item.readableEnded !== true, writableIncomplete = index > 0 && item.writableFinished !== true; if (readableIncomplete || writableIncomplete) { var error = new Error('Premature close'); error.code = 'ERR_STREAM_PREMATURE_CLOSE'; finish(error); } }); }); for (var index = 0; index < lastIndex; index++) streams[index].pipe(streams[index + 1]); var last = streams[lastIndex]; listen(last, 'finish', function() { finish(); }); abort = function() { finish(pipelineAbortError(options.signal)); }; if (options.signal) { if (options.signal.aborted) abort(); else options.signal.addEventListener('abort', abort, { once: true }); } return last; }Readable.toWeb = function(source) { var controller, onData, onEnd, onError; var canceled = false; function cleanup() { source.removeListener('data', onData); source.removeListener('end', onEnd); source.removeListener('error', onError); source.removeListener('close', onClose); } function onClose() { cleanup(); if (canceled || source.readableEnded) return; var closedError = new Error('Premature close'); closedError.code = 'ERR_STREAM_PREMATURE_CLOSE'; try { controller.error(closedError); } catch (_) {} } return new globalThis.ReadableStream({ start: function(value) { controller = value; onData = function(chunk) { controller.enqueue(chunk); if (controller.desiredSize <= 0) source.pause(); }; onEnd = function() { cleanup(); controller.close(); }; onError = function(error) { controller.error(error); }; source.on('data', onData); source.once('end', onEnd); source.once('error', onError); source.once('close', onClose); source.pause(); }, pull: function() { if (!source.destroyed && (source.readableLength > 0 || !source.readableEnded)) source.resume(); }, cancel: function(reason) { canceled = true; return new Promise(function(resolve) { if (source.closed || source._destroyFinished) { cleanup(); resolve(); return; } source._destroyWaiters.push(function() { cleanup(); resolve(); }); source.destroy(reason); }); } }); }; Readable.fromWeb = function(source, options) { options = options || {}; if (options.signal !== undefined) validateStreamSignal(options.signal); var reader = source.getReader(), outputOptions = options.signal ? Object.assign({}, options, { signal: undefined }) : options, output = new Readable(outputOptions), reading = false, done = false; function pump() { if (reading || done) return; reading = true; reader.read().then(function(result) { reading = false; if (result.done) { done = true; output.push(null); } else if (output.push(result.value)) pump(); }, function(error) { reading = false; done = true; output.destroy(error); }); } output._read = pump; output._destroy = function(error, callback) { if (done) { callback(error); return; } done = true; Promise.resolve(reader.cancel(error)).then(function() { callback(error); }, callback); }; if (options.signal) addAbortSignal(options.signal, output); Promise.resolve(reader.closed).then(undefined, function(error) { if (done) return; done = true; output.destroy(error); }); queueMicrotask(pump); return output; }; Writable.toWeb = function(destination) { return new globalThis.WritableStream({ start: function(controller) { destination.once('error', function(error) { try { controller.error(error); } catch (_) {} }); destination.once('close', function() { if (destination.writableFinished) return; var closedError = new Error('Premature close'); closedError.code = 'ERR_STREAM_PREMATURE_CLOSE'; try { controller.error(closedError); } catch (_) {} }); }, write: function(chunk) { return new Promise(function(resolve, reject) { try { destination.write(chunk, function(error) { if (error) reject(error); else resolve(); }); } catch (error) { reject(error); } }); }, close: function() { return new Promise(function(resolve, reject) { try { destination.end(function(error) { if (error) reject(error); else resolve(); }); } catch (error) { reject(error); } }); }, abort: function(reason) { destination.destroy(reason); } }); }; Writable.fromWeb = function(source, options) { options = options || {}; if (options.signal !== undefined) validateStreamSignal(options.signal); var writer = source.getWriter(), done = false, outputOptions = Object.assign({}, options || {}, { signal: undefined }), output = new Writable(Object.assign(outputOptions, { write: function(chunk, encoding, callback) { writer.write(chunk).then(function() { callback(); }, callback); }, final: function(callback) { writer.close().then(function() { done = true; callback(); }, callback); } })); output._destroy = function(error, callback) { if (done) { callback(error); return; } done = true; Promise.resolve(writer.abort(error)).then(function() { callback(error); }, callback); }; if (writer.closed && typeof writer.closed.then === 'function') writer.closed.then(null, function(error) { if (!done) { done = true; output.destroy(error); } }); if (options && options.signal) addAbortSignal(options.signal, output); return output; }; Duplex.toWeb = function(source) { return { readable: Readable.toWeb(source), writable: Writable.toWeb(source) }; }; Duplex.fromWeb = function(pair, options) { return duplexPair(Writable.fromWeb(pair.writable, options), Readable.fromWeb(pair.readable, options)); }; function validateStreamSignal(signal) { if (!signal || typeof signal.aborted !== 'boolean' || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function') { var signalError = new TypeError('The signal argument must be an instance of AbortSignal'); signalError.code = 'ERR_INVALID_ARG_TYPE'; throw signalError; } } function addAbortSignal(signal, stream) { validateStreamSignal(signal); var nodeStream = stream && typeof stream.destroy === 'function', webReadable = stream && typeof stream.cancel === 'function', webWritable = stream && typeof stream.abort === 'function'; if (!nodeStream && !webReadable && !webWritable) { var streamError = new TypeError('The stream argument must be a Stream'); streamError.code = 'ERR_INVALID_ARG_TYPE'; throw streamError; } var settled = false, onAbort = function() { abort(false); }; function cleanup() { signal.removeEventListener('abort', onAbort); if (nodeStream) { stream.removeListener('close', cleanup); if (stream._destroyWaiters) { var index = stream._destroyWaiters.indexOf(cleanup); if (index >= 0) stream._destroyWaiters.splice(index, 1); } } } function abort(deferNode) { if (settled) return; settled = true; cleanup(); var error = pipelineAbortError(signal); if (nodeStream) { if (deferNode) queueMicrotask(function() { stream.destroy(error); }); else stream.destroy(error); } else if (webReadable && stream._controller && typeof stream._controller.error === 'function') stream._controller.error(error); else if (webWritable && stream._controller && typeof stream._controller.error === 'function') stream._controller.error(error); else Promise.resolve(webReadable ? stream.cancel(error) : stream.abort(error)).catch(function() {}); } if (signal.aborted) abort(true); else { signal.addEventListener('abort', onAbort, { once: true }); if (nodeStream) { if (stream._destroyFinished) cleanup(); else { if (stream._destroyWaiters) stream._destroyWaiters.push(cleanup); stream.once('close', cleanup); } } } return stream; } function isDestroyed(stream) { return stream === null || stream === undefined ? false : Boolean(stream.destroyed); } function isDisturbed(stream) { return stream === null || stream === undefined ? false : Boolean(stream._readableDidRead || stream.readableEnded); } function isErrored(stream) { return stream === null || stream === undefined ? false : stream.errored !== null && stream.errored !== undefined; } function isReadable(stream) { return Boolean(stream && stream.readable === true && !stream.destroyed && !stream.readableEnded); } function isWritable(stream) { return Boolean(stream && stream.writable === true && !stream.destroyed && !stream.writableEnded); } Readable.isDisturbed = isDisturbed; Stream.isDestroyed = isDestroyed; Stream.isDisturbed = isDisturbed; Stream.isErrored = isErrored; Stream.isReadable = isReadable; Stream.isWritable = isWritable;
function duplexPair(writable, readable, stages) { stages = stages || [writable, readable]; var output = new Duplex({ readableObjectMode: Boolean(readable._readableObjectMode), writableObjectMode: Boolean(writable._writableObjectMode), read: function() { if (readable.resume) readable.resume(); }, write: function(chunk, encoding, callback) { try { writable.write(chunk, encoding, callback); } catch (error) { callback(error); } }, final: function(callback) { try { writable.end(callback); } catch (error) { callback(error); } } }); if (readable.pause) readable.pause(); readable.on('data', function(chunk) { if (!output.push(chunk) && readable.pause) readable.pause(); }); readable.once('end', function() { output.push(null); }); stages.forEach(function(stage) { var needsReadable = stage.readable === true, needsWritable = stage.writable === true; stage.once('error', function(error) { if (!output.destroyed) output.destroy(error); }); stage.once('close', function() { if (output.destroyed) return; if (stage.errored) { output.destroy(stage.errored); return; } if (output._compositionEnding) return; if ((needsReadable && stage.readableEnded !== true) || (needsWritable && stage.writableFinished !== true)) { var error = new Error('Premature close'); error.code = 'ERR_STREAM_PREMATURE_CLOSE'; output.destroy(error); } }); }); var destroyPair = output.destroy; output.destroy = function(error) { stages.forEach(function(stage) { if (stage !== output && stage.destroy && !stage.destroyed) stage.destroy(error); }); return destroyPair.call(output, error); }; if (readable.resume) readable.resume(); return output; } function compose() { var stages = Array.prototype.slice.call(arguments); if (!stages.length) throw new TypeError('compose requires at least one stream'); if (stages.length === 1) return Duplex.from(stages[0]); for (var index = 0; index + 1 < stages.length; index++) { if (!stages[index] || typeof stages[index].pipe !== 'function') throw new TypeError('compose stages must be readable streams'); stages[index].pipe(stages[index + 1]); } return duplexPair(stages[0], stages[stages.length - 1], stages); } Duplex.from = function(source) { if (source instanceof Duplex) return source; if (typeof source === 'function') { var input = new PassThrough({ objectMode: true }), produced, controller = new AbortController(); try { produced = source(input, { signal: controller.signal }); } catch (error) { input.destroy(error); produced = Promise.reject(error); } var sink = Boolean(produced && typeof produced.then === 'function'); if (sink) produced = Promise.resolve(produced).then(function(value) { if (value !== undefined && value !== null) { var invalid = new TypeError('Expected a null or undefined return value from the body function'); invalid.code = 'ERR_INVALID_RETURN_VALUE'; throw invalid; } }); var converted = Duplex.from(produced), functional = duplexPair(input, converted, [input, converted]), destroyFunctional = functional.destroy; if (sink) { functional.readable = false; functional._final = function(callback) { try { input.end(); } catch (error) { callback(error); return; } produced.then(function() { callback(); }, callback); }; } functional.destroy = function(error) { if (!controller.signal.aborted) controller.abort(error); return destroyFunctional.call(functional, error); }; return functional; } if (source && source.readable && source.writable === undefined) { var readableOnly = duplexPair(new Writable({ write: function(chunk, encoding, callback) { var error = new Error('stream is not writable'); error.code = 'ERR_STREAM_CANNOT_PIPE'; callback(error); } }), source, [source]); readableOnly.writable = false; return readableOnly; } if (source && source.writable && source.readable === undefined) { var empty = new Readable(); empty.push(null); var writableOnly = duplexPair(source, empty, [source, empty]); writableOnly.readable = false; return writableOnly; } if (source && source.readable && source.writable) return duplexPair(source.writable, source.readable, [source.writable, source.readable]); var output = new Duplex({ objectMode: true, read: function() {} }), sourceIterator = null, iteratorClosed = false, destroySource = output.destroy; output.writable = false; output.destroy = function(error) { if (!iteratorClosed && sourceIterator && typeof sourceIterator.return === 'function') { iteratorClosed = true; try { Promise.resolve(sourceIterator.return()).catch(function() {}); } catch (_) {} } return destroySource.call(output, error); }; queueMicrotask(async function() { try { if (source && typeof source.then === 'function') { var value = await source; if (value !== undefined && value !== null) output.push(value); } else if (typeof source === 'string' || globalThis.Buffer.isBuffer(source)) { output.push(source); } else { sourceIterator = typeof source[Symbol.asyncIterator] === 'function' ? source[Symbol.asyncIterator]() : source[Symbol.iterator](); while (!output.destroyed) { var step = await sourceIterator.next(); if (step.done || output.destroyed) break; var value = await step.value; if (value === null) { var nullError = new TypeError('May not write null values to stream'); nullError.code = 'ERR_STREAM_NULL_VALUES'; throw nullError; } output.push(value); } } if (!output.destroyed) output.push(null); } catch (error) { output.destroy(error); } }); return output; }; function createDuplexPair(options) { options = options || {}; var left, right; left = new Duplex(Object.assign({}, options, { read: function() {}, write: function(chunk, encoding, callback) { if (right.destroyed) { var error = new Error('Cannot call write after a stream was destroyed'); error.code = 'ERR_STREAM_DESTROYED'; callback(error); } else { right.push(chunk); callback(); } }, final: function(callback) { if (!right.destroyed) right.push(null); callback(); } })); right = new Duplex(Object.assign({}, options, { read: function() {}, write: function(chunk, encoding, callback) { if (left.destroyed) { var error = new Error('Cannot call write after a stream was destroyed'); error.code = 'ERR_STREAM_DESTROYED'; callback(error); } else { left.push(chunk); callback(); } }, final: function(callback) { if (!left.destroyed) left.push(null); callback(); } })); return [left, right]; } function destroyStream(stream, error) { if (!error) { error = new Error('The operation was aborted'); error.name = 'AbortError'; error.code = 'ABORT_ERR'; } if (stream && typeof stream.destroy === 'function') stream.destroy(error); } function isArrayBufferView(value) { return globalThis.ArrayBuffer.isView(value); } function isUint8Array(value) { return value instanceof globalThis.Uint8Array; } function uint8ArrayToBuffer(value) { if (!isUint8Array(value)) throw new TypeError('value must be a Uint8Array'); return globalThis.Buffer.from(value.buffer, value.byteOffset, value.byteLength); } var streamPromises = { pipeline: function() { var stages = Array.prototype.slice.call(arguments); return new Promise(function(resolve, reject) { stages.push(function(error, value) { if (error) reject(error); else resolve(value); }); pipeline.apply(null, stages); }); }, finished: function(stream, options) { return new Promise(function(resolve, reject) { finished(stream, Object.assign({}, options || {}, { cleanup: true }), function(error) { if (error) reject(error); else resolve(); }); }); } }; module.exports = Stream; Object.assign(module.exports, { Stream: Stream, Readable: Readable, Writable: Writable, Duplex: Duplex, Transform: Transform, PassThrough: PassThrough, pipeline: pipeline, compose: compose, finished: finished, addAbortSignal: addAbortSignal, isDestroyed: isDestroyed, isDisturbed: isDisturbed, isErrored: isErrored, isReadable: isReadable, isWritable: isWritable, getDefaultHighWaterMark: getDefaultHighWaterMark, setDefaultHighWaterMark: setDefaultHighWaterMark, duplexPair: createDuplexPair, destroy: destroyStream, _isArrayBufferView: isArrayBufferView, _isUint8Array: isUint8Array, _uint8ArrayToBuffer: uint8ArrayToBuffer, promises: streamPromises });
function writableComposition(stages) { var first = stages[0], last = stages[stages.length - 1], finalCallback = null, finalSettled = false, lastClosed = false; function settle(error) { if (finalSettled || !finalCallback) return; finalSettled = true; var callback = finalCallback; finalCallback = null; callback(error); } var output = new Duplex({ objectMode: true, read: function() {}, write: function(chunk, encoding, callback) { try { first.write(chunk, encoding, callback); } catch (error) { callback(error); } }, final: function(callback) { finalCallback = callback; if (lastClosed) { settle(last.errored); return; } stages.forEach(function(stage) { stage._compositionEnding = true; }); try { first.end(); } catch (error) { settle(error); } } }); output.readable = false; output.readableEnded = true; output._endEmitted = true; stages.forEach(function(stage) { var needsReadable = stage.readable === true, needsWritable = stage.writable === true; stage.once('error', function(error) { settle(error); if (!output.destroyed) output.destroy(error); }); stage.once('close', function() { if (stage === last) { lastClosed = true; settle(stage.errored); } if (output.destroyed || output.writableEnded || output._ending) return; if ((needsReadable && stage.readableEnded !== true) || (needsWritable && stage.writableFinished !== true)) { var error = new Error('Premature close'); error.code = 'ERR_STREAM_PREMATURE_CLOSE'; settle(error); output.destroy(error); } }); }); for (var index = 0; index + 1 < stages.length; index++) stages[index].pipe(stages[index + 1]); var destroyOutput = output.destroy; output.destroy = function(error) { stages.forEach(function(stage) { if (stage.destroy && !stage.destroyed) stage.destroy(error); }); return destroyOutput.call(output, error); }; return output; }
var duplexFromImplementation = Duplex.from; Duplex.from = function(source) { var valid = source instanceof Duplex || typeof source === 'function' || typeof source === 'string' || globalThis.ArrayBuffer.isView(source) || Boolean(source && (typeof source.then === 'function' || typeof source[Symbol.iterator] === 'function' || typeof source[Symbol.asyncIterator] === 'function' || source.readable === true || source.writable === true || (source.readable && source.writable))); if (!valid) { var invalid = new TypeError('The body argument must be a supported stream source'); invalid.code = 'ERR_INVALID_ARG_TYPE'; throw invalid; } return duplexFromImplementation.call(this, source); };
module.exports.default = Stream; module.exports.__esModule = true;

},
"node:events": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var errorMonitor = Symbol.for('events.errorMonitor');
function EventEmitter(options) {
  if (!(this instanceof EventEmitter)) return new EventEmitter(options);
  this._events = Object.create(null); this._maxListeners = undefined; if (options && options.captureRejections) Object.defineProperty(this, '_captureRejections', { value: true, writable: true, configurable: true });
}
function addEventListener(emitter, event, listener, prepend, once) {
  if (typeof listener !== 'function') throw new TypeError('listener must be a function');
  if (!emitter._events) emitter._events = Object.create(null);
  var name = typeof event === 'symbol' ? event : String(event); if (emitter._events.newListener && emitter._events.newListener.length) emitter.emit('newListener', name, listener); var list = emitter._events[name] || (emitter._events[name] = []);
  var entry = { listener: listener, once: Boolean(once) };
  if (prepend) list.unshift(entry); else list.push(entry);
  var max = emitter._maxListeners === undefined ? EventEmitter.defaultMaxListeners : emitter._maxListeners; if (max > 0 && list.length > max && !list.warned) { list.warned = true; var warning = new Error('Possible EventEmitter memory leak detected. ' + list.length + ' ' + String(name) + ' listeners added to ' + (emitter.constructor && emitter.constructor.name ? '[' + emitter.constructor.name + ']' : 'EventEmitter') + '. MaxListeners is ' + max + '. Use emitter.setMaxListeners() to increase limit'); warning.name = 'MaxListenersExceededWarning'; warning.emitter = emitter; warning.type = name; warning.count = list.length; if (typeof process !== 'undefined' && process.emitWarning) process.emitWarning(warning); }
  return emitter;
};
EventEmitter.prototype.addListener = EventEmitter.prototype.on = function(event, listener) { return addEventListener(this, event, listener, false, false); };
EventEmitter.prototype.once = function(event, listener) { return addEventListener(this, event, listener, false, true); };
EventEmitter.prototype.prependListener = function(event, listener) { return addEventListener(this, event, listener, true, false); };
EventEmitter.prototype.prependOnceListener = function(event, listener) { return addEventListener(this, event, listener, true, true); };
function removeEntry(emitter, name, entry) { var events = emitter._events; var list = events ? events[name] : undefined; var at = list ? list.indexOf(entry) : -1; if (at < 0) return; list.splice(at, 1); if (list.length === 0) delete events[name]; if (events.removeListener && events.removeListener.length) emitter.emit('removeListener', name, entry.listener); }
// ponytail: tiny inspect for the ERR_UNHANDLED_ERROR message only (strings, plain arrays/objects); a static require of node:util would make the bundler pull it into every events consumer.
             function inspectError(value, depth) { if (typeof value === 'string') return "'" + value + "'"; if (!value || typeof value !== 'object' || depth > 2) return String(value); if (Array.isArray(value)) return value.length ? '[ ' + value.map(function(item) { return inspectError(item, depth + 1); }).join(', ') + ' ]' : '[]'; if (Object.getPrototypeOf(value) !== Object.prototype) return String(value); var keys = Object.keys(value); return keys.length ? '{ ' + keys.map(function(key) { return key + ': ' + inspectError(value[key], depth + 1); }).join(', ') + ' }' : '{}'; }
EventEmitter.prototype.emit = function(event) {
  var name = typeof event === 'symbol' ? event : String(event); var events = this._events; var list = events ? events[name] : undefined;
  if (name === 'error' && events && events[errorMonitor] && events[errorMonitor].length) this.emit.apply(this, [errorMonitor].concat(Array.prototype.slice.call(arguments, 1)));
  if (!list || list.length === 0) {
    if (name === 'error') { var error = arguments[1]; if (error instanceof Error) throw error; var unhandled = new Error('Unhandled error. (' + inspectError(error, 0) + ')'); unhandled.code = 'ERR_UNHANDLED_ERROR'; unhandled.context = error; throw unhandled; }
    return false;
  }
  var args = Array.prototype.slice.call(arguments, 1);
  list.slice().forEach(function(entry) {
    if (entry.once) { if (entry.fired) return; entry.fired = true; removeEntry(this, name, entry); }
    var result = entry.listener.apply(this, args); if (this._captureRejections && result && typeof result.then === 'function') { var emitter = this; result.then(undefined, function(error) { var handler = emitter[Symbol.for('nodejs.rejection')]; if (typeof handler === 'function') handler.apply(emitter, [error, name].concat(args)); else { emitter._captureRejections = false; try { emitter.emit('error', error); } finally { emitter._captureRejections = true; } } }); }
  }, this);
  return true;
};
EventEmitter.prototype.removeListener = EventEmitter.prototype.off = function(event, listener) {
  var name = typeof event === 'symbol' ? event : String(event); var events = this._events; var list = events ? events[name] : undefined; if (!list) return this;
  for (var index = list.length - 1; index >= 0; index--) if (list[index].listener === listener || list[index].listener.listener === listener) { var removed = list[index].listener.listener || list[index].listener; list.splice(index, 1); if (list.length === 0) delete events[name]; if (events.removeListener && events.removeListener.length) this.emit('removeListener', name, removed); break; } return this;
};
EventEmitter.prototype.removeAllListeners = function(event) { var emitter = this; var events = this._events; if (!events) return this; if (!events.removeListener || !events.removeListener.length) { if (event === undefined) this._events = Object.create(null); else delete events[typeof event === 'symbol' ? event : String(event)]; return this; } if (event !== undefined) { var name = typeof event === 'symbol' ? event : String(event), list = (events[name] || []).slice(); for (var index = list.length - 1; index >= 0; index--) this.removeListener(name, list[index].listener); return this; } Reflect.ownKeys(events).filter(function(name) { return name !== 'removeListener'; }).forEach(function(name) { emitter.removeAllListeners(name); }); this.removeAllListeners('removeListener'); return this; };
EventEmitter.prototype.listeners = function(event) { var events = this._events; var list = (events ? events[typeof event === 'symbol' ? event : String(event)] : undefined) || []; return list.map(function(entry) { return entry.listener.listener || entry.listener; }); };
EventEmitter.prototype.rawListeners = function(event) { var events = this._events; var list = (events ? events[typeof event === 'symbol' ? event : String(event)] : undefined) || []; var emitter = this; return list.map(function(entry) { if (!entry.once) return entry.listener; if (!entry.wrapper) { entry.wrapper = function() { if (entry.fired) return; entry.fired = true; removeEntry(emitter, typeof event === 'symbol' ? event : String(event), entry); return entry.listener.apply(emitter, arguments); }; entry.wrapper.listener = entry.listener; } return entry.wrapper; }); };
EventEmitter.prototype.listenerCount = function(event) { var events = this._events; var list = events ? events[typeof event === 'symbol' ? event : String(event)] : undefined; return list ? list.length : 0; };
EventEmitter.prototype.eventNames = function() { return this._events ? Reflect.ownKeys(this._events) : []; };
EventEmitter.prototype.setMaxListeners = function(value) { value = Number(value); if (!Number.isFinite(value) || value < 0) throw new RangeError('The value of n is out of range'); this._maxListeners = value; return this; }; EventEmitter.prototype.getMaxListeners = function() { return this._maxListeners === undefined ? EventEmitter.defaultMaxListeners : this._maxListeners; }; EventEmitter.defaultMaxListeners = 10; EventEmitter.captureRejections = false;
EventEmitter.listenerCount = function(emitter, event) { return emitter.listenerCount(event); };
function isEventTarget(target) { return !!target && typeof target.addEventListener === 'function' && typeof target.on !== 'function'; }
function listenerTarget(source) { return isEventTarget(source) ? { on: function(name, listener) { source.addEventListener(name, listener); }, once: function(name, listener) { source.addEventListener(name, listener, { once: true }); }, removeListener: function(name, listener) { source.removeEventListener(name, listener); } } : source; }
var targetMaxListeners = new WeakMap();
function addAbortListener(signal, listener) { if (!signal || typeof signal.aborted !== 'boolean') { var signalError = new TypeError('The signal argument must be an instance of AbortSignal.'); signalError.code = 'ERR_INVALID_ARG_TYPE'; throw signalError; } if (typeof listener !== 'function') { var listenerError = new TypeError('The listener argument must be of type function.'); listenerError.code = 'ERR_INVALID_ARG_TYPE'; throw listenerError; } var dispose = typeof Symbol.dispose === 'symbol' ? Symbol.dispose : Symbol.for('nodejs.dispose'); if (signal.aborted) queueMicrotask(function() { listener(); }); else signal.addEventListener('abort', listener, { once: true }); var disposable = Object.create(null); disposable[dispose] = function() { signal.removeEventListener('abort', listener); }; return disposable; }
function once(source, event, options) { var emitter = listenerTarget(source);
  return new Promise(function(resolve, reject) {
    function cleanup() { emitter.removeListener(event, done); emitter.removeListener('error', failed); if (options && options.signal) options.signal.removeEventListener('abort', aborted); }
    function done() { var values = Array.prototype.slice.call(arguments); cleanup(); resolve(values); }
    function failed(error) { cleanup(); reject(error); }
    function aborted() { var error = new Error('The operation was aborted'); error.name = 'AbortError'; error.code = 'ABORT_ERR'; error.cause = options.signal.reason; cleanup(); reject(error); }
    if (options && options.signal && options.signal.aborted) { aborted(); return; } // shortcut: stream end is emitted synchronously, Node emits it on a later tick, so awaiting it afterwards must still resolve.
 if (event === 'end' && emitter._endEmitted === true) { resolve([]); return; } emitter.once(event, done); if (event !== 'error' && !isEventTarget(source)) emitter.once('error', failed); if (options && options.signal) options.signal.addEventListener('abort', aborted, { once: true });
  });
}
function on(source, event, options) { var emitter = listenerTarget(source); options = options || {}; var values = [], waiters = [], ended = false, failure; function received() { var value = Array.prototype.slice.call(arguments); if (waiters.length) waiters.shift().resolve({ value: value, done: false }); else values.push(value); } function fail(error) { failure = error; finish(); } function finish() { if (ended) return; ended = true; closeNames.forEach(function(name) { emitter.removeListener(name, finish); }); emitter.removeListener(event, received); if (event !== 'error') emitter.removeListener('error', fail); while (waiters.length) { var waiter = waiters.shift(); if (failure) waiter.reject(failure); else waiter.resolve({ value: undefined, done: true }); } } var closeNames = Array.isArray(options.close) ? options.close : []; closeNames.forEach(function(name) { emitter.on(name, finish); }); emitter.on(event, received); if (event !== 'error' && !isEventTarget(source)) emitter.on('error', fail); if (options.signal) { var abort = function() { var error = new Error('The operation was aborted'); error.name = 'AbortError'; error.code = 'ABORT_ERR'; error.cause = options.signal.reason; failure = error; finish(); }; if (options.signal.aborted) abort(); else options.signal.addEventListener('abort', abort, { once: true }); } return { next: function() { if (values.length) return Promise.resolve({ value: values.shift(), done: false }); if (failure) return Promise.reject(failure); if (ended) return Promise.resolve({ value: undefined, done: true }); return new Promise(function(resolve, reject) { waiters.push({ resolve: resolve, reject: reject }); }); }, return: function() { finish(); return Promise.resolve({ value: undefined, done: true }); }, throw: function(error) { failure = error; finish(); return Promise.reject(error); }, [Symbol.asyncIterator]: function() { return this; } }; }
function getEventListeners(emitter, event) { if (isEventTarget(emitter)) { var records = emitter.__thawListeners && emitter.__thawListeners.get(String(event)); return records ? records.map(function(entry) { return entry.callback; }) : []; } return typeof emitter.listeners === 'function' ? emitter.listeners(event) : []; } function getMaxListeners(emitter) { if (isEventTarget(emitter)) return targetMaxListeners.has(emitter) ? targetMaxListeners.get(emitter) : EventEmitter.defaultMaxListeners; return typeof emitter.getMaxListeners === 'function' ? emitter.getMaxListeners() : EventEmitter.defaultMaxListeners; } function setMaxListeners(value) { var emitters = Array.prototype.slice.call(arguments, 1); value = Number(value); if (!Number.isFinite(value) || value < 0) throw new RangeError('The value of n is out of range'); if (!emitters.length) EventEmitter.defaultMaxListeners = value; else emitters.forEach(function(emitter) { if (isEventTarget(emitter)) targetMaxListeners.set(emitter, value); else emitter.setMaxListeners(value); }); }
module.exports = EventEmitter;
module.exports.EventEmitter = EventEmitter;
module.exports.once = once;
module.exports.addAbortListener = addAbortListener;
module.exports.on = on; module.exports.getEventListeners = getEventListeners; module.exports.getMaxListeners = getMaxListeners; module.exports.setMaxListeners = setMaxListeners; module.exports.errorMonitor = errorMonitor; module.exports.captureRejectionSymbol = Symbol.for('nodejs.rejection');
EventEmitter.prototype._events = undefined; EventEmitter.prototype._eventsCount = 0; EventEmitter.prototype._maxListeners = undefined;
function EventEmitterAsyncResource(options) { if (!(this instanceof EventEmitterAsyncResource)) throw new TypeError("Class constructor EventEmitterAsyncResource cannot be invoked without 'new'"); if (!options || typeof options.name !== 'string') { var nameError = new TypeError('The "options.name" property must be of type string.'); nameError.code = 'ERR_INVALID_ARG_TYPE'; throw nameError; } EventEmitter.call(this, options); this._asyncId = ++asyncResourceCount; this._triggerAsyncId = options.triggerAsyncId === undefined ? 0 : options.triggerAsyncId; }
var asyncResourceCount = 1;
EventEmitterAsyncResource.prototype = Object.create(EventEmitter.prototype); EventEmitterAsyncResource.prototype.constructor = EventEmitterAsyncResource;
Object.defineProperty(EventEmitterAsyncResource.prototype, 'asyncId', { get: function() { return this._asyncId; }, configurable: true }); Object.defineProperty(EventEmitterAsyncResource.prototype, 'triggerAsyncId', { get: function() { return this._triggerAsyncId; }, configurable: true }); EventEmitterAsyncResource.prototype.emitDestroy = function() { return this; };
module.exports.EventEmitterAsyncResource = EventEmitterAsyncResource;
module.exports.usingDomains = false; module.exports.kMaxEventTargetListeners = Symbol('events.maxEventTargetListeners'); module.exports.kMaxEventTargetListenersWarned = Symbol('events.maxEventTargetListenersWarned');
module.exports.default = EventEmitter;
module.exports.__esModule = true;

},
"node:fs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var stream = require('node:stream'), EventEmitter = require('node:events'); function pathValue(path) { if (path instanceof URL) { if (path.protocol !== 'file:' || (path.host && path.host !== 'localhost') || /%2f|%5c/i.test(path.pathname)) throw new TypeError('Invalid file URL'); return decodeURIComponent(path.pathname); } return String(path); } function flagsValue(flags, fallback) { if (flags === undefined) return fallback; if (typeof flags === 'string') return flags; if (typeof flags !== 'number' || !Number.isInteger(flags) || flags < 0 || flags > 2147483647) throw new TypeError('Invalid file flags'); return flags; } var fsSyscalls = { fd_open: 'open', read: 'open', readdir: 'scandir', copy: 'copyfile', mkdir_mode: 'mkdir', fd_read_all: 'read', fd_read: 'read', fd_write: 'write', fd_write_all: 'write', fd_stat: 'fstat' }, fsErrnos = { EPERM: -1, ENOENT: -2, EIO: -5, EBADF: -9, EACCES: -13, EEXIST: -17, ENOTDIR: -20, EISDIR: -21, EINVAL: -22, EMFILE: -24, ENOSPC: -28, EROFS: -30, ENAMETOOLONG: -36, ENOSYS: -38, ENOTEMPTY: -39, ELOOP: -40 }, fsDescriptions = { EISDIR: 'illegal operation on a directory', EEXIST: 'file already exists', ENOTEMPTY: 'directory not empty', EPERM: 'operation not permitted' }; function invoke(operation, path, value, recursive) { var secondPath = /^(rename|copy|copy_excl|cp|same_file|copy_guard|link|symlink)$/.test(operation), rawPath = Buffer.isBuffer(path), rawValue = secondPath && Buffer.isBuffer(value), visiblePath = rawPath ? path : pathValue(path), hostOperation = operation + (rawPath ? '_raw' : '') + (rawValue ? '_raw_value' : ''), hostPath = rawPath ? path.toString('hex') : visiblePath, hostValue = rawValue ? value.toString('hex') : secondPath ? pathValue(value) : value || ''; var record = JSON.parse(globalThis.__thaw_fs(hostOperation, hostPath, hostValue, Boolean(recursive))); path = visiblePath; if (!record.ok) { if (record.code === 'EEXIST' && (/_excl$/.test(operation) || operation === 'fd_open')) throw exclusiveError(operation === 'copy_excl' ? value : path, operation === 'copy_excl' ? 'copyfile' : 'open'); var syscall = fsSyscalls[operation] || operation, desc = fsDescriptions[record.code] || String(record.message).replace(/ \(os error \d+\)$/, '').replace(/^./, function(c) { return c.toLowerCase(); }), pathless = /^fd_(read|write)/.test(operation), tick = String.fromCharCode(39), shown = tick + path + tick + (secondPath ? ' -> ' + tick + pathValue(value) + tick : ''), error = new Error(record.code + ': ' + desc + ', ' + syscall + (pathless ? '' : ' ' + shown)); error.errno = fsErrnos[record.code] || -1; error.code = record.code; error.syscall = syscall; if (!pathless) { error.path = path; if (secondPath) error.dest = pathValue(value); } throw error; } return record; } function statLookup(operation, path, options, suppressMissing) { var input = Buffer.isBuffer(path) ? path : pathValue(path), record; try { record = invoke(operation, input); } catch (error) { if (suppressMissing && options && options.throwIfNoEntry === false && (error.code === 'ENOENT' || (operation === 'stat' && error.code === 'ENOTDIR'))) return undefined; throw error; } return new Stats(record, Boolean(options && options.bigint)); } function encoding(options) { return typeof options === 'string' ? options : options && options.encoding; } function bufferShape(v) { return v && typeof v === 'object' && !ArrayBuffer.isView(v) && v.type === 'Buffer' && Array.isArray(v.data) ? Buffer.from(v.data) : v; } function data(value, options) { value = bufferShape(value); return ArrayBuffer.isView(value) ? Buffer.from(value.buffer, value.byteOffset, value.byteLength) : Buffer.from(String(value), encoding(options)); } function exclusiveError(path, syscall) { var error = new Error('EEXIST: path already exists, ' + syscall + ' ' + pathValue(path)); error.code = 'EEXIST'; error.errno = -1; error.path = pathValue(path); error.syscall = syscall; return error; } function timeValue(value) { var number = value instanceof Date ? value.getTime() / 1000 : Number(value); if (!Number.isFinite(number)) throw new TypeError('Invalid time value'); return number; } function Stats(record, bigint) { var exact = record.exact, convert = bigint ? function(value, key) { return BigInt(exact ? exact[key] : Math.trunc(Number(value))); } : Number, numeric = ['dev','mode','nlink','uid','gid','rdev','blksize','ino']; for (var index = 0; index < numeric.length; index++) this[numeric[index]] = convert(record[numeric[index]], numeric[index]); this.size = convert(record.length, 'length'); this.blocks = convert(record.blocks, 'blocks'); var atime = Number(record.atimeMs), mtime = Number(record.mtimeMs), ctime = Number(record.ctimeMs), birthtime = Number(record.birthtimeMs); if (bigint) { var nanos = function(key, millis) { return exact ? BigInt(exact[key]) : BigInt(Math.round(millis * 1000000)); }, million = BigInt(1000000); var an = nanos('atimeNs', atime), mn = nanos('mtimeNs', mtime), cn = nanos('ctimeNs', ctime), bn = nanos('birthtimeNs', birthtime); this.atimeMs = an / million; this.mtimeMs = mn / million; this.ctimeMs = cn / million; this.birthtimeMs = bn / million; this.atimeNs = an; this.mtimeNs = mn; this.ctimeNs = cn; this.birthtimeNs = bn; } else { this.atimeMs = atime; this.mtimeMs = mtime; this.ctimeMs = ctime; this.birthtimeMs = birthtime; } this.atime = new Date(atime); this.mtime = new Date(mtime); this.ctime = new Date(ctime); this.birthtime = new Date(birthtime); this._file = record.file; this._directory = record.directory; this._symlink = Boolean(record.symlink); } Stats.prototype.isFile = function() { return this._file; }; Stats.prototype.isDirectory = function() { return this._directory; }; Stats.prototype.isSymbolicLink = function() { return this._symlink; }; Stats.prototype.isSocket = function() { return (Number(this.mode) & 61440) === 49152; }; Stats.prototype.isFIFO = function() { return (Number(this.mode) & 61440) === 4096; }; Stats.prototype.isCharacterDevice = function() { return (Number(this.mode) & 61440) === 8192; }; Stats.prototype.isBlockDevice = function() { return (Number(this.mode) & 61440) === 24576; };
var __thaw_fs = { existsSync: function(path) { return invoke('exists', path).exists; }, readFileSync: function(path, options, signal) { return fsReadFile(path, options, signal); }, writeFileSync: function(path, value, options, signal) { fsWriteMode(path, value, options, 'w', signal); }, appendFileSync: function(path, value, options, signal) { fsWriteMode(path, value, options, 'a', signal); }, mkdirSync: function(path, options) { invoke('mkdir', path, '', options && options.recursive); }, readdirSync: function(path, options) { options = options || {}; var root = Buffer.isBuffer(path) ? path : pathValue(path), targetEncoding = encoding(options), withFileTypes = Boolean(options.withFileTypes), recursive = Boolean(options.recursive), entries = invoke('readdir', root, withFileTypes ? 'typed' : '', recursive).entries; function decode(bytes) { return targetEncoding === 'buffer' ? bytes : bytes.toString(targetEncoding || 'utf8'); } return entries.map(function(entry) { var name = decode(Buffer.from(entry.nameHex, 'hex')); if (withFileTypes) { var stat = entry.stat, dirent = { name: name, parentPath: entry.parentPath, path: entry.parentPath, isFile: function() { return stat.file; }, isDirectory: function() { return stat.directory; }, isSymbolicLink: function() { return Boolean(stat.symlink); }, isSocket: function() { return (Number(stat.mode) & 61440) === 49152; }, isFIFO: function() { return (Number(stat.mode) & 61440) === 4096; }, isCharacterDevice: function() { return (Number(stat.mode) & 61440) === 8192; }, isBlockDevice: function() { return (Number(stat.mode) & 61440) === 24576; } }; var rawPath = Buffer.from(entry.pathHex, 'hex'); Object.defineProperty(dirent, '_rawPath', { get: function() { return Buffer.from(rawPath); } }); return dirent; } return recursive ? decode(Buffer.from(entry.relativeHex, 'hex')) : name; }); }, statSync: function(path, options) { return statLookup('stat', path, options, true); }, lstatSync: function(path, options) { return statLookup('lstat', path, options, true); }, unlinkSync: function(path) { invoke('unlink', path); }, rmSync: function(path, options) { var stat; try { stat = invoke('lstat', path); } catch (error) { if (options && options.force && error.code === 'ENOENT') return; throw error; } if (stat.directory && !(options && options.recursive)) { var error = new Error('EISDIR: recursive option is required'); error.code = 'EISDIR'; throw error; } invoke(stat.directory ? 'rmdir' : 'unlink', path, '', options && options.recursive); }, rmdirSync: function(path, options) { invoke('rmdir', path, '', options && options.recursive); }, renameSync: function(oldPath, newPath) { invoke('rename', oldPath, newPath); } };
__thaw_fs.copyFileSync = function(source, destination, mode) { invoke((Number(mode) & __thaw_fs.constants.COPYFILE_EXCL) ? 'copy_excl' : 'copy', source, destination); }; __thaw_fs.cpSync = function(source, destination, options) { options = options || {}; destination = pathValue(destination); if (__thaw_fs.existsSync(destination)) { if (options.force === false) { if (options.errorOnExist) { var detail = destination + ' already exists', error = new Error('Target already exists: cp returned EEXIST (' + detail + ') ' + destination); Object.defineProperty(error, 'name', { value: 'SystemError', configurable: true, writable: true }); error.code = 'ERR_FS_CP_EEXIST'; error.info = { code: 'EEXIST', message: detail, path: destination, syscall: 'cp', errno: 17 }; error.errno = 17; error.syscall = 'cp'; error.path = destination; throw error; } return; } __thaw_fs.rmSync(destination, { recursive: true, force: true }); } invoke('cp', source, destination, Boolean(options.recursive)); }; __thaw_fs.realpathSync = function(path, options) { var result = invoke('realpath', path), bytes = Buffer.from(result.pathHex, 'hex'), target = encoding(options); return target === 'buffer' ? bytes : bytes.toString(target || 'utf8'); }; __thaw_fs.realpathSync.native = __thaw_fs.realpathSync; function mkdtempCreated(prefix, options) { var record = invoke('mkdtemp', prefix), rawPath = Buffer.from(record.pathHex, 'hex'), target = encoding(options); return { path: target === 'buffer' ? Buffer.from(rawPath) : rawPath.toString(target || 'utf8'), rawPath: rawPath }; } __thaw_fs.mkdtempSync = function(prefix, options) { return mkdtempCreated(prefix, options).path; }; __thaw_fs.mkdtempDisposableSync = function(prefix, options) { var created = mkdtempCreated(prefix, options), path = created.path, rawPath = created.rawPath, removed = false, disposable = { path: path, remove: function() { if (!removed) { __thaw_fs.rmSync(rawPath, { recursive: true, force: true }); removed = true; } } }; if (Symbol.dispose) disposable[Symbol.dispose] = disposable.remove; return disposable; }; function protectFileBlob(blob, verify) { var readArrayBuffer = blob.arrayBuffer.bind(blob), readBytes = blob.bytes.bind(blob), readText = blob.text.bind(blob), makeSlice = blob.slice.bind(blob), makeStream = blob.stream.bind(blob); blob.arrayBuffer = function() { return Promise.resolve().then(verify).then(readArrayBuffer); }; blob.bytes = function() { return Promise.resolve().then(verify).then(readBytes); }; blob.text = function() { return Promise.resolve().then(verify).then(readText); }; blob.slice = function(start, end, type) { return protectFileBlob(makeSlice(start, end, type), verify); }; blob.stream = function() { var reader = makeStream().getReader(); return new ReadableStream({ type: 'bytes', pull: async function(controller) { try { await verify(); var next = await reader.read(); if (next.done) { reader.releaseLock(); controller.close(); } else controller.enqueue(next.value); } catch (error) { try { await reader.cancel(error); } catch (_) {} reader.releaseLock(); throw error; } }, cancel: function(reason) { return reader.cancel(reason).finally(function() { reader.releaseLock(); }); } }); }; return blob; } __thaw_fs.openAsBlob = function(path, options) { if (Buffer.isBuffer(path)) path = Buffer.from(path); return Promise.resolve().then(function() { var initial = __thaw_fs.statSync(path), blob = new Blob([__thaw_fs.readFileSync(path)], { type: options && options.type }); function verify() { var current; try { current = __thaw_fs.statSync(path); } catch (error) { throw new DOMException('The blob could not be read', 'NotReadableError'); } if (current.size !== initial.size || current.mtimeMs !== initial.mtimeMs) throw new DOMException('The blob could not be read', 'NotReadableError'); } return protectFileBlob(blob, verify); }); };
__thaw_fs.linkSync = function(existingPath, newPath) { invoke('link', existingPath, newPath); }; __thaw_fs.symlinkSync = function(target, path) { invoke('symlink', target, path); }; __thaw_fs.readlinkSync = function(path, options) { var record = invoke('readlink', path), bytes = Buffer.from(record.pathHex, 'hex'), target = encoding(options); return target === 'buffer' ? bytes : bytes.toString(target || 'utf8'); }; __thaw_fs.chmodSync = function(path, mode) { if (mode === undefined) throw new TypeError('Invalid mode'); invoke('chmod', path, String(fsMode({ mode: mode }, 0))); }; __thaw_fs.utimesSync = function(path, atime, mtime) { invoke('utimes', path, String(timeValue(atime)) + ',' + String(timeValue(mtime))); }; __thaw_fs.lutimesSync = function(path, atime, mtime) { invoke('lutimes', path, String(timeValue(atime)) + ',' + String(timeValue(mtime))); }; __thaw_fs.chownSync = function(path, uid, gid) { invoke('chown', path, String(Number(uid)) + ',' + String(Number(gid))); }; __thaw_fs.lchownSync = function(path, uid, gid) { invoke('lchown', path, String(Number(uid)) + ',' + String(Number(gid))); }; __thaw_fs.truncateSync = function(path, length) { length = length === undefined ? 0 : Number(length); if (!Number.isSafeInteger(length) || length < 0) throw new RangeError('Invalid truncate length'); invoke('truncate', path, String(length)); }; __thaw_fs.accessSync = function(path, mode) { invoke('access', path, String(mode === undefined ? __thaw_fs.constants.F_OK : Number(mode))); }; function StatFs(record, bigint) { var exact = record.exact, convert = bigint ? function(value, key) { return BigInt(exact ? exact[key] : Math.trunc(Number(value))); } : Number, keys = ['type','bsize','blocks','bfree','bavail','files','ffree']; for (var key of keys) this[key] = convert(record[key], key); } __thaw_fs.StatFs = StatFs; __thaw_fs.statfsSync = function(path, options) { return new StatFs(invoke('statfs', path), Boolean(options && options.bigint)); }; var statWatchers = new Map(); function fsWatchKey(path) { return Buffer.isBuffer(path) ? 'raw:' + path.toString('hex') : 'text:' + pathValue(path); } function missingStats(bigint) { return new Stats({ length: 0, dev: 0, ino: 0, mode: 0, nlink: 0, uid: 0, gid: 0, rdev: 0, blksize: 0, blocks: 0, atimeMs: 0, mtimeMs: 0, ctimeMs: 0, birthtimeMs: 0, file: false, directory: false, symlink: false }, bigint); } function StatWatcher(path, options) { var watchedPath = Buffer.isBuffer(path) ? Buffer.from(path) : pathValue(path); this.path = Buffer.isBuffer(watchedPath) ? Buffer.from(watchedPath) : watchedPath; this._key = fsWatchKey(watchedPath); this._listeners = []; this._refed = options.persistent !== false; this._bigint = Boolean(options.bigint); var self = this; function sample() { try { return { stats: __thaw_fs.statSync(watchedPath, { bigint: self._bigint }), missing: false }; } catch (error) { if (error.code !== 'ENOENT') throw error; return { stats: missingStats(self._bigint), missing: true }; } } this._sample = sample; this._previous = sample(); this._pendingMissing = this._previous.missing; this._timer = setInterval(function() { var current; try { current = self._sample(); } catch (error) { return; } var previous = self._previous; if (self._pendingMissing || current.missing !== previous.missing || current.stats.mtimeMs !== previous.stats.mtimeMs || current.stats.ctimeMs !== previous.stats.ctimeMs || current.stats.mtimeNs !== previous.stats.mtimeNs || current.stats.ctimeNs !== previous.stats.ctimeNs || current.stats.size !== previous.stats.size) { self._pendingMissing = false; self._previous = current; self._listeners.slice().forEach(function(listener) { listener(current.stats, previous.stats); }); } }, Math.max(1, Number(options.interval || 5007))); if (!this._refed) this._timer.unref(); } StatWatcher.prototype.ref = function() { this._refed = true; if (this._timer) this._timer.ref(); return this; }; StatWatcher.prototype.unref = function() { this._refed = false; if (this._timer) this._timer.unref(); return this; }; StatWatcher.prototype.hasRef = function() { return this._refed; }; StatWatcher.prototype.stop = function() { if (this._timer !== null) { clearInterval(this._timer); this._timer = null; statWatchers.delete(this._key); } return this; }; __thaw_fs.StatWatcher = StatWatcher; __thaw_fs.watchFile = function(path, options, listener) { if (typeof options === 'function') { listener = options; options = {}; } if (typeof listener !== 'function') throw new TypeError('listener must be a function'); path = Buffer.isBuffer(path) ? path : pathValue(path); var key = fsWatchKey(path), watcher = statWatchers.get(key); if (!watcher) { watcher = new StatWatcher(path, options || {}); statWatchers.set(key, watcher); } if (watcher._listeners.indexOf(listener) < 0) watcher._listeners.push(listener); return watcher; }; __thaw_fs.unwatchFile = function(path, listener) { var watcher = statWatchers.get(fsWatchKey(path)); if (!watcher) return; if (typeof listener === 'function') watcher._listeners = watcher._listeners.filter(function(value) { return value !== listener; }); else watcher._listeners = []; if (!watcher._listeners.length) watcher.stop(); };
function Dir(path, options) { this.path = Buffer.isBuffer(path) ? Buffer.from(path) : pathValue(path); this.closed = false; this._index = 0; var settings = typeof options === 'string' ? { encoding: options } : options || {}; this._entries = __thaw_fs.readdirSync(this.path, Object.assign({}, settings, { withFileTypes: true })); } Dir.prototype._check = function() { if (this.closed) { var error = new Error('Directory handle was closed'); error.code = 'ERR_DIR_CLOSED'; throw error; } }; Dir.prototype.readSync = function() { this._check(); return this._index < this._entries.length ? this._entries[this._index++] : null; }; Dir.prototype.read = function(callback) { var self = this, operation = Promise.resolve().then(function() { return self.readSync(); }); if (typeof callback === 'function') { operation.then(function(value) { callback(null, value); }, callback); return; } return operation; }; Dir.prototype.closeSync = function() { this._check(); this.closed = true; }; Dir.prototype.close = function(callback) { var self = this, operation = Promise.resolve().then(function() { self.closeSync(); }); if (typeof callback === 'function') { operation.then(function() { callback(null); }, callback); return; } return operation; }; Dir.prototype[Symbol.asyncIterator] = function() { var self = this; return { next: function() { return self.read().then(function(value) { if (value === null) { if (!self.closed) self.closeSync(); return { value: undefined, done: true }; } return { value: value, done: false }; }); }, return: function() { return Promise.resolve().then(function() { if (!self.closed) self.closeSync(); return { value: undefined, done: true }; }); } }; }; __thaw_fs.Dir = Dir; __thaw_fs.opendirSync = function(path, options) { return new Dir(path, options); };
function ReadStream(path, options) { if (!(this instanceof ReadStream)) return new ReadStream(path, options); options = options || {}; stream.Readable.call(this, options); this.path = Buffer.isBuffer(path) ? Buffer.from(path) : pathValue(path); this.pending = true; this.fd = null; this.bytesRead = 0; this.close = this.destroy.bind(this); var self = this; queueMicrotask(function() { try { var value = Buffer.from(invoke('read', self.path).data, 'hex'), start = options.start === undefined ? 0 : Number(options.start), end = options.end === undefined ? value.length - 1 : Number(options.end), selected = value.subarray(start, Math.min(value.length, end + 1)), size = Math.max(1, Number(options.highWaterMark || 65536)); self.fd = 1; self.pending = false; self.emit('open', self.fd); self.emit('ready'); for (var offset = 0; offset < selected.length; offset += size) { var chunk = selected.subarray(offset, offset + size); self.bytesRead += chunk.length; self.push(chunk); } self.push(null); if (options.autoClose !== false) queueMicrotask(function() { self.fd = null; self.emit('close'); }); } catch (error) { self.pending = false; self.destroy(error); } }); } ReadStream.prototype = Object.create(stream.Readable.prototype); ReadStream.prototype.constructor = ReadStream;
function WriteStream(path, options) { if (!(this instanceof WriteStream)) return new WriteStream(path, options); options = options || {}; this.path = Buffer.isBuffer(path) ? Buffer.from(path) : pathValue(path); this.pending = true; this.fd = null; this.bytesWritten = 0; var chunks = [], self = this; stream.Writable.call(this, { write: function(chunk, encoding, callback) { chunks.push(Buffer.from(chunk)); self.bytesWritten += chunk.length; callback(); }, final: function(callback) { try { var value = Buffer.concat(chunks); invoke(options.flags === 'a' || options.flags === 'ax' ? 'append' : 'write', self.path, value.toString('hex')); callback(); if (options.autoClose !== false) queueMicrotask(function() { self.fd = null; self.emit('close'); }); } catch (error) { callback(error); } } }); queueMicrotask(function() { self.fd = 1; self.pending = false; self.emit('open', self.fd); self.emit('ready'); }); } WriteStream.prototype = Object.create(stream.Writable.prototype); WriteStream.prototype.constructor = WriteStream; WriteStream.prototype.close = function(callback) { if (!this.writableEnded) this.end(callback); else if (callback) queueMicrotask(callback); }; __thaw_fs.ReadStream = ReadStream; __thaw_fs.WriteStream = WriteStream; __thaw_fs.createReadStream = function(path, options) { return new ReadStream(path, options); }; __thaw_fs.createWriteStream = function(path, options) { return new WriteStream(path, options); };
var fileDescriptors = new Map(); function FileHandle(path, flags, fd) { EventEmitter.call(this); this.path = Buffer.isBuffer(path) ? Buffer.from(path) : pathValue(path); this.flags = flagsValue(flags, 'r'); this.fd = fd === undefined ? invoke('fd_open', this.path, (typeof flags === 'number' ? '#' + flags : this.flags) + ',438').fd : fd; this.closed = false; this._pendingOperations = new Set(); this._closing = false; this._closePromise = null; fileDescriptors.set(this.fd, this); } FileHandle.prototype = Object.create(EventEmitter.prototype); FileHandle.prototype.constructor = FileHandle; FileHandle.prototype._check = function() { if (this.closed) { var error = new Error('file closed'); error.code = 'EBADF'; throw error; } }; FileHandle.prototype._trackOperation = function(action) { if (this._closing || this.closed) { var closed = new Error('file closed'); closed.code = 'EBADF'; return Promise.reject(closed); } var complete, pending = new Promise(function(resolve) { complete = resolve; }), self = this, operation; this._pendingOperations.add(pending); try { operation = action(); } catch (error) { this._pendingOperations.delete(pending); complete(); throw error; } Promise.resolve(operation).then(function() { self._pendingOperations.delete(pending); complete(); }, function() { self._pendingOperations.delete(pending); complete(); }); return operation; }; FileHandle.prototype.close = function() { if (this._closePromise) return this._closePromise; var self = this; this._closing = true; this._closePromise = Promise.all(Array.from(this._pendingOperations)).then(function() { if (!self.closed) __thaw_fs.closeSync(self.fd); }); return this._closePromise; }; FileHandle.prototype.readFile = function(options) { var self = this, signal, entryError; try { signal = fsAbortSignal(options); entryError = fsAbortError(signal); } catch (error) { return Promise.reject(error); } return Promise.resolve().then(function() { var error = entryError || fsAbortError(signal); if (error) throw error; self._check(); return fsReadFile(self, options, signal); }); }; FileHandle.prototype.writeFile = function(value, options) { var self = this; return fsWriteAsync(self, value, options, 'w'); }; FileHandle.prototype.appendFile = function(value, options) { var self = this; return fsWriteAsync(self, value, options, 'a'); }; FileHandle.prototype.read = function(buffer, offset, length, position) { var self = this; if (buffer && !ArrayBuffer.isView(buffer)) { var options = buffer; offset = options.offset; length = options.length; position = options.position; if (options.buffer === undefined) { var allocationOffset = offset === undefined ? 0 : Number(offset), allocationLength = length === undefined ? 16384 : Number(length); if (!Number.isSafeInteger(allocationOffset) || !Number.isSafeInteger(allocationLength) || allocationOffset < 0 || allocationLength < 0 || !Number.isSafeInteger(allocationOffset + allocationLength)) throw new RangeError('Invalid read range'); buffer = Buffer.alloc(allocationOffset + allocationLength); } else buffer = options.buffer; } buffer = buffer || Buffer.alloc(16384); return Promise.resolve().then(function() { self._check(); return { bytesRead: __thaw_fs.readSync(self.fd, buffer, offset, length, position), buffer: buffer }; }); }; FileHandle.prototype.write = function(value, offset, length, position) { var self = this; return Promise.resolve().then(function() { self._check(); return { bytesWritten: __thaw_fs.writeSync(self.fd, value, offset, length, position), buffer: value }; }); }; FileHandle.prototype.stat = function(options) { var self = this; return Promise.resolve().then(function() { self._check(); return __thaw_fs.fstatSync(self.fd, options); }); }; FileHandle.prototype.truncate = function(length) { var self = this; return Promise.resolve().then(function() { self._check(); __thaw_fs.ftruncateSync(self.fd, length); }); }; FileHandle.prototype.createReadStream = function(options) { this._check(); return new ReadStream(this.path, Object.assign({ fd: this.fd }, options || {})); }; FileHandle.prototype.createWriteStream = function(options) { this._check(); return new WriteStream(this.path, Object.assign({ fd: this.fd, flags: this.flags }, options || {})); }; FileHandle.prototype[Symbol.asyncDispose] = FileHandle.prototype.close; __thaw_fs.FileHandle = FileHandle;
__thaw_fs.constants = globalThis.__thaw_fs_constants || (globalThis.__thaw_fs_constants = Object.assign(Object.create(null), { UV_FS_SYMLINK_DIR: 1, UV_FS_SYMLINK_JUNCTION: 2, O_RDONLY: 0, O_WRONLY: 1, O_RDWR: 2, UV_DIRENT_UNKNOWN: 0, UV_DIRENT_FILE: 1, UV_DIRENT_DIR: 2, UV_DIRENT_LINK: 3, UV_DIRENT_FIFO: 4, UV_DIRENT_SOCKET: 5, UV_DIRENT_CHAR: 6, UV_DIRENT_BLOCK: 7, S_IFMT: 61440, S_IFREG: 32768, S_IFDIR: 16384, S_IFCHR: 8192, S_IFBLK: 24576, S_IFIFO: 4096, S_IFLNK: 40960, S_IFSOCK: 49152, O_CREAT: 64, O_EXCL: 128, UV_FS_O_FILEMAP: 0, O_NOCTTY: 256, O_TRUNC: 512, O_APPEND: 1024, O_DIRECTORY: 65536, O_NOATIME: 262144, O_NOFOLLOW: 131072, O_SYNC: 1052672, O_DSYNC: 4096, O_DIRECT: 16384, O_NONBLOCK: 2048, S_IRWXU: 448, S_IRUSR: 256, S_IWUSR: 128, S_IXUSR: 64, S_IRWXG: 56, S_IRGRP: 32, S_IWGRP: 16, S_IXGRP: 8, S_IRWXO: 7, S_IROTH: 4, S_IWOTH: 2, S_IXOTH: 1, F_OK: 0, R_OK: 4, W_OK: 2, X_OK: 1, UV_FS_COPYFILE_EXCL: 1, COPYFILE_EXCL: 1, UV_FS_COPYFILE_FICLONE: 2, COPYFILE_FICLONE: 2, UV_FS_COPYFILE_FICLONE_FORCE: 4, COPYFILE_FICLONE_FORCE: 4 }));
function fdHandle(fd) { var handle = fileDescriptors.get(Number(fd)); if (!handle || handle.closed) { var error = new Error('EBADF: bad file descriptor'); error.code = 'EBADF'; error.errno = -1; error.syscall = 'fd'; throw error; } return handle; } function fdInvoke(operation, fd, value) { fdHandle(fd); return invoke('fd_' + operation, String(fd), value === undefined ? '' : String(value)); } function fdPosition(value) { if (value === null || value === undefined || value === -1) return '-1'; if (!Number.isSafeInteger(Number(value)) || Number(value) < 0) throw new RangeError('Invalid file position'); return String(value); } function fdView(buffer) { buffer = bufferShape(buffer); if (!ArrayBuffer.isView(buffer)) throw new TypeError('buffer must be an ArrayBuffer view'); return new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength); } __thaw_fs.openSync = function(path, flags, mode) { return fsOpenHandle(path, flags, mode).fd; }; __thaw_fs.closeSync = function(fd) { var handle = fdHandle(fd); fdInvoke('close', fd); fileDescriptors.delete(handle.fd); handle.closed = true; handle.fd = -1; handle.emit('close'); }; __thaw_fs.readSync = function(fd, buffer, offset, length, position) { if (offset && typeof offset === 'object') { var options = offset; offset = options.offset; length = options.length; position = options.position; } var view = fdView(buffer); offset = offset === undefined ? 0 : Number(offset); length = length === undefined ? view.byteLength - offset : Number(length); if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(length) || offset < 0 || length < 0 || offset + length > view.byteLength) throw new RangeError('Invalid read range'); var source = Buffer.from(fdInvoke('read', fd, fdPosition(position) + ',' + length).data, 'hex'); view.set(source, offset); thawLastRead = source; return source.length; }; var thawLastRead = null; __thaw_fs.__thawTakeReadSync = function() { var taken = thawLastRead; thawLastRead = null; return taken || Buffer.alloc(0); }; __thaw_fs.writeSync = function(fd, value, offset, length, position) { var bytes; if (offset && typeof offset === 'object') { var writeOptions = offset; offset = writeOptions.offset; length = writeOptions.length; position = writeOptions.position; } if (typeof value === 'string') { var encodingName = typeof length === 'string' ? length : 'utf8'; position = offset; bytes = Buffer.from(value, encodingName); } else { var view = fdView(value); offset = offset === undefined ? 0 : Number(offset); length = length === undefined ? view.byteLength - offset : Number(length); if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(length) || offset < 0 || length < 0 || offset + length > view.byteLength) throw new RangeError('Invalid write range'); bytes = Buffer.from(view.subarray(offset, offset + length)); } return fdInvoke('write', fd, fdPosition(position) + ':' + bytes.toString('hex')).length; }; __thaw_fs.fstatSync = function(fd, options) { return new Stats(fdInvoke('stat', fd), Boolean(options && options.bigint)); }; __thaw_fs.ftruncateSync = function(fd, length) { length = length === undefined ? 0 : Number(length); if (!Number.isSafeInteger(length) || length < 0) throw new RangeError('Invalid truncate length'); fdInvoke('truncate', fd, length); }; __thaw_fs.fchmodSync = function(fd, mode) { fdInvoke('chmod', fd, fsMode({ mode: mode }, 0)); }; __thaw_fs.fchownSync = function(fd, uid, gid) { fdInvoke('chown', fd, String(uid) + ',' + String(gid)); }; __thaw_fs.futimesSync = function(fd, atime, mtime) { fdInvoke('utimes', fd, String(timeValue(atime)) + ',' + String(timeValue(mtime))); }; __thaw_fs.fsyncSync = function(fd) { fdInvoke('sync', fd); }; __thaw_fs.fdatasyncSync = function(fd) { fdInvoke('datasync', fd); }; __thaw_fs.readvSync = function(fd, buffers, position) { var views = buffers.map(fdView), total = 0, cursor = position === -1 ? null : position; for (var index = 0; index < views.length; index++) { var size = views[index].byteLength, count = __thaw_fs.readSync(fd, buffers[index], 0, size, cursor); total += count; if (cursor !== null && cursor !== undefined) cursor = Number(cursor) + count; if (count < size) break; } return total; }; __thaw_fs.writevSync = function(fd, buffers, position) { var views = buffers.map(fdView), total = 0, cursor = position === -1 ? null : position; for (var index = 0; index < views.length; index++) { var size = views[index].byteLength, count = __thaw_fs.writeSync(fd, buffers[index], 0, size, cursor); total += count; if (cursor !== null && cursor !== undefined) cursor = Number(cursor) + count; if (count < size) break; } return total; };;
function fsAbortSignal(options) { var signal = options && typeof options === 'object' ? options.signal : undefined; if (signal !== undefined && (signal === null || typeof signal !== 'object' || !('aborted' in signal))) { var error = new TypeError('The "options.signal" argument must be an AbortSignal'); error.code = 'ERR_INVALID_ARG_TYPE'; throw error; } return signal; } function fsAbortError(signal) { if (!signal || !signal.aborted) return null; var error = new Error('The operation was aborted'); error.name = 'AbortError'; error.code = 'ABORT_ERR'; error.cause = signal.reason; return error; } function snapshotBufferArgs(args) { return Array.prototype.map.call(args, function(value) { return Buffer.isBuffer(value) ? Buffer.from(value) : value; }); } function promised(method, abortIndex) { return function() { var input = arguments; return new Promise(function(resolve, reject) { var args, signal, entryError; try { args = snapshotBufferArgs(input); signal = abortIndex === undefined ? undefined : fsAbortSignal(args[abortIndex]); entryError = fsAbortError(signal); } catch (error) { reject(error); return; } queueMicrotask(function() { try { var error = entryError || fsAbortError(signal); if (error) throw error; resolve(method.apply(__thaw_fs, abortIndex === undefined ? args : args.concat([signal]))); } catch (error) { reject(error); } }); }); }; } __thaw_fs.promises = { access: promised(__thaw_fs.accessSync), open: function(path, flags) { return promised(function() { return new FileHandle(path, flags); })(); }, readFile: promised(__thaw_fs.readFileSync, 1), readdir: promised(__thaw_fs.readdirSync), opendir: promised(__thaw_fs.opendirSync), stat: promised(__thaw_fs.statSync), lstat: promised(function(path, options) { return statLookup('lstat', path, options, false); }), writeFile: function(path, value, options) { return path instanceof FileHandle ? path._trackOperation(function() { return fsWriteAsync(path, value, options, 'w'); }) : fsWriteAsync(path, value, options, 'w'); }, appendFile: function(path, value, options) { return path instanceof FileHandle ? path._trackOperation(function() { return fsWriteAsync(path, value, options, 'a'); }) : fsWriteAsync(path, value, options, 'a'); }, mkdir: promised(__thaw_fs.mkdirSync), unlink: promised(__thaw_fs.unlinkSync), rm: promised(__thaw_fs.rmSync), rmdir: promised(__thaw_fs.rmdirSync), rename: promised(__thaw_fs.renameSync), copyFile: promised(__thaw_fs.copyFileSync), cp: promised(__thaw_fs.cpSync), realpath: promised(__thaw_fs.realpathSync), mkdtemp: promised(__thaw_fs.mkdtempSync), statfs: promised(__thaw_fs.statfsSync), lutimes: promised(__thaw_fs.lutimesSync), truncate: promised(__thaw_fs.truncateSync) }; __thaw_fs.promises.mkdtempDisposable = function(prefix, options) { if (Buffer.isBuffer(prefix)) prefix = Buffer.from(prefix); return Promise.resolve().then(function() { var created = mkdtempCreated(prefix, options), path = created.path, rawPath = created.rawPath, removal, disposable = { path: path, remove: function() { if (!removal) removal = __thaw_fs.promises.rm(rawPath, { recursive: true, force: true }); return removal; } }; if (Symbol.asyncDispose) disposable[Symbol.asyncDispose] = disposable.remove; return disposable; }); }; function callbackMethod(method, valueResult, abortIndex) { return function() { var args = Array.prototype.slice.call(arguments), callback = args.pop(); if (typeof callback !== 'function') throw new TypeError('callback must be a function'); var signal, entryError; try { args = snapshotBufferArgs(args); signal = abortIndex === undefined ? undefined : fsAbortSignal(args[abortIndex]); entryError = fsAbortError(signal); } catch (error) { queueMicrotask(function() { callback(error); }); return; } queueMicrotask(function() { var value; try { var error = entryError || fsAbortError(signal); if (error) throw error; value = method.apply(__thaw_fs, abortIndex === undefined ? args : args.concat([signal])); } catch (error) { callback(error); return; } if (valueResult) callback(null, value); else callback(null); }); }; } __thaw_fs.readFile = callbackMethod(__thaw_fs.readFileSync, true, 1); __thaw_fs.readdir = callbackMethod(__thaw_fs.readdirSync, true); __thaw_fs.opendir = callbackMethod(__thaw_fs.opendirSync, true); __thaw_fs.stat = callbackMethod(__thaw_fs.statSync, true); __thaw_fs.lstat = callbackMethod(function(path, options) { return statLookup('lstat', path, options, false); }, true); __thaw_fs.writeFile = callbackMethod(__thaw_fs.writeFileSync, false, 2); __thaw_fs.appendFile = callbackMethod(__thaw_fs.appendFileSync, false, 2); __thaw_fs.mkdir = callbackMethod(__thaw_fs.mkdirSync, false); __thaw_fs.unlink = callbackMethod(__thaw_fs.unlinkSync, false); __thaw_fs.rm = callbackMethod(__thaw_fs.rmSync, false); __thaw_fs.rmdir = callbackMethod(__thaw_fs.rmdirSync, false); __thaw_fs.rename = callbackMethod(__thaw_fs.renameSync, false); __thaw_fs.copyFile = callbackMethod(__thaw_fs.copyFileSync, false); __thaw_fs.cp = callbackMethod(__thaw_fs.cpSync, false); __thaw_fs.realpath = callbackMethod(__thaw_fs.realpathSync, true); __thaw_fs.realpath.native = __thaw_fs.realpath; __thaw_fs.mkdtemp = callbackMethod(__thaw_fs.mkdtempSync, true);
FileHandle.prototype.utimes = function(atime, mtime) { var self = this; return Promise.resolve().then(function() { self._check(); __thaw_fs.futimesSync(self.fd, atime, mtime); }); }; FileHandle.prototype.chmod = function(mode) { var self = this; return Promise.resolve().then(function() { self._check(); __thaw_fs.fchmodSync(self.fd, mode); }); }; FileHandle.prototype.sync = function() { var self = this; return Promise.resolve().then(function() { self._check(); __thaw_fs.fsyncSync(self.fd); }); }; FileHandle.prototype.datasync = function() { var self = this; return Promise.resolve().then(function() { self._check(); __thaw_fs.fdatasyncSync(self.fd); }); }; FileHandle.prototype.chown = function(uid, gid) { var self = this; return Promise.resolve().then(function() { self._check(); __thaw_fs.fchownSync(self.fd, uid, gid); }); }; Object.assign(__thaw_fs.promises, { link: promised(__thaw_fs.linkSync), symlink: promised(__thaw_fs.symlinkSync), readlink: promised(__thaw_fs.readlinkSync), chmod: promised(__thaw_fs.chmodSync), utimes: promised(__thaw_fs.utimesSync), chown: promised(__thaw_fs.chownSync), lchown: promised(__thaw_fs.lchownSync) }); __thaw_fs.link = callbackMethod(__thaw_fs.linkSync, false); __thaw_fs.symlink = callbackMethod(__thaw_fs.symlinkSync, false); __thaw_fs.readlink = callbackMethod(__thaw_fs.readlinkSync, true); __thaw_fs.chmod = callbackMethod(__thaw_fs.chmodSync, false); __thaw_fs.utimes = callbackMethod(__thaw_fs.utimesSync, false); __thaw_fs.lutimes = callbackMethod(__thaw_fs.lutimesSync, false); __thaw_fs.chown = callbackMethod(__thaw_fs.chownSync, false); __thaw_fs.lchown = callbackMethod(__thaw_fs.lchownSync, false); __thaw_fs.access = callbackMethod(__thaw_fs.accessSync, false); __thaw_fs.statfs = callbackMethod(__thaw_fs.statfsSync, true); __thaw_fs.truncate = callbackMethod(__thaw_fs.truncateSync, false); __thaw_fs.open = callbackMethod(__thaw_fs.openSync, true); __thaw_fs.close = callbackMethod(__thaw_fs.closeSync, false); __thaw_fs.fstat = callbackMethod(__thaw_fs.fstatSync, true); __thaw_fs.ftruncate = callbackMethod(__thaw_fs.ftruncateSync, false); __thaw_fs.fchmod = callbackMethod(__thaw_fs.fchmodSync, false); __thaw_fs.fchown = callbackMethod(__thaw_fs.fchownSync, false); __thaw_fs.futimes = callbackMethod(__thaw_fs.futimesSync, false); __thaw_fs.fsync = callbackMethod(__thaw_fs.fsyncSync, false); __thaw_fs.fdatasync = callbackMethod(__thaw_fs.fdatasyncSync, false); __thaw_fs.read = function(fd, buffer) { var args = Array.prototype.slice.call(arguments), callback = args.pop(); if (typeof callback !== 'function') throw new TypeError('callback must be a function'); queueMicrotask(function() { var count; try { count = __thaw_fs.readSync.apply(__thaw_fs, args); } catch (error) { callback(error); return; } callback(null, count, buffer); }); }; __thaw_fs.write = function(fd, value, offset, length, position, callback) { var args = Array.prototype.slice.call(arguments), done = args.pop(); if (typeof done !== 'function') throw new TypeError('callback must be a function'); queueMicrotask(function() { var count; try { count = __thaw_fs.writeSync.apply(__thaw_fs, args); } catch (error) { done(error); return; } done(null, count, value); }); }; FileHandle.prototype.statfs = function(options) { var self = this; return Promise.resolve().then(function() { self._check(); return new StatFs(fdInvoke('statfs', self.fd), Boolean(options && options.bigint)); }); }; FileHandle.prototype.readv = function(buffers, position) { var self = this; return Promise.resolve().then(function() { self._check(); return { bytesRead: __thaw_fs.readvSync(self.fd, buffers, position), buffers: buffers }; }); }; FileHandle.prototype.writev = function(buffers, position) { var self = this; return Promise.resolve().then(function() { self._check(); return { bytesWritten: __thaw_fs.writevSync(self.fd, buffers, position), buffers: buffers }; }); }; __thaw_fs.readv = function(fd, buffers, position, callback) { if (typeof position === 'function') { callback = position; position = null; } if (typeof callback !== 'function') throw new TypeError('callback must be a function'); queueMicrotask(function() { var count; try { count = __thaw_fs.readvSync(fd, buffers, position); } catch (error) { callback(error); return; } callback(null, count, buffers); }); }; __thaw_fs.writev = function(fd, buffers, position, callback) { if (typeof position === 'function') { callback = position; position = null; } if (typeof callback !== 'function') throw new TypeError('callback must be a function'); queueMicrotask(function() { var count; try { count = __thaw_fs.writevSync(fd, buffers, position); } catch (error) { callback(error); return; } callback(null, count, buffers); }); };;
['readFile','writeFile','appendFile','read','write','stat','truncate','utimes','chmod','sync','datasync','chown','statfs','readv','writev'].forEach(function(name) { var original = FileHandle.prototype[name]; FileHandle.prototype[name] = function() { var self = this, args = arguments; return this._trackOperation(function() { return original.apply(self, args); }); }; });
function watchSnapshot(path, recursive, prefix, output) { output = output || Object.create(null); prefix = prefix || Buffer.alloc(0); var stats = __thaw_fs.statSync(path); if (!stats.isDirectory()) { var bytes = cpBytes(path), slash = bytes.lastIndexOf(47), name = prefix.length ? prefix : bytes.subarray(slash + 1); output[name.toString('hex')] = { name: name, signature: String(stats.size) + ':' + String(stats.mtimeMs) }; return output; } __thaw_fs.readdirSync(path, { withFileTypes: true, encoding: 'buffer' }).forEach(function(entry) { var name = prefix.length ? Buffer.concat([prefix, Buffer.from('/'), entry.name]) : entry.name, full = entry._rawPath, value; try { value = __thaw_fs.statSync(full); } catch (error) { if (error && error.code === 'ENOENT') return; throw error; } output[name.toString('hex')] = { name: name, signature: String(value.size) + ':' + String(value.mtimeMs) }; if (recursive && value.isDirectory() && !entry.isSymbolicLink()) watchSnapshot(full, true, name, output); }); return output; } function watchLog() { if (typeof console !== 'undefined' && typeof process !== 'undefined' && process.env && process.env.THAW_FS_WATCH_DEBUG) console.error.apply(console, ['[fswatch]'].concat([].slice.call(arguments))); } function FSWatcher(path, options, listener) { var watchedPath = Buffer.isBuffer(path) ? Buffer.from(path) : pathValue(path); this.path = Buffer.isBuffer(watchedPath) ? Buffer.from(watchedPath) : watchedPath; this.closed = false; this._refed = options.persistent !== false; this._listeners = { change: [], error: [], close: [] }; if (typeof listener === 'function') this.on('change', listener); this._options = options; this._snapshot = watchSnapshot(watchedPath, Boolean(options.recursive)); var self = this; watchLog('open', String(watchedPath), 'keys', Object.keys(this._snapshot).length); this._timer = setInterval(function() { if (self.closed) return; var current; try { current = watchSnapshot(watchedPath, Boolean(options.recursive)); } catch (error) { watchLog('snapshot-error', error && error.code, error && error.message); if (error && error.code === 'ENOENT') { clearInterval(self._timer); self._timer = null; watchLog('enoent-rename', String(watchedPath)); var bytes = cpBytes(watchedPath), base = bytes.subarray(bytes.lastIndexOf(47) + 1); self.emit('change', 'rename', options.encoding === 'buffer' ? Buffer.from(base) : base.toString(options.encoding || 'utf8')); return; } self.emit('error', error); self.close(); return; } watchLog('tick', String(watchedPath), 'keys', Object.keys(current).length); var previous = self._snapshot, names = Object.keys(Object.assign({}, previous, current)); try { names.forEach(function(name) { var entry = current[name] || previous[name], filename = options.encoding === 'buffer' ? Buffer.from(entry.name) : entry.name.toString(options.encoding || 'utf8'); if (!(name in previous) || !(name in current)) self.emit('change', 'rename', filename); else if (previous[name].signature !== current[name].signature) self.emit('change', 'change', filename); }); } catch (error) { watchLog('emit-throw', error && (error.stack || error)); throw error; } self._snapshot = current; }, Math.max(1, Number(options.interval || 50))); if (!this._refed) this._timer.unref(); this._signal = options.signal; this._abort = function() { self.close(); }; if (this._signal) { if (this._signal.aborted) this.close(); else this._signal.addEventListener('abort', this._abort, { once: true }); } } FSWatcher.prototype.on = FSWatcher.prototype.addListener = function(event, listener) { (this._listeners[event] || (this._listeners[event] = [])).push(listener); return this; }; FSWatcher.prototype.once = function(event, listener) { var self = this, wrapped = function() { self.removeListener(event, wrapped); return listener.apply(self, arguments); }; return this.on(event, wrapped); }; FSWatcher.prototype.removeListener = function(event, listener) { if (this._listeners[event]) this._listeners[event] = this._listeners[event].filter(function(value) { return value !== listener; }); return this; }; FSWatcher.prototype.emit = function(event) { var args = Array.prototype.slice.call(arguments, 1), self = this; (this._listeners[event] || []).slice().forEach(function(listener) { listener.apply(self, args); }); return Boolean((this._listeners[event] || []).length); }; FSWatcher.prototype.close = function() { if (!this.closed) { this.closed = true; watchLog('close', String(this.path), new Error('close').stack); clearInterval(this._timer); this._timer = null; if (this._signal) this._signal.removeEventListener('abort', this._abort); this.emit('close'); } return this; }; FSWatcher.prototype.ref = function() { this._refed = true; if (this._timer) this._timer.ref(); return this; }; FSWatcher.prototype.unref = function() { this._refed = false; if (this._timer) this._timer.unref(); return this; }; FSWatcher.prototype.hasRef = function() { return this._refed; }; __thaw_fs.FSWatcher = FSWatcher; __thaw_fs.watch = function(path, options, listener) { if (typeof options === 'function') { listener = options; options = {}; } else if (typeof options === 'string') options = { encoding: options }; return new FSWatcher(path, options || {}, listener); };
function globExpandBraces(pattern) {
  var results = [];
  function expand(value, from) {
    for (var open = value.indexOf('{', from); open >= 0; open = value.indexOf('{', open + 1)) {
      var depth = 0, close = -1;
      for (var i = open; i < value.length; i++) {
        if (value[i] === '{') depth++;
        else if (value[i] === '}' && --depth === 0) { close = i; break; }
      }
      if (close < 0) break;
      var inside = value.slice(open + 1, close), pieces = [], start = 0;
      depth = 0;
      for (var j = 0; j < inside.length; j++) {
        if (inside[j] === '{') depth++;
        else if (inside[j] === '}') depth--;
        else if (inside[j] === ',' && depth === 0) { pieces.push(inside.slice(start, j)); start = j + 1; }
      }
      if (pieces.length) pieces.push(inside.slice(start));
      else {
        var numbers = /^(-?\d+)\.\.(-?\d+)(?:\.\.(-?\d+))?$/.exec(inside);
        var letters = /^([A-Za-z])\.\.([A-Za-z])(?:\.\.(-?\d+))?$/.exec(inside);
        if (numbers || letters) {
          var first = numbers ? Number(numbers[1]) : letters[1].charCodeAt(0);
          var last = numbers ? Number(numbers[2]) : letters[2].charCodeAt(0);
          var step = Math.abs(Number((numbers || letters)[3] || 1));
          if (step && Number.isSafeInteger(first) && Number.isSafeInteger(last)) {
            for (var n = first; first <= last ? n <= last : n >= last; n += first <= last ? step : -step) {
              var item = numbers ? String(n) : String.fromCharCode(n);
              if (numbers && [numbers[1], numbers[2]].some(function(endpoint) { return /^-?0\d/.test(endpoint); })) item = (n < 0 ? '-' : '') + String(Math.abs(n)).padStart(Math.max(numbers[1].replace(/^-/, '').length, numbers[2].replace(/^-/, '').length), '0');
              pieces.push(item);
              if (pieces.length > 10000) throw new RangeError('Glob brace expansion is too large');
            }
          }
        }
      }
      if (!pieces.length) continue;
      for (var part of pieces) expand(value.slice(0, open) + part + value.slice(close + 1), open);
      return;
    }
    results.push(value);
    if (results.length > 10000) throw new RangeError('Glob brace expansion is too large');
  }
  expand(String(pattern), 0);
  return results;
}
function globParseSegment(segment) {
  var nextId = 0;
  function parse(index, nested) {
    var tokens = [];
    tokens.id = ++nextId;
    while (index < segment.length) {
      var char = segment[index];
      if (nested && (char === '|' || char === ')')) break;
      if ('@?!+*'.indexOf(char) >= 0 && segment[index + 1] === '(') {
        var mode = char, alternatives = [];
        index += 2;
        while (true) {
          var child = parse(index, true);
          alternatives.push(child.tokens);
          index = child.index;
          if (segment[index] === '|') { index++; continue; }
          if (segment[index] === ')') { index++; break; }
          throw new TypeError('Unclosed glob extglob');
        }
        tokens.push({ kind: 'ext', mode: mode, alternatives: alternatives });
      } else if (char === '[') {
        var end = index + 1;
        while (end < segment.length) {
          if (segment.slice(end, end + 2) === '[:') {
            var namedEnd = segment.indexOf(':]', end + 2);
            if (namedEnd >= 0) { end = namedEnd + 2; continue; }
          }
          if (segment[end] === ']' && end > index + 1) break;
          end++;
        }
        if (end === segment.length) end = -1;
        if (end < 0) { tokens.push({ kind: 'literal', value: char }); index++; }
        else { tokens.push({ kind: 'class', value: segment.slice(index + 1, end) }); index = end + 1; }
      } else if (char === '*') { tokens.push({ kind: 'star' }); index++; }
      else if (char === '?') { tokens.push({ kind: 'any' }); index++; }
      else { tokens.push({ kind: 'literal', value: char }); index++; }
    }
    return { tokens: tokens, index: index };
  }
  return parse(0, false).tokens;
}
function globNamedClass(name, char) {
  switch (name) {
    case 'alnum': return /^[\p{L}\p{Nl}\p{Nd}]$/u.test(char);
    case 'alpha': return /^[\p{L}\p{Nl}]$/u.test(char);
    case 'ascii': return /^[\x00-\x7f]$/.test(char);
    case 'blank': return /^[\p{Zs}\t]$/u.test(char);
    case 'cntrl': return /^\p{Cc}$/u.test(char);
    case 'digit': return /^\p{Nd}$/u.test(char);
    case 'graph': return !/[\p{Z}\p{C}]/u.test(char);
    case 'lower': return /^\p{Ll}$/u.test(char);
    case 'print': return !/\p{C}/u.test(char);
    case 'punct': return /^\p{P}$/u.test(char);
    case 'space': return /^[\p{Z}\t\r\n\v\f]$/u.test(char);
    case 'upper': return /^\p{Lu}$/u.test(char);
    case 'word': return /^[\p{L}\p{Nl}\p{Nd}\p{Pc}]$/u.test(char);
    case 'xdigit': return /^[A-Fa-f0-9]$/.test(char);
    default: return false;
  }
}
function globClassMatches(body, char) {
  var negative = body[0] === '!' || body[0] === '^', index = negative ? 1 : 0, matches = false;
  for (; index < body.length; index++) {
    if (body.slice(index, index + 2) === '[:') {
      var end = body.indexOf(':]', index + 2);
      if (end >= 0) { if (globNamedClass(body.slice(index + 2, end), char)) matches = true; index = end + 1; continue; }
    }
    if (index + 2 < body.length && body[index + 1] === '-') {
      if (body[index] <= char && char <= body[index + 2]) matches = true;
      index += 2;
    } else if (body[index] === char) matches = true;
  }
  return negative ? !matches : matches;
}
function globSegmentMatches(tokens, name) {
  if (name[0] === '.' && !(tokens[0] && tokens[0].kind === 'literal' && tokens[0].value === '.')) return false;
  var memo = Object.create(null);
  function ends(sequence, tokenIndex, position) {
    var key = sequence.id + ':' + tokenIndex + ':' + position;
    if (memo[key]) return memo[key];
    if (tokenIndex === sequence.length) return memo[key] = [position];
    var token = sequence[tokenIndex], candidates = [];
    if (token.kind === 'literal') { if (name[position] === token.value) candidates.push(position + 1); }
    else if (token.kind === 'any') { if (position < name.length) candidates.push(position + (name.codePointAt(position) > 0xffff ? 2 : 1)); }
    else if (token.kind === 'class') { if (position < name.length) { var point = String.fromCodePoint(name.codePointAt(position)); if (globClassMatches(token.value, point)) candidates.push(position + point.length); } }
    else if (token.kind === 'star') { for (var i = position; i <= name.length; i++) candidates.push(i); }
    else {
      var direct = [], seen = Object.create(null);
      for (var alternative of token.alternatives) for (var end of ends(alternative, 0, position)) if (!seen[end]) { seen[end] = true; direct.push(end); }
      if (token.mode === '@') candidates = direct;
      else if (token.mode === '?') candidates = [position].concat(direct);
      else if (token.mode === '!') {
        for (var end = position; end <= name.length; end++) {
          var equal = false;
          for (var alternative of token.alternatives) if (ends(alternative, 0, position).indexOf(end) >= 0) { equal = true; break; }
          if (!equal) candidates.push(end);
        }
      } else {
        var queue = token.mode === '*' ? [position] : direct.slice(), visited = Object.create(null);
        while (queue.length) {
          var current = queue.shift();
          if (visited[current]) continue;
          visited[current] = true;
          candidates.push(current);
          for (var alternative of token.alternatives) for (var next of ends(alternative, 0, current)) if (next !== current && !visited[next]) queue.push(next);
        }
      }
    }
    var output = [], unique = Object.create(null);
    for (var candidate of candidates) for (var ending of ends(sequence, tokenIndex + 1, candidate)) if (!unique[ending]) { unique[ending] = true; output.push(ending); }
    return memo[key] = output;
  }
  return ends(tokens, 0, 0).indexOf(name.length) >= 0;
}
function globParts(pattern) {
  return String(pattern).replace(/\\/g, '/').split('/').filter(function(part) { return part && part !== '.'; });
}
function globCompileParts(parts) {
  return parts.map(function(part) { return part === '**' ? { globstar: true } : { tokens: globParseSegment(part) }; });
}
function globPathMatches(pattern, value, prefix) {
  var memo = Object.create(null);
  function match(pi, vi) {
    var key = pi + ':' + vi;
    if (key in memo) return memo[key];
    if (vi === value.length) return memo[key] = prefix ? pi < pattern.length : pattern.slice(pi).every(function(part) { return part.globstar; });
    if (pi === pattern.length) return memo[key] = false;
    if (pattern[pi].globstar) return memo[key] = match(pi + 1, vi) || (value[vi][0] !== '.' && match(pi, vi + 1));
    return memo[key] = globSegmentMatches(pattern[pi].tokens, value[vi]) && match(pi + 1, vi + 1);
  }
  return match(0, 0);
}
function globSpecs(pattern, cwd, rawCwd) {
  var output = [];
  for (var expanded of globExpandBraces(pattern)) {
    var absolute = expanded[0] === '/', parts = globParts(expanded), parents = [];
    if (!absolute) while (parts[0] === '..') { parents.push(parts.shift()); }
    if (!parts.length) continue;
    var display = absolute ? '/' : parents.join('/');
    var root = absolute ? '/' : cpNormalize(cwd.replace(/[/]$/, '') + '/' + parents.join('/'));
    var rawRoot = !absolute && rawCwd ? Buffer.from(cpNormalize((rawCwd.length ? rawCwd.toString('latin1') : '/') + '/' + parents.join('/')), 'latin1') : null; output.push({ root: root, rawRoot: rawRoot, display: display, pattern: globCompileParts(parts) });
  }
  return output;
}
function globJoin(prefix, name) { return prefix === '/' ? '/' + name : prefix ? prefix + '/' + name : name; }
function globExcluded(record, exclusions, callback, withFileTypes) {
  if (callback && callback(withFileTypes ? record.entry : record.name)) return true;
  var parts = globParts(record.full);
  return exclusions.some(function(pattern) { return globPathMatches(pattern, parts, false); });
}
function globWalk(spec, relative, output, seen, exclusions, callback, withFileTypes, rawDirectory) {
  var directory = relative ? globJoin(spec.root, relative) : spec.root, entries;
  try { entries = __thaw_fs.readdirSync(rawDirectory || spec.rawRoot || directory, { withFileTypes: true }); }
  catch (error) { if (error.code === 'ENOENT' || error.code === 'ENOTDIR') return; throw error; }
  entries.forEach(function(entry) {
    var relativeName = relative ? relative + '/' + entry.name : entry.name;
    var name = globJoin(spec.display, relativeName), record = { name: name, full: globJoin(directory, entry.name), entry: entry };
    if (globExcluded(record, exclusions, callback, withFileTypes)) return;
    var parts = globParts(relativeName);
    var identity = entry._rawPath ? entry._rawPath.toString('hex') : name; if (globPathMatches(spec.pattern, parts, false) && !seen[identity]) { seen[identity] = true; output.push(withFileTypes ? entry : name); }
    if (entry.isDirectory() && globPathMatches(spec.pattern, parts, true)) globWalk(spec, relativeName, output, seen, exclusions, callback, withFileTypes, entry._rawPath);
  });
}
__thaw_fs.globSync = function(patterns, options) {
  options = options || {};
  patterns = Array.isArray(patterns) ? patterns : [patterns];
  var rawCwd = Buffer.isBuffer(options.cwd) ? Buffer.from(cpAbsoluteBytes(options.cwd)) : null, cwd = rawCwd ? rawCwd.toString('utf8') : pathValue(options.cwd || process.cwd()), output = [], seen = Object.create(null), exclusions = [], callback = typeof options.exclude === 'function' ? options.exclude : null;
  if (cwd[0] !== '/') cwd = cpNormalize(process.cwd() + '/' + cwd);
  if (!callback && options.exclude) for (var excluded of Array.isArray(options.exclude) ? options.exclude : [options.exclude]) for (var excludeSpec of globSpecs(excluded, cwd, rawCwd)) exclusions.push(globCompileParts(globParts(excludeSpec.root)).concat(excludeSpec.pattern));
  for (var pattern of patterns) for (var spec of globSpecs(pattern, cwd, rawCwd)) globWalk(spec, '', output, seen, exclusions, callback, Boolean(options.withFileTypes));
  return output;
};
__thaw_fs.glob = function(patterns, options, callback) {
  if (typeof options === 'function') { callback = options; options = {}; }
  if (typeof callback !== 'function') throw new TypeError('callback must be a function');
  if (options && Buffer.isBuffer(options.cwd)) options = Object.assign({}, options, { cwd: Buffer.from(options.cwd) });
  queueMicrotask(function() { var values; try { values = __thaw_fs.globSync(patterns, options); } catch (error) { callback(error); return; } callback(null, values); });
};
__thaw_fs.promises.glob = function(patterns, options) {
  if (options && Buffer.isBuffer(options.cwd)) options = Object.assign({}, options, { cwd: Buffer.from(options.cwd) });
  var values, index = 0;
  return { [Symbol.asyncIterator]: function() { return this; }, next: function() { return Promise.resolve().then(function() { if (!values) values = __thaw_fs.globSync(patterns, options); return index < values.length ? { value: values[index++], done: false } : { value: undefined, done: true }; }); } };
};
__thaw_fs.promises.watch = function(path, options) { options = options || {}; var queue = [], waiters = [], closed = false, failure, watchOptions = Object.assign({}, options); delete watchOptions.signal; var watcher = __thaw_fs.watch(path, watchOptions, function(eventType, filename) { var value = { eventType: eventType, filename: filename }; if (waiters.length) waiters.shift().resolve({ value: value, done: false }); else queue.push(value); }); function finish(error) { if (closed) return; closed = true; failure = error; queue.length = 0; if (signal) signal.removeEventListener('abort', abort); watcher.close(); while (waiters.length) { var waiter = waiters.shift(); error ? waiter.reject(error) : waiter.resolve({ value: undefined, done: true }); } } watcher.on('error', function(error) { finish(error); }); var signal = options.signal; var abort; if (signal) { abort = function() { var error = new DOMException('The operation was aborted', 'AbortError'); error.cause = signal.reason; finish(error); }; if (signal.aborted) abort(); else signal.addEventListener('abort', abort, { once: true }); } return { [Symbol.asyncIterator]: function() { return this; }, next: function() { if (failure) return Promise.reject(failure); if (closed) return Promise.resolve({ value: undefined, done: true }); if (queue.length) return Promise.resolve({ value: queue.shift(), done: false }); return new Promise(function(resolve, reject) { waiters.push({ resolve: resolve, reject: reject }); }); }, return: function() { finish(); return Promise.resolve({ value: undefined, done: true }); }, throw: function(error) { finish(error); return Promise.reject(error); } }; };
function cpError(path) { var shown = Buffer.isBuffer(path) ? path.toString() : String(path), detail = shown + ' already exists', error = new Error('Target already exists: cp returned EEXIST (' + detail + ') ' + shown); Object.defineProperty(error, 'name', { value: 'SystemError', configurable: true, writable: true }); error.code = 'ERR_FS_CP_EEXIST'; error.info = { code: 'EEXIST', message: detail, path: shown, syscall: 'cp', errno: 17 }; error.errno = 17; error.syscall = 'cp'; error.path = shown; return error; } function cpInvalid(message) { var error = new Error(message); error.code = 'ERR_FS_CP_EINVAL'; return error; } function cpSame(path) { return cpInvalid('src and dest cannot be the same ' + (Buffer.isBuffer(path) ? path.toString() : String(path))); } function cpSelf(source, destination) { return cpInvalid('Cannot copy ' + (Buffer.isBuffer(source) ? source.toString() : String(source)) + '/ to a subdirectory of self ' + (Buffer.isBuffer(destination) ? destination.toString() : String(destination))); } function cpDirectoryError(path) { var error = new Error('ERR_FS_EISDIR: recursive option is required, cp ' + path); error.code = 'ERR_FS_EISDIR'; error.path = path; error.syscall = 'cp'; return error; } function cpBytes(path) { return Buffer.isBuffer(path) ? path : Buffer.from(pathValue(path)); } function cpAbsoluteBytes(path) { var bytes = cpBytes(path); return bytes[0] === 47 ? bytes : Buffer.concat([Buffer.from(process.cwd() + '/'), bytes]); } function cpCompare(path) { return cpNormalize(cpAbsoluteBytes(path).toString('latin1')); } function cpJoin(path, name) { if (!Buffer.isBuffer(path) && !Buffer.isBuffer(name)) return pathValue(path).replace(/[/]$/, '') + '/' + name; var base = cpBytes(path); if (base.length && base[base.length - 1] === 47) base = base.subarray(0, base.length - 1); return Buffer.concat([base, Buffer.from('/'), cpBytes(name)]); } function cpParent(path) { var slash = Buffer.isBuffer(path) ? path.lastIndexOf(47) : path.lastIndexOf('/'); return slash > 0 ? path.slice(0, slash) : slash === 0 ? (Buffer.isBuffer(path) ? Buffer.from('/') : '/') : '.'; } function cpNormalize(path) { var absolute = path.charAt(0) === '/', values = []; path.split('/').forEach(function(part) { if (!part || part === '.') return; if (part === '..') values.pop(); else values.push(part); }); return (absolute ? '/' : '') + values.join('/'); } function cpEnsureParent(path) { var parent = cpParent(path); if (parent && parent !== '.' && !__thaw_fs.existsSync(parent)) __thaw_fs.mkdirSync(parent, { recursive: true }); } function cpPrepare(destination, directory, options, keepRegular, source) { if (!__thaw_fs.existsSync(destination)) return true; var current = __thaw_fs.lstatSync(destination); if (directory !== current.isDirectory()) { var shownDestination = Buffer.isBuffer(destination) ? destination.toString() : String(destination), shownSource = Buffer.isBuffer(source) ? source.toString() : String(source), mismatch = new Error(directory ? 'Cannot overwrite non-directory ' + shownDestination + ' with directory ' + shownSource : 'Cannot overwrite directory ' + shownDestination + ' with non-directory ' + shownSource); mismatch.code = directory ? 'ERR_FS_CP_DIR_TO_NON_DIR' : 'ERR_FS_CP_NON_DIR_TO_DIR'; throw mismatch; } if (directory) { if (options.force === false && options.errorOnExist) throw cpError(destination); return true; } if (options.force === false) { if (options.errorOnExist) throw cpError(destination); return false; } if (keepRegular && current.isFile()) return true; __thaw_fs.rmSync(destination, { recursive: true, force: true }); return true; } function cpPreserve(sourceStats, destination, options) { if (options.preserveTimestamps) __thaw_fs.utimesSync(destination, sourceStats.atime, sourceStats.mtime); } function cpLinkTarget(source, options) { var target = __thaw_fs.readlinkSync(source, { encoding: 'buffer' }); if (options.verbatimSymlinks || target[0] === 47) return target; return Buffer.from(cpNormalize(cpJoin(cpParent(cpAbsoluteBytes(source)), target).toString('latin1')), 'latin1'); } function cpNodeSync(source, destination, options, ancestors) { source = Buffer.isBuffer(source) ? Buffer.from(source) : pathValue(source); destination = Buffer.isBuffer(destination) ? Buffer.from(destination) : pathValue(destination); if (cpCompare(source) === cpCompare(destination)) throw cpSame(destination); if (typeof options.filter === 'function') { var allowed = options.filter(pathValue(source), pathValue(destination)); if (allowed && typeof allowed.then === 'function') throw new TypeError('fs.cpSync filter must return a boolean'); if (!allowed) return; } var stats = options.dereference ? __thaw_fs.statSync(source) : __thaw_fs.lstatSync(source); if (invoke('copy_guard', source, destination, Boolean(options.dereference)).unsafe) throw cpSelf(source, destination); if (stats.isSymbolicLink() && !options.dereference) { if (!cpPrepare(destination, false, options, false, source)) return; cpEnsureParent(destination); __thaw_fs.symlinkSync(cpLinkTarget(source, options), destination); return; } if (stats.isDirectory()) { if (!options.recursive) throw cpDirectoryError(source); var identity = __thaw_fs.realpathSync(source, { encoding: 'buffer' }).toString('hex'); if (ancestors && ancestors.indexOf(identity) >= 0) throw cpSelf(source, destination); var childAncestors = (ancestors || []).concat(identity); if (!cpPrepare(destination, true, options, false, source)) return; var created = !__thaw_fs.existsSync(destination) && __thaw_fs.mkdirSync(destination, { recursive: true }) !== undefined; try { __thaw_fs.readdirSync(source, { encoding: 'buffer' }).forEach(function(name) { cpNodeSync(cpJoin(source, name), cpJoin(destination, name), options, childAncestors); }); cpPreserve(stats, destination, options); } finally { if (created) __thaw_fs.chmodSync(destination, Number(stats.mode) & 4095); } return; } if (!cpPrepare(destination, false, options, true, source)) return; cpEnsureParent(destination); __thaw_fs.copyFileSync(source, destination); cpPreserve(stats, destination, options); } __thaw_fs.cpSync = function(source, destination, options) { cpNodeSync(source, destination, options || {}); }; function cpNodeAsync(source, destination, options, ancestors) { source = Buffer.isBuffer(source) ? Buffer.from(source) : pathValue(source); destination = Buffer.isBuffer(destination) ? Buffer.from(destination) : pathValue(destination); if (cpCompare(source) === cpCompare(destination)) return Promise.reject(cpSame(destination)); var filtered = typeof options.filter === 'function' ? Promise.resolve().then(function() { return options.filter(pathValue(source), pathValue(destination)); }) : Promise.resolve(true); return filtered.then(function(allowed) { if (!allowed) return; var stats = options.dereference ? __thaw_fs.statSync(source) : __thaw_fs.lstatSync(source); if (invoke('copy_guard', source, destination, Boolean(options.dereference)).unsafe) throw cpSelf(source, destination); if (stats.isSymbolicLink() && !options.dereference) { if (!cpPrepare(destination, false, options, false, source)) return; cpEnsureParent(destination); __thaw_fs.symlinkSync(cpLinkTarget(source, options), destination); return; } if (stats.isDirectory()) { if (!options.recursive) throw cpDirectoryError(source); var identity = __thaw_fs.realpathSync(source, { encoding: 'buffer' }).toString('hex'); if (ancestors && ancestors.indexOf(identity) >= 0) throw cpSelf(source, destination); var childAncestors = (ancestors || []).concat(identity); if (!cpPrepare(destination, true, options, false, source)) return; var created = !__thaw_fs.existsSync(destination) && __thaw_fs.mkdirSync(destination, { recursive: true }) !== undefined; return Promise.resolve().then(function() { return __thaw_fs.readdirSync(source, { encoding: 'buffer' }).reduce(function(chain, name) { return chain.then(function() { return cpNodeAsync(cpJoin(source, name), cpJoin(destination, name), options, childAncestors); }); }, Promise.resolve()); }).then(function() { cpPreserve(stats, destination, options); }).finally(function() { if (created) __thaw_fs.chmodSync(destination, Number(stats.mode) & 4095); }); } if (!cpPrepare(destination, false, options, true, source)) return; cpEnsureParent(destination); __thaw_fs.copyFileSync(source, destination); cpPreserve(stats, destination, options); }); } __thaw_fs.promises.cp = function(source, destination, options) { return cpNodeAsync(source, destination, options || {}); }; __thaw_fs.cp = function(source, destination, options, callback) { if (typeof options === 'function') { callback = options; options = {}; } if (typeof callback !== 'function') throw new TypeError('callback must be a function'); cpNodeAsync(source, destination, options || {}).then(function() { callback(null); }, callback); };
function streamPosition(value, name) { if (typeof value !== 'number') { var typeError = new TypeError('Invalid stream ' + name); typeError.code = 'ERR_INVALID_ARG_TYPE'; throw typeError; } if (!Number.isSafeInteger(value) || value < 0) { var rangeError = new RangeError('Invalid stream ' + name); rangeError.code = 'ERR_OUT_OF_RANGE'; throw rangeError; } return value; } ReadStream = function ReadStream(path, options) { if (!(this instanceof ReadStream)) return new ReadStream(path, options); options = options || {}; stream.Readable.call(this, options); var openPath = Buffer.isBuffer(path) ? Buffer.from(path) : pathValue(path); this.path = Buffer.isBuffer(openPath) ? Buffer.from(openPath) : openPath; this.pending = true; this.fd = options.fd === undefined ? null : Number(options.fd); this.bytesRead = 0; this._position = options.start === undefined ? null : streamPosition(options.start, 'start'); this._explicitStart = options.start !== undefined; this._autoClose = options.autoClose !== false; this._end = options.end === undefined || options.end === Infinity ? Infinity : streamPosition(options.end, 'end'); if (this._position !== null && this._position > this._end) { var rangeError = new RangeError('Invalid stream start'); rangeError.code = 'ERR_OUT_OF_RANGE'; throw rangeError; } this._chunkSize = Math.max(1, Number(options.highWaterMark || 65536)); this.close = this.destroy.bind(this); if (options.encoding) this.setEncoding(options.encoding); var self = this; queueMicrotask(function() { if (self.destroyed) return; try { if (self.fd === null) self.fd = fsOpenHandle(openPath, options.flags === undefined ? 'r' : options.flags, options.mode).fd; else fdHandle(self.fd); if (self._position === null) self._position = fdInvoke('tell', self.fd).position; self.pending = false; self.emit('open', self.fd); self.emit('ready'); self._read(); } catch (error) { self.pending = false; self.destroy(error); } }); if (options.signal) stream.addAbortSignal(options.signal, this); }; ReadStream.prototype = Object.create(stream.Readable.prototype); ReadStream.prototype.constructor = ReadStream; ReadStream.prototype._read = function() { if (this.pending || this.destroyed || this.readableEnded || this._reading) return; var self = this; this._reading = true; queueMicrotask(function() { self._reading = false; if (self.destroyed || self.readableEnded) return; try { if (self._position > self._end) { self.push(null); return; } var length = Math.min(self._chunkSize, self._end === Infinity ? self._chunkSize : self._end - self._position + 1), buffer = Buffer.alloc(length), count = __thaw_fs.readSync(self.fd, buffer, 0, length, optionsStart(self)); if (!count) { self.push(null); return; } self._position += count; self.bytesRead += count; if (self.push(buffer.subarray(0, count)) && self.readableFlowing === true) self._read(); } catch (error) { self.destroy(error); } }); }; function optionsStart(reader) { return reader._explicitStart ? reader._position : null; } ReadStream.prototype._destroy = function(error, callback) { if (this.fd !== null && this._autoClose !== false) { try { __thaw_fs.closeSync(this.fd); } catch (closeError) { if (!error) error = closeError; } this.fd = null; } callback(error); }; WriteStream = function WriteStream(path, options) { if (!(this instanceof WriteStream)) return new WriteStream(path, options); options = options || {}; initializeWriteQueue(this, options.highWaterMark); var openPath = Buffer.isBuffer(path) ? Buffer.from(path) : pathValue(path); this.path = Buffer.isBuffer(openPath) ? Buffer.from(openPath) : openPath; this.pending = true; this.fd = options.fd === undefined ? null : Number(options.fd); this.bytesWritten = 0; this._position = options.start === undefined ? null : streamPosition(options.start, 'start'); this._flags = flagsValue(options.flags, 'w'); this._autoClose = options.autoClose !== false; var self = this; stream.Writable.call(this, { highWaterMark: options.highWaterMark, defaultEncoding: options.encoding, write: function(chunk, encoding, callback) { queueMicrotask(function() { try { if (self.pending) throw new Error('File stream is not open'); var cursor = 0; while (cursor < chunk.length) { var count = __thaw_fs.writeSync(self.fd, chunk, cursor, chunk.length - cursor, self._position); if (!count) throw new Error('File write returned zero bytes'); cursor += count; if (self._position !== null) self._position += count; self.bytesWritten += count; } callback(); } catch (error) { callback(error); } }); }, final: function(callback) { queueMicrotask(function() { if (self.destroyed || self.pending) { callback(new Error('File stream is not open')); return; } if (self._autoClose && self.fd !== null) { try { __thaw_fs.closeSync(self.fd); self.fd = null; } catch (error) { callback(error); return; } } callback(); }); } }); queueMicrotask(function() { if (self.destroyed) return; try { if (self.fd === null) self.fd = fsOpenHandle(openPath, options.flags === undefined ? 'w' : options.flags, options.mode).fd; else fdHandle(self.fd); self.pending = false; self.emit('open', self.fd); self.emit('ready'); } catch (error) { self.pending = false; self.destroy(error); } }); if (options.signal) stream.addAbortSignal(options.signal, this); }; WriteStream.prototype = Object.create(stream.Writable.prototype); WriteStream.prototype.constructor = WriteStream; WriteStream.prototype._destroy = function(error, callback) { if (this.fd !== null && (this._autoClose || this._fsCloseRequested)) { try { __thaw_fs.closeSync(this.fd); } catch (closeError) { if (!error) error = closeError; } this.fd = null; } callback(error); }; WriteStream.prototype.close = function(callback) { var self = this; this._fsCloseRequested = true; if (this.destroyed && this.fd !== null) { try { __thaw_fs.closeSync(this.fd); } catch (error) { this.errored = error; } this.fd = null; } if (typeof callback === 'function') { if (this.closed) queueMicrotask(function() { callback(self.errored || null); }); else this.once('close', function() { callback(self.errored || null); }); } if (this.closed || this.destroyed) return this; if (this.writableFinished) { queueMicrotask(function() { if (!self.destroyed) self.destroy(); }); } else { if (!this._fsCloseFinishHooked) { this._fsCloseFinishHooked = true; this.once('finish', function() { queueMicrotask(function() { if (!self.destroyed) self.destroy(); }); }); } if (!this.writableEnded) this.end(); } return this; }; __thaw_fs.ReadStream = ReadStream; __thaw_fs.WriteStream = WriteStream; __thaw_fs.createReadStream = function(path, options) { return new ReadStream(path, options); }; __thaw_fs.createWriteStream = function(path, options) { return new WriteStream(path, options); };
function fsMode(options, fallback) { var mode = typeof options === 'number' ? options : options && typeof options === 'object' ? options.mode : undefined; if (mode === undefined) return fallback; if (typeof mode === 'string') { if (!/^[0-7]+$/.test(mode)) throw new TypeError('Invalid mode'); mode = parseInt(mode, 8); } if (!Number.isInteger(mode) || mode < 0 || mode > 4095) throw new TypeError('Invalid mode'); return mode; } function withOpenFile(path, flag, mode, action) { var fd = fsOpenHandle(path, flag, mode).fd; try { return action(fd); } finally { __thaw_fs.closeSync(fd); } } function fsReadFile(path, options, signal) { var target = encoding(options); if (target && !Buffer.isEncoding(target)) throw new TypeError('Unknown encoding: ' + target); var fd = typeof path === 'number' ? path : path instanceof FileHandle ? Number(path.fd) : null, flag = fd === null ? flagsValue(options && typeof options === 'object' ? options.flag : undefined, 'r') : undefined, openPath = fd === null ? (Buffer.isBuffer(path) ? path : pathValue(path)) : path, aborted = fsAbortError(signal); if (aborted) throw aborted; var record = fd === null ? withOpenFile(openPath, flag, 438, function(opened) { return fdInvoke('read_all', opened); }) : fdInvoke('read_all', fd), output = Buffer.from(record.data, 'hex'); return target ? output.toString(target) : output; } function fsWriteMode(path, value, options, defaultFlag, signal) { var encoded = data(value, options).toString('hex'), aborted; if (typeof path === 'number' || path instanceof FileHandle) { var descriptor = typeof path === 'number' ? path : Number(path.fd); aborted = fsAbortError(signal); if (aborted) throw aborted; fdInvoke('write_all', descriptor, encoded); return; } var flag = flagsValue(options && typeof options === 'object' ? options.flag : undefined, defaultFlag), mode = fsMode(options, 438), openPath = Buffer.isBuffer(path) ? path : pathValue(path); aborted = fsAbortError(signal); if (aborted) throw aborted; withOpenFile(openPath, flag, mode, function(fd) { fdInvoke('write_all', fd, encoded); }); } async function fsWriteAsync(path, value, options, defaultFlag) { if (Buffer.isBuffer(path)) path = Buffer.from(path); var signal = fsAbortSignal(options), entryError = fsAbortError(signal); await Promise.resolve(); var aborted = entryError || fsAbortError(signal); if (aborted) throw aborted; if (path instanceof FileHandle) path._check(); var iterable = value !== null && value !== undefined && typeof value !== 'string' && !ArrayBuffer.isView(value) && (typeof value[Symbol.asyncIterator] === 'function' || typeof value[Symbol.iterator] === 'function'); if (!iterable) { fsWriteMode(path, value, options, defaultFlag, signal); return; } var targetEncoding = encoding(options); if (targetEncoding && !Buffer.isEncoding(targetEncoding)) throw new TypeError('Unknown encoding: ' + targetEncoding); var owned = typeof path !== 'number' && !(path instanceof FileHandle), flag = owned ? flagsValue(options && typeof options === 'object' ? options.flag : undefined, defaultFlag) : undefined, mode = owned ? fsMode(options, 438) : undefined, openPath = owned ? (Buffer.isBuffer(path) ? path : pathValue(path)) : path; var fd = owned ? null : path instanceof FileHandle ? Number(path.fd) : path; aborted = fsAbortError(signal); if (aborted) throw aborted; if (owned) fd = fsOpenHandle(openPath, flag, mode).fd; try { for await (var chunk of value) { aborted = fsAbortError(signal); if (aborted) throw aborted; if (typeof chunk !== 'string' && !ArrayBuffer.isView(chunk)) throw new TypeError('Invalid data chunk for writeFile'); var encoded = data(chunk, targetEncoding).toString('hex'); aborted = fsAbortError(signal); if (aborted) throw aborted; fdInvoke('write_all', fd, encoded); } aborted = fsAbortError(signal); if (aborted) throw aborted; } finally { if (owned) __thaw_fs.closeSync(fd); }} __thaw_fs.mkdirSync = function(path, options) { var recursive = Boolean(options && typeof options === 'object' && options.recursive), result = invoke('mkdir_mode', path, String(fsMode(options, 511)), recursive); return recursive && result.created !== null ? result.created : undefined; }; function fsOpenHandle(path, flags, mode) { var rawFlags = flagsValue(flags, 'r'), creationMode = fsMode({ mode: mode }, 438), encodedFlags = typeof rawFlags === 'number' ? '#' + rawFlags : rawFlags; var fd = invoke('fd_open', path, encodedFlags + ',' + creationMode).fd; return new FileHandle(path, rawFlags, fd); } __thaw_fs.openSync = function(path, flags, mode) { return fsOpenHandle(path, flags, mode).fd; }; __thaw_fs.promises.open = function(path, flags, mode) { if (Buffer.isBuffer(path)) path = Buffer.from(path); return Promise.resolve().then(function() { return fsOpenHandle(path, flags, mode); }); }; __thaw_fs.promises.mkdir = promised(__thaw_fs.mkdirSync); __thaw_fs.writeFile = callbackMethod(__thaw_fs.writeFileSync, false, 2); __thaw_fs.appendFile = callbackMethod(__thaw_fs.appendFileSync, false, 2); __thaw_fs.mkdir = function(path, options, callback) { if (typeof options === 'function') { callback = options; options = undefined; } if (typeof callback !== 'function') throw new TypeError('callback must be a function'); if (Buffer.isBuffer(path)) path = Buffer.from(path); queueMicrotask(function() { var recursive = Boolean(options && typeof options === 'object' && options.recursive), created; try { created = __thaw_fs.mkdirSync(path, options); } catch (error) { callback(error); return; } if (recursive) callback(null, created); else callback(null); }); }; __thaw_fs.open = callbackMethod(__thaw_fs.openSync, true);
function initializeWriteQueue(streamValue, highWaterMark) { if (streamValue._writeQueue) return; streamValue.writableHighWaterMark = Math.max(1, Number(highWaterMark || 16384)); streamValue.writableLength = 0; streamValue._writeQueue = []; streamValue._writing = false; streamValue._ending = false; streamValue._finishing = false; streamValue._needsDrain = false; streamValue._endCallbacks = []; } WriteStream.prototype._pumpWrites = function() { var self = this; if (this._writing || !this._writeQueue.length) { if (!this._writing && !this._writeQueue.length && this._ending) this._finishWrites(); return; } this._writing = true; var entry = this._writeQueue[0]; this._write(entry.chunk, entry.encoding, function(error) { self._writing = false; self._writeQueue.shift(); self.writableLength -= entry.chunk.length; if (entry.callback) entry.callback(error); if (error) { self.destroy(error); return; } if (self._needsDrain && !self._ending && self.writableLength === 0) { self._needsDrain = false; self.emit('drain'); } self._pumpWrites(); }); }; WriteStream.prototype.write = function(chunk, encoding, callback) { initializeWriteQueue(this); if (typeof encoding === 'function') { callback = encoding; encoding = undefined; } if (this.writableEnded) { var error = new Error('write after end'); error.code = 'ERR_STREAM_WRITE_AFTER_END'; throw error; } var value = typeof chunk === 'string' ? Buffer.from(chunk, encoding) : Buffer.from(chunk); this._writeQueue.push({ chunk: value, encoding: encoding || 'buffer', callback: callback }); this.writableLength += value.length; var available = this.writableLength < this.writableHighWaterMark; if (!available) this._needsDrain = true; this._pumpWrites(); return available; }; WriteStream.prototype._finishWrites = function() { if (this._finishing || this.writableFinished) return; this._finishing = true; var self = this, finish = function(error) { if (error) { self.destroy(error); return; } self.writable = false; self.writableFinished = true; self.emit('finish'); self._endCallbacks.splice(0).forEach(function(callback) { callback(); }); }; if (this._final) this._final(finish); else finish(); }; WriteStream.prototype.end = function(chunk, encoding, callback) { initializeWriteQueue(this); if (typeof chunk === 'function') { callback = chunk; chunk = undefined; } else if (typeof encoding === 'function') { callback = encoding; encoding = undefined; } if (chunk !== undefined) this.write(chunk, encoding); if (callback) this._endCallbacks.push(callback); this.writableEnded = true; this._ending = true; this._pumpWrites(); return this; }; var createWriteStreamWithoutQueue = __thaw_fs.createWriteStream; __thaw_fs.createWriteStream = function(path, options) { var output = createWriteStreamWithoutQueue(path, options); initializeWriteQueue(output, options && options.highWaterMark); return output; }; FileHandle.prototype.createWriteStream = function(options) { this._check(); return __thaw_fs.createWriteStream(this.path, Object.assign({ fd: this.fd, flags: this.flags }, options || {})); };
function emitFsStream(event) { if (event === 'close') { if (this._fsCloseEmitted) return false; this._fsCloseEmitted = true; } return stream.Stream.prototype.emit.apply(this, arguments); } ReadStream.prototype.emit = emitFsStream; WriteStream.prototype.emit = emitFsStream;
WriteStream.prototype._pumpWrites = stream.Writable.prototype._pumpWrites; WriteStream.prototype._finishWrites = stream.Writable.prototype._finishWrites; WriteStream.prototype.write = stream.Writable.prototype.write; WriteStream.prototype.end = stream.Writable.prototype.end; WriteStream.prototype.cork = stream.Writable.prototype.cork; WriteStream.prototype.uncork = stream.Writable.prototype.uncork;
__thaw_fs.promises.constants = __thaw_fs.constants;
__thaw_fs.F_OK = __thaw_fs.constants.F_OK; __thaw_fs.R_OK = __thaw_fs.constants.R_OK; __thaw_fs.W_OK = __thaw_fs.constants.W_OK; __thaw_fs.X_OK = __thaw_fs.constants.X_OK;
__thaw_fs.exists = function(path, callback) { var found = false; try { found = __thaw_fs.existsSync(path); } catch (_) {} queueMicrotask(function() { callback(found); }); };
module.exports = __thaw_fs;
module.exports.default = __thaw_fs;
module.exports.__esModule = true;

},
"node:path": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {

function posixNormalize(value) {
  var path = String(value); if (path === '') return '.';
  var absolute = path.charAt(0) === '/', trailing = path.length > 1 && path.charAt(path.length - 1) === '/';
  var input = path.split('/'), output = [];
  for (var i = 0; i < input.length; i++) {
    var part = input[i]; if (!part || part === '.') continue;
    if (part === '..') { if (output.length && output[output.length - 1] !== '..') output.pop(); else if (!absolute) output.push('..'); }
    else output.push(part);
  }
  var result = (absolute ? '/' : '') + output.join('/'); if (!result) result = absolute ? '/' : '.';
  if (trailing && result !== '/') result += '/'; return result;
}
function posixResolve() {
  var args = Array.prototype.map.call(arguments, String), path = '', absolute = false;
  for (var i = args.length - 1; i >= 0 && !absolute; i--) { var part = args[i]; if (!part) continue; path = part + '/' + path; absolute = part.charAt(0) === '/'; }
  if (!absolute) path = (globalThis.process && process.cwd ? process.cwd() : '/') + '/' + path;
  path = posixNormalize(path); return path.length > 1 && path.charAt(path.length - 1) === '/' ? path.slice(0, -1) : path;
}
function posixJoin() {
  var parts = []; for (var i = 0; i < arguments.length; i++) if (arguments[i] !== '') parts.push(arguments[i]);
  return posixNormalize(Array.prototype.join.call(parts, '/'));
}
function posixLex(path) {
  path = String(path); var end = path.length; while (end > 1 && path.charAt(end - 1) === '/') end--;
  var root = path.charAt(0) === '/' ? '/' : '', sep = path.lastIndexOf('/', end - 1), base = path.substring(sep + 1, end);
  var dir = sep < 0 ? '' : sep === 0 ? '/' : sep === 1 && path.charAt(0) === '/' && path.charAt(1) === '/' ? '//' : path.substring(0, sep);
  if (!base && root) dir = path.substring(0, end);
  return { root: root, dir: dir, base: base };
}
function posixDirname(path) { var lex = posixLex(path); return lex.dir || '.'; }
function posixBasename(path, suffix) { path = String(path); var base = posixLex(path).base; if (suffix) { suffix = String(suffix); if (suffix === path) base = ''; else if (suffix && base.length > suffix.length && base.endsWith(suffix)) base = base.slice(0, -suffix.length); } return base; }
function extension(base) { if (base === '..' || base === '.' || !base) return ''; var dot = base.lastIndexOf('.'); return dot <= 0 ? '' : base.slice(dot); }
function posixExtname(path) { return extension(posixLex(path).base); }
function posixParse(path) { path = String(path); var lex = posixLex(path), dir = lex.dir === '//' && path.slice(0, 2) === '//' && path.charAt(2) !== '/' ? '/' : lex.dir, ext = lex.root && lex.dir === lex.root && lex.base === '..' ? '.' : extension(lex.base); return { root: lex.root, dir: dir, base: lex.base, ext: ext, name: ext ? lex.base.slice(0, -ext.length) : lex.base }; }
function formatPath(value, separator) {
  var dir = value.dir || value.root || '', base = value.base;
  if (!base) { var name = String(value.name || ''), ext = String(value.ext || ''); if (ext && ext.charAt(0) !== '.') ext = '.' + ext; base = name + ext; }
  return dir ? (dir === value.root ? dir + base : dir + separator + base) : base;
}
function posixIsAbsolute(path) { return String(path).charAt(0) === '/'; }
function posixRelative(from, to) { var left = posixResolve(from).split('/').filter(Boolean), right = posixResolve(to).split('/').filter(Boolean), shared = 0; while (shared < left.length && shared < right.length && left[shared] === right[shared]) shared++; return left.slice(shared).map(function() { return '..'; }).concat(right.slice(shared)).join('/'); }
function toNamespacedPath(path) { return path; }
var posix = { resolve: posixResolve, join: posixJoin, dirname: posixDirname, basename: posixBasename, extname: posixExtname, normalize: posixNormalize, relative: posixRelative, isAbsolute: posixIsAbsolute, parse: posixParse, format: function(value) { return formatPath(value, '/'); }, toNamespacedPath: toNamespacedPath, sep: '/', delimiter: ':' };
function isWinSep(char) { return char === '/' || char === '\\'; }
function winScan(path) {
  path = String(path); var normalized = path.replace(/\\/g, '/'), drive = /^([A-Za-z]:)/.exec(normalized);
  if (drive) { var absolute = normalized.charAt(2) === '/', rootEnd = absolute ? 3 : 2; return { device: drive[1], root: normalized.slice(0, rootEnd), rootEnd: rootEnd, absolute: absolute, unc: false, tail: normalized.slice(rootEnd) }; }
  if (normalized.slice(0, 2) === '//') {
    var serverStart = 2; while (normalized.charAt(serverStart) === '/') serverStart++;
    var serverEnd = normalized.indexOf('/', serverStart);
    if (serverEnd > serverStart) {
      var shareStart = serverEnd; while (normalized.charAt(shareStart) === '/') shareStart++;
      var shareEnd = normalized.indexOf('/', shareStart);
      if (shareEnd < 0) shareEnd = normalized.length;
      if (shareEnd > shareStart && serverStart === 2) {
        var afterRoot = shareEnd; if (normalized.charAt(afterRoot) === '/') afterRoot++;
        var device = '//' + normalized.slice(serverStart, serverEnd) + '/' + normalized.slice(shareStart, shareEnd);
        return { device: device, root: device + '/', rootEnd: shareEnd + (normalized.charAt(shareEnd) === '/' ? 1 : 0), absolute: true, unc: true, share: normalized.slice(shareStart, shareEnd), serverEnd: serverEnd, shareEnd: shareEnd, tail: normalized.slice(afterRoot) };
      }
    }
  }
  var rooted = normalized.charAt(0) === '/'; var rootEnd = 0; if (rooted) { rootEnd = 1; while (normalized.charAt(rootEnd) === '/') rootEnd++; }
  return { device: '', root: rooted ? '/' : '', rootEnd: rootEnd, absolute: rooted, unc: false, tail: normalized.slice(rootEnd) };
}
function winTailNormalize(tail, absolute) {
  var parts = tail.split('/'), out = [];
  for (var i = 0; i < parts.length; i++) { var part = parts[i]; if (!part || part === '.') continue; if (part === '..') { if (out.length && out[out.length - 1] !== '..') out.pop(); else if (!absolute) out.push('..'); } else out.push(part); }
  return out;
}
function winNormalize(path) {
  path = String(path); if (!path) return '.';
  var root = winScan(path), trailing = /[\\/]$/.test(path), parts = winTailNormalize(root.tail, root.absolute), tail = parts.join('/'), result;
  if (root.root) {
    if (root.device && !root.unc && !root.absolute) result = root.device + (tail || '.');
    else result = root.root + tail;
  } else result = tail || '.';
  if (trailing && (result !== '.' || path !== '') && !/[\/]$/.test(result)) result += '/';
  return result.replace(/\//g, '\\');
}
function winOutput(path) { return String(path).replace(/\//g, '\\'); }
function winJoin() {
  var parts = []; for (var i = 0; i < arguments.length; i++) { var part = String(arguments[i]); if (part !== '') parts.push(part); }
  if (!parts.length) return '.';
  var preserveUnc = /^[\\/]{2}[^\\/]/.test(parts[0]), joined = parts.join('/').replace(/\\/g, '/');
  if (!preserveUnc) joined = joined.replace(/^\/{2,}/, '/');
  return winNormalize(joined);
}
function winResolve() {
  var args = Array.prototype.map.call(arguments, String), device = '', absolute = false, tail = '';
  for (var i = args.length - 1; i >= -1 && !(absolute && device); i--) {
    var value = i >= 0 ? args[i] : '';
    if (i < 0 || !value) {
      if (i < 0) {
        var cwd;
        if (device) {
          var driveCwd = globalThis.process && process.env ? process.env['=' + device] : undefined;
          cwd = driveCwd || (globalThis.process && process.cwd ? process.cwd() : '/');
          if (cwd === undefined || (String(cwd).slice(0, 2).toLowerCase() !== device.toLowerCase() && String(cwd).charAt(2) === '\\')) cwd = device + '\\';
        } else cwd = globalThis.process && process.cwd ? process.cwd() : '/';
        var current = winScan(String(cwd));
        if (current.device && !device) device = current.device;
        if (!absolute && (!current.device || current.device.toLowerCase() === device.toLowerCase())) { tail = current.tail + '/' + tail; absolute = current.absolute; }
      }
      continue;
    }
    var parsed = winScan(value);
    if (parsed.device) { if (device && device.toLowerCase() !== parsed.device.toLowerCase()) continue; if (!device) device = parsed.device; }
    if (parsed.absolute) { if (!absolute) { tail = parsed.tail + '/' + tail; absolute = true; } }
    else if (!absolute) tail = parsed.tail + '/' + tail;
  }
  var normalized = winTailNormalize(tail, absolute), root = device ? (device.slice(0, 2) === '//' ? device + '/' : device + (absolute ? '/' : '')) : (absolute ? '/' : '');
  var result = root + normalized.join('/'); if (!result) result = '.';
  return winOutput(result);
}
function winLex(path) {
  path = String(path); var normalized = path.replace(/\\/g, '/'), scan = winScan(path), rootEnd = scan.unc || scan.device ? scan.rootEnd : scan.absolute ? 1 : 0, end = normalized.length;
  while (end > rootEnd && normalized.charAt(end - 1) === '/') end--;
  if (scan.unc && end <= scan.shareEnd) return { scan: scan, end: end, baseStart: end, base: '', root: rawWinRoot(path, scan), dir: rawWinRoot(path, scan) };
  var sep = normalized.lastIndexOf('/', end - 1), baseStart = Math.max(sep + 1, rootEnd), base = normalized.slice(baseStart, end);
  var dir = sep < 0 ? (scan.device ? path.slice(0, 2) : '') : sep < rootEnd ? rawWinRoot(path, scan) : path.slice(0, sep);
  var root = rawWinRoot(path, scan); if (!base && root) dir = root;
  return { scan: scan, end: end, baseStart: baseStart, base: base, root: root, dir: dir };
}
function rawWinRoot(path, scan) {
  if (!scan.root) return '';
  var end = scan.rootEnd;
  if (!scan.device && !scan.unc) end = Math.min(end, 1);
  return path.slice(0, end);
}
function winDirname(path) { var lex = winLex(path); return lex.dir || '.'; }
function winBasename(path, suffix) {
  path = String(path); var lex = winLex(path), scan = lex.scan, base = lex.base;
  if (scan.unc && lex.end <= scan.shareEnd + 1) base = scan.share;
  if (suffix) { suffix = String(suffix); if (suffix === path) base = ''; else if (suffix && base.length > suffix.length && base.endsWith(suffix)) base = base.slice(0, -suffix.length); } return base;
}
function winExtname(path) { var lex = winLex(path); return lex.scan.unc && lex.end <= lex.scan.shareEnd + 1 ? extension(lex.scan.share) : extension(lex.base); }
function winParse(path) { var lex = winLex(path), ext = extension(lex.base); return { root: lex.root, dir: lex.dir, base: lex.base, ext: ext, name: ext ? lex.base.slice(0, -ext.length) : lex.base }; }
function winIsAbsolute(path) { path = String(path); return isWinSep(path.charAt(0)) || /^[A-Za-z]:[\\/]/.test(path); }
/*
 * Adapted from Node.js v22.20.0 lib/path.js.
 * Copyright Joyent, Inc. and other Node contributors.
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
function winRelative(from, to) {
  var fromPath = winResolve(from), toPath = winResolve(to);
  if (fromPath === toPath) return '';
  var fromLower = fromPath.toLowerCase(), toLower = toPath.toLowerCase();
  if (fromLower === toLower) return '';
  if (fromPath.length !== fromLower.length || toPath.length !== toLower.length) {
    var fromParts = fromPath.split('\\'), toParts = toPath.split('\\');
    if (fromParts[fromParts.length - 1] === '') fromParts.pop();
    if (toParts[toParts.length - 1] === '') toParts.pop();
    var count = Math.min(fromParts.length, toParts.length), shared = 0;
    while (shared < count && fromParts[shared].toLowerCase() === toParts[shared].toLowerCase()) shared++;
    if (shared === 0) return toPath;
    if (shared === count) {
      if (toParts.length > count) return toParts.slice(shared).join('\\');
      if (fromParts.length > count) return '..\\'.repeat(fromParts.length - 1 - shared) + '..';
      return '';
    }
    return '..\\'.repeat(fromParts.length - shared) + toParts.slice(shared).join('\\');
  }

  var fromStart = 0, fromEnd = fromLower.length;
  while (fromStart < fromEnd && fromLower.charAt(fromStart) === '\\') fromStart++;
  while (fromEnd - 1 > fromStart && fromLower.charAt(fromEnd - 1) === '\\') fromEnd--;
  var toStart = 0, toEnd = toLower.length;
  while (toStart < toEnd && toLower.charAt(toStart) === '\\') toStart++;
  while (toEnd - 1 > toStart && toLower.charAt(toEnd - 1) === '\\') toEnd--;
  var fromLength = fromEnd - fromStart, toLength = toEnd - toStart;
  var length = Math.min(fromLength, toLength), lastCommonSep = -1, i = 0;
  for (; i < length; i++) {
    var fromChar = fromLower.charAt(fromStart + i);
    if (fromChar !== toLower.charAt(toStart + i)) break;
    if (fromChar === '\\') lastCommonSep = i;
  }
  if (i !== length) {
    if (lastCommonSep === -1) return toPath;
  } else {
    if (toLength > length) {
      if (toLower.charAt(toStart + i) === '\\') return toPath.slice(toStart + i + 1);
      if (i === 2) return toPath.slice(toStart + i);
    }
    if (fromLength > length) {
      if (fromLower.charAt(fromStart + i) === '\\') lastCommonSep = i;
      else if (i === 2) lastCommonSep = 3;
    }
    if (lastCommonSep === -1) lastCommonSep = 0;
  }
  var out = '';
  for (i = fromStart + lastCommonSep + 1; i <= fromEnd; i++) {
    if (i === fromEnd || fromLower.charAt(i) === '\\') out += out ? '\\..' : '..';
  }
  toStart += lastCommonSep;
  if (out) return out + toPath.slice(toStart, toEnd);
  if (toPath.charAt(toStart) === '\\') toStart++;
  return toPath.slice(toStart, toEnd);
}
var win32 = { resolve: winResolve, join: winJoin, dirname: winDirname, basename: winBasename, extname: winExtname, normalize: winNormalize, relative: winRelative, isAbsolute: winIsAbsolute, parse: winParse, format: function(value) { return String(formatPath(value, '\\')); }, toNamespacedPath: toNamespacedPath, sep: '\\', delimiter: ';' };
posix.posix = posix; posix.win32 = win32; win32.posix = posix; win32.win32 = win32;
module.exports = posix; module.exports.default = module.exports; module.exports.__esModule = true;

},
"better-sqlite3/lib/database.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const fs = require('fs');
const path = require('path');
const util = require('./util');
const SqliteError = require('./sqlite-error');

let DEFAULT_ADDON;

function Database(filenameGiven, options) {
	if (new.target == null) {
		return new Database(filenameGiven, options);
	}

	// Apply defaults
	let buffer;
	if (Buffer.isBuffer(filenameGiven)) {
		buffer = filenameGiven;
		filenameGiven = ':memory:';
	}
	if (filenameGiven == null) filenameGiven = '';
	if (options == null) options = {};

	// Validate arguments
	if (typeof filenameGiven !== 'string') throw new TypeError('Expected first argument to be a string');
	if (typeof options !== 'object') throw new TypeError('Expected second argument to be an options object');
	if ('readOnly' in options) throw new TypeError('Misspelled option "readOnly" should be "readonly"');
	if ('memory' in options) throw new TypeError('Option "memory" was removed in v7.0.0 (use ":memory:" filename instead)');

	// Interpret options
	const filename = filenameGiven.trim();
	const anonymous = filename === '' || filename === ':memory:';
	const readonly = util.getBooleanOption(options, 'readonly');
	const fileMustExist = util.getBooleanOption(options, 'fileMustExist');
	const timeout = 'timeout' in options ? options.timeout : 5000;
	const verbose = 'verbose' in options ? options.verbose : null;
	const nativeBinding = 'nativeBinding' in options ? options.nativeBinding : null;

	// Validate interpreted options
	if (readonly && anonymous && !buffer) throw new TypeError('In-memory/temporary databases cannot be readonly');
	if (!Number.isInteger(timeout) || timeout < 0) throw new TypeError('Expected the "timeout" option to be a positive integer');
	if (timeout > 0x7fffffff) throw new RangeError('Option "timeout" cannot be greater than 2147483647');
	if (verbose != null && typeof verbose !== 'function') throw new TypeError('Expected the "verbose" option to be a function');
	if (nativeBinding != null && typeof nativeBinding !== 'string' && typeof nativeBinding !== 'object') throw new TypeError('Expected the "nativeBinding" option to be a string or addon object');

	// Load the native addon
	let addon;
	if (nativeBinding == null) {
		addon = DEFAULT_ADDON || (DEFAULT_ADDON = require('bindings')('better_sqlite3.node'));
	} else if (typeof nativeBinding === 'string') {
		// See <https://webpack.js.org/api/module-variables/#__non_webpack_require__-webpack-specific>
		const requireFunc = typeof __non_webpack_require__ === 'function' ? __non_webpack_require__ : require;
		addon = requireFunc(path.resolve(nativeBinding).replace(/(\.node)?$/, '.node'));
	} else {
		// See <https://github.com/WiseLibs/better-sqlite3/issues/972>
		addon = nativeBinding;
	}

	if (!addon.isInitialized) {
		addon.setErrorConstructor(SqliteError);
		addon.isInitialized = true;
	}

	// Make sure the specified directory exists
	if (!anonymous && !filename.startsWith('file:') && !fs.existsSync(path.dirname(filename))) {
		throw new TypeError('Cannot open database because the directory does not exist');
	}

	Object.defineProperties(this, {
		[util.cppdb]: { value: new addon.Database(filename, filenameGiven, anonymous, readonly, fileMustExist, timeout, verbose || null, buffer || null) },
		...wrappers.getters,
	});
}

const wrappers = require('./methods/wrappers');
Database.prototype.prepare = wrappers.prepare;
Database.prototype.transaction = require('./methods/transaction');
Database.prototype.pragma = require('./methods/pragma');
Database.prototype.backup = require('./methods/backup');
Database.prototype.serialize = require('./methods/serialize');
Database.prototype.function = require('./methods/function');
Database.prototype.aggregate = require('./methods/aggregate');
Database.prototype.table = require('./methods/table');
Database.prototype.loadExtension = wrappers.loadExtension;
Database.prototype.exec = wrappers.exec;
Database.prototype.close = wrappers.close;
Database.prototype.defaultSafeIntegers = wrappers.defaultSafeIntegers;
Database.prototype.unsafeMode = wrappers.unsafeMode;
Database.prototype[util.inspect] = require('./methods/inspect');

module.exports = Database;

},
"bindings/./bindings.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
/**
 * Module dependencies.
 */

var fs = require('fs'),
  path = require('path'),
  fileURLToPath = require('file-uri-to-path'),
  join = path.join,
  dirname = path.dirname,
  exists =
    (fs.accessSync &&
      function(path) {
        try {
          fs.accessSync(path);
        } catch (e) {
          return false;
        }
        return true;
      }) ||
    fs.existsSync ||
    path.existsSync,
  defaults = {
    arrow: process.env.NODE_BINDINGS_ARROW || ' → ',
    compiled: process.env.NODE_BINDINGS_COMPILED_DIR || 'compiled',
    platform: process.platform,
    arch: process.arch,
    nodePreGyp:
      'node-v' +
      process.versions.modules +
      '-' +
      process.platform +
      '-' +
      process.arch,
    version: process.versions.node,
    bindings: 'bindings.node',
    try: [
      // node-gyp's linked version in the "build" dir
      ['module_root', 'build', 'bindings'],
      // node-waf and gyp_addon (a.k.a node-gyp)
      ['module_root', 'build', 'Debug', 'bindings'],
      ['module_root', 'build', 'Release', 'bindings'],
      // Debug files, for development (legacy behavior, remove for node v0.9)
      ['module_root', 'out', 'Debug', 'bindings'],
      ['module_root', 'Debug', 'bindings'],
      // Release files, but manually compiled (legacy behavior, remove for node v0.9)
      ['module_root', 'out', 'Release', 'bindings'],
      ['module_root', 'Release', 'bindings'],
      // Legacy from node-waf, node <= 0.4.x
      ['module_root', 'build', 'default', 'bindings'],
      // Production "Release" buildtype binary (meh...)
      ['module_root', 'compiled', 'version', 'platform', 'arch', 'bindings'],
      // node-qbs builds
      ['module_root', 'addon-build', 'release', 'install-root', 'bindings'],
      ['module_root', 'addon-build', 'debug', 'install-root', 'bindings'],
      ['module_root', 'addon-build', 'default', 'install-root', 'bindings'],
      // node-pre-gyp path ./lib/binding/{node_abi}-{platform}-{arch}
      ['module_root', 'lib', 'binding', 'nodePreGyp', 'bindings']
    ]
  };

/**
 * The main `bindings()` function loads the compiled bindings for a given module.
 * It uses V8's Error API to determine the parent filename that this function is
 * being invoked from, which is then used to find the root directory.
 */

function bindings(opts) {
  // Argument surgery
  if (typeof opts == 'string') {
    opts = { bindings: opts };
  } else if (!opts) {
    opts = {};
  }

  // maps `defaults` onto `opts` object
  Object.keys(defaults).map(function(i) {
    if (!(i in opts)) opts[i] = defaults[i];
  });

  // Get the module root
  if (!opts.module_root) {
    opts.module_root = exports.getRoot(exports.getFileName());
  }

  // Ensure the given bindings name ends with .node
  if (path.extname(opts.bindings) != '.node') {
    opts.bindings += '.node';
  }

  // https://github.com/webpack/webpack/issues/4175#issuecomment-342931035
  var requireFunc =
    typeof __webpack_require__ === 'function'
      ? __non_webpack_require__
      : require;

  var tries = [],
    i = 0,
    l = opts.try.length,
    n,
    b,
    err;

  for (; i < l; i++) {
    n = join.apply(
      null,
      opts.try[i].map(function(p) {
        return opts[p] || p;
      })
    );
    tries.push(n);
    try {
      b = opts.path ? requireFunc.resolve(n) : requireFunc(n);
      if (!opts.path) {
        b.path = n;
      }
      return b;
    } catch (e) {
      if (e.code !== 'MODULE_NOT_FOUND' &&
          e.code !== 'QUALIFIED_PATH_RESOLUTION_FAILED' &&
          !/not find/i.test(e.message)) {
        throw e;
      }
    }
  }

  err = new Error(
    'Could not locate the bindings file. Tried:\n' +
      tries
        .map(function(a) {
          return opts.arrow + a;
        })
        .join('\n')
  );
  err.tries = tries;
  throw err;
}
module.exports = exports = bindings;

/**
 * Gets the filename of the JavaScript file that invokes this function.
 * Used to help find the root directory of a module.
 * Optionally accepts an filename argument to skip when searching for the invoking filename
 */

exports.getFileName = function getFileName(calling_file) {
  var origPST = Error.prepareStackTrace,
    origSTL = Error.stackTraceLimit,
    dummy = {},
    fileName;

  Error.stackTraceLimit = 10;

  Error.prepareStackTrace = function(e, st) {
    for (var i = 0, l = st.length; i < l; i++) {
      fileName = st[i].getFileName();
      if (fileName !== __filename) {
        if (calling_file) {
          if (fileName !== calling_file) {
            return;
          }
        } else {
          return;
        }
      }
    }
  };

  // run the 'prepareStackTrace' function above
  Error.captureStackTrace(dummy);
  dummy.stack;

  // cleanup
  Error.prepareStackTrace = origPST;
  Error.stackTraceLimit = origSTL;

  // handle filename that starts with "file://"
  var fileSchema = 'file://';
  if (fileName.indexOf(fileSchema) === 0) {
    fileName = fileURLToPath(fileName);
  }

  return fileName;
};

/**
 * Gets the root directory of a module, given an arbitrary filename
 * somewhere in the module tree. The "root directory" is the directory
 * containing the `package.json` file.
 *
 *   In:  /home/nate/node-native-module/lib/index.js
 *   Out: /home/nate/node-native-module
 */

exports.getRoot = function getRoot(file) {
  var dir = dirname(file),
    prev;
  while (true) {
    if (dir === '.') {
      // Avoids an infinite loop in rare cases, like the REPL
      dir = process.cwd();
    }
    if (
      exists(join(dir, 'package.json')) ||
      exists(join(dir, 'node_modules'))
    ) {
      // Found the 'package.json' file or 'node_modules' dir; we're done
      return dir;
    }
    if (prev === dir) {
      // Got to the top
      throw new Error(
        'Could not find module root given file: "' +
          file +
          '". Do you have a `package.json` file? '
      );
    }
    // Try the parent dir next
    prev = dir;
    dir = join(dir, '..');
  }
};

},
"file-uri-to-path/index.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {

/**
 * Module dependencies.
 */

var sep = require('path').sep || '/';

/**
 * Module exports.
 */

module.exports = fileUriToPath;

/**
 * File URI to Path function.
 *
 * @param {String} uri
 * @return {String} path
 * @api public
 */

function fileUriToPath (uri) {
  if ('string' != typeof uri ||
      uri.length <= 7 ||
      'file://' != uri.substring(0, 7)) {
    throw new TypeError('must pass in a file:// URI to convert to a file path');
  }

  var rest = decodeURI(uri.substring(7));
  var firstSlash = rest.indexOf('/');
  var host = rest.substring(0, firstSlash);
  var path = rest.substring(firstSlash + 1);

  // 2.  Scheme Definition
  // As a special case, <host> can be the string "localhost" or the empty
  // string; this is interpreted as "the machine from which the URL is
  // being interpreted".
  if ('localhost' == host) host = '';

  if (host) {
    host = sep + sep + host;
  }

  // 3.2  Drives, drive letters, mount points, file system root
  // Drive letters are mapped into the top of a file URI in various ways,
  // depending on the implementation; some applications substitute
  // vertical bar ("|") for the colon after the drive letter, yielding
  // "file:///c|/tmp/test.txt".  In some cases, the colon is left
  // unchanged, as in "file:///c:/tmp/test.txt".  In other cases, the
  // colon is simply omitted, as in "file:///c/tmp/test.txt".
  path = path.replace(/^(.+)\|/, '$1:');

  // for Windows, we need to invert the path separators from what a URI uses
  if (sep == '\\') {
    path = path.replace(/\//g, '\\');
  }

  if (/^.+\:/.test(path)) {
    // has Windows drive at beginning of path
  } else {
    // unix path…
    path = sep + path;
  }

  return host + path;
}

},
"better-sqlite3/lib/methods/inspect.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const DatabaseInspection = function Database() {};

module.exports = function inspect(depth, opts) {
	return Object.assign(new DatabaseInspection(), this);
};


},
"better-sqlite3/lib/methods/table.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const { cppdb } = require('../util');

module.exports = function defineTable(name, factory) {
	// Validate arguments
	if (typeof name !== 'string') throw new TypeError('Expected first argument to be a string');
	if (!name) throw new TypeError('Virtual table module name cannot be an empty string');

	// Determine whether the module is eponymous-only or not
	let eponymous = false;
	if (typeof factory === 'object' && factory !== null) {
		eponymous = true;
		factory = defer(parseTableDefinition(factory, 'used', name));
	} else {
		if (typeof factory !== 'function') throw new TypeError('Expected second argument to be a function or a table definition object');
		factory = wrapFactory(factory);
	}

	this[cppdb].table(factory, name, eponymous);
	return this;
};

function wrapFactory(factory) {
	return function virtualTableFactory(moduleName, databaseName, tableName, ...args) {
		const thisObject = {
			module: moduleName,
			database: databaseName,
			table: tableName,
		};

		// Generate a new table definition by invoking the factory
		const def = apply.call(factory, thisObject, args);
		if (typeof def !== 'object' || def === null) {
			throw new TypeError(`Virtual table module "${moduleName}" did not return a table definition object`);
		}

		return parseTableDefinition(def, 'returned', moduleName);
	};
}

function parseTableDefinition(def, verb, moduleName) {
	// Validate required properties
	if (!hasOwnProperty.call(def, 'rows')) {
		throw new TypeError(`Virtual table module "${moduleName}" ${verb} a table definition without a "rows" property`);
	}
	if (!hasOwnProperty.call(def, 'columns')) {
		throw new TypeError(`Virtual table module "${moduleName}" ${verb} a table definition without a "columns" property`);
	}

	// Validate "rows" property
	const rows = def.rows;
	if (typeof rows !== 'function' || Object.getPrototypeOf(rows) !== GeneratorFunctionPrototype) {
		throw new TypeError(`Virtual table module "${moduleName}" ${verb} a table definition with an invalid "rows" property (should be a generator function)`);
	}

	// Validate "columns" property
	let columns = def.columns;
	if (!Array.isArray(columns) || !(columns = [...columns]).every(x => typeof x === 'string')) {
		throw new TypeError(`Virtual table module "${moduleName}" ${verb} a table definition with an invalid "columns" property (should be an array of strings)`);
	}
	if (columns.length !== new Set(columns).size) {
		throw new TypeError(`Virtual table module "${moduleName}" ${verb} a table definition with duplicate column names`);
	}
	if (!columns.length) {
		throw new RangeError(`Virtual table module "${moduleName}" ${verb} a table definition with zero columns`);
	}

	// Validate "parameters" property
	let parameters;
	if (hasOwnProperty.call(def, 'parameters')) {
		parameters = def.parameters;
		if (!Array.isArray(parameters) || !(parameters = [...parameters]).every(x => typeof x === 'string')) {
			throw new TypeError(`Virtual table module "${moduleName}" ${verb} a table definition with an invalid "parameters" property (should be an array of strings)`);
		}
	} else {
		parameters = inferParameters(rows);
	}
	if (parameters.length !== new Set(parameters).size) {
		throw new TypeError(`Virtual table module "${moduleName}" ${verb} a table definition with duplicate parameter names`);
	}
	if (parameters.length > 32) {
		throw new RangeError(`Virtual table module "${moduleName}" ${verb} a table definition with more than the maximum number of 32 parameters`);
	}
	for (const parameter of parameters) {
		if (columns.includes(parameter)) {
			throw new TypeError(`Virtual table module "${moduleName}" ${verb} a table definition with column "${parameter}" which was ambiguously defined as both a column and parameter`);
		}
	}

	// Validate "safeIntegers" option
	let safeIntegers = 2;
	if (hasOwnProperty.call(def, 'safeIntegers')) {
		const bool = def.safeIntegers;
		if (typeof bool !== 'boolean') {
			throw new TypeError(`Virtual table module "${moduleName}" ${verb} a table definition with an invalid "safeIntegers" property (should be a boolean)`);
		}
		safeIntegers = +bool;
	}

	// Validate "directOnly" option
	let directOnly = false;
	if (hasOwnProperty.call(def, 'directOnly')) {
		directOnly = def.directOnly;
		if (typeof directOnly !== 'boolean') {
			throw new TypeError(`Virtual table module "${moduleName}" ${verb} a table definition with an invalid "directOnly" property (should be a boolean)`);
		}
	}

	// Generate SQL for the virtual table definition
	const columnDefinitions = [
		...parameters.map(identifier).map(str => `${str} HIDDEN`),
		...columns.map(identifier),
	];
	return [
		`CREATE TABLE x(${columnDefinitions.join(', ')});`,
		wrapGenerator(rows, new Map(columns.map((x, i) => [x, parameters.length + i])), moduleName),
		parameters,
		safeIntegers,
		directOnly,
	];
}

function wrapGenerator(generator, columnMap, moduleName) {
	return function* virtualTable(...args) {
		/*
			We must defensively clone any buffers in the arguments, because
			otherwise the generator could mutate one of them, which would cause
			us to return incorrect values for hidden columns, potentially
			corrupting the database.
		 */
		const output = args.map(x => Buffer.isBuffer(x) ? Buffer.from(x) : x);
		for (let i = 0; i < columnMap.size; ++i) {
			output.push(null); // Fill with nulls to prevent gaps in array (v8 optimization)
		}
		for (const row of generator(...args)) {
			if (Array.isArray(row)) {
				extractRowArray(row, output, columnMap.size, moduleName);
				yield output;
			} else if (typeof row === 'object' && row !== null) {
				extractRowObject(row, output, columnMap, moduleName);
				yield output;
			} else {
				throw new TypeError(`Virtual table module "${moduleName}" yielded something that isn't a valid row object`);
			}
		}
	};
}

function extractRowArray(row, output, columnCount, moduleName) {
	if (row.length !== columnCount) {
		throw new TypeError(`Virtual table module "${moduleName}" yielded a row with an incorrect number of columns`);
	}
	const offset = output.length - columnCount;
	for (let i = 0; i < columnCount; ++i) {
		output[i + offset] = row[i];
	}
}

function extractRowObject(row, output, columnMap, moduleName) {
	let count = 0;
	for (const key of Object.keys(row)) {
		const index = columnMap.get(key);
		if (index === undefined) {
			throw new TypeError(`Virtual table module "${moduleName}" yielded a row with an undeclared column "${key}"`);
		}
		output[index] = row[key];
		count += 1;
	}
	if (count !== columnMap.size) {
		throw new TypeError(`Virtual table module "${moduleName}" yielded a row with missing columns`);
	}
}

function inferParameters({ length }) {
	if (!Number.isInteger(length) || length < 0) {
		throw new TypeError('Expected function.length to be a positive integer');
	}
	const params = [];
	for (let i = 0; i < length; ++i) {
		params.push(`$${i + 1}`);
	}
	return params;
}

const { hasOwnProperty } = Object.prototype;
const { apply } = Function.prototype;
const GeneratorFunctionPrototype = Object.getPrototypeOf(function*(){});
const identifier = str => `"${str.replace(/"/g, '""')}"`;
const defer = x => () => x;

},
"better-sqlite3/lib/methods/aggregate.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const { getBooleanOption, cppdb } = require('../util');

module.exports = function defineAggregate(name, options) {
	// Validate arguments
	if (typeof name !== 'string') throw new TypeError('Expected first argument to be a string');
	if (typeof options !== 'object' || options === null) throw new TypeError('Expected second argument to be an options object');
	if (!name) throw new TypeError('User-defined function name cannot be an empty string');

	// Interpret options
	const start = 'start' in options ? options.start : null;
	const step = getFunctionOption(options, 'step', true);
	const inverse = getFunctionOption(options, 'inverse', false);
	const result = getFunctionOption(options, 'result', false);
	const safeIntegers = 'safeIntegers' in options ? +getBooleanOption(options, 'safeIntegers') : 2;
	const deterministic = getBooleanOption(options, 'deterministic');
	const directOnly = getBooleanOption(options, 'directOnly');
	const varargs = getBooleanOption(options, 'varargs');
	let argCount = -1;

	// Determine argument count
	if (!varargs) {
		argCount = Math.max(getLength(step), inverse ? getLength(inverse) : 0);
		if (argCount > 0) argCount -= 1;
		if (argCount > 100) throw new RangeError('User-defined functions cannot have more than 100 arguments');
	}

	this[cppdb].aggregate(start, step, inverse, result, name, argCount, safeIntegers, deterministic, directOnly);
	return this;
};

const getFunctionOption = (options, key, required) => {
	const value = key in options ? options[key] : null;
	if (typeof value === 'function') return value;
	if (value != null) throw new TypeError(`Expected the "${key}" option to be a function`);
	if (required) throw new TypeError(`Missing required option "${key}"`);
	return null;
};

const getLength = ({ length }) => {
	if (Number.isInteger(length) && length >= 0) return length;
	throw new TypeError('Expected function.length to be a positive integer');
};

},
"better-sqlite3/lib/methods/function.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const { getBooleanOption, cppdb } = require('../util');

module.exports = function defineFunction(name, options, fn) {
	// Apply defaults
	if (options == null) options = {};
	if (typeof options === 'function') { fn = options; options = {}; }

	// Validate arguments
	if (typeof name !== 'string') throw new TypeError('Expected first argument to be a string');
	if (typeof fn !== 'function') throw new TypeError('Expected last argument to be a function');
	if (typeof options !== 'object') throw new TypeError('Expected second argument to be an options object');
	if (!name) throw new TypeError('User-defined function name cannot be an empty string');

	// Interpret options
	const safeIntegers = 'safeIntegers' in options ? +getBooleanOption(options, 'safeIntegers') : 2;
	const deterministic = getBooleanOption(options, 'deterministic');
	const directOnly = getBooleanOption(options, 'directOnly');
	const varargs = getBooleanOption(options, 'varargs');
	let argCount = -1;

	// Determine argument count
	if (!varargs) {
		argCount = fn.length;
		if (!Number.isInteger(argCount) || argCount < 0) throw new TypeError('Expected function.length to be a positive integer');
		if (argCount > 100) throw new RangeError('User-defined functions cannot have more than 100 arguments');
	}

	this[cppdb].function(fn, name, argCount, safeIntegers, deterministic, directOnly);
	return this;
};

},
"better-sqlite3/lib/methods/serialize.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const { cppdb } = require('../util');

module.exports = function serialize(options) {
	if (options == null) options = {};

	// Validate arguments
	if (typeof options !== 'object') throw new TypeError('Expected first argument to be an options object');

	// Interpret and validate options
	const attachedName = 'attached' in options ? options.attached : 'main';
	if (typeof attachedName !== 'string') throw new TypeError('Expected the "attached" option to be a string');
	if (!attachedName) throw new TypeError('The "attached" option cannot be an empty string');

	return this[cppdb].serialize(attachedName);
};

},
"node:util": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var inspectCustom = Symbol.for('nodejs.util.inspect.custom');
function inspect(value, options) {
  if (typeof options === 'boolean') options = { showHidden: options, depth: arguments[2], colors: arguments[3] };
  var merged = {}, defaults = inspect.defaultOptions, given = options || {};
  Object.keys(defaults).forEach(function(key) { merged[key] = defaults[key]; });
  Object.keys(given).forEach(function(key) { if (given[key] !== undefined) merged[key] = given[key]; });
  options = merged;
  var depth = options.depth === null ? Infinity : options.depth, seen = [], refs = new Map();
  var STYLES = { number: [33, 39], bigint: [33, 39], boolean: [33, 39], string: [32, 39], symbol: [32, 39], undefined: [90, 39], null: [1, 22], special: [36, 39], date: [35, 39], regexp: [31, 39] };
  function paint(text, kind) { if (!options.colors) return text; var style = STYLES[kind]; return '\u001b[' + style[0] + 'm' + text + '\u001b[' + style[1] + 'm'; }
  function quote(text) {
    var mark = "'";
    if (text.indexOf("'") !== -1) { if (text.indexOf('"') === -1) mark = '"'; else if (text.indexOf('`') === -1 && text.indexOf('${') === -1) mark = '`'; }
    var out = '';
    for (var i = 0; i < text.length; i++) {
      var ch = text[i], code = text.charCodeAt(i);
      if (ch === mark || ch === '\\') out += '\\' + ch;
      else if (ch === '\n') out += '\\n'; else if (ch === '\t') out += '\\t'; else if (ch === '\r') out += '\\r'; else if (ch === '\b') out += '\\b'; else if (ch === '\f') out += '\\f';
      else if (code < 32 || code === 127) out += '\\x' + (code < 16 ? '0' : '') + code.toString(16).toUpperCase();
      else out += ch;
    }
    return mark + out + mark;
  }
  function renderString(text) {
    var rest = 0;
    if (text.length > options.maxStringLength) { rest = text.length - options.maxStringLength; text = text.slice(0, options.maxStringLength); }
    return paint(quote(text), 'string') + (rest ? '... ' + rest + ' more character' + (rest > 1 ? 's' : '') : '');
  }
  function groupDigits(text) {
    if (!options.numericSeparator || /[^0-9.\-]/.test(text)) return text;
    var parts = text.split('.'), integer = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '_');
    return parts.length > 1 ? integer + '.' + parts[1].replace(/(\d{3})(?=\d)/g, '$1_') : integer;
  }
  function identifierKey(key) { return /^[a-zA-Z_][a-zA-Z_0-9]*$/.test(key) ? key : paint(quote(key), 'string'); }
  function constructorName(object) {
    for (var pointer = object; pointer; pointer = Object.getPrototypeOf(pointer)) {
      var descriptor = Object.getOwnPropertyDescriptor(pointer, 'constructor');
      if (descriptor && typeof descriptor.value === 'function' && descriptor.value.name !== '') return descriptor.value.name;
    }
    return null;
  }
  function isEmptyContainer(input) { if (Object.keys(input).length !== 0 || Object.getOwnPropertySymbols(input).length !== 0) return false; return Array.isArray(input) ? input.length === 0 : input instanceof Map || input instanceof Set ? input.size === 0 : true; }
  function indented(value, remaining) { indentationLvl += 2; try { return render(value, remaining); } finally { indentationLvl -= 2; } }
  function renderProperty(owner, key, remaining) {
    var descriptor = Object.getOwnPropertyDescriptor(owner, key);
    if (!descriptor) return '';
    if (Object.prototype.hasOwnProperty.call(descriptor, 'value')) return indented(descriptor.value, remaining);
    var getter = descriptor.get, setter = descriptor.set, evaluate = getter && (options.getters === true || options.getters === 'get' && !setter || options.getters === 'set' && setter);
    if (evaluate) {
      var got; try { got = getter.call(owner); } catch (_) { return paint('[Inspection threw]', 'special'); }
      return paint(setter ? '[Getter/Setter:' : '[Getter:', 'special') + ' ' + render(got, remaining) + paint(']', 'special');
    }
    return paint(getter && setter ? '[Getter/Setter]' : getter ? '[Getter]' : '[Setter]', 'special');
  }
  function entriesOf(input, remaining, skipIndices) {
    var keys = Object.keys(input).filter(function(key) { return !skipIndices || !/^(0|[1-9][0-9]*)$/.test(key); });
    if (options.showHidden) Object.getOwnPropertyNames(input).forEach(function(key) { if (keys.indexOf(key) < 0 && !(skipIndices && (key === 'length' || /^(0|[1-9][0-9]*)$/.test(key))) && !(typeof input === 'function' && (key === 'length' || key === 'name' || key === 'prototype'))) keys.push(key); });
    if (options.sorted) keys.sort(typeof options.sorted === 'function' ? options.sorted : undefined);
    var out = keys.map(function(key) {
      var enumerable = Object.prototype.propertyIsEnumerable.call(input, key), label = identifierKey(key);
      return (enumerable ? label : '[' + label + ']') + ': ' + renderProperty(input, key, remaining);
    });
    Object.getOwnPropertySymbols(input).forEach(function(symbol) {
      if (Object.prototype.propertyIsEnumerable.call(input, symbol)) out.push('[' + paint(String(symbol), 'symbol') + ']: ' + renderProperty(input, symbol, remaining));
    });
    return out;
  }
var indentationLvl = 0, currentDepth = 0;
function isBelowBreakLength(output, start, base) {
var total = output.length + start;
if (total + output.length > options.breakLength) return false;
for (var i = 0; i < output.length; i++) { total += output[i].length; if (total > options.breakLength) return false; }
return base === '' || base.indexOf('\n') < 0;
}
function groupArrayElements(output, value) {
var totalLength = 0, maxLength = 0, i = 0, outputLength = output.length;
if (options.maxArrayLength < output.length) outputLength--;
var separatorSpace = 2, dataLen = new Array(outputLength);
for (; i < outputLength; i++) { var len = options.colors ? output[i].replace(/\u001b\[\d\d?m/g, '').length : output[i].length; dataLen[i] = len; totalLength += len + separatorSpace; if (maxLength < len) maxLength = len; }
var actualMax = maxLength + separatorSpace;
if (actualMax * 3 + indentationLvl < options.breakLength && (totalLength / actualMax > 5 || maxLength <= 6)) {
var averageBias = Math.sqrt(actualMax - totalLength / output.length), biasedMax = Math.max(actualMax - 3 - averageBias, 1);
var columns = Math.min(Math.round(Math.sqrt(2.5 * biasedMax * outputLength) / biasedMax), Math.floor((options.breakLength - indentationLvl) / actualMax), options.compact * 4, 15);
if (columns <= 1) return output;
var tmp = [], maxLineLength = [];
for (var c = 0; c < columns; c++) { var lineLength = 0; for (var j = c; j < output.length; j += columns) { if (dataLen[j] > lineLength) lineLength = dataLen[j]; } maxLineLength.push(lineLength + separatorSpace); }
var padStart = true;
if (value !== undefined) { for (var k = 0; k < output.length; k++) { if (typeof value[k] !== 'number' && typeof value[k] !== 'bigint') { padStart = false; break; } } }
for (var row = 0; row < outputLength; row += columns) {
var max = Math.min(row + columns, outputLength), str = '', col = row;
for (; col < max - 1; col++) { var padding = maxLineLength[col - row] + output[col].length - dataLen[col], cell = output[col] + ', '; str += padStart ? cell.padStart(padding, ' ') : cell.padEnd(padding, ' '); }
if (padStart) str += output[col].padStart(maxLineLength[col - row] + output[col].length - dataLen[col] - separatorSpace, ' '); else str += output[col];
tmp.push(str);
}
if (options.maxArrayLength < output.length) tmp.push(output[outputLength]);
output = tmp;
}
return output;
}
function wrap(prefix, open, items, close, level, arrayValue) {
var brace0 = (prefix ? prefix + ' ' : '') + open;
if (!items.length) return brace0 + close;
var compact = options.compact;
if (compact !== true) {
if (typeof compact === 'number' && compact >= 1) {
var entries = items.length, grouped = items;
if (arrayValue !== undefined && entries > 6) grouped = groupArrayElements(grouped, arrayValue);
if (currentDepth - level < compact && entries === grouped.length) {
var start = grouped.length + indentationLvl + brace0.length + 10;
if (isBelowBreakLength(grouped, start, '')) { var joined = grouped.join(', '); if (joined.indexOf('\n') < 0) return brace0 + ' ' + joined + ' ' + close; }
}
items = grouped;
}
var indentation = '\n' + ' '.repeat(indentationLvl);
return brace0 + indentation + '  ' + items.join(',' + indentation + '  ') + indentation + close;
}
if (isBelowBreakLength(items, 0, '')) return brace0 + ' ' + items.join(', ') + ' ' + close;
var pad = ' '.repeat(indentationLvl);
return brace0 + (brace0.length === 1 ? ' ' : '\n' + pad + '  ') + items.join(',\n' + pad + '  ') + ' ' + close;
}
  function render(input, remaining) {
    if (input !== null && (typeof input === 'object' || typeof input === 'function') && options.customInspect !== false) {
      var custom = input[inspectCustom];
      if (typeof custom === 'function' && custom !== inspect) {
        var hookOptions = Object.assign({}, options, { stylize: function(text, kind) { return paint(String(text), kind); } }); var result = custom.call(input, remaining, hookOptions, inspect);
        if (result !== input) return typeof result === 'string' ? result : render(result, remaining);
      }
    }
    if (input === null) return paint('null', 'null');
    if (input === undefined) return paint('undefined', 'undefined');
    if (typeof input === 'bigint') return paint(groupDigits(String(input)) + 'n', 'bigint');
    if (typeof input === 'number') return paint(Object.is(input, -0) ? '-0' : groupDigits(String(input)), 'number');
    if (typeof input === 'boolean') return paint(String(input), 'boolean');
    if (typeof input === 'string') return renderString(input);
    if (typeof input === 'symbol') return paint(String(input), 'symbol');
    var base = '';
    if (typeof input === 'function') {
      var source = Function.prototype.toString.call(input), kind = /^class[\s{]/.test(source) ? 'class' : 'Function';
      if (kind === 'class') { var parent = Object.getPrototypeOf(input); base = '[class ' + (input.name || '(anonymous)') + (parent && parent.name ? ' extends ' + parent.name : '') + ']'; }
      else { var tag = input.constructor && input.constructor.name && input.constructor.name !== 'Function' ? input.constructor.name : 'Function'; base = '[' + tag + (input.name ? ': ' + input.name : ' (anonymous)') + ']'; }
      base = paint(base, 'special');
      var extra = entriesOf(input, remaining - 1, false);
      return extra.length ? (remaining < 0 ? base : base + ' { ' + extra.join(', ') + ' }') : base;
    }
    if (typeof input !== 'object') return String(input);
    if (input instanceof Error) { var header = input.message ? input.name + ': ' + input.message : String(input.name), frames = String(input.stack || '').split('\n').filter(function(line) { return /^\s+at /.test(line) && !/thaw[A-Z]|eval_script/.test(line); }); return String(input.stack || '').indexOf(header) === 0 && frames.length === String(input.stack).split('\n').length - 1 ? input.stack : [header].concat(frames).join('\n'); }
    if (input instanceof Date) return paint(isNaN(input.getTime()) ? 'Invalid Date' : input.toISOString(), 'date');
    if (input instanceof RegExp) return paint(String(input), 'regexp');
    if (ArrayBuffer.isView(input) && !(input instanceof DataView)) { if (typeof Buffer !== 'undefined' && Buffer.isBuffer(input)) { var hex = []; for (var b = 0; b < input.length && b < 50; b++) hex.push((input[b] < 16 ? '0' : '') + input[b].toString(16)); return '<Buffer' + (hex.length ? ' ' + hex.join(' ') : '') + (input.length > 50 ? ' ... ' + (input.length - 50) + ' more byte' + (input.length - 50 > 1 ? 's' : '') : '') + '>'; } var typedItems = [], typedMax = Math.min(input.length, options.maxArrayLength); for (var t = 0; t < typedMax; t++) typedItems.push(render(input[t], remaining - 1)); if (input.length > typedMax) typedItems.push('... ' + (input.length - typedMax) + ' more item' + (input.length - typedMax > 1 ? 's' : '')); if (options.showHidden) typedItems.push('[BYTES_PER_ELEMENT]: ' + input.BYTES_PER_ELEMENT, '[length]: ' + input.length, '[byteLength]: ' + input.byteLength, '[byteOffset]: ' + input.byteOffset, '[buffer]: ' + render(input.buffer, remaining - 1)); return input[Symbol.toStringTag] + '(' + input.length + ') ' + (typedItems.length ? '[ ' + typedItems.join(', ') + ' ]' : '[]'); }
    if (remaining < 0 && !(Array.isArray(input) ? input.length === 0 && Object.keys(input).length === 0 : Object.getPrototypeOf(input) === Object.prototype && Object.keys(input).length === 0 && Object.getOwnPropertySymbols(input).length === 0)) { var shortName = constructorName(input); return paint('[' + (Array.isArray(input) ? 'Array' : input instanceof Map ? 'Map' : input instanceof Set ? 'Set' : shortName || 'Object') + ']', 'special'); }
    if (seen.indexOf(input) >= 0) { if (!refs.has(input)) refs.set(input, refs.size + 1); return paint('[Circular *' + refs.get(input) + ']', 'special'); }
    seen.push(input);
    if (!isEmptyContainer(input)) currentDepth = seen.length - 1;
    try {
      var name = constructorName(input), nullProto = Object.getPrototypeOf(input) === null, result;
      if (Array.isArray(input)) {
        var items = [], holes = 0, shown = 0, length = input.length;
        for (var index = 0; index < length && shown < options.maxArrayLength; index++) {
          if (!Object.prototype.hasOwnProperty.call(input, index)) { holes++; continue; }
          if (holes) { items.push(paint('<' + holes + ' empty item' + (holes > 1 ? 's' : '') + '>', 'undefined')); shown++; holes = 0; if (shown >= options.maxArrayLength) { index--; continue; } }
          items.push(renderProperty(input, String(index), remaining - 1)); shown++;
        }
        if (holes && shown < options.maxArrayLength) { items.push(paint('<' + holes + ' empty item' + (holes > 1 ? 's' : '') + '>', 'undefined')); index = length; }
        if (index < length) { var more = length - index; items.push('... ' + more + ' more item' + (more > 1 ? 's' : '')); }
        items = items.concat(entriesOf(input, remaining - 1, true));
        if (options.showHidden) items.push('[length]: ' + length);
        result = wrap(name && name !== 'Array' ? name + '(' + length + ')' : '', '[', items, ']', seen.length - 1, input);
      } else if (input instanceof Map) {
        result = wrap('Map(' + input.size + ')', '{', Array.from(input).map(function(entry) { return indented(entry[0], remaining - 1) + ' => ' + indented(entry[1], remaining - 1); }).concat(entriesOf(input, remaining - 1, false)), '}', seen.length - 1);
      } else if (input instanceof Set) {
        result = wrap('Set(' + input.size + ')', '{', Array.from(input).map(function(item) { return indented(item, remaining - 1); }).concat(entriesOf(input, remaining - 1, false)), '}', seen.length - 1);
      } else {
        var tagName = input[Symbol.toStringTag], label = nullProto ? '[Object: null prototype]' : name && name !== 'Object' ? name : '';
        if (typeof tagName === 'string' && tagName !== '' && tagName !== name && !(options.showHidden ? Object.prototype.hasOwnProperty : Object.prototype.propertyIsEnumerable).call(input, Symbol.toStringTag)) label = (label || 'Object') + ' [' + tagName + ']';
        result = wrap(label, '{', entriesOf(input, remaining - 1, false), '}', seen.length - 1);
      }
      if (refs.has(input)) result = '<ref *' + refs.get(input) + '> ' + result;
      return result;
    } finally { seen.pop(); }
  }
  return render(value, depth);
}
inspect.custom = inspectCustom; inspect.defaultOptions = { showHidden: false, depth: 2, colors: false, customInspect: true, showProxy: false, maxArrayLength: 100, maxStringLength: 10000, breakLength: 80, compact: 3, sorted: false, getters: false, numericSeparator: false };
function fmtNumber(n) { return Object.is(n, -0) ? '-0' : String(n); }
function hasBuiltInToString(value) {
  if (typeof value.toString !== 'function') return true;
  if (Object.prototype.hasOwnProperty.call(value, 'toString')) return false;
  var pointer = value; do { pointer = Object.getPrototypeOf(pointer); } while (pointer && !Object.prototype.hasOwnProperty.call(pointer, 'toString'));
  if (!pointer) return true; var descriptor = Object.getOwnPropertyDescriptor(pointer, 'constructor');
  return descriptor !== undefined && typeof descriptor.value === 'function' && globalThis[descriptor.value.name] === descriptor.value;
}
function format() {
  var args = Array.prototype.slice.call(arguments), first = args[0], a = 0, str = '', join = '';
  if (typeof first === 'string') {
    if (args.length === 1) return first;
    var lastPos = 0, tempStr, tempArg;
    for (var i = 0; i < first.length - 1; i++) {
      if (first.charCodeAt(i) !== 37) continue;
      var next = first.charCodeAt(++i);
      if (a + 1 !== args.length) {
        switch (next) {
          case 115: tempArg = args[++a]; tempStr = typeof tempArg === 'number' ? fmtNumber(tempArg) : typeof tempArg === 'bigint' ? String(tempArg) + 'n' : (typeof tempArg !== 'object' || tempArg === null || !hasBuiltInToString(tempArg)) ? String(tempArg) : inspect(tempArg, { depth: 0 }); break;
          case 106: tempArg = args[++a]; try { tempStr = JSON.stringify(tempArg); } catch (_) { tempStr = '[Circular]'; } break;
          case 100: tempArg = args[++a]; tempStr = typeof tempArg === 'bigint' ? String(tempArg) + 'n' : typeof tempArg === 'symbol' ? 'NaN' : fmtNumber(Number(tempArg)); break;
          case 79: tempStr = inspect(args[++a]); break;
          case 111: tempStr = inspect(args[++a], { showHidden: true, depth: 4 }); break;
          case 105: tempArg = args[++a]; tempStr = typeof tempArg === 'bigint' ? String(tempArg) + 'n' : typeof tempArg === 'symbol' ? 'NaN' : fmtNumber(parseInt(tempArg)); break;
          case 102: tempArg = args[++a]; tempStr = typeof tempArg === 'symbol' ? 'NaN' : fmtNumber(parseFloat(tempArg)); break;
          case 99: a += 1; tempStr = ''; break;
          case 37: str += first.slice(lastPos, i); lastPos = i + 1; continue;
          default: continue;
        }
        if (lastPos !== i - 1) str += first.slice(lastPos, i - 1);
        str += tempStr; lastPos = i + 1;
      } else if (next === 37) { str += first.slice(lastPos, i); lastPos = i + 1; }
    }
    if (lastPos !== 0) { a++; join = ' '; if (lastPos < first.length) str += first.slice(lastPos); }
  }
  while (a < args.length) { var value = args[a]; str += join; str += typeof value !== 'string' ? inspect(value) : value; join = ' '; a++; }
  return str;
}
function formatWithOptions(options) { return format.apply(null, Array.prototype.slice.call(arguments, 1)); }
function inherits(constructor, superConstructor) { if (constructor === undefined || superConstructor === undefined) throw new TypeError('constructors are required'); constructor.super_ = superConstructor; Object.setPrototypeOf(constructor.prototype, superConstructor.prototype); }
var promisifyCustom = Symbol.for('nodejs.util.promisify.custom');
function promisify(original) {
  if (typeof original !== 'function') throw new TypeError('original must be a function');
  if (original[promisifyCustom]) { var custom = original[promisifyCustom]; if (typeof custom !== 'function') { var error = new TypeError('util.promisify.custom must be a function'); error.code = 'ERR_INVALID_ARG_TYPE'; throw error; } Object.defineProperty(custom, promisifyCustom, { value: custom, enumerable: false, writable: false, configurable: true }); return custom; }
  function wrapped() { var self = this; var args = Array.prototype.slice.call(arguments); return new Promise(function(resolve, reject) { args.push(function(error, value) { if (error) reject(error); else resolve(value); }); original.apply(self, args); }); }
  Object.setPrototypeOf(wrapped, Object.getPrototypeOf(original));
  Object.defineProperty(wrapped, promisifyCustom, { value: wrapped, enumerable: false, writable: false, configurable: true }); return wrapped;
}
promisify.custom = promisifyCustom;
function callbackifyError(reason) { var error = new Error('Promise was rejected with falsy value'); error.code = 'ERR_FALSY_VALUE_REJECTION'; error.reason = reason; return error; }
function callbackifyReason(error) { return error ? error : callbackifyError(error); }
function callbackify(original) {
  if (typeof original !== 'function') throw new TypeError('original must be a function');
  return function() { var self = this, args = Array.prototype.slice.call(arguments), callback = args.pop(); if (typeof callback !== 'function') throw new TypeError('callback must be a function'); Promise.resolve(original.apply(self, args)).then(function(value) { queueMicrotask(function() { callback.call(self, null, value); }); }, function(error) { queueMicrotask(function() { callback.call(self, callbackifyReason(error)); }); }); };
}
function deprecate(fn) { return function() { return fn.apply(this, arguments); }; }
function debuglog(section) { var enabled = String(process.env.NODE_DEBUG || '').toUpperCase().split(/[ ,]+/).indexOf(String(section).toUpperCase()) >= 0; var logger = enabled ? function() { console.error(String(section).toUpperCase() + ' ' + format.apply(null, arguments)); } : function() {}; logger.enabled = enabled; return logger; }
function stripVTControlCharacters(value) { return String(value).replace(/[\u001B\u009B][[\]()#;?]*(?:(?:[a-zA-Z\d]*(?:;[-a-zA-Z\d\/#&.:=?%@~_]+)*)?\u0007|(?:(?:\d{1,4}(?:;\d{0,4})*)?[\dA-PR-TZcf-nq-uy=><~]))/g, ''); }
function toUSVString(value) { return String(value).replace(/[\uD800-\uDFFF]/gu, '\uFFFD'); }
function parseArgs(config) {
  config = config || {};
  var args = Array.from(config.args === undefined ? (process.argv || []).slice(2) : config.args, String), definitions = config.options || {}, values = Object.create(null), positionals = [], tokens = [], short = Object.create(null), allowPositionals = config.allowPositionals === undefined ? config.strict === false : config.allowPositionals;
  Object.keys(definitions).forEach(function(name) { var definition = definitions[name] || {}; if (definition.short) short[String(definition.short)] = name; });
  function assign(name, value, optionIndex, rawName, inlineValue) {
    var definition = definitions[name];
    if (!definition) { if (config.strict !== false) { var error = new TypeError('Unknown option --' + name); error.code = 'ERR_PARSE_ARGS_UNKNOWN_OPTION'; throw error; } definition = { type: 'boolean' }; }
    var strict = config.strict !== false, supplied = typeof value === 'string';
    if (strict && definition.type === 'boolean' && supplied) { var error = new TypeError('Option --' + name + ' does not take an argument'); error.code = 'ERR_PARSE_ARGS_INVALID_OPTION_VALUE'; throw error; }
    if (strict && definition.type === 'string' && (value === undefined || (!inlineValue && supplied && value.length > 1 && value.charAt(0) === '-'))) { var error = new TypeError(value === undefined ? 'Option --' + name + ' argument is missing' : 'Option --' + name + ' argument is ambiguous'); error.code = 'ERR_PARSE_ARGS_INVALID_OPTION_VALUE'; throw error; }
    if (definition.type === 'string' && value !== undefined) value = String(value);
    else if (value === undefined) value = true;
    else if (strict || !supplied) value = Boolean(value);
    if (definition.multiple) (values[name] || (values[name] = [])).push(value); else values[name] = value;
    tokens.push({ kind: 'option', index: optionIndex, name: name, rawName: rawName, value: definition.type === 'string' || (!strict && supplied) ? (supplied ? value : undefined) : undefined, inlineValue: inlineValue });
  }
  function addPositional(value, index) { if (!allowPositionals) { var error = new TypeError('Unexpected argument ' + value); error.code = 'ERR_PARSE_ARGS_UNEXPECTED_POSITIONAL'; throw error; } positionals.push(value); tokens.push({ kind: 'positional', index: index, value: value }); }
  for (var index = 0; index < args.length; index++) {
    var argument = args[index];
    if (argument === '--') { tokens.push({ kind: 'option-terminator', index: index }); for (index++; index < args.length; index++) addPositional(args[index], index); break; }
    if (argument.slice(0, 2) === '--') {
      var optionIndex = index, equal = argument.indexOf('='), name = argument.slice(2, equal < 0 ? undefined : equal), value = equal < 0 ? undefined : argument.slice(equal + 1), rawName = '--' + name, definition = definitions[name];
      if (name.slice(0, 3) === 'no-' && config.allowNegative && definitions[name.slice(3)] && definitions[name.slice(3)].type === 'boolean') {
        if (equal < 0) { assign(name.slice(3), false, optionIndex, argument, undefined); continue; }
        if (config.strict !== false) { assign(name.slice(3), value, optionIndex, rawName, true); continue; }
      }
      if (equal < 0 && definition && definition.type === 'string' && index + 1 < args.length) value = args[++index];
      assign(name, value, optionIndex, rawName, equal < 0 ? (value === undefined ? undefined : false) : true);
    } else if (argument[0] === '-' && argument.length > 1) {
      var letters = argument.slice(1);
      for (var letterIndex = 0; letterIndex < letters.length; letterIndex++) {
        var optionIndex = index, character = letters.charAt(letterIndex), name = short[character] || character, definition = definitions[name], value, inlineValue = undefined;
        if (definition && definition.type === 'string') {
          value = letters.slice(letterIndex + 1);
          if (value !== '') inlineValue = true; else { value = args[index + 1]; if (value !== undefined) { index++; inlineValue = false; } }
          assign(name, value, optionIndex, '-' + character, inlineValue); break;
        }
        assign(name, undefined, optionIndex, '-' + character, undefined);
      }
    } else addPositional(argument, index);
  }
  Object.keys(definitions).forEach(function(name) { if (!Object.prototype.hasOwnProperty.call(values, name)) { var definition = definitions[name] || {}, defaultValue = definition.default; if (defaultValue !== undefined) values[name] = definition.multiple ? Array.from(defaultValue) : defaultValue; } });
  var result = { values: values, positionals: positionals }; if (config.tokens) result.tokens = tokens; return result;
}
function strictDeep(actual, expected, seen) {
if (Object.is(actual, expected)) return true;
if (actual === null || expected === null || typeof actual !== 'object' || typeof expected !== 'object') return false;
if (Object.getPrototypeOf(actual) !== Object.getPrototypeOf(expected)) return false;
seen = seen || new Map(); if (seen.get(actual) === expected) return true; seen.set(actual, expected);
if (actual instanceof Date) return expected instanceof Date && actual.getTime() === expected.getTime();
if (actual instanceof RegExp) return expected instanceof RegExp && actual.source === expected.source && actual.flags === expected.flags;
if ((actual instanceof Number || actual instanceof String || actual instanceof Boolean) && !Object.is(actual.valueOf(), expected.valueOf())) return false;
if (actual instanceof Error) { if (actual.name !== expected.name || actual.message !== expected.message || ('cause' in actual) !== ('cause' in expected) || !strictDeep(actual.cause, expected.cause, seen) || !strictDeep(actual.errors, expected.errors, seen)) return false; }
if (Array.isArray(actual) && actual.length !== expected.length) return false;
if (actual instanceof ArrayBuffer || actual instanceof DataView) { if (actual.byteLength !== expected.byteLength) return false; var left = actual instanceof DataView ? new Uint8Array(actual.buffer, actual.byteOffset, actual.byteLength) : new Uint8Array(actual), right = expected instanceof DataView ? new Uint8Array(expected.buffer, expected.byteOffset, expected.byteLength) : new Uint8Array(expected); for (var at = 0; at < left.length; at++) if (left[at] !== right[at]) return false; return true; }
if (ArrayBuffer.isView(actual)) { if (!ArrayBuffer.isView(expected) || actual.length !== expected.length) return false; for (var i = 0; i < actual.length; i++) if (!Object.is(actual[i], expected[i])) return false; return true; }
if (actual instanceof Map) { if (actual.size !== expected.size) return false; var usedKeys = new Set(); for (var entry of actual) { if (expected.has(entry[0]) && strictDeep(entry[1], expected.get(entry[0]), seen)) { usedKeys.add(entry[0]); continue; } var found = false; for (var other of expected) { if (usedKeys.has(other[0])) continue; if (strictDeep(entry[0], other[0], seen) && strictDeep(entry[1], other[1], seen)) { usedKeys.add(other[0]); found = true; break; } } if (!found) return false; } }
if (actual instanceof Set) { if (actual.size !== expected.size) return false; var usedValues = new Set(); for (var item of actual) { if (expected.has(item)) { usedValues.add(item); continue; } var matched = false; for (var candidate of expected) { if (usedValues.has(candidate)) continue; if (strictDeep(item, candidate, seen)) { usedValues.add(candidate); matched = true; break; } } if (!matched) return false; } }
var left = Object.keys(actual); var right = Object.keys(expected); if (left.length !== right.length) return false;
for (var index = 0; index < left.length; index++) { var key = left[index]; if (!Object.prototype.hasOwnProperty.call(expected, key) || !strictDeep(actual[key], expected[key], seen)) return false; }
return true;
}
function isDeepStrictEqual(left, right) { return strictDeep(left, right); }
var styleCodes = { reset: [0, 0], bold: [1, 22], dim: [2, 22], italic: [3, 23], underline: [4, 24], blink: [5, 25], inverse: [7, 27], hidden: [8, 28], strikethrough: [9, 29], doubleunderline: [21, 24], black: [30, 39], red: [31, 39], green: [32, 39], yellow: [33, 39], blue: [34, 39], magenta: [35, 39], cyan: [36, 39], white: [37, 39], gray: [90, 39], grey: [90, 39], blackBright: [90, 39], redBright: [91, 39], greenBright: [92, 39], yellowBright: [93, 39], blueBright: [94, 39], magentaBright: [95, 39], cyanBright: [96, 39], whiteBright: [97, 39], bgBlack: [40, 49], bgRed: [41, 49], bgGreen: [42, 49], bgYellow: [43, 49], bgBlue: [44, 49], bgMagenta: [45, 49], bgCyan: [46, 49], bgWhite: [47, 49], bgGray: [100, 49], bgGrey: [100, 49], bgBlackBright: [100, 49], bgRedBright: [101, 49], bgGreenBright: [102, 49], bgYellowBright: [103, 49], bgBlueBright: [104, 49], bgMagentaBright: [105, 49], bgCyanBright: [106, 49], bgWhiteBright: [107, 49] };
function styleText(format, text, options) {
  if (typeof text !== 'string') { var textError = new TypeError('The "text" argument must be of type string. Received ' + (text === null ? 'null' : typeof text === 'object' ? 'an instance of ' + (text.constructor && text.constructor.name) : 'type ' + typeof text + ' (' + String(text) + ')')); textError.code = 'ERR_INVALID_ARG_TYPE'; throw textError; }
  var names = Array.isArray(format) ? format : [format], left = '', right = '';
  names.forEach(function(name) { var code = styleCodes[name]; if (!code) { var formatError = new TypeError('The argument \'format\' must be one of: ' + Object.keys(styleCodes).map(function(key) { return "'" + key + "'"; }).join(', ') + '. Received ' + format); formatError.code = 'ERR_INVALID_ARG_VALUE'; throw formatError; } left += '\u001b[' + code[0] + 'm'; right = '\u001b[' + code[1] + 'm' + right; });
  var stream = options && options.stream !== undefined ? options.stream : process.stdout;
  if (!(options && options.validateStream === false) && !(stream && stream.isTTY && (typeof stream.hasColors !== 'function' || stream.hasColors()))) return text;
  return left + text + right;
}
var systemErrorNames = {'-1':'EPERM','-2':'ENOENT','-3':'ESRCH','-4':'EINTR','-5':'EIO','-6':'ENXIO','-7':'E2BIG','-8':'ENOEXEC','-9':'EBADF','-10':'ECHILD','-11':'EWOULDBLOCK','-12':'ENOMEM','-13':'EACCES','-14':'EFAULT','-16':'EBUSY','-17':'EEXIST','-18':'EXDEV','-19':'ENODEV','-20':'ENOTDIR','-21':'EISDIR','-22':'EINVAL','-23':'ENFILE','-24':'EMFILE','-25':'ENOTTY','-26':'ETXTBSY','-27':'EFBIG','-28':'ENOSPC','-29':'ESPIPE','-30':'EROFS','-31':'EMLINK','-32':'EPIPE','-33':'EDOM','-34':'ERANGE','-35':'EDEADLK','-36':'ENAMETOOLONG','-37':'ENOLCK','-38':'ENOSYS','-39':'ENOTEMPTY','-40':'ELOOP','-42':'ENOMSG','-43':'EIDRM','-60':'ENOSTR','-61':'ENODATA','-62':'ETIME','-63':'ENOSR','-67':'ENOLINK','-71':'EPROTO','-72':'EMULTIHOP','-74':'EBADMSG','-75':'EOVERFLOW','-84':'EILSEQ','-88':'ENOTSOCK','-89':'EDESTADDRREQ','-90':'EMSGSIZE','-91':'EPROTOTYPE','-92':'ENOPROTOOPT','-93':'EPROTONOSUPPORT','-95':'EOPNOTSUPP','-97':'EAFNOSUPPORT','-98':'EADDRINUSE','-99':'EADDRNOTAVAIL','-100':'ENETDOWN','-101':'ENETUNREACH','-102':'ENETRESET','-103':'ECONNABORTED','-104':'ECONNRESET','-105':'ENOBUFS','-106':'EISCONN','-107':'ENOTCONN','-110':'ETIMEDOUT','-111':'ECONNREFUSED','-113':'EHOSTUNREACH','-114':'EALREADY','-115':'EINPROGRESS','-116':'ESTALE','-122':'EDQUOT','-125':'ECANCELED'}; function getSystemErrorName(code) { return systemErrorNames[code] || 'Unknown system error ' + code; }
function isArray(value) { return Array.isArray(value); }
var types = globalThis.__thaw_util_types;
module.exports = { inspect: inspect, format: format, formatWithOptions: formatWithOptions, inherits: inherits, promisify: promisify, callbackify: callbackify, deprecate: deprecate, debuglog: debuglog, isDeepStrictEqual: isDeepStrictEqual, styleText: styleText, getSystemErrorName: getSystemErrorName, isArray: isArray, stripVTControlCharacters: stripVTControlCharacters, toUSVString: toUSVString, parseArgs: parseArgs, TextEncoder: globalThis.TextEncoder, TextDecoder: globalThis.TextDecoder, types: types };
module.exports.default = module.exports; module.exports.__esModule = true;

},
"better-sqlite3/lib/methods/backup.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');
const { cppdb } = require('../util');
const fsAccess = promisify(fs.access);

module.exports = async function backup(filename, options) {
	if (options == null) options = {};

	// Validate arguments
	if (typeof filename !== 'string') throw new TypeError('Expected first argument to be a string');
	if (typeof options !== 'object') throw new TypeError('Expected second argument to be an options object');

	// Interpret options
	filename = filename.trim();
	const attachedName = 'attached' in options ? options.attached : 'main';
	const handler = 'progress' in options ? options.progress : null;

	// Validate interpreted options
	if (!filename) throw new TypeError('Backup filename cannot be an empty string');
	if (filename === ':memory:') throw new TypeError('Invalid backup filename ":memory:"');
	if (typeof attachedName !== 'string') throw new TypeError('Expected the "attached" option to be a string');
	if (!attachedName) throw new TypeError('The "attached" option cannot be an empty string');
	if (handler != null && typeof handler !== 'function') throw new TypeError('Expected the "progress" option to be a function');

	// Make sure the specified directory exists
	await fsAccess(path.dirname(filename)).catch(() => {
		throw new TypeError('Cannot save backup because the directory does not exist');
	});

	const isNewFile = await fsAccess(filename).then(() => false, () => true);
	return runBackup(this[cppdb].backup(this, attachedName, filename, isNewFile), handler || null);
};

const runBackup = (backup, handler) => {
	let rate = 0;
	let useDefault = true;

	return new Promise((resolve, reject) => {
		setImmediate(function step() {
			try {
				const progress = backup.transfer(rate);
				if (!progress.remainingPages) {
					backup.close();
					resolve(progress);
					return;
				}
				if (useDefault) {
					useDefault = false;
					rate = 100;
				}
				if (handler) {
					const ret = handler(progress);
					if (ret !== undefined) {
						if (typeof ret === 'number' && ret === ret) rate = Math.max(0, Math.min(0x7fffffff, Math.round(ret)));
						else throw new TypeError('Expected progress callback to return a number or undefined');
					}
				}
				setImmediate(step);
			} catch (err) {
				backup.close();
				reject(err);
			}
		});
	});
};

},
"better-sqlite3/lib/methods/pragma.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const { getBooleanOption, cppdb } = require('../util');

module.exports = function pragma(source, options) {
	if (options == null) options = {};
	if (typeof source !== 'string') throw new TypeError('Expected first argument to be a string');
	if (typeof options !== 'object') throw new TypeError('Expected second argument to be an options object');
	const simple = getBooleanOption(options, 'simple');

	const stmt = this[cppdb].prepare(`PRAGMA ${source}`, this, true);
	return simple ? stmt.pluck().get() : stmt.all();
};

},
"better-sqlite3/lib/methods/transaction.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const { cppdb } = require('../util');
const controllers = new WeakMap();

module.exports = function transaction(fn) {
	if (typeof fn !== 'function') throw new TypeError('Expected first argument to be a function');

	const db = this[cppdb];
	const controller = getController(db, this);
	const { apply } = Function.prototype;

	// Each version of the transaction function has these same properties
	const properties = {
		default: { value: wrapTransaction(apply, fn, db, controller.default) },
		deferred: { value: wrapTransaction(apply, fn, db, controller.deferred) },
		immediate: { value: wrapTransaction(apply, fn, db, controller.immediate) },
		exclusive: { value: wrapTransaction(apply, fn, db, controller.exclusive) },
		database: { value: this, enumerable: true },
	};

	Object.defineProperties(properties.default.value, properties);
	Object.defineProperties(properties.deferred.value, properties);
	Object.defineProperties(properties.immediate.value, properties);
	Object.defineProperties(properties.exclusive.value, properties);

	// Return the default version of the transaction function
	return properties.default.value;
};

// Return the database's cached transaction controller, or create a new one
const getController = (db, self) => {
	let controller = controllers.get(db);
	if (!controller) {
		const shared = {
			commit: db.prepare('COMMIT', self, false),
			rollback: db.prepare('ROLLBACK', self, false),
			savepoint: db.prepare('SAVEPOINT `\t_bs3.\t`', self, false),
			release: db.prepare('RELEASE `\t_bs3.\t`', self, false),
			rollbackTo: db.prepare('ROLLBACK TO `\t_bs3.\t`', self, false),
		};
		controllers.set(db, controller = {
			default: Object.assign({ begin: db.prepare('BEGIN', self, false) }, shared),
			deferred: Object.assign({ begin: db.prepare('BEGIN DEFERRED', self, false) }, shared),
			immediate: Object.assign({ begin: db.prepare('BEGIN IMMEDIATE', self, false) }, shared),
			exclusive: Object.assign({ begin: db.prepare('BEGIN EXCLUSIVE', self, false) }, shared),
		});
	}
	return controller;
};

// Return a new transaction function by wrapping the given function
const wrapTransaction = (apply, fn, db, { begin, commit, rollback, savepoint, release, rollbackTo }) => function sqliteTransaction() {
	let before, after, undo;
	if (db.inTransaction) {
		before = savepoint;
		after = release;
		undo = rollbackTo;
	} else {
		before = begin;
		after = commit;
		undo = rollback;
	}
	before.run();
	try {
		const result = apply.call(fn, this, arguments);
		if (result && typeof result.then === 'function') {
			throw new TypeError('Transaction function cannot return a promise');
		}
		after.run();
		return result;
	} catch (ex) {
		if (db.inTransaction) {
			undo.run();
			if (undo !== rollback) after.run();
		}
		throw ex;
	}
};

},
"better-sqlite3/lib/methods/wrappers.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';
const { cppdb } = require('../util');

exports.prepare = function prepare(sql) {
	return this[cppdb].prepare(sql, this, false);
};

exports.exec = function exec(sql) {
	this[cppdb].exec(sql);
	return this;
};

exports.close = function close() {
	this[cppdb].close();
	return this;
};

exports.loadExtension = function loadExtension(...args) {
	this[cppdb].loadExtension(...args);
	return this;
};

exports.defaultSafeIntegers = function defaultSafeIntegers(...args) {
	this[cppdb].defaultSafeIntegers(...args);
	return this;
};

exports.unsafeMode = function unsafeMode(...args) {
	this[cppdb].unsafeMode(...args);
	return this;
};

exports.getters = {
	name: {
		get: function name() { return this[cppdb].name; },
		enumerable: true,
	},
	open: {
		get: function open() { return this[cppdb].open; },
		enumerable: true,
	},
	inTransaction: {
		get: function inTransaction() { return this[cppdb].inTransaction; },
		enumerable: true,
	},
	readonly: {
		get: function readonly() { return this[cppdb].readonly; },
		enumerable: true,
	},
	memory: {
		get: function memory() { return this[cppdb].memory; },
		enumerable: true,
	},
};

},
"better-sqlite3/lib/util.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
'use strict';

exports.getBooleanOption = (options, key) => {
	let value = false;
	if (key in options && typeof (value = options[key]) !== 'boolean') {
		throw new TypeError(`Expected the "${key}" option to be a boolean`);
	}
	return value;
};

exports.cppdb = Symbol();
exports.inspect = Symbol.for('nodejs.util.inspect.custom');

},
};
var __thaw_bundle_import_maps = {
"better-sqlite3/lib/index.js": {},
"better-sqlite3/lib/sqlite-error.js": {},
"node:stream": {},
"node:events": {},
"node:fs": {},
"node:path": {},
"better-sqlite3/lib/database.js": {},
"bindings/./bindings.js": {},
"file-uri-to-path/index.js": {},
"better-sqlite3/lib/methods/inspect.js": {},
"better-sqlite3/lib/methods/table.js": {},
"better-sqlite3/lib/methods/aggregate.js": {},
"better-sqlite3/lib/methods/function.js": {},
"better-sqlite3/lib/methods/serialize.js": {},
"node:util": {},
"better-sqlite3/lib/methods/backup.js": {},
"better-sqlite3/lib/methods/pragma.js": {},
"better-sqlite3/lib/methods/transaction.js": {},
"better-sqlite3/lib/methods/wrappers.js": {},
"better-sqlite3/lib/util.js": {},
};
var __thaw_bundle_known_package_maps = {
"better-sqlite3/lib/index.js": [],
"better-sqlite3/lib/sqlite-error.js": [],
"node:stream": [],
"node:events": [],
"node:fs": [],
"node:path": [],
"better-sqlite3/lib/database.js": ["bindings"],
"bindings/./bindings.js": ["file-uri-to-path"],
"file-uri-to-path/index.js": [],
"better-sqlite3/lib/methods/inspect.js": [],
"better-sqlite3/lib/methods/table.js": [],
"better-sqlite3/lib/methods/aggregate.js": [],
"better-sqlite3/lib/methods/function.js": [],
"better-sqlite3/lib/methods/serialize.js": [],
"node:util": [],
"better-sqlite3/lib/methods/backup.js": [],
"better-sqlite3/lib/methods/pragma.js": [],
"better-sqlite3/lib/methods/transaction.js": [],
"better-sqlite3/lib/methods/wrappers.js": [],
"better-sqlite3/lib/util.js": [],
};
var __thaw_bundle_require_maps = {
"better-sqlite3/lib/index.js": {"./database": "better-sqlite3/lib/database.js", "./sqlite-error": "better-sqlite3/lib/sqlite-error.js", },
"better-sqlite3/lib/sqlite-error.js": {},
"node:stream": {},
"node:events": {},
"node:fs": {"node:stream": "node:stream", "node:events": "node:events", },
"node:path": {},
"better-sqlite3/lib/database.js": {"./util": "better-sqlite3/lib/util.js", "./sqlite-error": "better-sqlite3/lib/sqlite-error.js", "./methods/wrappers": "better-sqlite3/lib/methods/wrappers.js", "./methods/transaction": "better-sqlite3/lib/methods/transaction.js", "./methods/pragma": "better-sqlite3/lib/methods/pragma.js", "./methods/backup": "better-sqlite3/lib/methods/backup.js", "./methods/serialize": "better-sqlite3/lib/methods/serialize.js", "./methods/function": "better-sqlite3/lib/methods/function.js", "./methods/aggregate": "better-sqlite3/lib/methods/aggregate.js", "./methods/table": "better-sqlite3/lib/methods/table.js", "./methods/inspect": "better-sqlite3/lib/methods/inspect.js", "fs": "node:fs", "path": "node:path", "bindings": "bindings/./bindings.js", },
"bindings/./bindings.js": {"fs": "node:fs", "path": "node:path", "file-uri-to-path": "file-uri-to-path/index.js", },
"file-uri-to-path/index.js": {"path": "node:path", },
"better-sqlite3/lib/methods/inspect.js": {},
"better-sqlite3/lib/methods/table.js": {"../util": "better-sqlite3/lib/util.js", },
"better-sqlite3/lib/methods/aggregate.js": {"../util": "better-sqlite3/lib/util.js", },
"better-sqlite3/lib/methods/function.js": {"../util": "better-sqlite3/lib/util.js", },
"better-sqlite3/lib/methods/serialize.js": {"../util": "better-sqlite3/lib/util.js", },
"node:util": {},
"better-sqlite3/lib/methods/backup.js": {"../util": "better-sqlite3/lib/util.js", "fs": "node:fs", "path": "node:path", "util": "node:util", },
"better-sqlite3/lib/methods/pragma.js": {"../util": "better-sqlite3/lib/util.js", },
"better-sqlite3/lib/methods/transaction.js": {"../util": "better-sqlite3/lib/util.js", },
"better-sqlite3/lib/methods/wrappers.js": {"../util": "better-sqlite3/lib/util.js", },
"better-sqlite3/lib/util.js": {},
};
var __thaw_bundle_export_graphs = JSON.parse("{}");
var __thaw_bundle_commonjs_contexts = JSON.parse("{\"better-sqlite3/lib/index.js\":true,\"better-sqlite3/lib/sqlite-error.js\":true,\"node:stream\":true,\"node:events\":true,\"node:fs\":true,\"node:path\":true,\"better-sqlite3/lib/database.js\":true,\"bindings/./bindings.js\":true,\"file-uri-to-path/index.js\":true,\"better-sqlite3/lib/methods/inspect.js\":true,\"better-sqlite3/lib/methods/table.js\":true,\"better-sqlite3/lib/methods/aggregate.js\":true,\"better-sqlite3/lib/methods/function.js\":true,\"better-sqlite3/lib/methods/serialize.js\":true,\"node:util\":true,\"better-sqlite3/lib/methods/backup.js\":true,\"better-sqlite3/lib/methods/pragma.js\":true,\"better-sqlite3/lib/methods/transaction.js\":true,\"better-sqlite3/lib/methods/wrappers.js\":true,\"better-sqlite3/lib/util.js\":true}");
var __thaw_bundle_cjs_export_names = JSON.parse("{\"better-sqlite3/lib/index.js\":[\"SqliteError\",\"default\"],\"better-sqlite3/lib/sqlite-error.js\":[\"default\"],\"node:stream\":[\"__esModule\",\"default\"],\"node:events\":[\"EventEmitter\",\"EventEmitterAsyncResource\",\"__esModule\",\"addAbortListener\",\"captureRejectionSymbol\",\"default\",\"errorMonitor\",\"getEventListeners\",\"getMaxListeners\",\"kMaxEventTargetListeners\",\"kMaxEventTargetListenersWarned\",\"on\",\"once\",\"setMaxListeners\",\"usingDomains\"],\"node:fs\":[\"__esModule\",\"default\"],\"node:path\":[\"__esModule\",\"default\"],\"better-sqlite3/lib/database.js\":[\"default\"],\"bindings/./bindings.js\":[\"default\",\"getFileName\",\"getRoot\"],\"file-uri-to-path/index.js\":[\"default\"],\"better-sqlite3/lib/methods/inspect.js\":[\"default\"],\"better-sqlite3/lib/methods/table.js\":[\"default\"],\"better-sqlite3/lib/methods/aggregate.js\":[\"default\"],\"better-sqlite3/lib/methods/function.js\":[\"default\"],\"better-sqlite3/lib/methods/serialize.js\":[\"default\"],\"node:util\":[\"TextDecoder\",\"TextEncoder\",\"__esModule\",\"callbackify\",\"debuglog\",\"default\",\"deprecate\",\"format\",\"formatWithOptions\",\"getSystemErrorName\",\"inherits\",\"inspect\",\"isArray\",\"isDeepStrictEqual\",\"parseArgs\",\"promisify\",\"stripVTControlCharacters\",\"styleText\",\"toUSVString\",\"types\"],\"better-sqlite3/lib/methods/backup.js\":[\"default\"],\"better-sqlite3/lib/methods/pragma.js\":[\"default\"],\"better-sqlite3/lib/methods/transaction.js\":[\"default\"],\"better-sqlite3/lib/methods/wrappers.js\":[\"close\",\"defaultSafeIntegers\",\"exec\",\"getters\",\"loadExtension\",\"prepare\",\"unsafeMode\"],\"better-sqlite3/lib/util.js\":[\"cppdb\",\"getBooleanOption\",\"inspect\"]}");
function __thaw_bundle_factory_of(key) {
  if (Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, key)) return key;
  var query = key.indexOf('?'), fragment = key.indexOf('#', 1);
  var at = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  return at < 0 ? key : key.slice(0, at);
}
function __thaw_bundle_validate_static(key, visited) {
  visited = visited || [];
  if (visited.indexOf(key) >= 0) return;
  var graph = __thaw_bundle_export_graphs[__thaw_bundle_factory_of(key)];
  if (!graph) return;
  var next = visited.concat(key), dependencies = graph.dependencies || [];
  var map = __thaw_bundle_import_maps[__thaw_bundle_factory_of(key)] || {};
  for (var i = 0; i < dependencies.length; i++) {
    var target = __thaw_bundle_target(map, dependencies[i]);
    if (!target) {
      var spec = dependencies[i], builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
      if (__thaw_bundle_builtin_names.indexOf(builtin) < 0 && !(String(spec).endsWith('.node') && typeof require.addon === 'function'))
        throw new SyntaxError('Cannot resolve import ' + spec);
    } else __thaw_bundle_validate_static(target.key, next);
  }
  var origin = __thaw_bundle_origin_for(key), requests = graph.requests || [];
  for (var j = 0; j < requests.length; j++)
    origin.validateKnownStatic(requests[j][0], requests[j][1]);
}
var __thaw_namespace_create = Object.create, __thaw_namespace_define = Object.defineProperty;
var __thaw_namespace_prevent = Object.preventExtensions, __thaw_namespace_own = Object.prototype.hasOwnProperty;
var __thaw_namespace_keys = Object.keys, __thaw_namespace_apply = Reflect.apply;
var __thaw_namespace_get = WeakMap.prototype.get, __thaw_namespace_set = WeakMap.prototype.set;
var __thaw_namespace_has = WeakMap.prototype.has, __thaw_namespace_tag = Symbol.toStringTag;
var __thaw_namespace_promise = Promise, __thaw_namespace_resolve = Promise.resolve;
var __thaw_namespace_reject = Promise.reject, __thaw_namespace_then = Promise.prototype.then;
var __thaw_bundle_cjs_namespaces = Object.create(null);
var __thaw_bundle_cjs_namespace_values = new WeakMap();
function __thaw_bundle_cjs_namespace(key, value, names) {
  if (__thaw_namespace_apply(__thaw_namespace_own, __thaw_bundle_cjs_namespaces, [key]))
    return __thaw_bundle_cjs_namespaces[key];
  var namespace = __thaw_namespace_create(null);
  __thaw_namespace_define(namespace, 'default', {value:value, enumerable:true});
  __thaw_namespace_define(namespace, 'module.exports', {value:value, enumerable:true});
  for (var index = 0; index < names.length; index++) {
    var name = names[index];
    if (!__thaw_namespace_apply(__thaw_namespace_own, namespace, [name]))
      __thaw_namespace_define(namespace, name, {value:value == null ? undefined : value[name], enumerable:true});
  }
  __thaw_namespace_define(namespace, __thaw_namespace_tag, {value:'Module'});
  __thaw_namespace_prevent(namespace);
  __thaw_namespace_apply(__thaw_namespace_set, __thaw_bundle_cjs_namespace_values, [namespace, value]);
  __thaw_bundle_cjs_namespaces[key] = namespace;
  return namespace;
}
function __thaw_bundle_cjs_fallback_namespace(spec, value) {
  var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
  var known = __thaw_bundle_builtin_names.indexOf(builtin) >= 0;
  return __thaw_bundle_cjs_namespace('external:' + (known ? 'node:' + builtin : spec),
    value, known && value != null ? __thaw_namespace_keys(value) : []);
}
function __thaw_bundle_origin_for(ownerKey) {
  var own = Object.prototype.hasOwnProperty;
  var ambiguous = {};
  function graphOf(key) { return __thaw_bundle_export_graphs[__thaw_bundle_factory_of(key)]; }
  function targetOf(key, spec) {
    return __thaw_bundle_target(__thaw_bundle_import_maps[__thaw_bundle_factory_of(key)] || {}, spec);
  }
  var enumerable = Object.prototype.propertyIsEnumerable;
  function valueOf(target, sourceKey, spec) {
    var edges = __thaw_bundle_edges[sourceKey];
    if (edges && own.call(edges, spec)) {
      var edgeTarget = targetOf(sourceKey, spec);
      // A CommonJS cycle initially exposes provisional exports. The cache
      // remains authoritative if its factory later replaces module.exports.
      if (edgeTarget && own.call(__thaw_bundle_cache, edgeTarget.key))
        return __thaw_bundle_cache[edgeTarget.key].exports;
      return edges[spec];
    }
    // A cycle may reach this edge before its owner executes the loader.
    // Export discovery must never evaluate a dependency ahead of that owner.
    return undefined;
  }
  function namesOf(key, visited, sourceKey, spec) {
    if (visited.indexOf(key) >= 0) return [];
    var graph = graphOf(key);
    if (!graph) {
      var value = valueOf({ key: key, factory: __thaw_bundle_factory_of(key) }, sourceKey, spec);
      return value == null ? [] : Object.keys(value).filter(function(name) { return name !== '__esModule'; });
    }
    var next = visited.concat(key);
    var names = Object.keys(graph.local).concat(Object.keys(graph.indirect));
    for (var index = 0; index < graph.stars.length; index++) {
      var target = targetOf(key, graph.stars[index]);
      if (!target) continue;
      var more = namesOf(target.key, next, key, graph.stars[index]);
      for (var j = 0; j < more.length; j++) {
        if (more[j] !== 'default' && names.indexOf(more[j]) < 0) names.push(more[j]);
      }
    }
    return names;
  }
  function retainedNativeEdge(key) {
    return typeof __thaw_bundle_native_keys !== 'undefined'
      && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(key))
      && !own.call(__thaw_bundle_mixed_keys, __thaw_bundle_factory_of(key));
  }
  function retainedNamespaceAnchor(key, name, targetKey, anchor) {
    if (!retainedNativeEdge(targetKey)) return null;
    // A rewritten mixed edge strips the importer's native export, but a
    // following pure-native edge retains the current module's own alias.
    return anchor || (typeof __thaw_bundle_native_keys !== 'undefined'
      && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(key)) ? { key: key, name: name } : null);
  }
  function resolve(key, name, visited, allowMissing, sourceKey, spec, anchor) {
    var visit = key + '\u0000' + name;
    if (visited.indexOf(visit) >= 0) return null;
    var graph = graphOf(key);
    if (!graph) {
      // Star exports skip the CommonJS interop marker; explicit named
      // reexports still resolve it through allowMissing.
      if (name === '__esModule' && !allowMissing) return null;
      var value = valueOf({ key: key, factory: __thaw_bundle_factory_of(key) }, sourceKey, spec);
      return (allowMissing || (value != null && enumerable.call(value, name))) ? { kind: 'cjs', key: key, sourceKey: sourceKey, spec: spec, name: name } : null;
    }
    var next = visited.concat(visit);
    if (own.call(graph.local, name)) {
      return { kind: 'esm', key: key, binding: graph.local[name], name: name };
    }
    if (own.call(graph.indirect, name)) {
      var indirect = graph.indirect[name];
      var source = targetOf(key, indirect[0]);
      if (!source) return null;
      if (indirect[1] === null) {
        return { kind: 'namespace', key: source.key, binding: '*namespace*', sourceKey: key,
          spec: indirect[0], name: name,
          anchor: retainedNamespaceAnchor(key, name, source.key, anchor) };
      }
      if (indirect[2] && !graphOf(source.key)) {
        return { kind: 'cjs-default', key: source.key, sourceKey: key, spec: indirect[0] };
      }
      return resolve(source.key, indirect[1], next, true, key, indirect[0],
        retainedNamespaceAnchor(key, name, source.key, anchor));
    }
    if (name === 'default') return null;
    var found = null;
    for (var index = 0; index < graph.stars.length; index++) {
      var star = targetOf(key, graph.stars[index]);
      if (!star) continue;
      var candidate = resolve(star.key, name, next, false, key, graph.stars[index],
        retainedNamespaceAnchor(key, name, star.key, anchor));
      if (candidate === ambiguous) return ambiguous;
      if (!candidate) continue;
      if (found && !sameBinding(found, candidate)) return ambiguous;
      found = candidate;
    }
    return found;
  }
  function sameBinding(left, right) {
    if (left.kind !== right.kind) return false;
    if (left.kind === 'cjs') return left.key === right.key && left.name === right.name;
    if (left.kind === 'cjs-default') return left.key === right.key;
    return left.key === right.key && left.binding === right.binding;
  }
  function read(resolution) {
    if (resolution.kind === 'cjs' || resolution.kind === 'cjs-default') {
      var edges = __thaw_bundle_edges[resolution.sourceKey];
      if (!edges || !own.call(edges, resolution.spec)) throw new ReferenceError("Cannot access '" + (resolution.name || 'default') + "' before initialization");
      var value = valueOf(null, resolution.sourceKey, resolution.spec);
      return resolution.kind === 'cjs' ? value[resolution.name] : value && value.__esModule ? value.default : value;
    }
    if (typeof __thaw_native_entry !== 'undefined' && __thaw_native_entry) {
      if (resolution.kind === 'namespace') {
        if (graphOf(resolution.key)) return __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(resolution.key)]
          ? __thaw_bundle_facade_for(resolution.key)
          : resolution.anchor
            ? __thaw_native_entry.readNative(resolution.anchor.key, resolution.anchor.name)
            : __thaw_native_entry.readNative(resolution.key);
        var edge = __thaw_bundle_edges[resolution.sourceKey];
        if (!edge || !own.call(edge, resolution.spec)) throw new ReferenceError('Import is not initialized');
        return edge[resolution.spec];
      }
      // `binding` is the local declaration used for diamond identity;
      // native namespaces expose the exported alias in `name` instead.
      return __thaw_native_entry.readNative(resolution.key, resolution.name);
    }
    var source = __thaw_bundle_require(resolution.key, __thaw_bundle_factory_of(resolution.key), true);
    return resolution.kind === 'namespace' ? source : source[resolution.name];
  }
  function linksReady(key, visited) {
    if (visited.indexOf(key) >= 0) return true;
    var graph = graphOf(key);
    if (!graph) return true;
    var next = visited.concat(key), edges = __thaw_bundle_edges[key];
    // Explicit named reexports cannot introduce a competing star binding.
    // Their names are static even if their opaque target has not run yet.
    var specs = graph.stars;
    for (var index = 0; index < specs.length; index++) {
      var spec = specs[index], target = targetOf(key, spec);
      if (!target) continue;
      // ESM names and terminal bindings are known from the source graph
      // before evaluation. Only opaque CJS/native targets need a loaded edge
      // to discover their exported names.
      if ((!graphOf(target.key) && (!edges || !own.call(edges, spec))) || !linksReady(target.key, next)) return false;
    }
    var indirectNames = Object.keys(graph.indirect);
    for (var n = 0; n < indirectNames.length; n++) {
      var indirect = graph.indirect[indirectNames[n]], target = targetOf(key, indirect[0]);
      // A direct opaque named reexport has a statically fixed name/binding.
      // An ESM target can itself resolve through unknown opaque stars.
      if (target && graphOf(target.key) && !linksReady(target.key, next)) return false;
    }
    return true;
  }
  return {
    validateStatic: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new SyntaxError('Cannot resolve import ' + spec);
      // CommonJS default is the established synthetic default interop. All
      // other requested names in this route have a statically known graph.
      if (name === 'default' && !graphOf(target.key)) return;
      var resolution = resolve(target.key, name, [], false, ownerKey, spec);
      if (!resolution || resolution === ambiguous)
        throw new SyntaxError('Missing or ambiguous export ' + name);
    },
    validateKnownStatic: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      // Opaque CommonJS stars are discovered only after their owner's load.
      // Do not execute that owner during source-graph validation.
      if (!target) {
        var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
        if (__thaw_bundle_builtin_names.indexOf(builtin) < 0 && !(String(spec).endsWith('.node') && typeof require.addon === 'function'))
          throw new SyntaxError('Cannot resolve import ' + spec);
        return;
      }
      if (graphOf(target.key) && linksReady(target.key, []))
        this.validateStatic(spec, name);
    },
    validateRequests: function() {
      var graph = graphOf(ownerKey), requests = graph && graph.requests || [];
      for (var index = 0; index < requests.length; index++)
        this.validateKnownStatic(requests[index][0], requests[index][1]);
    },
    validateDynamic: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (target) __thaw_validate_native_link(target.key);
    },
    completeDynamic: function(spec, promise) {
      var origin = this;
      return __thaw_native_apply(__thaw_native_then, promise,
        [function(namespace) { return origin.selectDynamic(spec, namespace); }]);
    },
    rejectDynamic: function(error) {
      return __thaw_native_apply(__thaw_native_reject, __thaw_native_promise, [error]);
    },
    edge: function(spec, value) {
      // Async static imports share the loader with dynamic import. Only our
      // own namespace wrappers unwrap here; user exports keep their identity.
      if (value != null && (typeof value === 'object' || typeof value === 'function')
          && __thaw_namespace_apply(__thaw_namespace_has, __thaw_bundle_cjs_namespace_values, [value]))
        value = __thaw_namespace_apply(__thaw_namespace_get, __thaw_bundle_cjs_namespace_values, [value]);
      var edges = __thaw_bundle_edges[ownerKey];
      if (!edges) edges = __thaw_bundle_edges[ownerKey] = Object.create(null);
      if (own.call(edges, spec) && edges[spec] === value) return;
      edges[spec] = value;
      __thaw_bundle_edge_version++;
      // A cycle can reach an ESM module before its later CJS/native loader.
      // Only link when its full transitive export graph is available.
      for (var key in __thaw_bundle_star_linkers) __thaw_bundle_star_linkers[key]();
    },
    track: function(exports) {
      var linked = false, linking = false;
      var link = function() {
        if (linked || linking || !linksReady(ownerKey, [])) return;
        linking = true;
        try {
          // A CJS Proxy ownKeys trap can record another edge while names are
          // discovered. Recompute before publication if the graph changed.
          var bindings, before;
          do {
            before = __thaw_bundle_edge_version;
            bindings = [];
            var graph = graphOf(ownerKey), names = [];
            for (var index = 0; index < graph.stars.length; index++) {
              var spec = graph.stars[index], target = targetOf(ownerKey, spec);
              if (!target) continue;
              var more = namesOf(target.key, [], ownerKey, spec);
              for (var j = 0; j < more.length; j++) {
                var name = more[j];
                if (name !== 'default' && names.indexOf(name) < 0) names.push(name);
              }
            }
            for (var n = 0; n < names.length; n++) {
              var name = names[n];
              if (own.call(graph.local, name) || own.call(graph.indirect, name) || (name !== '__esModule' && own.call(exports, name))) continue;
              var resolution = resolve(ownerKey, name, [], false, null, null,
                { key: ownerKey, name: name });
              if (resolution && resolution !== ambiguous) bindings.push([name, resolution]);
            }
          } while (before !== __thaw_bundle_edge_version && linksReady(ownerKey, []));
          if (!linksReady(ownerKey, [])) return;
          for (var b = 0; b < bindings.length; b++) {
            var binding = bindings[b];
            if (binding[0] !== '__esModule' && own.call(exports, binding[0])) continue;
            Object.defineProperty(exports, binding[0], { enumerable: true, get: function(r) { return function() { return read(r); }; }(binding[1]) });
          }
          linked = true;
          delete __thaw_bundle_star_linkers[ownerKey];
        } finally { linking = false; }
      };
      __thaw_bundle_star_linkers[ownerKey] = link;
      link();
    },
    defaultImport: function(spec, value) {
      var target = targetOf(ownerKey, spec);
      return target && graphOf(target.key) ? value.default : value && value.__esModule ? value.default : value;
    },
    readImport: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      var resolution = resolve(target.key, name, [], true, ownerKey, spec,
        typeof __thaw_bundle_native_keys !== 'undefined' && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(target.key))
          ? { key: target.key, name: name } : null);
      if (!resolution || resolution === ambiguous) throw new SyntaxError('Missing or ambiguous export ' + name);
      return read(resolution);
    },
    readDefault: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      if (!graphOf(target.key)) {
        var edges = __thaw_bundle_edges[ownerKey];
        if (!edges || !own.call(edges, spec)) throw new ReferenceError('Import is not initialized');
        return this.defaultImport(spec, edges[spec]);
      }
      var resolution = resolve(target.key, 'default', [], true, ownerKey, spec,
        typeof __thaw_bundle_native_keys !== 'undefined' && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(target.key))
          ? { key: target.key, name: 'default' } : null);
      if (!resolution || resolution === ambiguous) throw new SyntaxError('Missing or ambiguous default export');
      return read(resolution);
    },
    namespaceImport: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      if (!graphOf(target.key)) {
        var edges = __thaw_bundle_edges[ownerKey];
        if (!edges || !own.call(edges, spec)) throw new ReferenceError('Import is not initialized');
        // Keep the legacy CJS namespace-import object; only ESM targets
        // select the tracked facade.
        return edges[spec];
      }
      return typeof __thaw_native_entry === 'undefined' || !__thaw_native_entry || __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(target.key)]
        ? __thaw_bundle_facade_for(target.key) : __thaw_native_entry.readNative(target.key);
    },
    selectDynamic: function(spec, namespace) {
      var target = targetOf(ownerKey, spec);
      if (!target) return namespace;
      // The private shell's namespace contains no CJS exports. The existing
      // bundle contract returns that target's cached CommonJS value instead.
      if (!graphOf(target.key)) return __thaw_bundle_cjs_namespace(target.key, this.namespaceImport(spec), __thaw_bundle_cjs_export_names[target.factory] || []);
      return __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(target.key)]
        ? __thaw_bundle_facade_for(target.key) : namespace;
    },
    names: function(spec, value) {
      var target = targetOf(ownerKey, spec);
      return target && graphOf(target.key) ? namesOf(target.key, [], ownerKey, spec) : (value == null ? [] : Object.keys(value).filter(function(name) { return name !== '__esModule'; }));
    },
    resolve: function(name) { var found = resolve(ownerKey, name, [], false, null, null,
      { key: ownerKey, name: name }); return found === ambiguous ? null : found; },
    read: read
  };
}
function __thaw_bundle_target(map, spec) {
  if (Object.prototype.hasOwnProperty.call(map, spec)) return { key: map[spec], factory: map[spec] };
  var query = spec.indexOf('?');
  var fragment = spec.indexOf('#', 1);
  var suffixAt = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  if (suffixAt < 0) return null;
  var base = spec.slice(0, suffixAt);
  if (!Object.prototype.hasOwnProperty.call(map, base)) return null;
  var factory = map[base];
  return { key: factory + spec.slice(suffixAt), factory: factory };
}
function __thaw_bundle_import_missing(known, spec) {
  spec = String(spec);
  if (spec.charAt(0) === '#') return true;
  var query = spec.indexOf('?'), fragment = spec.indexOf('#', 1);
  var suffixAt = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  if (suffixAt >= 0) spec = spec.slice(0, suffixAt);
  var slash = spec.indexOf('/');
  var next = spec.charAt(0) === '@' && slash >= 0 ? spec.indexOf('/', slash + 1) : slash;
  var name = next < 0 ? spec : spec.slice(0, next);
  return known.indexOf(name) >= 0;
}
function __thaw_bundle_resolve(map, spec, keys, searchAll, allowExports) {
  spec = String(spec);
  if (allowExports && Object.prototype.hasOwnProperty.call(__thaw_bundle_exports, spec)) return spec;
  var target = __thaw_bundle_target(map, spec);
  if (!target && searchAll) for (var index = 0; index < keys.length && !target; index++) target = __thaw_bundle_target(__thaw_bundle_require_maps[keys[index]] || {}, spec);
  if (target) return target.key;
  var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
  if (__thaw_bundle_builtin_names.indexOf(builtin) >= 0) return spec;
  var error = new Error('Cannot find module ' + spec);
  error.code = 'MODULE_NOT_FOUND';
  throw error;
}
function __thaw_bundle_async_error(factoryKey) {
  var error = new Error('Cannot synchronously require an async module: ' + factoryKey);
  error.code = 'ERR_REQUIRE_ASYNC_MODULE';
  return error;
}
function __thaw_bundle_require(key, factoryKey, allowAsync) {
  factoryKey = factoryKey || key;
  if (!allowAsync && Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, factoryKey)) throw __thaw_bundle_async_error(factoryKey);
  if (String(factoryKey).endsWith('.node') && require.addon) return require.addon();
  if (typeof __thaw_bundle_native_keys !== 'undefined' && Object.prototype.hasOwnProperty.call(__thaw_bundle_native_keys, factoryKey)) {
    var namespace = __thaw_native_entry.evalNativeSync(key, factoryKey);
    return Object.prototype.hasOwnProperty.call(__thaw_bundle_mixed_keys, factoryKey) ? __thaw_bundle_facade_for(key) : namespace;
  }
  __thaw_bundle_validate_static(key);
  if (!(key in __thaw_bundle_cache)) {
    var mod = { exports: {}, filename: '/thaw_modules/' + (factoryKey || key) };
    __thaw_bundle_cache[key] = mod;
    var map = __thaw_bundle_require_maps[factoryKey] || {};
    var importMap = __thaw_bundle_import_maps[factoryKey] || {};
    var knownPackages = __thaw_bundle_known_package_maps[factoryKey] || [];
    var localRequire = function(spec) {
      if ((spec === 'bindings' || spec === 'node-gyp-build') && typeof require.addon === 'function') return require.addon;
      var target = __thaw_bundle_target(map, spec);
      if (target) return __thaw_bundle_require(target.key, target.factory);
      return require(spec);
    };
    localRequire.addon = typeof require === 'function' ? require.addon : undefined;
    localRequire.resolve = function(spec) { return __thaw_bundle_resolve(map, spec, null, false, false); };
    localRequire.cache = __thaw_bundle_cache;
    var localImport = function(spec) { var target = __thaw_bundle_target(importMap, spec); if (target) return __thaw_bundle_require(target.key, target.factory); if (__thaw_bundle_import_missing(knownPackages, spec)) throw new Error('Cannot resolve import ' + spec); return require(spec); };
    var localRequireAsync = __thaw_bundle_create_import_async(factoryKey, globalThis.__thaw_worker_module);
    var filename = '/thaw_modules/' + factoryKey, slash = filename.lastIndexOf('/'), dirname = slash < 0 ? '.' : filename.slice(0, slash);
    var initialized;
    try { var factory = __thaw_bundle_factories[factoryKey]; if (Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, factoryKey)) factory = factory(__thaw_bundle_origin_for(key)); initialized = Object.prototype.hasOwnProperty.call(__thaw_bundle_commonjs_contexts, factoryKey) ? factory.call(mod.exports, mod, mod.exports, localRequire, localRequireAsync, filename, dirname, localImport) : factory(mod, mod.exports, localRequire, localRequireAsync, filename, dirname, localImport); } catch (error) { delete __thaw_bundle_cache[key]; delete __thaw_bundle_edges[key]; delete __thaw_bundle_star_linkers[key]; throw error; }
    mod.ready = __thaw_namespace_apply(__thaw_namespace_then, __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, [Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, factoryKey) ? initialized : undefined]), [function() {}, function(error) { delete __thaw_bundle_cache[key]; delete __thaw_bundle_edges[key]; delete __thaw_bundle_star_linkers[key]; throw error; }]);
  }
  return __thaw_bundle_cache[key].exports;
}
function __thaw_bundle_create_require(base) {
  var text = String(base || '');
  var keys = Object.keys(__thaw_bundle_require_maps);
  var factoryKey = keys.indexOf(text) >= 0 ? text : keys.reduce(function(best, key) { return text.endsWith('/' + key) && (!best || key.length > best.length) ? key : best; }, null);
  var map = {}, staticMap = __thaw_bundle_import_maps[factoryKey] || {}, requireMap = __thaw_bundle_require_maps[factoryKey] || {};
  for (var staticSpec in staticMap) if (Object.prototype.hasOwnProperty.call(staticMap, staticSpec)) map[staticSpec] = staticMap[staticSpec];
  for (var requireSpec in requireMap) if (Object.prototype.hasOwnProperty.call(requireMap, requireSpec)) map[requireSpec] = requireMap[requireSpec];
  var created = function(spec) { if ((String(spec) === 'bindings' || String(spec) === 'node-gyp-build') && typeof require.addon === 'function') return require.addon; spec = String(spec); if (Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, spec)) throw __thaw_bundle_async_error(spec); if (Object.prototype.hasOwnProperty.call(__thaw_bundle_exports, spec)) return __thaw_bundle_exports[spec]; var target = __thaw_bundle_target(map, spec); if (!target && !factoryKey) { for (var index = 0; index < keys.length && !target; index++) target = __thaw_bundle_target(__thaw_bundle_require_maps[keys[index]] || {}, spec); } if (target) return __thaw_bundle_require(target.key, target.factory); return require(spec); };
  created.addon = typeof require === 'function' ? require.addon : undefined;
  created.resolve = function(spec) { return __thaw_bundle_resolve(map, spec, keys, !factoryKey, true); };
  created.cache = __thaw_bundle_cache; return created;
}
function __thaw_bundle_create_import(base) {
  var map = __thaw_bundle_import_maps[String(base)] || {};
  var known = __thaw_bundle_known_package_maps[String(base)] || [];
  return function(spec) { spec = String(spec); var target = __thaw_bundle_target(map, spec); if (target) return __thaw_bundle_require(target.key, target.factory); if (__thaw_bundle_import_missing(known, spec)) throw new Error('Cannot resolve import ' + spec); return require(spec); };
}
function __thaw_bundle_create_import_async(base, workerModule) {
  var map = __thaw_bundle_import_maps[String(base)] || {};
  var known = __thaw_bundle_known_package_maps[String(base)] || [];
  return function(spec) {
    try { spec = `${spec}`; } catch (error) { return __thaw_namespace_apply(__thaw_namespace_reject, __thaw_namespace_promise, [error]); }
    if (workerModule !== undefined && (spec === 'worker_threads' || spec === 'node:worker_threads')) { try { return __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, [__thaw_bundle_cjs_fallback_namespace(spec, workerModule)]); } catch (error) { return __thaw_namespace_apply(__thaw_namespace_reject, __thaw_namespace_promise, [error]); } }
  return new __thaw_namespace_promise(function(resolve, reject) {
   __thaw_namespace_apply(__thaw_namespace_then, __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, []), [function() {
    try {
     var target = __thaw_bundle_target(map, spec);
     if (target) {
      if (typeof __thaw_bundle_native_keys !== 'undefined' && Object.prototype.hasOwnProperty.call(__thaw_bundle_native_keys, target.factory)) {
       __thaw_native_apply(__thaw_native_then, __thaw_native_entry.evalNative(target.key, target.factory), [function(namespace) { try { resolve(__thaw_bundle_mixed_keys[target.factory] ? __thaw_bundle_facade_for(target.key) : namespace); } catch (error) { reject(error); } }, reject]);
       return;
      }
      __thaw_bundle_require(target.key, target.factory, true);
      __thaw_namespace_apply(__thaw_namespace_then, __thaw_bundle_cache[target.key].ready, [function() { try { var value = __thaw_bundle_cache[target.key].exports; resolve(Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, target.factory) ? value : __thaw_bundle_cjs_namespace(target.key, value, __thaw_bundle_cjs_export_names[target.factory] || [])); } catch (error) { reject(error); } }, reject]);
      return;
     }
     if (__thaw_bundle_import_missing(known, spec)) throw new Error('Cannot resolve import ' + spec);
     resolve(__thaw_bundle_cjs_fallback_namespace(spec, require(spec)));
    } catch (error) { reject(error); }
   }, reject]);
  });
  };
}
function __thaw_bundle_register_worker_main(key, mod) {
  __thaw_bundle_validate_static(key);
  if (Object.prototype.hasOwnProperty.call(__thaw_bundle_cache, key)) throw new Error('Worker entry already initialized');
  mod.filename = '/thaw_modules/' + key;
  var resolveReady, rejectReady;
  mod.ready = new __thaw_namespace_promise(function(resolve, reject) { resolveReady = resolve; rejectReady = reject; });
  __thaw_bundle_cache[key] = mod;
  return function(succeeded, error) { if (succeeded) resolveReady(); else rejectReady(error); };
}
globalThis.__thaw_bundle_create_require = __thaw_bundle_create_require;
globalThis.__thaw_bundle_create_import = __thaw_bundle_create_import;
globalThis.__thaw_bundle_create_import_async = __thaw_bundle_create_import_async;
var __thaw_worker_bundle_source =
  '(function() {\nvar __thaw_worker_bundle_source = globalThis.__thaw_worker_bundle_source;\nvar require = function(name) { if (name === "worker_threads" || name === "node:worker_threads") return globalThis.__thaw_worker_module; if (String(name).endsWith(".node") && typeof require.addon === "function") return require.addon(); var error = new Error("Cannot find module " + name); error.code = "MODULE_NOT_FOUND"; throw error; };\nrequire.addon = globalThis.require && globalThis.require.addon;\nvar __thaw_bundle_exports = globalThis.__thaw_bundle_exports || (globalThis.__thaw_bundle_exports = {});\nvar __thaw_bundle_builtin_names = Object.freeze(' + JSON.stringify(__thaw_bundle_builtin_names) + ');\nvar __thaw_bundle_cache = {};\nvar __thaw_bundle_async_keys = ' + JSON.stringify(__thaw_bundle_async_keys) + ';\nvar __thaw_bundle_edges = Object.create(null);\nvar __thaw_bundle_star_linkers = Object.create(null);\nvar __thaw_bundle_edge_version = 0;\nvar __thaw_bundle_factories = {' +
  Object.keys(__thaw_bundle_factories).map(function(key) { return JSON.stringify(key) + ': ' + __thaw_bundle_factories[key].toString(); }).join(',\n') +
  '};\nvar __thaw_bundle_require_maps = ' + JSON.stringify(__thaw_bundle_require_maps) + ';\n' +
  'var __thaw_bundle_import_maps = ' + JSON.stringify(__thaw_bundle_import_maps) + ';\n' +
  'var __thaw_bundle_known_package_maps = ' + JSON.stringify(__thaw_bundle_known_package_maps) + ';\n' +
  'var __thaw_bundle_export_graphs = JSON.parse(' + JSON.stringify(JSON.stringify(__thaw_bundle_export_graphs)) + ');\n' +
  'var __thaw_bundle_commonjs_contexts = JSON.parse(' + JSON.stringify(JSON.stringify(__thaw_bundle_commonjs_contexts)) + ');\n' +
  'var __thaw_namespace_create = Object.create, __thaw_namespace_define = Object.defineProperty;\nvar __thaw_namespace_prevent = Object.preventExtensions, __thaw_namespace_own = Object.prototype.hasOwnProperty;\nvar __thaw_namespace_keys = Object.keys, __thaw_namespace_apply = Reflect.apply;\nvar __thaw_namespace_get = WeakMap.prototype.get, __thaw_namespace_set = WeakMap.prototype.set;\nvar __thaw_namespace_has = WeakMap.prototype.has, __thaw_namespace_tag = Symbol.toStringTag;\nvar __thaw_namespace_promise = Promise, __thaw_namespace_resolve = Promise.resolve;\nvar __thaw_namespace_reject = Promise.reject, __thaw_namespace_then = Promise.prototype.then;\nvar __thaw_bundle_cjs_namespaces = Object.create(null);\nvar __thaw_bundle_cjs_namespace_values = new WeakMap();\nvar __thaw_bundle_cjs_export_names = ' + JSON.stringify(__thaw_bundle_cjs_export_names) + ';\n' +
  __thaw_bundle_cjs_namespace.toString() + '\n' + __thaw_bundle_cjs_fallback_namespace.toString() + '\n' + __thaw_bundle_factory_of.toString() + '\n' + __thaw_bundle_validate_static.toString() + '\n' + __thaw_bundle_origin_for.toString() + '\n' + __thaw_bundle_target.toString() + '\n' + __thaw_bundle_import_missing.toString() + '\n' + __thaw_bundle_resolve.toString() + '\n' + __thaw_bundle_async_error.toString() + '\n' + __thaw_bundle_require.toString() + '\n' + __thaw_bundle_create_require.toString() + '\n' + __thaw_bundle_create_import.toString() + '\n' + __thaw_bundle_create_import_async.toString() + '\n' + __thaw_bundle_register_worker_main.toString() + '\n' +
  'globalThis.__thaw_bundle_create_require = __thaw_bundle_create_require;\nglobalThis.__thaw_bundle_create_import = __thaw_bundle_create_import;\nglobalThis.__thaw_bundle_create_import_async = __thaw_bundle_create_import_async;\nglobalThis.__thaw_bundle_worker_origin = __thaw_bundle_origin_for;\nglobalThis.__thaw_bundle_register_worker_main = __thaw_bundle_register_worker_main;\n})();\n';
globalThis.__thaw_worker_bundle_source = __thaw_worker_bundle_source;
var __thaw_bundle_entry_key = "better-sqlite3/lib/index.js";
var __thaw_bundle_entry = __thaw_bundle_require(__thaw_bundle_entry_key, undefined, true);
__thaw_bundle_exports[__thaw_bundle_entry_key] = __thaw_bundle_entry;
globalThis.__thaw_module_ready = __thaw_bundle_cache[__thaw_bundle_entry_key].ready;
return __thaw_bundle_entry;
})(globalThis.require);
