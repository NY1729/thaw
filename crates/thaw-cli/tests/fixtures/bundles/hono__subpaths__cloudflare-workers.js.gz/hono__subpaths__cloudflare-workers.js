module.exports = (function(require) {
if (typeof require !== 'function') require = function(name) { var error = new Error('Cannot find module ' + name); error.code = 'MODULE_NOT_FOUND'; throw error; };
var __thaw_bundle_exports = globalThis.__thaw_bundle_exports || (globalThis.__thaw_bundle_exports = {});
var __thaw_bundle_builtin_names = Object.freeze(["_http_agent","_http_client","_http_common","_http_incoming","_http_outgoing","_http_server","_stream_duplex","_stream_passthrough","_stream_readable","_stream_transform","_stream_wrap","_stream_writable","_tls_common","_tls_wrap","assert","assert/strict","async_hooks","buffer","child_process","cluster","console","constants","crypto","dgram","diagnostics_channel","dns","dns/promises","domain","events","fs","fs/promises","http","http2","https","inspector","inspector/promises","module","net","os","path","path/posix","path/win32","perf_hooks","process","punycode","querystring","readline","readline/promises","repl","stream","stream/consumers","stream/promises","stream/web","string_decoder","sys","test","test/reporters","timers","timers/promises","tls","trace_events","tty","url","util","util/types","v8","vm","wasi","worker_threads","zlib"]);
var __thaw_bundle_cache = {};
var __thaw_bundle_async_keys = JSON.parse("{}");
var __thaw_bundle_edges = Object.create(null);
var __thaw_bundle_star_linkers = Object.create(null);
var __thaw_bundle_edge_version = 0;
var __thaw_bundle_factories = {
"hono/./dist/cjs/adapter/cloudflare-workers/index.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cloudflare_workers_exports = {};
__export(cloudflare_workers_exports, {
  getConnInfo: () => import_conninfo.getConnInfo,
  serveStatic: () => import_serve_static_module.serveStatic,
  upgradeWebSocket: () => import_websocket.upgradeWebSocket
});
module.exports = __toCommonJS(cloudflare_workers_exports);
var import_serve_static_module = require("./serve-static-module");
var import_websocket = require("./websocket");
var import_conninfo = require("./conninfo");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getConnInfo,
  serveStatic,
  upgradeWebSocket
});

},
"hono/dist/cjs/adapter/cloudflare-workers/conninfo.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var conninfo_exports = {};
__export(conninfo_exports, {
  getConnInfo: () => getConnInfo
});
module.exports = __toCommonJS(conninfo_exports);
const getConnInfo = (c) => ({
  remote: {
    address: c.req.header("cf-connecting-ip")
  }
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getConnInfo
});

},
"hono/dist/cjs/adapter/cloudflare-workers/websocket.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var websocket_exports = {};
__export(websocket_exports, {
  upgradeWebSocket: () => upgradeWebSocket
});
module.exports = __toCommonJS(websocket_exports);
var import_websocket = require("../../helper/websocket");
const upgradeWebSocket = (0, import_websocket.defineWebSocketHelper)(async (c, events) => {
  const upgradeHeader = c.req.header("Upgrade");
  if (upgradeHeader !== "websocket") {
    return;
  }
  const webSocketPair = new WebSocketPair();
  const client = webSocketPair[0];
  const server = webSocketPair[1];
  const wsContext = new import_websocket.WSContext({
    close: (code, reason) => server.close(code, reason),
    get protocol() {
      return server.protocol;
    },
    raw: server,
    get readyState() {
      return server.readyState;
    },
    url: server.url ? new URL(server.url) : null,
    send: (source) => server.send(source)
  });
  if (events.onClose) {
    server.addEventListener("close", (evt) => events.onClose?.(evt, wsContext));
  }
  if (events.onMessage) {
    server.addEventListener("message", (evt) => events.onMessage?.(evt, wsContext));
  }
  if (events.onError) {
    server.addEventListener("error", (evt) => events.onError?.(evt, wsContext));
  }
  server.accept?.();
  return new Response(null, {
    status: 101,
    // @ts-expect-error - webSocket is not typed
    webSocket: client
  });
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  upgradeWebSocket
});

},
"hono/dist/cjs/helper/websocket/index.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var websocket_exports = {};
__export(websocket_exports, {
  WSContext: () => WSContext,
  createWSMessageEvent: () => createWSMessageEvent,
  defineWebSocketHelper: () => defineWebSocketHelper
});
module.exports = __toCommonJS(websocket_exports);
class WSContext {
  #init;
  constructor(init) {
    this.#init = init;
    this.raw = init.raw;
    this.url = init.url ? new URL(init.url) : null;
    this.protocol = init.protocol ?? null;
  }
  send(source, options) {
    this.#init.send(source, options ?? {});
  }
  raw;
  binaryType = "arraybuffer";
  get readyState() {
    return this.#init.readyState;
  }
  url;
  protocol;
  close(code, reason) {
    this.#init.close(code, reason);
  }
}
const createWSMessageEvent = (source) => {
  return new MessageEvent("message", {
    data: source
  });
};
const defineWebSocketHelper = (handler) => {
  return ((...args) => {
    if (typeof args[0] === "function") {
      const [createEvents, options] = args;
      return async function upgradeWebSocket(c, next) {
        const events = await createEvents(c);
        const result = await handler(c, events, options);
        if (result) {
          return result;
        }
        await next();
      };
    } else {
      const [c, events, options] = args;
      return (async () => {
        const upgraded = await handler(c, events, options);
        if (!upgraded) {
          throw new Error("Failed to upgrade WebSocket");
        }
        return upgraded;
      })();
    }
  });
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  WSContext,
  createWSMessageEvent,
  defineWebSocketHelper
});

},
"hono/dist/cjs/adapter/cloudflare-workers/serve-static-module.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var serve_static_module_exports = {};
__export(serve_static_module_exports, {
  serveStatic: () => module2
});
module.exports = __toCommonJS(serve_static_module_exports);
var import_serve_static = require("./serve-static");
const module2 = (options) => {
  return (0, import_serve_static.serveStatic)(options);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  serveStatic
});

},
"hono/dist/cjs/adapter/cloudflare-workers/serve-static.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var serve_static_exports = {};
__export(serve_static_exports, {
  serveStatic: () => serveStatic
});
module.exports = __toCommonJS(serve_static_exports);
var import_serve_static = require("../../middleware/serve-static");
var import_utils = require("./utils");
const serveStatic = (options = {}) => {
  return async function serveStatic2(c, next) {
    const getContent = async (path) => {
      return (0, import_utils.getContentFromKVAsset)(path, {
        manifest: options.manifest,
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        namespace: options.namespace ? options.namespace : c.env ? c.env.__STATIC_CONTENT : void 0
      });
    };
    return (0, import_serve_static.serveStatic)({
      ...options,
      getContent
    })(c, next);
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  serveStatic
});

},
"hono/dist/cjs/adapter/cloudflare-workers/utils.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var utils_exports = {};
__export(utils_exports, {
  getContentFromKVAsset: () => getContentFromKVAsset
});
module.exports = __toCommonJS(utils_exports);
const getContentFromKVAsset = async (path, options) => {
  let ASSET_MANIFEST;
  if (options && options.manifest) {
    if (typeof options.manifest === "string") {
      ASSET_MANIFEST = JSON.parse(options.manifest);
    } else {
      ASSET_MANIFEST = options.manifest;
    }
  } else {
    if (typeof __STATIC_CONTENT_MANIFEST === "string") {
      ASSET_MANIFEST = JSON.parse(__STATIC_CONTENT_MANIFEST);
    } else {
      ASSET_MANIFEST = __STATIC_CONTENT_MANIFEST;
    }
  }
  let ASSET_NAMESPACE;
  if (options && options.namespace) {
    ASSET_NAMESPACE = options.namespace;
  } else {
    ASSET_NAMESPACE = __STATIC_CONTENT;
  }
  const key = ASSET_MANIFEST[path];
  if (!key) {
    return null;
  }
  const content = await ASSET_NAMESPACE.get(key, { type: "stream" });
  if (!content) {
    return null;
  }
  return content;
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getContentFromKVAsset
});

},
"hono/dist/cjs/middleware/serve-static/index.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var serve_static_exports = {};
__export(serve_static_exports, {
  serveStatic: () => serveStatic
});
module.exports = __toCommonJS(serve_static_exports);
var import_compress = require("../../utils/compress");
var import_mime = require("../../utils/mime");
var import_url = require("../../utils/url");
var import_path = require("./path");
const ENCODINGS = {
  br: ".br",
  zstd: ".zst",
  gzip: ".gz"
};
const ENCODINGS_ORDERED_KEYS = Object.keys(ENCODINGS);
const DEFAULT_DOCUMENT = "index.html";
const serveStatic = (options) => {
  const root = options.root ?? "./";
  const optionPath = options.path;
  const join = options.join ?? import_path.defaultJoin;
  return async (c, next) => {
    if (c.finalized) {
      return next();
    }
    let filename;
    if (options.path) {
      filename = options.path;
    } else {
      try {
        filename = (0, import_url.tryDecodeURI)(c.req.path);
        if (/(?:^|[\/\\])\.{1,2}(?:$|[\/\\])|[\/\\]{2,}|\\/.test(filename)) {
          throw new Error();
        }
      } catch {
        await options.onNotFound?.(c.req.path, c);
        return next();
      }
    }
    let path = join(
      root,
      !optionPath && options.rewriteRequestPath ? options.rewriteRequestPath(filename) : filename
    );
    if (options.isDir && await options.isDir(path)) {
      path = join(path, DEFAULT_DOCUMENT);
    }
    const getContent = options.getContent;
    let content = await getContent(path, c);
    if (content instanceof Response) {
      return c.newResponse(content.body, content);
    }
    if (content != null) {
      const mimeType = options.mimes && (0, import_mime.getMimeType)(path, options.mimes) || (0, import_mime.getMimeType)(path);
      c.header("Content-Type", mimeType || "application/octet-stream");
      if (options.precompressed && (!mimeType || import_compress.COMPRESSIBLE_CONTENT_TYPE_REGEX.test(mimeType))) {
        const acceptEncodingSet = new Set(
          c.req.header("Accept-Encoding")?.split(",").map((encoding) => encoding.trim())
        );
        for (const encoding of ENCODINGS_ORDERED_KEYS) {
          if (!acceptEncodingSet.has(encoding)) {
            continue;
          }
          const compressedContent = await getContent(path + ENCODINGS[encoding], c);
          if (compressedContent) {
            content = compressedContent;
            c.header("Content-Encoding", encoding);
            c.header("Vary", "Accept-Encoding", { append: true });
            break;
          }
        }
      }
      await options.onFound?.(path, c);
      return c.body(content);
    }
    await options.onNotFound?.(path, c);
    await next();
    return;
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  serveStatic
});

},
"hono/dist/cjs/middleware/serve-static/path.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var path_exports = {};
__export(path_exports, {
  defaultJoin: () => defaultJoin
});
module.exports = __toCommonJS(path_exports);
const defaultJoin = (...paths) => {
  let result = paths.filter((p) => p !== "").join("/");
  result = result.replace(/(?<=\/)\/+/g, "");
  const segments = result.split("/");
  const resolved = [];
  for (const segment of segments) {
    if (segment === ".." && resolved.length > 0 && resolved.at(-1) !== "..") {
      resolved.pop();
    } else if (segment !== ".") {
      resolved.push(segment);
    }
  }
  return resolved.join("/") || ".";
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  defaultJoin
});

},
"hono/dist/cjs/utils/url.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var url_exports = {};
__export(url_exports, {
  checkOptionalParameter: () => checkOptionalParameter,
  decodeURIComponent_: () => decodeURIComponent_,
  getPath: () => getPath,
  getPathNoStrict: () => getPathNoStrict,
  getPattern: () => getPattern,
  getQueryParam: () => getQueryParam,
  getQueryParams: () => getQueryParams,
  getQueryStrings: () => getQueryStrings,
  mergePath: () => mergePath,
  splitPath: () => splitPath,
  splitRoutingPath: () => splitRoutingPath,
  tryDecode: () => tryDecode,
  tryDecodeURI: () => tryDecodeURI,
  tryDecodeURIComponent: () => tryDecodeURIComponent
});
module.exports = __toCommonJS(url_exports);
const splitPath = (path) => {
  const paths = path.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
const splitRoutingPath = (routePath) => {
  const { groups, path } = extractGroupsFromPath(routePath);
  const paths = splitPath(path);
  return replaceGroupMarks(paths, groups);
};
const extractGroupsFromPath = (path) => {
  const groups = [];
  path = path.replace(/\{[^}]+\}/g, (match, index) => {
    const mark = `@${index}`;
    groups.push([mark, match]);
    return mark;
  });
  return { groups, path };
};
const replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1; i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1; j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
const patternCache = {};
const getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match) {
    const cacheKey = `${label}#${next}`;
    if (!patternCache[cacheKey]) {
      if (match[2]) {
        patternCache[cacheKey] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey, match[1], new RegExp(`^${match[2]}(?=/${next})`)] : [label, match[1], new RegExp(`^${match[2]}$`)];
      } else {
        patternCache[cacheKey] = [label, match[1], true];
      }
    }
    return patternCache[cacheKey];
  }
  return null;
};
const tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match) => {
      try {
        return decoder(match);
      } catch {
        return match;
      }
    });
  }
};
const tryDecodeURI = (str) => tryDecode(str, decodeURI);
const getPath = (request) => {
  const url = request.url;
  const start = url.indexOf("/", url.indexOf(":") + 4);
  let i = start;
  for (; i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path = url.slice(start, end);
      return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start, i);
};
const getQueryStrings = (url) => {
  const queryIndex = url.indexOf("?", 8);
  if (queryIndex === -1) {
    return "";
  }
  const hashIndex = url.indexOf("#", 8);
  return hashIndex === -1 ? url.slice(queryIndex) : queryIndex < hashIndex ? url.slice(queryIndex, hashIndex) : "";
};
const getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
const mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
const checkOptionalParameter = (path) => {
  if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) {
    return null;
  }
  const segments = path.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (segment.charCodeAt(segment.length - 1) === 63) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.slice(0, -1);
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
const tryDecodeURIComponent = (str) => str.indexOf("%") !== -1 ? tryDecode(str, decodeURIComponent_) : str;
const _decodeURI = (value) => {
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return tryDecodeURIComponent(value);
};
const _getQueryParam = (url, key, multiple) => {
  const hashIndex = url.indexOf("#", 8);
  if (hashIndex !== -1) {
    url = url.slice(0, hashIndex);
  }
  let encoded;
  if (!multiple && key && key.indexOf("%") === -1 && key.indexOf("+") === -1) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return void 0;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return void 0;
    }
  }
  const results = /* @__PURE__ */ Object.create(null);
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(
      keyIndex + 1,
      valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex
    );
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      ;
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
const getQueryParam = _getQueryParam;
const getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
const decodeURIComponent_ = decodeURIComponent;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  checkOptionalParameter,
  decodeURIComponent_,
  getPath,
  getPathNoStrict,
  getPattern,
  getQueryParam,
  getQueryParams,
  getQueryStrings,
  mergePath,
  splitPath,
  splitRoutingPath,
  tryDecode,
  tryDecodeURI,
  tryDecodeURIComponent
});

},
"hono/dist/cjs/utils/mime.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var mime_exports = {};
__export(mime_exports, {
  getExtension: () => getExtension,
  getMimeType: () => getMimeType,
  mimes: () => baseMimes
});
module.exports = __toCommonJS(mime_exports);
const getMimeType = (filename, mimes = baseMimes) => {
  const regexp = /\.([a-zA-Z0-9]+?)$/;
  const match = filename.match(regexp);
  if (!match) {
    return;
  }
  return mimes[match[1].toLowerCase()];
};
const getExtension = (mimeType) => {
  const baseType = mimeType.split(";", 1)[0].trim();
  for (const ext in baseMimes) {
    const stored = baseMimes[ext];
    if (stored === mimeType || stored.split(";", 1)[0].trim() === baseType) {
      return ext;
    }
  }
};
const _baseMimes = {
  aac: "audio/aac",
  avi: "video/x-msvideo",
  avif: "image/avif",
  av1: "video/av1",
  bin: "application/octet-stream",
  bmp: "image/bmp",
  css: "text/css; charset=utf-8",
  csv: "text/csv; charset=utf-8",
  eot: "application/vnd.ms-fontobject",
  epub: "application/epub+zip",
  gif: "image/gif",
  gz: "application/gzip",
  htm: "text/html; charset=utf-8",
  html: "text/html; charset=utf-8",
  ico: "image/x-icon",
  ics: "text/calendar; charset=utf-8",
  jpeg: "image/jpeg",
  jpg: "image/jpeg",
  js: "text/javascript; charset=utf-8",
  json: "application/json",
  jsonld: "application/ld+json",
  map: "application/json",
  mid: "audio/x-midi",
  midi: "audio/x-midi",
  mjs: "text/javascript; charset=utf-8",
  mp3: "audio/mpeg",
  mp4: "video/mp4",
  mpeg: "video/mpeg",
  oga: "audio/ogg",
  ogv: "video/ogg",
  ogx: "application/ogg",
  opus: "audio/opus",
  otf: "font/otf",
  pdf: "application/pdf",
  png: "image/png",
  rtf: "application/rtf",
  svg: "image/svg+xml; charset=utf-8",
  tif: "image/tiff",
  tiff: "image/tiff",
  ts: "video/mp2t",
  ttf: "font/ttf",
  txt: "text/plain; charset=utf-8",
  wasm: "application/wasm",
  webm: "video/webm",
  weba: "audio/webm",
  webmanifest: "application/manifest+json",
  webp: "image/webp",
  woff: "font/woff",
  woff2: "font/woff2",
  xhtml: "application/xhtml+xml; charset=utf-8",
  xml: "application/xml; charset=utf-8",
  zip: "application/zip",
  "3gp": "video/3gpp",
  "3g2": "video/3gpp2",
  gltf: "model/gltf+json",
  glb: "model/gltf-binary"
};
const baseMimes = _baseMimes;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getExtension,
  getMimeType,
  mimes
});

},
"hono/dist/cjs/utils/compress.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var compress_exports = {};
__export(compress_exports, {
  COMPRESSIBLE_CONTENT_TYPE_REGEX: () => COMPRESSIBLE_CONTENT_TYPE_REGEX
});
module.exports = __toCommonJS(compress_exports);
const COMPRESSIBLE_CONTENT_TYPE_REGEX = /^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|msgpack|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|vnd\.msgpack|wasm|x-httpd-php|x-javascript|x-msgpack|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml|msgpack))(?:[;\s]|$)/i;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  COMPRESSIBLE_CONTENT_TYPE_REGEX
});

},
};
var __thaw_bundle_import_maps = {
"hono/./dist/cjs/adapter/cloudflare-workers/index.js": {},
"hono/dist/cjs/adapter/cloudflare-workers/conninfo.js": {},
"hono/dist/cjs/adapter/cloudflare-workers/websocket.js": {},
"hono/dist/cjs/helper/websocket/index.js": {},
"hono/dist/cjs/adapter/cloudflare-workers/serve-static-module.js": {},
"hono/dist/cjs/adapter/cloudflare-workers/serve-static.js": {},
"hono/dist/cjs/adapter/cloudflare-workers/utils.js": {},
"hono/dist/cjs/middleware/serve-static/index.js": {},
"hono/dist/cjs/middleware/serve-static/path.js": {},
"hono/dist/cjs/utils/url.js": {},
"hono/dist/cjs/utils/mime.js": {},
"hono/dist/cjs/utils/compress.js": {},
};
var __thaw_bundle_known_package_maps = {
"hono/./dist/cjs/adapter/cloudflare-workers/index.js": [],
"hono/dist/cjs/adapter/cloudflare-workers/conninfo.js": [],
"hono/dist/cjs/adapter/cloudflare-workers/websocket.js": [],
"hono/dist/cjs/helper/websocket/index.js": [],
"hono/dist/cjs/adapter/cloudflare-workers/serve-static-module.js": [],
"hono/dist/cjs/adapter/cloudflare-workers/serve-static.js": [],
"hono/dist/cjs/adapter/cloudflare-workers/utils.js": [],
"hono/dist/cjs/middleware/serve-static/index.js": [],
"hono/dist/cjs/middleware/serve-static/path.js": [],
"hono/dist/cjs/utils/url.js": [],
"hono/dist/cjs/utils/mime.js": [],
"hono/dist/cjs/utils/compress.js": [],
};
var __thaw_bundle_require_maps = {
"hono/./dist/cjs/adapter/cloudflare-workers/index.js": {"./serve-static-module": "hono/dist/cjs/adapter/cloudflare-workers/serve-static-module.js", "./websocket": "hono/dist/cjs/adapter/cloudflare-workers/websocket.js", "./conninfo": "hono/dist/cjs/adapter/cloudflare-workers/conninfo.js", },
"hono/dist/cjs/adapter/cloudflare-workers/conninfo.js": {},
"hono/dist/cjs/adapter/cloudflare-workers/websocket.js": {"../../helper/websocket": "hono/dist/cjs/helper/websocket/index.js", },
"hono/dist/cjs/helper/websocket/index.js": {},
"hono/dist/cjs/adapter/cloudflare-workers/serve-static-module.js": {"./serve-static": "hono/dist/cjs/adapter/cloudflare-workers/serve-static.js", },
"hono/dist/cjs/adapter/cloudflare-workers/serve-static.js": {"../../middleware/serve-static": "hono/dist/cjs/middleware/serve-static/index.js", "./utils": "hono/dist/cjs/adapter/cloudflare-workers/utils.js", },
"hono/dist/cjs/adapter/cloudflare-workers/utils.js": {},
"hono/dist/cjs/middleware/serve-static/index.js": {"../../utils/compress": "hono/dist/cjs/utils/compress.js", "../../utils/mime": "hono/dist/cjs/utils/mime.js", "../../utils/url": "hono/dist/cjs/utils/url.js", "./path": "hono/dist/cjs/middleware/serve-static/path.js", },
"hono/dist/cjs/middleware/serve-static/path.js": {},
"hono/dist/cjs/utils/url.js": {},
"hono/dist/cjs/utils/mime.js": {},
"hono/dist/cjs/utils/compress.js": {},
};
var __thaw_bundle_export_graphs = JSON.parse("{}");
var __thaw_bundle_commonjs_contexts = JSON.parse("{\"hono/./dist/cjs/adapter/cloudflare-workers/index.js\":true,\"hono/dist/cjs/adapter/cloudflare-workers/conninfo.js\":true,\"hono/dist/cjs/adapter/cloudflare-workers/websocket.js\":true,\"hono/dist/cjs/helper/websocket/index.js\":true,\"hono/dist/cjs/adapter/cloudflare-workers/serve-static-module.js\":true,\"hono/dist/cjs/adapter/cloudflare-workers/serve-static.js\":true,\"hono/dist/cjs/adapter/cloudflare-workers/utils.js\":true,\"hono/dist/cjs/middleware/serve-static/index.js\":true,\"hono/dist/cjs/middleware/serve-static/path.js\":true,\"hono/dist/cjs/utils/url.js\":true,\"hono/dist/cjs/utils/mime.js\":true,\"hono/dist/cjs/utils/compress.js\":true}");
var __thaw_bundle_cjs_export_names = JSON.parse("{\"hono/./dist/cjs/adapter/cloudflare-workers/index.js\":[\"default\",\"getConnInfo\",\"serveStatic\",\"upgradeWebSocket\"],\"hono/dist/cjs/adapter/cloudflare-workers/conninfo.js\":[\"default\",\"getConnInfo\"],\"hono/dist/cjs/adapter/cloudflare-workers/websocket.js\":[\"default\",\"upgradeWebSocket\"],\"hono/dist/cjs/helper/websocket/index.js\":[\"WSContext\",\"createWSMessageEvent\",\"default\",\"defineWebSocketHelper\"],\"hono/dist/cjs/adapter/cloudflare-workers/serve-static-module.js\":[\"default\",\"serveStatic\"],\"hono/dist/cjs/adapter/cloudflare-workers/serve-static.js\":[\"default\",\"serveStatic\"],\"hono/dist/cjs/adapter/cloudflare-workers/utils.js\":[\"default\",\"getContentFromKVAsset\"],\"hono/dist/cjs/middleware/serve-static/index.js\":[\"default\",\"serveStatic\"],\"hono/dist/cjs/middleware/serve-static/path.js\":[\"default\",\"defaultJoin\"],\"hono/dist/cjs/utils/url.js\":[\"checkOptionalParameter\",\"decodeURIComponent_\",\"default\",\"getPath\",\"getPathNoStrict\",\"getPattern\",\"getQueryParam\",\"getQueryParams\",\"getQueryStrings\",\"mergePath\",\"splitPath\",\"splitRoutingPath\",\"tryDecode\",\"tryDecodeURI\",\"tryDecodeURIComponent\"],\"hono/dist/cjs/utils/mime.js\":[\"default\",\"getExtension\",\"getMimeType\",\"mimes\"],\"hono/dist/cjs/utils/compress.js\":[\"COMPRESSIBLE_CONTENT_TYPE_REGEX\",\"default\"]}");
function __thaw_bundle_factory_of(key) {
  if (Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, key)) return key;
  var query = key.indexOf('?'), fragment = key.indexOf('#', 1);
  var at = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  return at < 0 ? key : key.slice(0, at);
}
function __thaw_bundle_validate_static(key, visited) {
  visited = visited || [];
  if (visited.indexOf(key) >= 0) return;
  var graph = __thaw_bundle_export_graphs[__thaw_bundle_factory_of(key)];
  if (!graph) return;
  var next = visited.concat(key), dependencies = graph.dependencies || [];
  var map = __thaw_bundle_import_maps[__thaw_bundle_factory_of(key)] || {};
  for (var i = 0; i < dependencies.length; i++) {
    var target = __thaw_bundle_target(map, dependencies[i]);
    if (!target) {
      var spec = dependencies[i], builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
      if (__thaw_bundle_builtin_names.indexOf(builtin) < 0 && !(String(spec).endsWith('.node') && typeof require.addon === 'function'))
        throw new SyntaxError('Cannot resolve import ' + spec);
    } else __thaw_bundle_validate_static(target.key, next);
  }
  var origin = __thaw_bundle_origin_for(key), requests = graph.requests || [];
  for (var j = 0; j < requests.length; j++)
    origin.validateKnownStatic(requests[j][0], requests[j][1]);
}
var __thaw_namespace_create = Object.create, __thaw_namespace_define = Object.defineProperty;
var __thaw_namespace_prevent = Object.preventExtensions, __thaw_namespace_own = Object.prototype.hasOwnProperty;
var __thaw_namespace_keys = Object.keys, __thaw_namespace_apply = Reflect.apply;
var __thaw_namespace_get = WeakMap.prototype.get, __thaw_namespace_set = WeakMap.prototype.set;
var __thaw_namespace_has = WeakMap.prototype.has, __thaw_namespace_tag = Symbol.toStringTag;
var __thaw_namespace_promise = Promise, __thaw_namespace_resolve = Promise.resolve;
var __thaw_namespace_reject = Promise.reject, __thaw_namespace_then = Promise.prototype.then;
var __thaw_bundle_cjs_namespaces = Object.create(null);
var __thaw_bundle_cjs_namespace_values = new WeakMap();
function __thaw_bundle_cjs_namespace(key, value, names) {
  if (__thaw_namespace_apply(__thaw_namespace_own, __thaw_bundle_cjs_namespaces, [key]))
    return __thaw_bundle_cjs_namespaces[key];
  var namespace = __thaw_namespace_create(null);
  __thaw_namespace_define(namespace, 'default', {value:value, enumerable:true});
  __thaw_namespace_define(namespace, 'module.exports', {value:value, enumerable:true});
  for (var index = 0; index < names.length; index++) {
    var name = names[index];
    if (!__thaw_namespace_apply(__thaw_namespace_own, namespace, [name]))
      __thaw_namespace_define(namespace, name, {value:value == null ? undefined : value[name], enumerable:true});
  }
  __thaw_namespace_define(namespace, __thaw_namespace_tag, {value:'Module'});
  __thaw_namespace_prevent(namespace);
  __thaw_namespace_apply(__thaw_namespace_set, __thaw_bundle_cjs_namespace_values, [namespace, value]);
  __thaw_bundle_cjs_namespaces[key] = namespace;
  return namespace;
}
function __thaw_bundle_cjs_fallback_namespace(spec, value) {
  var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
  var known = __thaw_bundle_builtin_names.indexOf(builtin) >= 0;
  return __thaw_bundle_cjs_namespace('external:' + (known ? 'node:' + builtin : spec),
    value, known && value != null ? __thaw_namespace_keys(value) : []);
}
function __thaw_bundle_origin_for(ownerKey) {
  var own = Object.prototype.hasOwnProperty;
  var ambiguous = {};
  function graphOf(key) { return __thaw_bundle_export_graphs[__thaw_bundle_factory_of(key)]; }
  function targetOf(key, spec) {
    return __thaw_bundle_target(__thaw_bundle_import_maps[__thaw_bundle_factory_of(key)] || {}, spec);
  }
  var enumerable = Object.prototype.propertyIsEnumerable;
  function valueOf(target, sourceKey, spec) {
    var edges = __thaw_bundle_edges[sourceKey];
    if (edges && own.call(edges, spec)) {
      var edgeTarget = targetOf(sourceKey, spec);
      // A CommonJS cycle initially exposes provisional exports. The cache
      // remains authoritative if its factory later replaces module.exports.
      if (edgeTarget && own.call(__thaw_bundle_cache, edgeTarget.key))
        return __thaw_bundle_cache[edgeTarget.key].exports;
      return edges[spec];
    }
    // A cycle may reach this edge before its owner executes the loader.
    // Export discovery must never evaluate a dependency ahead of that owner.
    return undefined;
  }
  function namesOf(key, visited, sourceKey, spec) {
    if (visited.indexOf(key) >= 0) return [];
    var graph = graphOf(key);
    if (!graph) {
      var value = valueOf({ key: key, factory: __thaw_bundle_factory_of(key) }, sourceKey, spec);
      return value == null ? [] : Object.keys(value).filter(function(name) { return name !== '__esModule'; });
    }
    var next = visited.concat(key);
    var names = Object.keys(graph.local).concat(Object.keys(graph.indirect));
    for (var index = 0; index < graph.stars.length; index++) {
      var target = targetOf(key, graph.stars[index]);
      if (!target) continue;
      var more = namesOf(target.key, next, key, graph.stars[index]);
      for (var j = 0; j < more.length; j++) {
        if (more[j] !== 'default' && names.indexOf(more[j]) < 0) names.push(more[j]);
      }
    }
    return names;
  }
  function retainedNativeEdge(key) {
    return typeof __thaw_bundle_native_keys !== 'undefined'
      && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(key))
      && !own.call(__thaw_bundle_mixed_keys, __thaw_bundle_factory_of(key));
  }
  function retainedNamespaceAnchor(key, name, targetKey, anchor) {
    if (!retainedNativeEdge(targetKey)) return null;
    // A rewritten mixed edge strips the importer's native export, but a
    // following pure-native edge retains the current module's own alias.
    return anchor || (typeof __thaw_bundle_native_keys !== 'undefined'
      && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(key)) ? { key: key, name: name } : null);
  }
  function resolve(key, name, visited, allowMissing, sourceKey, spec, anchor) {
    var visit = key + '\u0000' + name;
    if (visited.indexOf(visit) >= 0) return null;
    var graph = graphOf(key);
    if (!graph) {
      // Star exports skip the CommonJS interop marker; explicit named
      // reexports still resolve it through allowMissing.
      if (name === '__esModule' && !allowMissing) return null;
      var value = valueOf({ key: key, factory: __thaw_bundle_factory_of(key) }, sourceKey, spec);
      return (allowMissing || (value != null && enumerable.call(value, name))) ? { kind: 'cjs', key: key, sourceKey: sourceKey, spec: spec, name: name } : null;
    }
    var next = visited.concat(visit);
    if (own.call(graph.local, name)) {
      return { kind: 'esm', key: key, binding: graph.local[name], name: name };
    }
    if (own.call(graph.indirect, name)) {
      var indirect = graph.indirect[name];
      var source = targetOf(key, indirect[0]);
      if (!source) return null;
      if (indirect[1] === null) {
        return { kind: 'namespace', key: source.key, binding: '*namespace*', sourceKey: key,
          spec: indirect[0], name: name,
          anchor: retainedNamespaceAnchor(key, name, source.key, anchor) };
      }
      if (indirect[2] && !graphOf(source.key)) {
        return { kind: 'cjs-default', key: source.key, sourceKey: key, spec: indirect[0] };
      }
      return resolve(source.key, indirect[1], next, true, key, indirect[0],
        retainedNamespaceAnchor(key, name, source.key, anchor));
    }
    if (name === 'default') return null;
    var found = null;
    for (var index = 0; index < graph.stars.length; index++) {
      var star = targetOf(key, graph.stars[index]);
      if (!star) continue;
      var candidate = resolve(star.key, name, next, false, key, graph.stars[index],
        retainedNamespaceAnchor(key, name, star.key, anchor));
      if (candidate === ambiguous) return ambiguous;
      if (!candidate) continue;
      if (found && !sameBinding(found, candidate)) return ambiguous;
      found = candidate;
    }
    return found;
  }
  function sameBinding(left, right) {
    if (left.kind !== right.kind) return false;
    if (left.kind === 'cjs') return left.key === right.key && left.name === right.name;
    if (left.kind === 'cjs-default') return left.key === right.key;
    return left.key === right.key && left.binding === right.binding;
  }
  function read(resolution) {
    if (resolution.kind === 'cjs' || resolution.kind === 'cjs-default') {
      var edges = __thaw_bundle_edges[resolution.sourceKey];
      if (!edges || !own.call(edges, resolution.spec)) throw new ReferenceError("Cannot access '" + (resolution.name || 'default') + "' before initialization");
      var value = valueOf(null, resolution.sourceKey, resolution.spec);
      return resolution.kind === 'cjs' ? value[resolution.name] : value && value.__esModule ? value.default : value;
    }
    if (typeof __thaw_native_entry !== 'undefined' && __thaw_native_entry) {
      if (resolution.kind === 'namespace') {
        if (graphOf(resolution.key)) return __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(resolution.key)]
          ? __thaw_bundle_facade_for(resolution.key)
          : resolution.anchor
            ? __thaw_native_entry.readNative(resolution.anchor.key, resolution.anchor.name)
            : __thaw_native_entry.readNative(resolution.key);
        var edge = __thaw_bundle_edges[resolution.sourceKey];
        if (!edge || !own.call(edge, resolution.spec)) throw new ReferenceError('Import is not initialized');
        return edge[resolution.spec];
      }
      // `binding` is the local declaration used for diamond identity;
      // native namespaces expose the exported alias in `name` instead.
      return __thaw_native_entry.readNative(resolution.key, resolution.name);
    }
    var source = __thaw_bundle_require(resolution.key, __thaw_bundle_factory_of(resolution.key), true);
    return resolution.kind === 'namespace' ? source : source[resolution.name];
  }
  function linksReady(key, visited) {
    if (visited.indexOf(key) >= 0) return true;
    var graph = graphOf(key);
    if (!graph) return true;
    var next = visited.concat(key), edges = __thaw_bundle_edges[key];
    // Explicit named reexports cannot introduce a competing star binding.
    // Their names are static even if their opaque target has not run yet.
    var specs = graph.stars;
    for (var index = 0; index < specs.length; index++) {
      var spec = specs[index], target = targetOf(key, spec);
      if (!target) continue;
      // ESM names and terminal bindings are known from the source graph
      // before evaluation. Only opaque CJS/native targets need a loaded edge
      // to discover their exported names.
      if ((!graphOf(target.key) && (!edges || !own.call(edges, spec))) || !linksReady(target.key, next)) return false;
    }
    var indirectNames = Object.keys(graph.indirect);
    for (var n = 0; n < indirectNames.length; n++) {
      var indirect = graph.indirect[indirectNames[n]], target = targetOf(key, indirect[0]);
      // A direct opaque named reexport has a statically fixed name/binding.
      // An ESM target can itself resolve through unknown opaque stars.
      if (target && graphOf(target.key) && !linksReady(target.key, next)) return false;
    }
    return true;
  }
  return {
    validateStatic: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new SyntaxError('Cannot resolve import ' + spec);
      // CommonJS default is the established synthetic default interop. All
      // other requested names in this route have a statically known graph.
      if (name === 'default' && !graphOf(target.key)) return;
      var resolution = resolve(target.key, name, [], false, ownerKey, spec);
      if (!resolution || resolution === ambiguous)
        throw new SyntaxError('Missing or ambiguous export ' + name);
    },
    validateKnownStatic: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      // Opaque CommonJS stars are discovered only after their owner's load.
      // Do not execute that owner during source-graph validation.
      if (!target) {
        var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
        if (__thaw_bundle_builtin_names.indexOf(builtin) < 0 && !(String(spec).endsWith('.node') && typeof require.addon === 'function'))
          throw new SyntaxError('Cannot resolve import ' + spec);
        return;
      }
      if (graphOf(target.key) && linksReady(target.key, []))
        this.validateStatic(spec, name);
    },
    validateRequests: function() {
      var graph = graphOf(ownerKey), requests = graph && graph.requests || [];
      for (var index = 0; index < requests.length; index++)
        this.validateKnownStatic(requests[index][0], requests[index][1]);
    },
    validateDynamic: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (target) __thaw_validate_native_link(target.key);
    },
    completeDynamic: function(spec, promise) {
      var origin = this;
      return __thaw_native_apply(__thaw_native_then, promise,
        [function(namespace) { return origin.selectDynamic(spec, namespace); }]);
    },
    rejectDynamic: function(error) {
      return __thaw_native_apply(__thaw_native_reject, __thaw_native_promise, [error]);
    },
    edge: function(spec, value) {
      // Async static imports share the loader with dynamic import. Only our
      // own namespace wrappers unwrap here; user exports keep their identity.
      if (value != null && (typeof value === 'object' || typeof value === 'function')
          && __thaw_namespace_apply(__thaw_namespace_has, __thaw_bundle_cjs_namespace_values, [value]))
        value = __thaw_namespace_apply(__thaw_namespace_get, __thaw_bundle_cjs_namespace_values, [value]);
      var edges = __thaw_bundle_edges[ownerKey];
      if (!edges) edges = __thaw_bundle_edges[ownerKey] = Object.create(null);
      if (own.call(edges, spec) && edges[spec] === value) return;
      edges[spec] = value;
      __thaw_bundle_edge_version++;
      // A cycle can reach an ESM module before its later CJS/native loader.
      // Only link when its full transitive export graph is available.
      for (var key in __thaw_bundle_star_linkers) __thaw_bundle_star_linkers[key]();
    },
    track: function(exports) {
      var linked = false, linking = false;
      var link = function() {
        if (linked || linking || !linksReady(ownerKey, [])) return;
        linking = true;
        try {
          // A CJS Proxy ownKeys trap can record another edge while names are
          // discovered. Recompute before publication if the graph changed.
          var bindings, before;
          do {
            before = __thaw_bundle_edge_version;
            bindings = [];
            var graph = graphOf(ownerKey), names = [];
            for (var index = 0; index < graph.stars.length; index++) {
              var spec = graph.stars[index], target = targetOf(ownerKey, spec);
              if (!target) continue;
              var more = namesOf(target.key, [], ownerKey, spec);
              for (var j = 0; j < more.length; j++) {
                var name = more[j];
                if (name !== 'default' && names.indexOf(name) < 0) names.push(name);
              }
            }
            for (var n = 0; n < names.length; n++) {
              var name = names[n];
              if (own.call(graph.local, name) || own.call(graph.indirect, name) || (name !== '__esModule' && own.call(exports, name))) continue;
              var resolution = resolve(ownerKey, name, [], false, null, null,
                { key: ownerKey, name: name });
              if (resolution && resolution !== ambiguous) bindings.push([name, resolution]);
            }
          } while (before !== __thaw_bundle_edge_version && linksReady(ownerKey, []));
          if (!linksReady(ownerKey, [])) return;
          for (var b = 0; b < bindings.length; b++) {
            var binding = bindings[b];
            if (binding[0] !== '__esModule' && own.call(exports, binding[0])) continue;
            Object.defineProperty(exports, binding[0], { enumerable: true, get: function(r) { return function() { return read(r); }; }(binding[1]) });
          }
          linked = true;
          delete __thaw_bundle_star_linkers[ownerKey];
        } finally { linking = false; }
      };
      __thaw_bundle_star_linkers[ownerKey] = link;
      link();
    },
    defaultImport: function(spec, value) {
      var target = targetOf(ownerKey, spec);
      return target && graphOf(target.key) ? value.default : value && value.__esModule ? value.default : value;
    },
    readImport: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      var resolution = resolve(target.key, name, [], true, ownerKey, spec,
        typeof __thaw_bundle_native_keys !== 'undefined' && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(target.key))
          ? { key: target.key, name: name } : null);
      if (!resolution || resolution === ambiguous) throw new SyntaxError('Missing or ambiguous export ' + name);
      return read(resolution);
    },
    readDefault: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      if (!graphOf(target.key)) {
        var edges = __thaw_bundle_edges[ownerKey];
        if (!edges || !own.call(edges, spec)) throw new ReferenceError('Import is not initialized');
        return this.defaultImport(spec, edges[spec]);
      }
      var resolution = resolve(target.key, 'default', [], true, ownerKey, spec,
        typeof __thaw_bundle_native_keys !== 'undefined' && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(target.key))
          ? { key: target.key, name: 'default' } : null);
      if (!resolution || resolution === ambiguous) throw new SyntaxError('Missing or ambiguous default export');
      return read(resolution);
    },
    namespaceImport: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      if (!graphOf(target.key)) {
        var edges = __thaw_bundle_edges[ownerKey];
        if (!edges || !own.call(edges, spec)) throw new ReferenceError('Import is not initialized');
        // Keep the legacy CJS namespace-import object; only ESM targets
        // select the tracked facade.
        return edges[spec];
      }
      return typeof __thaw_native_entry === 'undefined' || !__thaw_native_entry || __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(target.key)]
        ? __thaw_bundle_facade_for(target.key) : __thaw_native_entry.readNative(target.key);
    },
    selectDynamic: function(spec, namespace) {
      var target = targetOf(ownerKey, spec);
      if (!target) return namespace;
      // The private shell's namespace contains no CJS exports. The existing
      // bundle contract returns that target's cached CommonJS value instead.
      if (!graphOf(target.key)) return __thaw_bundle_cjs_namespace(target.key, this.namespaceImport(spec), __thaw_bundle_cjs_export_names[target.factory] || []);
      return __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(target.key)]
        ? __thaw_bundle_facade_for(target.key) : namespace;
    },
    names: function(spec, value) {
      var target = targetOf(ownerKey, spec);
      return target && graphOf(target.key) ? namesOf(target.key, [], ownerKey, spec) : (value == null ? [] : Object.keys(value).filter(function(name) { return name !== '__esModule'; }));
    },
    resolve: function(name) { var found = resolve(ownerKey, name, [], false, null, null,
      { key: ownerKey, name: name }); return found === ambiguous ? null : found; },
    read: read
  };
}
function __thaw_bundle_target(map, spec) {
  if (Object.prototype.hasOwnProperty.call(map, spec)) return { key: map[spec], factory: map[spec] };
  var query = spec.indexOf('?');
  var fragment = spec.indexOf('#', 1);
  var suffixAt = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  if (suffixAt < 0) return null;
  var base = spec.slice(0, suffixAt);
  if (!Object.prototype.hasOwnProperty.call(map, base)) return null;
  var factory = map[base];
  return { key: factory + spec.slice(suffixAt), factory: factory };
}
function __thaw_bundle_import_missing(known, spec) {
  spec = String(spec);
  if (spec.charAt(0) === '#') return true;
  var query = spec.indexOf('?'), fragment = spec.indexOf('#', 1);
  var suffixAt = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  if (suffixAt >= 0) spec = spec.slice(0, suffixAt);
  var slash = spec.indexOf('/');
  var next = spec.charAt(0) === '@' && slash >= 0 ? spec.indexOf('/', slash + 1) : slash;
  var name = next < 0 ? spec : spec.slice(0, next);
  return known.indexOf(name) >= 0;
}
function __thaw_bundle_resolve(map, spec, keys, searchAll, allowExports) {
  spec = String(spec);
  if (allowExports && Object.prototype.hasOwnProperty.call(__thaw_bundle_exports, spec)) return spec;
  var target = __thaw_bundle_target(map, spec);
  if (!target && searchAll) for (var index = 0; index < keys.length && !target; index++) target = __thaw_bundle_target(__thaw_bundle_require_maps[keys[index]] || {}, spec);
  if (target) return target.key;
  var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
  if (__thaw_bundle_builtin_names.indexOf(builtin) >= 0) return spec;
  var error = new Error('Cannot find module ' + spec);
  error.code = 'MODULE_NOT_FOUND';
  throw error;
}
function __thaw_bundle_async_error(factoryKey) {
  var error = new Error('Cannot synchronously require an async module: ' + factoryKey);
  error.code = 'ERR_REQUIRE_ASYNC_MODULE';
  return error;
}
function __thaw_bundle_require(key, factoryKey, allowAsync) {
  factoryKey = factoryKey || key;
  if (!allowAsync && Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, factoryKey)) throw __thaw_bundle_async_error(factoryKey);
  if (String(factoryKey).endsWith('.node') && require.addon) return require.addon();
  if (typeof __thaw_bundle_native_keys !== 'undefined' && Object.prototype.hasOwnProperty.call(__thaw_bundle_native_keys, factoryKey)) {
    var namespace = __thaw_native_entry.evalNativeSync(key, factoryKey);
    return Object.prototype.hasOwnProperty.call(__thaw_bundle_mixed_keys, factoryKey) ? __thaw_bundle_facade_for(key) : namespace;
  }
  __thaw_bundle_validate_static(key);
  if (!(key in __thaw_bundle_cache)) {
    var mod = { exports: {}, filename: '/thaw_modules/' + (factoryKey || key) };
    __thaw_bundle_cache[key] = mod;
    var map = __thaw_bundle_require_maps[factoryKey] || {};
    var importMap = __thaw_bundle_import_maps[factoryKey] || {};
    var knownPackages = __thaw_bundle_known_package_maps[factoryKey] || [];
    var localRequire = function(spec) {
      if ((spec === 'bindings' || spec === 'node-gyp-build') && typeof require.addon === 'function') return require.addon;
      var target = __thaw_bundle_target(map, spec);
      if (target) return __thaw_bundle_require(target.key, target.factory);
      return require(spec);
    };
    localRequire.addon = typeof require === 'function' ? require.addon : undefined;
    localRequire.resolve = function(spec) { return __thaw_bundle_resolve(map, spec, null, false, false); };
    localRequire.cache = __thaw_bundle_cache;
    var localImport = function(spec) { var target = __thaw_bundle_target(importMap, spec); if (target) return __thaw_bundle_require(target.key, target.factory); if (__thaw_bundle_import_missing(knownPackages, spec)) throw new Error('Cannot resolve import ' + spec); return require(spec); };
    var localRequireAsync = __thaw_bundle_create_import_async(factoryKey, globalThis.__thaw_worker_module);
    var filename = '/thaw_modules/' + factoryKey, slash = filename.lastIndexOf('/'), dirname = slash < 0 ? '.' : filename.slice(0, slash);
    var initialized;
    try { var factory = __thaw_bundle_factories[factoryKey]; if (Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, factoryKey)) factory = factory(__thaw_bundle_origin_for(key)); initialized = Object.prototype.hasOwnProperty.call(__thaw_bundle_commonjs_contexts, factoryKey) ? factory.call(mod.exports, mod, mod.exports, localRequire, localRequireAsync, filename, dirname, localImport) : factory(mod, mod.exports, localRequire, localRequireAsync, filename, dirname, localImport); } catch (error) { delete __thaw_bundle_cache[key]; delete __thaw_bundle_edges[key]; delete __thaw_bundle_star_linkers[key]; throw error; }
    mod.ready = __thaw_namespace_apply(__thaw_namespace_then, __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, [Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, factoryKey) ? initialized : undefined]), [function() {}, function(error) { delete __thaw_bundle_cache[key]; delete __thaw_bundle_edges[key]; delete __thaw_bundle_star_linkers[key]; throw error; }]);
  }
  return __thaw_bundle_cache[key].exports;
}
function __thaw_bundle_create_require(base) {
  var text = String(base || '');
  var keys = Object.keys(__thaw_bundle_require_maps);
  var factoryKey = keys.indexOf(text) >= 0 ? text : keys.reduce(function(best, key) { return text.endsWith('/' + key) && (!best || key.length > best.length) ? key : best; }, null);
  var map = {}, staticMap = __thaw_bundle_import_maps[factoryKey] || {}, requireMap = __thaw_bundle_require_maps[factoryKey] || {};
  for (var staticSpec in staticMap) if (Object.prototype.hasOwnProperty.call(staticMap, staticSpec)) map[staticSpec] = staticMap[staticSpec];
  for (var requireSpec in requireMap) if (Object.prototype.hasOwnProperty.call(requireMap, requireSpec)) map[requireSpec] = requireMap[requireSpec];
  var created = function(spec) { if ((String(spec) === 'bindings' || String(spec) === 'node-gyp-build') && typeof require.addon === 'function') return require.addon; spec = String(spec); if (Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, spec)) throw __thaw_bundle_async_error(spec); if (Object.prototype.hasOwnProperty.call(__thaw_bundle_exports, spec)) return __thaw_bundle_exports[spec]; var target = __thaw_bundle_target(map, spec); if (!target && !factoryKey) { for (var index = 0; index < keys.length && !target; index++) target = __thaw_bundle_target(__thaw_bundle_require_maps[keys[index]] || {}, spec); } if (target) return __thaw_bundle_require(target.key, target.factory); return require(spec); };
  created.addon = typeof require === 'function' ? require.addon : undefined;
  created.resolve = function(spec) { return __thaw_bundle_resolve(map, spec, keys, !factoryKey, true); };
  created.cache = __thaw_bundle_cache; return created;
}
function __thaw_bundle_create_import(base) {
  var map = __thaw_bundle_import_maps[String(base)] || {};
  var known = __thaw_bundle_known_package_maps[String(base)] || [];
  return function(spec) { spec = String(spec); var target = __thaw_bundle_target(map, spec); if (target) return __thaw_bundle_require(target.key, target.factory); if (__thaw_bundle_import_missing(known, spec)) throw new Error('Cannot resolve import ' + spec); return require(spec); };
}
function __thaw_bundle_create_import_async(base, workerModule) {
  var map = __thaw_bundle_import_maps[String(base)] || {};
  var known = __thaw_bundle_known_package_maps[String(base)] || [];
  return function(spec) {
    try { spec = `${spec}`; } catch (error) { return __thaw_namespace_apply(__thaw_namespace_reject, __thaw_namespace_promise, [error]); }
    if (workerModule !== undefined && (spec === 'worker_threads' || spec === 'node:worker_threads')) { try { return __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, [__thaw_bundle_cjs_fallback_namespace(spec, workerModule)]); } catch (error) { return __thaw_namespace_apply(__thaw_namespace_reject, __thaw_namespace_promise, [error]); } }
  return new __thaw_namespace_promise(function(resolve, reject) {
   __thaw_namespace_apply(__thaw_namespace_then, __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, []), [function() {
    try {
     var target = __thaw_bundle_target(map, spec);
     if (target) {
      if (typeof __thaw_bundle_native_keys !== 'undefined' && Object.prototype.hasOwnProperty.call(__thaw_bundle_native_keys, target.factory)) {
       __thaw_native_apply(__thaw_native_then, __thaw_native_entry.evalNative(target.key, target.factory), [function(namespace) { try { resolve(__thaw_bundle_mixed_keys[target.factory] ? __thaw_bundle_facade_for(target.key) : namespace); } catch (error) { reject(error); } }, reject]);
       return;
      }
      __thaw_bundle_require(target.key, target.factory, true);
      __thaw_namespace_apply(__thaw_namespace_then, __thaw_bundle_cache[target.key].ready, [function() { try { var value = __thaw_bundle_cache[target.key].exports; resolve(Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, target.factory) ? value : __thaw_bundle_cjs_namespace(target.key, value, __thaw_bundle_cjs_export_names[target.factory] || [])); } catch (error) { reject(error); } }, reject]);
      return;
     }
     if (__thaw_bundle_import_missing(known, spec)) throw new Error('Cannot resolve import ' + spec);
     resolve(__thaw_bundle_cjs_fallback_namespace(spec, require(spec)));
    } catch (error) { reject(error); }
   }, reject]);
  });
  };
}
function __thaw_bundle_register_worker_main(key, mod) {
  __thaw_bundle_validate_static(key);
  if (Object.prototype.hasOwnProperty.call(__thaw_bundle_cache, key)) throw new Error('Worker entry already initialized');
  mod.filename = '/thaw_modules/' + key;
  var resolveReady, rejectReady;
  mod.ready = new __thaw_namespace_promise(function(resolve, reject) { resolveReady = resolve; rejectReady = reject; });
  __thaw_bundle_cache[key] = mod;
  return function(succeeded, error) { if (succeeded) resolveReady(); else rejectReady(error); };
}
globalThis.__thaw_bundle_create_require = __thaw_bundle_create_require;
globalThis.__thaw_bundle_create_import = __thaw_bundle_create_import;
globalThis.__thaw_bundle_create_import_async = __thaw_bundle_create_import_async;
var __thaw_worker_bundle_source =
  '(function() {\nvar __thaw_worker_bundle_source = globalThis.__thaw_worker_bundle_source;\nvar require = function(name) { if (name === "worker_threads" || name === "node:worker_threads") return globalThis.__thaw_worker_module; if (String(name).endsWith(".node") && typeof require.addon === "function") return require.addon(); var error = new Error("Cannot find module " + name); error.code = "MODULE_NOT_FOUND"; throw error; };\nrequire.addon = globalThis.require && globalThis.require.addon;\nvar __thaw_bundle_exports = globalThis.__thaw_bundle_exports || (globalThis.__thaw_bundle_exports = {});\nvar __thaw_bundle_builtin_names = Object.freeze(' + JSON.stringify(__thaw_bundle_builtin_names) + ');\nvar __thaw_bundle_cache = {};\nvar __thaw_bundle_async_keys = ' + JSON.stringify(__thaw_bundle_async_keys) + ';\nvar __thaw_bundle_edges = Object.create(null);\nvar __thaw_bundle_star_linkers = Object.create(null);\nvar __thaw_bundle_edge_version = 0;\nvar __thaw_bundle_factories = {' +
  Object.keys(__thaw_bundle_factories).map(function(key) { return JSON.stringify(key) + ': ' + __thaw_bundle_factories[key].toString(); }).join(',\n') +
  '};\nvar __thaw_bundle_require_maps = ' + JSON.stringify(__thaw_bundle_require_maps) + ';\n' +
  'var __thaw_bundle_import_maps = ' + JSON.stringify(__thaw_bundle_import_maps) + ';\n' +
  'var __thaw_bundle_known_package_maps = ' + JSON.stringify(__thaw_bundle_known_package_maps) + ';\n' +
  'var __thaw_bundle_export_graphs = JSON.parse(' + JSON.stringify(JSON.stringify(__thaw_bundle_export_graphs)) + ');\n' +
  'var __thaw_bundle_commonjs_contexts = JSON.parse(' + JSON.stringify(JSON.stringify(__thaw_bundle_commonjs_contexts)) + ');\n' +
  'var __thaw_namespace_create = Object.create, __thaw_namespace_define = Object.defineProperty;\nvar __thaw_namespace_prevent = Object.preventExtensions, __thaw_namespace_own = Object.prototype.hasOwnProperty;\nvar __thaw_namespace_keys = Object.keys, __thaw_namespace_apply = Reflect.apply;\nvar __thaw_namespace_get = WeakMap.prototype.get, __thaw_namespace_set = WeakMap.prototype.set;\nvar __thaw_namespace_has = WeakMap.prototype.has, __thaw_namespace_tag = Symbol.toStringTag;\nvar __thaw_namespace_promise = Promise, __thaw_namespace_resolve = Promise.resolve;\nvar __thaw_namespace_reject = Promise.reject, __thaw_namespace_then = Promise.prototype.then;\nvar __thaw_bundle_cjs_namespaces = Object.create(null);\nvar __thaw_bundle_cjs_namespace_values = new WeakMap();\nvar __thaw_bundle_cjs_export_names = ' + JSON.stringify(__thaw_bundle_cjs_export_names) + ';\n' +
  __thaw_bundle_cjs_namespace.toString() + '\n' + __thaw_bundle_cjs_fallback_namespace.toString() + '\n' + __thaw_bundle_factory_of.toString() + '\n' + __thaw_bundle_validate_static.toString() + '\n' + __thaw_bundle_origin_for.toString() + '\n' + __thaw_bundle_target.toString() + '\n' + __thaw_bundle_import_missing.toString() + '\n' + __thaw_bundle_resolve.toString() + '\n' + __thaw_bundle_async_error.toString() + '\n' + __thaw_bundle_require.toString() + '\n' + __thaw_bundle_create_require.toString() + '\n' + __thaw_bundle_create_import.toString() + '\n' + __thaw_bundle_create_import_async.toString() + '\n' + __thaw_bundle_register_worker_main.toString() + '\n' +
  'globalThis.__thaw_bundle_create_require = __thaw_bundle_create_require;\nglobalThis.__thaw_bundle_create_import = __thaw_bundle_create_import;\nglobalThis.__thaw_bundle_create_import_async = __thaw_bundle_create_import_async;\nglobalThis.__thaw_bundle_worker_origin = __thaw_bundle_origin_for;\nglobalThis.__thaw_bundle_register_worker_main = __thaw_bundle_register_worker_main;\n})();\n';
globalThis.__thaw_worker_bundle_source = __thaw_worker_bundle_source;
var __thaw_bundle_entry_key = "hono/./dist/cjs/adapter/cloudflare-workers/index.js";
var __thaw_bundle_entry = __thaw_bundle_require(__thaw_bundle_entry_key, undefined, true);
__thaw_bundle_exports[__thaw_bundle_entry_key] = __thaw_bundle_entry;
globalThis.__thaw_module_ready = __thaw_bundle_cache[__thaw_bundle_entry_key].ready;
return __thaw_bundle_entry;
})(globalThis.require);
