module.exports = (function(require) {
if (typeof require !== 'function') require = function(name) { var error = new Error('Cannot find module ' + name); error.code = 'MODULE_NOT_FOUND'; throw error; };
var __thaw_bundle_exports = globalThis.__thaw_bundle_exports || (globalThis.__thaw_bundle_exports = {});
var __thaw_bundle_builtin_names = Object.freeze(["_http_agent","_http_client","_http_common","_http_incoming","_http_outgoing","_http_server","_stream_duplex","_stream_passthrough","_stream_readable","_stream_transform","_stream_wrap","_stream_writable","_tls_common","_tls_wrap","assert","assert/strict","async_hooks","buffer","child_process","cluster","console","constants","crypto","dgram","diagnostics_channel","dns","dns/promises","domain","events","fs","fs/promises","http","http2","https","inspector","inspector/promises","module","net","os","path","path/posix","path/win32","perf_hooks","process","punycode","querystring","readline","readline/promises","repl","stream","stream/consumers","stream/promises","stream/web","string_decoder","sys","test","test/reporters","timers","timers/promises","tls","trace_events","tty","url","util","util/types","v8","vm","wasi","worker_threads","zlib"]);
var __thaw_bundle_cache = {};
var __thaw_bundle_async_keys = JSON.parse("{}");
var __thaw_bundle_edges = Object.create(null);
var __thaw_bundle_star_linkers = Object.create(null);
var __thaw_bundle_edge_version = 0;
var __thaw_bundle_factories = {
"drizzle-orm/./node-postgres/index.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var node_postgres_exports = {};
module.exports = __toCommonJS(node_postgres_exports);
__reExport(node_postgres_exports, require("./driver.cjs"), module.exports);
__reExport(node_postgres_exports, require("./session.cjs"), module.exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ...require("./driver.cjs"),
  ...require("./session.cjs")
});
//# sourceMappingURL=index.cjs.map
},
"drizzle-orm/node-postgres/session.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var session_exports = {};
__export(session_exports, {
  NodePgPreparedQuery: () => NodePgPreparedQuery,
  NodePgSession: () => NodePgSession,
  NodePgTransaction: () => NodePgTransaction
});
module.exports = __toCommonJS(session_exports);
var import_pg = __toESM(require("pg"), 1);
var import_core = require("../cache/core/index.cjs");
var import_entity = require("../entity.cjs");
var import_logger = require("../logger.cjs");
var import_pg_core = require("../pg-core/index.cjs");
var import_session = require("../pg-core/session.cjs");
var import_sql = require("../sql/sql.cjs");
var import_tracing = require("../tracing.cjs");
var import_utils = require("../utils.cjs");
const { Pool, types } = import_pg.default;
class NodePgPreparedQuery extends import_session.PgPreparedQuery {
  constructor(client, queryString, params, logger, cache, queryMetadata, cacheConfig, fields, name, _isResponseInArrayMode, customResultMapper) {
    super({ sql: queryString, params }, cache, queryMetadata, cacheConfig);
    this.client = client;
    this.queryString = queryString;
    this.params = params;
    this.logger = logger;
    this.fields = fields;
    this._isResponseInArrayMode = _isResponseInArrayMode;
    this.customResultMapper = customResultMapper;
    this.rawQueryConfig = {
      name,
      text: queryString,
      types: {
        // @ts-ignore
        getTypeParser: (typeId, format) => {
          if (typeId === types.builtins.TIMESTAMPTZ) {
            return (val) => val;
          }
          if (typeId === types.builtins.TIMESTAMP) {
            return (val) => val;
          }
          if (typeId === types.builtins.DATE) {
            return (val) => val;
          }
          if (typeId === types.builtins.INTERVAL) {
            return (val) => val;
          }
          if (typeId === 1231) {
            return (val) => val;
          }
          if (typeId === 1115) {
            return (val) => val;
          }
          if (typeId === 1185) {
            return (val) => val;
          }
          if (typeId === 1187) {
            return (val) => val;
          }
          if (typeId === 1182) {
            return (val) => val;
          }
          return types.getTypeParser(typeId, format);
        }
      }
    };
    this.queryConfig = {
      name,
      text: queryString,
      rowMode: "array",
      types: {
        // @ts-ignore
        getTypeParser: (typeId, format) => {
          if (typeId === types.builtins.TIMESTAMPTZ) {
            return (val) => val;
          }
          if (typeId === types.builtins.TIMESTAMP) {
            return (val) => val;
          }
          if (typeId === types.builtins.DATE) {
            return (val) => val;
          }
          if (typeId === types.builtins.INTERVAL) {
            return (val) => val;
          }
          if (typeId === 1231) {
            return (val) => val;
          }
          if (typeId === 1115) {
            return (val) => val;
          }
          if (typeId === 1185) {
            return (val) => val;
          }
          if (typeId === 1187) {
            return (val) => val;
          }
          if (typeId === 1182) {
            return (val) => val;
          }
          return types.getTypeParser(typeId, format);
        }
      }
    };
  }
  static [import_entity.entityKind] = "NodePgPreparedQuery";
  rawQueryConfig;
  queryConfig;
  async execute(placeholderValues = {}) {
    return import_tracing.tracer.startActiveSpan("drizzle.execute", async () => {
      const params = (0, import_sql.fillPlaceholders)(this.params, placeholderValues);
      this.logger.logQuery(this.rawQueryConfig.text, params);
      const { fields, rawQueryConfig: rawQuery, client, queryConfig: query, joinsNotNullableMap, customResultMapper } = this;
      if (!fields && !customResultMapper) {
        return import_tracing.tracer.startActiveSpan("drizzle.driver.execute", async (span) => {
          span?.setAttributes({
            "drizzle.query.name": rawQuery.name,
            "drizzle.query.text": rawQuery.text,
            "drizzle.query.params": JSON.stringify(params)
          });
          return this.queryWithCache(rawQuery.text, params, async () => {
            return await client.query(rawQuery, params);
          });
        });
      }
      const result = await import_tracing.tracer.startActiveSpan("drizzle.driver.execute", (span) => {
        span?.setAttributes({
          "drizzle.query.name": query.name,
          "drizzle.query.text": query.text,
          "drizzle.query.params": JSON.stringify(params)
        });
        return this.queryWithCache(query.text, params, async () => {
          return await client.query(query, params);
        });
      });
      return import_tracing.tracer.startActiveSpan("drizzle.mapResponse", () => {
        return customResultMapper ? customResultMapper(result.rows) : result.rows.map((row) => (0, import_utils.mapResultRow)(fields, row, joinsNotNullableMap));
      });
    });
  }
  all(placeholderValues = {}) {
    return import_tracing.tracer.startActiveSpan("drizzle.execute", () => {
      const params = (0, import_sql.fillPlaceholders)(this.params, placeholderValues);
      this.logger.logQuery(this.rawQueryConfig.text, params);
      return import_tracing.tracer.startActiveSpan("drizzle.driver.execute", (span) => {
        span?.setAttributes({
          "drizzle.query.name": this.rawQueryConfig.name,
          "drizzle.query.text": this.rawQueryConfig.text,
          "drizzle.query.params": JSON.stringify(params)
        });
        return this.queryWithCache(this.rawQueryConfig.text, params, async () => {
          return this.client.query(this.rawQueryConfig, params);
        }).then((result) => result.rows);
      });
    });
  }
  /** @internal */
  isResponseInArrayMode() {
    return this._isResponseInArrayMode;
  }
}
class NodePgSession extends import_session.PgSession {
  constructor(client, dialect, schema, options = {}) {
    super(dialect);
    this.client = client;
    this.schema = schema;
    this.options = options;
    this.logger = options.logger ?? new import_logger.NoopLogger();
    this.cache = options.cache ?? new import_core.NoopCache();
  }
  static [import_entity.entityKind] = "NodePgSession";
  logger;
  cache;
  prepareQuery(query, fields, name, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig) {
    return new NodePgPreparedQuery(
      this.client,
      query.sql,
      query.params,
      this.logger,
      this.cache,
      queryMetadata,
      cacheConfig,
      fields,
      name,
      isResponseInArrayMode,
      customResultMapper
    );
  }
  async transaction(transaction, config) {
    const isPool = this.client instanceof Pool || Object.getPrototypeOf(this.client).constructor.name.includes("Pool");
    const session = isPool ? new NodePgSession(await this.client.connect(), this.dialect, this.schema, this.options) : this;
    const tx = new NodePgTransaction(this.dialect, session, this.schema);
    await tx.execute(import_sql.sql`begin${config ? import_sql.sql` ${tx.getTransactionConfigSQL(config)}` : void 0}`);
    try {
      const result = await transaction(tx);
      await tx.execute(import_sql.sql`commit`);
      return result;
    } catch (error) {
      await tx.execute(import_sql.sql`rollback`);
      throw error;
    } finally {
      if (isPool) session.client.release();
    }
  }
  async count(sql2) {
    const res = await this.execute(sql2);
    return Number(
      res["rows"][0]["count"]
    );
  }
}
class NodePgTransaction extends import_pg_core.PgTransaction {
  static [import_entity.entityKind] = "NodePgTransaction";
  async transaction(transaction) {
    const savepointName = `sp${this.nestedIndex + 1}`;
    const tx = new NodePgTransaction(
      this.dialect,
      this.session,
      this.schema,
      this.nestedIndex + 1
    );
    await tx.execute(import_sql.sql.raw(`savepoint ${savepointName}`));
    try {
      const result = await transaction(tx);
      await tx.execute(import_sql.sql.raw(`release savepoint ${savepointName}`));
      return result;
    } catch (err) {
      await tx.execute(import_sql.sql.raw(`rollback to savepoint ${savepointName}`));
      throw err;
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  NodePgPreparedQuery,
  NodePgSession,
  NodePgTransaction
});
//# sourceMappingURL=session.cjs.map
},
"drizzle-orm/utils.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var utils_exports = {};
__export(utils_exports, {
  applyMixins: () => applyMixins,
  getColumnNameAndConfig: () => getColumnNameAndConfig,
  getTableColumns: () => getTableColumns,
  getTableLikeName: () => getTableLikeName,
  getViewSelectedFields: () => getViewSelectedFields,
  haveSameKeys: () => haveSameKeys,
  isConfig: () => isConfig,
  mapResultRow: () => mapResultRow,
  mapUpdateSet: () => mapUpdateSet,
  orderSelectedFields: () => orderSelectedFields,
  textDecoder: () => textDecoder
});
module.exports = __toCommonJS(utils_exports);
var import_column = require("./column.cjs");
var import_entity = require("./entity.cjs");
var import_sql = require("./sql/sql.cjs");
var import_subquery = require("./subquery.cjs");
var import_table = require("./table.cjs");
var import_view_common = require("./view-common.cjs");
function mapResultRow(columns, row, joinsNotNullableMap) {
  const nullifyMap = {};
  const result = columns.reduce(
    (result2, { path, field }, columnIndex) => {
      let decoder;
      if ((0, import_entity.is)(field, import_column.Column)) {
        decoder = field;
      } else if ((0, import_entity.is)(field, import_sql.SQL)) {
        decoder = field.decoder;
      } else if ((0, import_entity.is)(field, import_subquery.Subquery)) {
        decoder = field._.sql.decoder;
      } else {
        decoder = field.sql.decoder;
      }
      let node = result2;
      for (const [pathChunkIndex, pathChunk] of path.entries()) {
        if (pathChunkIndex < path.length - 1) {
          if (!(pathChunk in node)) {
            node[pathChunk] = {};
          }
          node = node[pathChunk];
        } else {
          const rawValue = row[columnIndex];
          const value = node[pathChunk] = rawValue === null ? null : decoder.mapFromDriverValue(rawValue);
          if (joinsNotNullableMap && (0, import_entity.is)(field, import_column.Column) && path.length === 2) {
            const objectName = path[0];
            if (!(objectName in nullifyMap)) {
              nullifyMap[objectName] = value === null ? (0, import_table.getTableName)(field.table) : false;
            } else if (typeof nullifyMap[objectName] === "string" && nullifyMap[objectName] !== (0, import_table.getTableName)(field.table)) {
              nullifyMap[objectName] = false;
            }
          }
        }
      }
      return result2;
    },
    {}
  );
  if (joinsNotNullableMap && Object.keys(nullifyMap).length > 0) {
    for (const [objectName, tableName] of Object.entries(nullifyMap)) {
      if (typeof tableName === "string" && !joinsNotNullableMap[tableName]) {
        result[objectName] = null;
      }
    }
  }
  return result;
}
function orderSelectedFields(fields, pathPrefix) {
  return Object.entries(fields).reduce((result, [name, field]) => {
    if (typeof name !== "string") {
      return result;
    }
    const newPath = pathPrefix ? [...pathPrefix, name] : [name];
    if ((0, import_entity.is)(field, import_column.Column) || (0, import_entity.is)(field, import_sql.SQL) || (0, import_entity.is)(field, import_sql.SQL.Aliased) || (0, import_entity.is)(field, import_subquery.Subquery)) {
      result.push({ path: newPath, field });
    } else if ((0, import_entity.is)(field, import_table.Table)) {
      result.push(...orderSelectedFields(field[import_table.Table.Symbol.Columns], newPath));
    } else {
      result.push(...orderSelectedFields(field, newPath));
    }
    return result;
  }, []);
}
function haveSameKeys(left, right) {
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  if (leftKeys.length !== rightKeys.length) {
    return false;
  }
  for (const [index, key] of leftKeys.entries()) {
    if (key !== rightKeys[index]) {
      return false;
    }
  }
  return true;
}
function mapUpdateSet(table, values) {
  const entries = Object.entries(values).filter(([, value]) => value !== void 0).map(([key, value]) => {
    if ((0, import_entity.is)(value, import_sql.SQL) || (0, import_entity.is)(value, import_column.Column)) {
      return [key, value];
    } else {
      return [key, new import_sql.Param(value, table[import_table.Table.Symbol.Columns][key])];
    }
  });
  if (entries.length === 0) {
    throw new Error("No values to set");
  }
  return Object.fromEntries(entries);
}
function applyMixins(baseClass, extendedClasses) {
  for (const extendedClass of extendedClasses) {
    for (const name of Object.getOwnPropertyNames(extendedClass.prototype)) {
      if (name === "constructor") continue;
      Object.defineProperty(
        baseClass.prototype,
        name,
        Object.getOwnPropertyDescriptor(extendedClass.prototype, name) || /* @__PURE__ */ Object.create(null)
      );
    }
  }
}
function getTableColumns(table) {
  return table[import_table.Table.Symbol.Columns];
}
function getViewSelectedFields(view) {
  return view[import_view_common.ViewBaseConfig].selectedFields;
}
function getTableLikeName(table) {
  return (0, import_entity.is)(table, import_subquery.Subquery) ? table._.alias : (0, import_entity.is)(table, import_sql.View) ? table[import_view_common.ViewBaseConfig].name : (0, import_entity.is)(table, import_sql.SQL) ? void 0 : table[import_table.Table.Symbol.IsAlias] ? table[import_table.Table.Symbol.Name] : table[import_table.Table.Symbol.BaseName];
}
function getColumnNameAndConfig(a, b) {
  return {
    name: typeof a === "string" && a.length > 0 ? a : "",
    config: typeof a === "object" ? a : b
  };
}
const _ = {};
const __ = {};
function isConfig(data) {
  if (typeof data !== "object" || data === null) return false;
  if (data.constructor.name !== "Object") return false;
  if ("logger" in data) {
    const type = typeof data["logger"];
    if (type !== "boolean" && (type !== "object" || typeof data["logger"]["logQuery"] !== "function") && type !== "undefined") return false;
    return true;
  }
  if ("schema" in data) {
    const type = typeof data["schema"];
    if (type !== "object" && type !== "undefined") return false;
    return true;
  }
  if ("casing" in data) {
    const type = typeof data["casing"];
    if (type !== "string" && type !== "undefined") return false;
    return true;
  }
  if ("mode" in data) {
    if (data["mode"] !== "default" || data["mode"] !== "planetscale" || data["mode"] !== void 0) return false;
    return true;
  }
  if ("connection" in data) {
    const type = typeof data["connection"];
    if (type !== "string" && type !== "object" && type !== "undefined") return false;
    return true;
  }
  if ("client" in data) {
    const type = typeof data["client"];
    if (type !== "object" && type !== "function" && type !== "undefined") return false;
    return true;
  }
  if (Object.keys(data).length === 0) return true;
  return false;
}
const textDecoder = typeof TextDecoder === "undefined" ? null : new TextDecoder();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  applyMixins,
  getColumnNameAndConfig,
  getTableColumns,
  getTableLikeName,
  getViewSelectedFields,
  haveSameKeys,
  isConfig,
  mapResultRow,
  mapUpdateSet,
  orderSelectedFields,
  textDecoder
});
//# sourceMappingURL=utils.cjs.map
},
"drizzle-orm/view-common.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var view_common_exports = {};
__export(view_common_exports, {
  ViewBaseConfig: () => ViewBaseConfig
});
module.exports = __toCommonJS(view_common_exports);
const ViewBaseConfig = Symbol.for("drizzle:ViewBaseConfig");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ViewBaseConfig
});
//# sourceMappingURL=view-common.cjs.map
},
"drizzle-orm/table.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var table_exports = {};
__export(table_exports, {
  BaseName: () => BaseName,
  Columns: () => Columns,
  ExtraConfigBuilder: () => ExtraConfigBuilder,
  ExtraConfigColumns: () => ExtraConfigColumns,
  IsAlias: () => IsAlias,
  OriginalName: () => OriginalName,
  Schema: () => Schema,
  Table: () => Table,
  getTableName: () => getTableName,
  getTableUniqueName: () => getTableUniqueName,
  isTable: () => isTable
});
module.exports = __toCommonJS(table_exports);
var import_entity = require("./entity.cjs");
var import_table_utils = require("./table.utils.cjs");
const Schema = Symbol.for("drizzle:Schema");
const Columns = Symbol.for("drizzle:Columns");
const ExtraConfigColumns = Symbol.for("drizzle:ExtraConfigColumns");
const OriginalName = Symbol.for("drizzle:OriginalName");
const BaseName = Symbol.for("drizzle:BaseName");
const IsAlias = Symbol.for("drizzle:IsAlias");
const ExtraConfigBuilder = Symbol.for("drizzle:ExtraConfigBuilder");
const IsDrizzleTable = Symbol.for("drizzle:IsDrizzleTable");
class Table {
  static [import_entity.entityKind] = "Table";
  /** @internal */
  static Symbol = {
    Name: import_table_utils.TableName,
    Schema,
    OriginalName,
    Columns,
    ExtraConfigColumns,
    BaseName,
    IsAlias,
    ExtraConfigBuilder
  };
  /**
   * @internal
   * Can be changed if the table is aliased.
   */
  [import_table_utils.TableName];
  /**
   * @internal
   * Used to store the original name of the table, before any aliasing.
   */
  [OriginalName];
  /** @internal */
  [Schema];
  /** @internal */
  [Columns];
  /** @internal */
  [ExtraConfigColumns];
  /**
   *  @internal
   * Used to store the table name before the transformation via the `tableCreator` functions.
   */
  [BaseName];
  /** @internal */
  [IsAlias] = false;
  /** @internal */
  [IsDrizzleTable] = true;
  /** @internal */
  [ExtraConfigBuilder] = void 0;
  constructor(name, schema, baseName) {
    this[import_table_utils.TableName] = this[OriginalName] = name;
    this[Schema] = schema;
    this[BaseName] = baseName;
  }
}
function isTable(table) {
  return typeof table === "object" && table !== null && IsDrizzleTable in table;
}
function getTableName(table) {
  return table[import_table_utils.TableName];
}
function getTableUniqueName(table) {
  return `${table[Schema] ?? "public"}.${table[import_table_utils.TableName]}`;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  BaseName,
  Columns,
  ExtraConfigBuilder,
  ExtraConfigColumns,
  IsAlias,
  OriginalName,
  Schema,
  Table,
  getTableName,
  getTableUniqueName,
  isTable
});
//# sourceMappingURL=table.cjs.map
},
"drizzle-orm/table.utils.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var table_utils_exports = {};
__export(table_utils_exports, {
  TableName: () => TableName
});
module.exports = __toCommonJS(table_utils_exports);
const TableName = Symbol.for("drizzle:Name");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TableName
});
//# sourceMappingURL=table.utils.cjs.map
},
"drizzle-orm/subquery.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var subquery_exports = {};
__export(subquery_exports, {
  Subquery: () => Subquery,
  WithSubquery: () => WithSubquery
});
module.exports = __toCommonJS(subquery_exports);
var import_entity = require("./entity.cjs");
class Subquery {
  static [import_entity.entityKind] = "Subquery";
  constructor(sql, fields, alias, isWith = false, usedTables = []) {
    this._ = {
      brand: "Subquery",
      sql,
      selectedFields: fields,
      alias,
      isWith,
      usedTables
    };
  }
  // getSQL(): SQL<unknown> {
  // 	return new SQL([this]);
  // }
}
class WithSubquery extends Subquery {
  static [import_entity.entityKind] = "WithSubquery";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Subquery,
  WithSubquery
});
//# sourceMappingURL=subquery.cjs.map
},
"drizzle-orm/column.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var column_exports = {};
__export(column_exports, {
  Column: () => Column
});
module.exports = __toCommonJS(column_exports);
var import_entity = require("./entity.cjs");
class Column {
  constructor(table, config) {
    this.table = table;
    this.config = config;
    this.name = config.name;
    this.keyAsName = config.keyAsName;
    this.notNull = config.notNull;
    this.default = config.default;
    this.defaultFn = config.defaultFn;
    this.onUpdateFn = config.onUpdateFn;
    this.hasDefault = config.hasDefault;
    this.primary = config.primaryKey;
    this.isUnique = config.isUnique;
    this.uniqueName = config.uniqueName;
    this.uniqueType = config.uniqueType;
    this.dataType = config.dataType;
    this.columnType = config.columnType;
    this.generated = config.generated;
    this.generatedIdentity = config.generatedIdentity;
  }
  static [import_entity.entityKind] = "Column";
  name;
  keyAsName;
  primary;
  notNull;
  default;
  defaultFn;
  onUpdateFn;
  hasDefault;
  isUnique;
  uniqueName;
  uniqueType;
  dataType;
  columnType;
  enumValues = void 0;
  generated = void 0;
  generatedIdentity = void 0;
  config;
  mapFromDriverValue(value) {
    return value;
  }
  mapToDriverValue(value) {
    return value;
  }
  // ** @internal */
  shouldDisableInsert() {
    return this.config.generated !== void 0 && this.config.generated.type !== "byDefault";
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Column
});
//# sourceMappingURL=column.cjs.map
},
"drizzle-orm/tracing.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tracing_exports = {};
__export(tracing_exports, {
  tracer: () => tracer
});
module.exports = __toCommonJS(tracing_exports);
var import_tracing_utils = require("./tracing-utils.cjs");
var import_version = require("./version.cjs");
let otel;
let rawTracer;
const tracer = {
  startActiveSpan(name, fn) {
    if (!otel) {
      return fn();
    }
    if (!rawTracer) {
      rawTracer = otel.trace.getTracer("drizzle-orm", import_version.npmVersion);
    }
    return (0, import_tracing_utils.iife)(
      (otel2, rawTracer2) => rawTracer2.startActiveSpan(
        name,
        (span) => {
          try {
            return fn(span);
          } catch (e) {
            span.setStatus({
              code: otel2.SpanStatusCode.ERROR,
              message: e instanceof Error ? e.message : "Unknown error"
              // eslint-disable-line no-instanceof/no-instanceof
            });
            throw e;
          } finally {
            span.end();
          }
        }
      ),
      otel,
      rawTracer
    );
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  tracer
});
//# sourceMappingURL=tracing.cjs.map
},
"drizzle-orm/version.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/version.ts
var version_exports = {};
__export(version_exports, {
  compatibilityVersion: () => compatibilityVersion,
  npmVersion: () => version
});
module.exports = __toCommonJS(version_exports);

// package.json
var version = "0.45.4";

// src/version.ts
var compatibilityVersion = 10;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  compatibilityVersion,
  npmVersion
});

},
"drizzle-orm/tracing-utils.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tracing_utils_exports = {};
__export(tracing_utils_exports, {
  iife: () => iife
});
module.exports = __toCommonJS(tracing_utils_exports);
function iife(fn, ...args) {
  return fn(...args);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  iife
});
//# sourceMappingURL=tracing-utils.cjs.map
},
"drizzle-orm/sql/sql.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name2 in all)
    __defProp(target, name2, { get: all[name2], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var sql_exports = {};
__export(sql_exports, {
  FakePrimitiveParam: () => FakePrimitiveParam,
  Name: () => Name,
  Param: () => Param,
  Placeholder: () => Placeholder,
  SQL: () => SQL,
  StringChunk: () => StringChunk,
  View: () => View,
  fillPlaceholders: () => fillPlaceholders,
  getViewName: () => getViewName,
  isDriverValueEncoder: () => isDriverValueEncoder,
  isSQLWrapper: () => isSQLWrapper,
  isView: () => isView,
  name: () => name,
  noopDecoder: () => noopDecoder,
  noopEncoder: () => noopEncoder,
  noopMapper: () => noopMapper,
  param: () => param,
  placeholder: () => placeholder,
  sql: () => sql
});
module.exports = __toCommonJS(sql_exports);
var import_entity = require("../entity.cjs");
var import_enum = require("../pg-core/columns/enum.cjs");
var import_subquery = require("../subquery.cjs");
var import_tracing = require("../tracing.cjs");
var import_view_common = require("../view-common.cjs");
var import_column = require("../column.cjs");
var import_table = require("../table.cjs");
class FakePrimitiveParam {
  static [import_entity.entityKind] = "FakePrimitiveParam";
}
function isSQLWrapper(value) {
  return value !== null && value !== void 0 && typeof value.getSQL === "function";
}
function mergeQueries(queries) {
  const result = { sql: "", params: [] };
  for (const query of queries) {
    result.sql += query.sql;
    result.params.push(...query.params);
    if (query.typings?.length) {
      if (!result.typings) {
        result.typings = [];
      }
      result.typings.push(...query.typings);
    }
  }
  return result;
}
class StringChunk {
  static [import_entity.entityKind] = "StringChunk";
  value;
  constructor(value) {
    this.value = Array.isArray(value) ? value : [value];
  }
  getSQL() {
    return new SQL([this]);
  }
}
class SQL {
  constructor(queryChunks) {
    this.queryChunks = queryChunks;
    for (const chunk of queryChunks) {
      if ((0, import_entity.is)(chunk, import_table.Table)) {
        const schemaName = chunk[import_table.Table.Symbol.Schema];
        this.usedTables.push(
          schemaName === void 0 ? chunk[import_table.Table.Symbol.Name] : schemaName + "." + chunk[import_table.Table.Symbol.Name]
        );
      }
    }
  }
  static [import_entity.entityKind] = "SQL";
  /** @internal */
  decoder = noopDecoder;
  shouldInlineParams = false;
  /** @internal */
  usedTables = [];
  append(query) {
    this.queryChunks.push(...query.queryChunks);
    return this;
  }
  toQuery(config) {
    return import_tracing.tracer.startActiveSpan("drizzle.buildSQL", (span) => {
      const query = this.buildQueryFromSourceParams(this.queryChunks, config);
      span?.setAttributes({
        "drizzle.query.text": query.sql,
        "drizzle.query.params": JSON.stringify(query.params)
      });
      return query;
    });
  }
  buildQueryFromSourceParams(chunks, _config) {
    const config = Object.assign({}, _config, {
      inlineParams: _config.inlineParams || this.shouldInlineParams,
      paramStartIndex: _config.paramStartIndex || { value: 0 }
    });
    const {
      casing,
      escapeName,
      escapeParam,
      prepareTyping,
      inlineParams,
      paramStartIndex
    } = config;
    return mergeQueries(chunks.map((chunk) => {
      if ((0, import_entity.is)(chunk, StringChunk)) {
        return { sql: chunk.value.join(""), params: [] };
      }
      if ((0, import_entity.is)(chunk, Name)) {
        return { sql: escapeName(chunk.value), params: [] };
      }
      if (chunk === void 0) {
        return { sql: "", params: [] };
      }
      if (Array.isArray(chunk)) {
        const result = [new StringChunk("(")];
        for (const [i, p] of chunk.entries()) {
          result.push(p);
          if (i < chunk.length - 1) {
            result.push(new StringChunk(", "));
          }
        }
        result.push(new StringChunk(")"));
        return this.buildQueryFromSourceParams(result, config);
      }
      if ((0, import_entity.is)(chunk, SQL)) {
        return this.buildQueryFromSourceParams(chunk.queryChunks, {
          ...config,
          inlineParams: inlineParams || chunk.shouldInlineParams
        });
      }
      if ((0, import_entity.is)(chunk, import_table.Table)) {
        const schemaName = chunk[import_table.Table.Symbol.Schema];
        const tableName = chunk[import_table.Table.Symbol.Name];
        return {
          sql: schemaName === void 0 || chunk[import_table.IsAlias] ? escapeName(tableName) : escapeName(schemaName) + "." + escapeName(tableName),
          params: []
        };
      }
      if ((0, import_entity.is)(chunk, import_column.Column)) {
        const columnName = casing.getColumnCasing(chunk);
        if (_config.invokeSource === "indexes") {
          return { sql: escapeName(columnName), params: [] };
        }
        const schemaName = chunk.table[import_table.Table.Symbol.Schema];
        return {
          sql: chunk.table[import_table.IsAlias] || schemaName === void 0 ? escapeName(chunk.table[import_table.Table.Symbol.Name]) + "." + escapeName(columnName) : escapeName(schemaName) + "." + escapeName(chunk.table[import_table.Table.Symbol.Name]) + "." + escapeName(columnName),
          params: []
        };
      }
      if ((0, import_entity.is)(chunk, View)) {
        const schemaName = chunk[import_view_common.ViewBaseConfig].schema;
        const viewName = chunk[import_view_common.ViewBaseConfig].name;
        return {
          sql: schemaName === void 0 || chunk[import_view_common.ViewBaseConfig].isAlias ? escapeName(viewName) : escapeName(schemaName) + "." + escapeName(viewName),
          params: []
        };
      }
      if ((0, import_entity.is)(chunk, Param)) {
        if ((0, import_entity.is)(chunk.value, Placeholder)) {
          return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
        }
        const mappedValue = chunk.value === null ? null : chunk.encoder.mapToDriverValue(chunk.value);
        if ((0, import_entity.is)(mappedValue, SQL)) {
          return this.buildQueryFromSourceParams([mappedValue], config);
        }
        if (inlineParams) {
          return { sql: this.mapInlineParam(mappedValue, config), params: [] };
        }
        let typings = ["none"];
        if (prepareTyping) {
          typings = [prepareTyping(chunk.encoder)];
        }
        return { sql: escapeParam(paramStartIndex.value++, mappedValue), params: [mappedValue], typings };
      }
      if ((0, import_entity.is)(chunk, Placeholder)) {
        return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
      }
      if ((0, import_entity.is)(chunk, SQL.Aliased) && chunk.fieldAlias !== void 0) {
        return { sql: escapeName(chunk.fieldAlias), params: [] };
      }
      if ((0, import_entity.is)(chunk, import_subquery.Subquery)) {
        if (chunk._.isWith) {
          return { sql: escapeName(chunk._.alias), params: [] };
        }
        return this.buildQueryFromSourceParams([
          new StringChunk("("),
          chunk._.sql,
          new StringChunk(") "),
          new Name(chunk._.alias)
        ], config);
      }
      if ((0, import_enum.isPgEnum)(chunk)) {
        if (chunk.schema) {
          return { sql: escapeName(chunk.schema) + "." + escapeName(chunk.enumName), params: [] };
        }
        return { sql: escapeName(chunk.enumName), params: [] };
      }
      if (isSQLWrapper(chunk)) {
        if (chunk.shouldOmitSQLParens?.()) {
          return this.buildQueryFromSourceParams([chunk.getSQL()], config);
        }
        return this.buildQueryFromSourceParams([
          new StringChunk("("),
          chunk.getSQL(),
          new StringChunk(")")
        ], config);
      }
      if (inlineParams) {
        return { sql: this.mapInlineParam(chunk, config), params: [] };
      }
      return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
    }));
  }
  mapInlineParam(chunk, { escapeString }) {
    if (chunk === null) {
      return "null";
    }
    if (typeof chunk === "number" || typeof chunk === "boolean") {
      return chunk.toString();
    }
    if (typeof chunk === "string") {
      return escapeString(chunk);
    }
    if (typeof chunk === "object") {
      const mappedValueAsString = chunk.toString();
      if (mappedValueAsString === "[object Object]") {
        return escapeString(JSON.stringify(chunk));
      }
      return escapeString(mappedValueAsString);
    }
    throw new Error("Unexpected param value: " + chunk);
  }
  getSQL() {
    return this;
  }
  as(alias) {
    if (alias === void 0) {
      return this;
    }
    return new SQL.Aliased(this, alias);
  }
  mapWith(decoder) {
    this.decoder = typeof decoder === "function" ? { mapFromDriverValue: decoder } : decoder;
    return this;
  }
  inlineParams() {
    this.shouldInlineParams = true;
    return this;
  }
  /**
   * This method is used to conditionally include a part of the query.
   *
   * @param condition - Condition to check
   * @returns itself if the condition is `true`, otherwise `undefined`
   */
  if(condition) {
    return condition ? this : void 0;
  }
}
class Name {
  constructor(value) {
    this.value = value;
  }
  static [import_entity.entityKind] = "Name";
  brand;
  getSQL() {
    return new SQL([this]);
  }
}
function name(value) {
  return new Name(value);
}
function isDriverValueEncoder(value) {
  return typeof value === "object" && value !== null && "mapToDriverValue" in value && typeof value.mapToDriverValue === "function";
}
const noopDecoder = {
  mapFromDriverValue: (value) => value
};
const noopEncoder = {
  mapToDriverValue: (value) => value
};
const noopMapper = {
  ...noopDecoder,
  ...noopEncoder
};
class Param {
  /**
   * @param value - Parameter value
   * @param encoder - Encoder to convert the value to a driver parameter
   */
  constructor(value, encoder = noopEncoder) {
    this.value = value;
    this.encoder = encoder;
  }
  static [import_entity.entityKind] = "Param";
  brand;
  getSQL() {
    return new SQL([this]);
  }
}
function param(value, encoder) {
  return new Param(value, encoder);
}
function sql(strings, ...params) {
  const queryChunks = [];
  if (params.length > 0 || strings.length > 0 && strings[0] !== "") {
    queryChunks.push(new StringChunk(strings[0]));
  }
  for (const [paramIndex, param2] of params.entries()) {
    queryChunks.push(param2, new StringChunk(strings[paramIndex + 1]));
  }
  return new SQL(queryChunks);
}
((sql2) => {
  function empty() {
    return new SQL([]);
  }
  sql2.empty = empty;
  function fromList(list) {
    return new SQL(list);
  }
  sql2.fromList = fromList;
  function raw(str) {
    return new SQL([new StringChunk(str)]);
  }
  sql2.raw = raw;
  function join(chunks, separator) {
    const result = [];
    for (const [i, chunk] of chunks.entries()) {
      if (i > 0 && separator !== void 0) {
        result.push(separator);
      }
      result.push(chunk);
    }
    return new SQL(result);
  }
  sql2.join = join;
  function identifier(value) {
    return new Name(value);
  }
  sql2.identifier = identifier;
  function placeholder2(name2) {
    return new Placeholder(name2);
  }
  sql2.placeholder = placeholder2;
  function param2(value, encoder) {
    return new Param(value, encoder);
  }
  sql2.param = param2;
})(sql || (sql = {}));
((SQL2) => {
  class Aliased {
    constructor(sql2, fieldAlias) {
      this.sql = sql2;
      this.fieldAlias = fieldAlias;
    }
    static [import_entity.entityKind] = "SQL.Aliased";
    /** @internal */
    isSelectionField = false;
    getSQL() {
      return this.sql;
    }
    /** @internal */
    clone() {
      return new Aliased(this.sql, this.fieldAlias);
    }
  }
  SQL2.Aliased = Aliased;
})(SQL || (SQL = {}));
class Placeholder {
  constructor(name2) {
    this.name = name2;
  }
  static [import_entity.entityKind] = "Placeholder";
  getSQL() {
    return new SQL([this]);
  }
}
function placeholder(name2) {
  return new Placeholder(name2);
}
function fillPlaceholders(params, values) {
  return params.map((p) => {
    if ((0, import_entity.is)(p, Placeholder)) {
      if (!(p.name in values)) {
        throw new Error(`No value for placeholder "${p.name}" was provided`);
      }
      return values[p.name];
    }
    if ((0, import_entity.is)(p, Param) && (0, import_entity.is)(p.value, Placeholder)) {
      if (!(p.value.name in values)) {
        throw new Error(`No value for placeholder "${p.value.name}" was provided`);
      }
      return p.encoder.mapToDriverValue(values[p.value.name]);
    }
    return p;
  });
}
const IsDrizzleView = Symbol.for("drizzle:IsDrizzleView");
class View {
  static [import_entity.entityKind] = "View";
  /** @internal */
  [import_view_common.ViewBaseConfig];
  /** @internal */
  [IsDrizzleView] = true;
  constructor({ name: name2, schema, selectedFields, query }) {
    this[import_view_common.ViewBaseConfig] = {
      name: name2,
      originalName: name2,
      schema,
      selectedFields,
      query,
      isExisting: !query,
      isAlias: false
    };
  }
  getSQL() {
    return new SQL([this]);
  }
}
function isView(view) {
  return typeof view === "object" && view !== null && IsDrizzleView in view;
}
function getViewName(view) {
  return view[import_view_common.ViewBaseConfig].name;
}
import_column.Column.prototype.getSQL = function() {
  return new SQL([this]);
};
import_table.Table.prototype.getSQL = function() {
  return new SQL([this]);
};
import_subquery.Subquery.prototype.getSQL = function() {
  return new SQL([this]);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  FakePrimitiveParam,
  Name,
  Param,
  Placeholder,
  SQL,
  StringChunk,
  View,
  fillPlaceholders,
  getViewName,
  isDriverValueEncoder,
  isSQLWrapper,
  isView,
  name,
  noopDecoder,
  noopEncoder,
  noopMapper,
  param,
  placeholder,
  sql
});
//# sourceMappingURL=sql.cjs.map
},
"drizzle-orm/pg-core/columns/enum.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var enum_exports = {};
__export(enum_exports, {
  PgEnumColumn: () => PgEnumColumn,
  PgEnumColumnBuilder: () => PgEnumColumnBuilder,
  PgEnumObjectColumn: () => PgEnumObjectColumn,
  PgEnumObjectColumnBuilder: () => PgEnumObjectColumnBuilder,
  isPgEnum: () => isPgEnum,
  pgEnum: () => pgEnum,
  pgEnumObjectWithSchema: () => pgEnumObjectWithSchema,
  pgEnumWithSchema: () => pgEnumWithSchema
});
module.exports = __toCommonJS(enum_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgEnumObjectColumnBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgEnumObjectColumnBuilder";
  constructor(name, enumInstance) {
    super(name, "string", "PgEnumObjectColumn");
    this.config.enum = enumInstance;
  }
  /** @internal */
  build(table) {
    return new PgEnumObjectColumn(
      table,
      this.config
    );
  }
}
class PgEnumObjectColumn extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgEnumObjectColumn";
  enum;
  enumValues = this.config.enum.enumValues;
  constructor(table, config) {
    super(table, config);
    this.enum = config.enum;
  }
  getSQLType() {
    return this.enum.enumName;
  }
}
const isPgEnumSym = Symbol.for("drizzle:isPgEnum");
function isPgEnum(obj) {
  return !!obj && typeof obj === "function" && isPgEnumSym in obj && obj[isPgEnumSym] === true;
}
class PgEnumColumnBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgEnumColumnBuilder";
  constructor(name, enumInstance) {
    super(name, "string", "PgEnumColumn");
    this.config.enum = enumInstance;
  }
  /** @internal */
  build(table) {
    return new PgEnumColumn(
      table,
      this.config
    );
  }
}
class PgEnumColumn extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgEnumColumn";
  enum = this.config.enum;
  enumValues = this.config.enum.enumValues;
  constructor(table, config) {
    super(table, config);
    this.enum = config.enum;
  }
  getSQLType() {
    return this.enum.enumName;
  }
}
function pgEnum(enumName, input) {
  return Array.isArray(input) ? pgEnumWithSchema(enumName, [...input], void 0) : pgEnumObjectWithSchema(enumName, input, void 0);
}
function pgEnumWithSchema(enumName, values, schema) {
  const enumInstance = Object.assign(
    (name) => new PgEnumColumnBuilder(name ?? "", enumInstance),
    {
      enumName,
      enumValues: values,
      schema,
      [isPgEnumSym]: true
    }
  );
  return enumInstance;
}
function pgEnumObjectWithSchema(enumName, values, schema) {
  const enumInstance = Object.assign(
    (name) => new PgEnumObjectColumnBuilder(name ?? "", enumInstance),
    {
      enumName,
      enumValues: Object.values(values),
      schema,
      [isPgEnumSym]: true
    }
  );
  return enumInstance;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgEnumColumn,
  PgEnumColumnBuilder,
  PgEnumObjectColumn,
  PgEnumObjectColumnBuilder,
  isPgEnum,
  pgEnum,
  pgEnumObjectWithSchema,
  pgEnumWithSchema
});
//# sourceMappingURL=enum.cjs.map
},
"drizzle-orm/pg-core/columns/common.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var common_exports = {};
__export(common_exports, {
  ExtraConfigColumn: () => ExtraConfigColumn,
  IndexedColumn: () => IndexedColumn,
  PgArray: () => PgArray,
  PgArrayBuilder: () => PgArrayBuilder,
  PgColumn: () => PgColumn,
  PgColumnBuilder: () => PgColumnBuilder
});
module.exports = __toCommonJS(common_exports);
var import_column_builder = require("../../column-builder.cjs");
var import_column = require("../../column.cjs");
var import_entity = require("../../entity.cjs");
var import_foreign_keys = require("../foreign-keys.cjs");
var import_tracing_utils = require("../../tracing-utils.cjs");
var import_unique_constraint = require("../unique-constraint.cjs");
var import_array = require("../utils/array.cjs");
class PgColumnBuilder extends import_column_builder.ColumnBuilder {
  foreignKeyConfigs = [];
  static [import_entity.entityKind] = "PgColumnBuilder";
  array(size) {
    return new PgArrayBuilder(this.config.name, this, size);
  }
  references(ref, actions = {}) {
    this.foreignKeyConfigs.push({ ref, actions });
    return this;
  }
  unique(name, config) {
    this.config.isUnique = true;
    this.config.uniqueName = name;
    this.config.uniqueType = config?.nulls;
    return this;
  }
  generatedAlwaysAs(as) {
    this.config.generated = {
      as,
      type: "always",
      mode: "stored"
    };
    return this;
  }
  /** @internal */
  buildForeignKeys(column, table) {
    return this.foreignKeyConfigs.map(({ ref, actions }) => {
      return (0, import_tracing_utils.iife)(
        (ref2, actions2) => {
          const builder = new import_foreign_keys.ForeignKeyBuilder(() => {
            const foreignColumn = ref2();
            return { columns: [column], foreignColumns: [foreignColumn] };
          });
          if (actions2.onUpdate) {
            builder.onUpdate(actions2.onUpdate);
          }
          if (actions2.onDelete) {
            builder.onDelete(actions2.onDelete);
          }
          return builder.build(table);
        },
        ref,
        actions
      );
    });
  }
  /** @internal */
  buildExtraConfigColumn(table) {
    return new ExtraConfigColumn(table, this.config);
  }
}
class PgColumn extends import_column.Column {
  constructor(table, config) {
    if (!config.uniqueName) {
      config.uniqueName = (0, import_unique_constraint.uniqueKeyName)(table, [config.name]);
    }
    super(table, config);
    this.table = table;
  }
  static [import_entity.entityKind] = "PgColumn";
}
class ExtraConfigColumn extends PgColumn {
  static [import_entity.entityKind] = "ExtraConfigColumn";
  getSQLType() {
    return this.getSQLType();
  }
  indexConfig = {
    order: this.config.order ?? "asc",
    nulls: this.config.nulls ?? "last",
    opClass: this.config.opClass
  };
  defaultConfig = {
    order: "asc",
    nulls: "last",
    opClass: void 0
  };
  asc() {
    this.indexConfig.order = "asc";
    return this;
  }
  desc() {
    this.indexConfig.order = "desc";
    return this;
  }
  nullsFirst() {
    this.indexConfig.nulls = "first";
    return this;
  }
  nullsLast() {
    this.indexConfig.nulls = "last";
    return this;
  }
  /**
   * ### PostgreSQL documentation quote
   *
   * > An operator class with optional parameters can be specified for each column of an index.
   * The operator class identifies the operators to be used by the index for that column.
   * For example, a B-tree index on four-byte integers would use the int4_ops class;
   * this operator class includes comparison functions for four-byte integers.
   * In practice the default operator class for the column's data type is usually sufficient.
   * The main point of having operator classes is that for some data types, there could be more than one meaningful ordering.
   * For example, we might want to sort a complex-number data type either by absolute value or by real part.
   * We could do this by defining two operator classes for the data type and then selecting the proper class when creating an index.
   * More information about operator classes check:
   *
   * ### Useful links
   * https://www.postgresql.org/docs/current/sql-createindex.html
   *
   * https://www.postgresql.org/docs/current/indexes-opclass.html
   *
   * https://www.postgresql.org/docs/current/xindex.html
   *
   * ### Additional types
   * If you have the `pg_vector` extension installed in your database, you can use the
   * `vector_l2_ops`, `vector_ip_ops`, `vector_cosine_ops`, `vector_l1_ops`, `bit_hamming_ops`, `bit_jaccard_ops`, `halfvec_l2_ops`, `sparsevec_l2_ops` options, which are predefined types.
   *
   * **You can always specify any string you want in the operator class, in case Drizzle doesn't have it natively in its types**
   *
   * @param opClass
   * @returns
   */
  op(opClass) {
    this.indexConfig.opClass = opClass;
    return this;
  }
}
class IndexedColumn {
  static [import_entity.entityKind] = "IndexedColumn";
  constructor(name, keyAsName, type, indexConfig) {
    this.name = name;
    this.keyAsName = keyAsName;
    this.type = type;
    this.indexConfig = indexConfig;
  }
  name;
  keyAsName;
  type;
  indexConfig;
}
class PgArrayBuilder extends PgColumnBuilder {
  static [import_entity.entityKind] = "PgArrayBuilder";
  constructor(name, baseBuilder, size) {
    super(name, "array", "PgArray");
    this.config.baseBuilder = baseBuilder;
    this.config.size = size;
  }
  /** @internal */
  build(table) {
    const baseColumn = this.config.baseBuilder.build(table);
    return new PgArray(
      table,
      this.config,
      baseColumn
    );
  }
}
class PgArray extends PgColumn {
  constructor(table, config, baseColumn, range) {
    super(table, config);
    this.baseColumn = baseColumn;
    this.range = range;
    this.size = config.size;
  }
  size;
  static [import_entity.entityKind] = "PgArray";
  getSQLType() {
    return `${this.baseColumn.getSQLType()}[${typeof this.size === "number" ? this.size : ""}]`;
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") {
      value = (0, import_array.parsePgArray)(value);
    }
    return value.map((v) => this.baseColumn.mapFromDriverValue(v));
  }
  mapToDriverValue(value, isNestedArray = false) {
    const a = value.map(
      (v) => v === null ? null : (0, import_entity.is)(this.baseColumn, PgArray) ? this.baseColumn.mapToDriverValue(v, true) : this.baseColumn.mapToDriverValue(v)
    );
    if (isNestedArray) return a;
    return (0, import_array.makePgArray)(a);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ExtraConfigColumn,
  IndexedColumn,
  PgArray,
  PgArrayBuilder,
  PgColumn,
  PgColumnBuilder
});
//# sourceMappingURL=common.cjs.map
},
"drizzle-orm/pg-core/utils/array.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var array_exports = {};
__export(array_exports, {
  makePgArray: () => makePgArray,
  parsePgArray: () => parsePgArray,
  parsePgNestedArray: () => parsePgNestedArray
});
module.exports = __toCommonJS(array_exports);
function parsePgArrayValue(arrayString, startFrom, inQuotes) {
  for (let i = startFrom; i < arrayString.length; i++) {
    const char = arrayString[i];
    if (char === "\\") {
      i++;
      continue;
    }
    if (char === '"') {
      return [arrayString.slice(startFrom, i).replace(/\\/g, ""), i + 1];
    }
    if (inQuotes) {
      continue;
    }
    if (char === "," || char === "}") {
      return [arrayString.slice(startFrom, i).replace(/\\/g, ""), i];
    }
  }
  return [arrayString.slice(startFrom).replace(/\\/g, ""), arrayString.length];
}
function parsePgNestedArray(arrayString, startFrom = 0) {
  const result = [];
  let i = startFrom;
  let lastCharIsComma = false;
  while (i < arrayString.length) {
    const char = arrayString[i];
    if (char === ",") {
      if (lastCharIsComma || i === startFrom) {
        result.push("");
      }
      lastCharIsComma = true;
      i++;
      continue;
    }
    lastCharIsComma = false;
    if (char === "\\") {
      i += 2;
      continue;
    }
    if (char === '"') {
      const [value2, startFrom2] = parsePgArrayValue(arrayString, i + 1, true);
      result.push(value2);
      i = startFrom2;
      continue;
    }
    if (char === "}") {
      return [result, i + 1];
    }
    if (char === "{") {
      const [value2, startFrom2] = parsePgNestedArray(arrayString, i + 1);
      result.push(value2);
      i = startFrom2;
      continue;
    }
    const [value, newStartFrom] = parsePgArrayValue(arrayString, i, false);
    result.push(value);
    i = newStartFrom;
  }
  return [result, i];
}
function parsePgArray(arrayString) {
  const [result] = parsePgNestedArray(arrayString, 1);
  return result;
}
function makePgArray(array) {
  return `{${array.map((item) => {
    if (Array.isArray(item)) {
      return makePgArray(item);
    }
    if (typeof item === "string") {
      return `"${item.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
    }
    return `${item}`;
  }).join(",")}}`;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  makePgArray,
  parsePgArray,
  parsePgNestedArray
});
//# sourceMappingURL=array.cjs.map
},
"drizzle-orm/pg-core/unique-constraint.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var unique_constraint_exports = {};
__export(unique_constraint_exports, {
  UniqueConstraint: () => UniqueConstraint,
  UniqueConstraintBuilder: () => UniqueConstraintBuilder,
  UniqueOnConstraintBuilder: () => UniqueOnConstraintBuilder,
  unique: () => unique,
  uniqueKeyName: () => uniqueKeyName
});
module.exports = __toCommonJS(unique_constraint_exports);
var import_entity = require("../entity.cjs");
var import_table_utils = require("../table.utils.cjs");
function unique(name) {
  return new UniqueOnConstraintBuilder(name);
}
function uniqueKeyName(table, columns) {
  return `${table[import_table_utils.TableName]}_${columns.join("_")}_unique`;
}
class UniqueConstraintBuilder {
  constructor(columns, name) {
    this.name = name;
    this.columns = columns;
  }
  static [import_entity.entityKind] = "PgUniqueConstraintBuilder";
  /** @internal */
  columns;
  /** @internal */
  nullsNotDistinctConfig = false;
  nullsNotDistinct() {
    this.nullsNotDistinctConfig = true;
    return this;
  }
  /** @internal */
  build(table) {
    return new UniqueConstraint(table, this.columns, this.nullsNotDistinctConfig, this.name);
  }
}
class UniqueOnConstraintBuilder {
  static [import_entity.entityKind] = "PgUniqueOnConstraintBuilder";
  /** @internal */
  name;
  constructor(name) {
    this.name = name;
  }
  on(...columns) {
    return new UniqueConstraintBuilder(columns, this.name);
  }
}
class UniqueConstraint {
  constructor(table, columns, nullsNotDistinct, name) {
    this.table = table;
    this.columns = columns;
    this.name = name ?? uniqueKeyName(this.table, this.columns.map((column) => column.name));
    this.nullsNotDistinct = nullsNotDistinct;
  }
  static [import_entity.entityKind] = "PgUniqueConstraint";
  columns;
  name;
  nullsNotDistinct = false;
  getName() {
    return this.name;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  UniqueConstraint,
  UniqueConstraintBuilder,
  UniqueOnConstraintBuilder,
  unique,
  uniqueKeyName
});
//# sourceMappingURL=unique-constraint.cjs.map
},
"drizzle-orm/pg-core/foreign-keys.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var foreign_keys_exports = {};
__export(foreign_keys_exports, {
  ForeignKey: () => ForeignKey,
  ForeignKeyBuilder: () => ForeignKeyBuilder,
  foreignKey: () => foreignKey
});
module.exports = __toCommonJS(foreign_keys_exports);
var import_entity = require("../entity.cjs");
var import_table_utils = require("../table.utils.cjs");
class ForeignKeyBuilder {
  static [import_entity.entityKind] = "PgForeignKeyBuilder";
  /** @internal */
  reference;
  /** @internal */
  _onUpdate = "no action";
  /** @internal */
  _onDelete = "no action";
  constructor(config, actions) {
    this.reference = () => {
      const { name, columns, foreignColumns } = config();
      return { name, columns, foreignTable: foreignColumns[0].table, foreignColumns };
    };
    if (actions) {
      this._onUpdate = actions.onUpdate;
      this._onDelete = actions.onDelete;
    }
  }
  onUpdate(action) {
    this._onUpdate = action === void 0 ? "no action" : action;
    return this;
  }
  onDelete(action) {
    this._onDelete = action === void 0 ? "no action" : action;
    return this;
  }
  /** @internal */
  build(table) {
    return new ForeignKey(table, this);
  }
}
class ForeignKey {
  constructor(table, builder) {
    this.table = table;
    this.reference = builder.reference;
    this.onUpdate = builder._onUpdate;
    this.onDelete = builder._onDelete;
  }
  static [import_entity.entityKind] = "PgForeignKey";
  reference;
  onUpdate;
  onDelete;
  getName() {
    const { name, columns, foreignColumns } = this.reference();
    const columnNames = columns.map((column) => column.name);
    const foreignColumnNames = foreignColumns.map((column) => column.name);
    const chunks = [
      this.table[import_table_utils.TableName],
      ...columnNames,
      foreignColumns[0].table[import_table_utils.TableName],
      ...foreignColumnNames
    ];
    return name ?? `${chunks.join("_")}_fk`;
  }
}
function foreignKey(config) {
  function mappedConfig() {
    const { name, columns, foreignColumns } = config;
    return {
      name,
      columns,
      foreignColumns
    };
  }
  return new ForeignKeyBuilder(mappedConfig);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ForeignKey,
  ForeignKeyBuilder,
  foreignKey
});
//# sourceMappingURL=foreign-keys.cjs.map
},
"drizzle-orm/column-builder.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var column_builder_exports = {};
__export(column_builder_exports, {
  ColumnBuilder: () => ColumnBuilder
});
module.exports = __toCommonJS(column_builder_exports);
var import_entity = require("./entity.cjs");
class ColumnBuilder {
  static [import_entity.entityKind] = "ColumnBuilder";
  config;
  constructor(name, dataType, columnType) {
    this.config = {
      name,
      keyAsName: name === "",
      notNull: false,
      default: void 0,
      hasDefault: false,
      primaryKey: false,
      isUnique: false,
      uniqueName: void 0,
      uniqueType: void 0,
      dataType,
      columnType,
      generated: void 0
    };
  }
  /**
   * Changes the data type of the column. Commonly used with `json` columns. Also, useful for branded types.
   *
   * @example
   * ```ts
   * const users = pgTable('users', {
   * 	id: integer('id').$type<UserId>().primaryKey(),
   * 	details: json('details').$type<UserDetails>().notNull(),
   * });
   * ```
   */
  $type() {
    return this;
  }
  /**
   * Adds a `not null` clause to the column definition.
   *
   * Affects the `select` model of the table - columns *without* `not null` will be nullable on select.
   */
  notNull() {
    this.config.notNull = true;
    return this;
  }
  /**
   * Adds a `default <value>` clause to the column definition.
   *
   * Affects the `insert` model of the table - columns *with* `default` are optional on insert.
   *
   * If you need to set a dynamic default value, use {@link $defaultFn} instead.
   */
  default(value) {
    this.config.default = value;
    this.config.hasDefault = true;
    return this;
  }
  /**
   * Adds a dynamic default value to the column.
   * The function will be called when the row is inserted, and the returned value will be used as the column value.
   *
   * **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
   */
  $defaultFn(fn) {
    this.config.defaultFn = fn;
    this.config.hasDefault = true;
    return this;
  }
  /**
   * Alias for {@link $defaultFn}.
   */
  $default = this.$defaultFn;
  /**
   * Adds a dynamic update value to the column.
   * The function will be called when the row is updated, and the returned value will be used as the column value if none is provided.
   * If no `default` (or `$defaultFn`) value is provided, the function will be called when the row is inserted as well, and the returned value will be used as the column value.
   *
   * **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
   */
  $onUpdateFn(fn) {
    this.config.onUpdateFn = fn;
    this.config.hasDefault = true;
    return this;
  }
  /**
   * Alias for {@link $onUpdateFn}.
   */
  $onUpdate = this.$onUpdateFn;
  /**
   * Adds a `primary key` clause to the column definition. This implicitly makes the column `not null`.
   *
   * In SQLite, `integer primary key` implicitly makes the column auto-incrementing.
   */
  primaryKey() {
    this.config.primaryKey = true;
    this.config.notNull = true;
    return this;
  }
  /** @internal Sets the name of the column to the key within the table definition if a name was not given. */
  setName(name) {
    if (this.config.name !== "") return;
    this.config.name = name;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ColumnBuilder
});
//# sourceMappingURL=column-builder.cjs.map
},
"drizzle-orm/pg-core/session.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var session_exports = {};
__export(session_exports, {
  PgPreparedQuery: () => PgPreparedQuery,
  PgSession: () => PgSession,
  PgTransaction: () => PgTransaction
});
module.exports = __toCommonJS(session_exports);
var import_cache = require("../cache/core/cache.cjs");
var import_entity = require("../entity.cjs");
var import_errors = require("../errors.cjs");
var import_sql = require("../sql/index.cjs");
var import_tracing = require("../tracing.cjs");
var import_db = require("./db.cjs");
class PgPreparedQuery {
  constructor(query, cache, queryMetadata, cacheConfig) {
    this.query = query;
    this.cache = cache;
    this.queryMetadata = queryMetadata;
    this.cacheConfig = cacheConfig;
    if (cache && cache.strategy() === "all" && cacheConfig === void 0) {
      this.cacheConfig = { enable: true, autoInvalidate: true };
    }
    if (!this.cacheConfig?.enable) {
      this.cacheConfig = void 0;
    }
  }
  authToken;
  getQuery() {
    return this.query;
  }
  mapResult(response, _isFromBatch) {
    return response;
  }
  /** @internal */
  setToken(token) {
    this.authToken = token;
    return this;
  }
  static [import_entity.entityKind] = "PgPreparedQuery";
  /** @internal */
  joinsNotNullableMap;
  /** @internal */
  async queryWithCache(queryString, params, query) {
    if (this.cache === void 0 || (0, import_entity.is)(this.cache, import_cache.NoopCache) || this.queryMetadata === void 0) {
      try {
        return await query();
      } catch (e) {
        throw new import_errors.DrizzleQueryError(queryString, params, e);
      }
    }
    if (this.cacheConfig && !this.cacheConfig.enable) {
      try {
        return await query();
      } catch (e) {
        throw new import_errors.DrizzleQueryError(queryString, params, e);
      }
    }
    if ((this.queryMetadata.type === "insert" || this.queryMetadata.type === "update" || this.queryMetadata.type === "delete") && this.queryMetadata.tables.length > 0) {
      try {
        const [res] = await Promise.all([
          query(),
          this.cache.onMutate({ tables: this.queryMetadata.tables })
        ]);
        return res;
      } catch (e) {
        throw new import_errors.DrizzleQueryError(queryString, params, e);
      }
    }
    if (!this.cacheConfig) {
      try {
        return await query();
      } catch (e) {
        throw new import_errors.DrizzleQueryError(queryString, params, e);
      }
    }
    if (this.queryMetadata.type === "select") {
      const fromCache = await this.cache.get(
        this.cacheConfig.tag ?? (await (0, import_cache.hashQuery)(queryString, params)),
        this.queryMetadata.tables,
        this.cacheConfig.tag !== void 0,
        this.cacheConfig.autoInvalidate
      );
      if (fromCache === void 0) {
        let result;
        try {
          result = await query();
        } catch (e) {
          throw new import_errors.DrizzleQueryError(queryString, params, e);
        }
        await this.cache.put(
          this.cacheConfig.tag ?? (await (0, import_cache.hashQuery)(queryString, params)),
          result,
          // make sure we send tables that were used in a query only if user wants to invalidate it on each write
          this.cacheConfig.autoInvalidate ? this.queryMetadata.tables : [],
          this.cacheConfig.tag !== void 0,
          this.cacheConfig.config
        );
        return result;
      }
      return fromCache;
    }
    try {
      return await query();
    } catch (e) {
      throw new import_errors.DrizzleQueryError(queryString, params, e);
    }
  }
}
class PgSession {
  constructor(dialect) {
    this.dialect = dialect;
  }
  static [import_entity.entityKind] = "PgSession";
  /** @internal */
  execute(query, token) {
    return import_tracing.tracer.startActiveSpan("drizzle.operation", () => {
      const prepared = import_tracing.tracer.startActiveSpan("drizzle.prepareQuery", () => {
        return this.prepareQuery(
          this.dialect.sqlToQuery(query),
          void 0,
          void 0,
          false
        );
      });
      return prepared.setToken(token).execute(void 0, token);
    });
  }
  all(query) {
    return this.prepareQuery(
      this.dialect.sqlToQuery(query),
      void 0,
      void 0,
      false
    ).all();
  }
  /** @internal */
  async count(sql2, token) {
    const res = await this.execute(sql2, token);
    return Number(
      res[0]["count"]
    );
  }
}
class PgTransaction extends import_db.PgDatabase {
  constructor(dialect, session, schema, nestedIndex = 0) {
    super(dialect, session, schema);
    this.schema = schema;
    this.nestedIndex = nestedIndex;
  }
  static [import_entity.entityKind] = "PgTransaction";
  rollback() {
    throw new import_errors.TransactionRollbackError();
  }
  /** @internal */
  getTransactionConfigSQL(config) {
    const chunks = [];
    if (config.isolationLevel) {
      chunks.push(`isolation level ${config.isolationLevel}`);
    }
    if (config.accessMode) {
      chunks.push(config.accessMode);
    }
    if (typeof config.deferrable === "boolean") {
      chunks.push(config.deferrable ? "deferrable" : "not deferrable");
    }
    return import_sql.sql.raw(chunks.join(" "));
  }
  setTransaction(config) {
    return this.session.execute(import_sql.sql`set transaction ${this.getTransactionConfigSQL(config)}`);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgPreparedQuery,
  PgSession,
  PgTransaction
});
//# sourceMappingURL=session.cjs.map
},
"drizzle-orm/pg-core/db.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var db_exports = {};
__export(db_exports, {
  PgDatabase: () => PgDatabase,
  withReplicas: () => withReplicas
});
module.exports = __toCommonJS(db_exports);
var import_entity = require("../entity.cjs");
var import_query_builders = require("./query-builders/index.cjs");
var import_selection_proxy = require("../selection-proxy.cjs");
var import_sql = require("../sql/sql.cjs");
var import_subquery = require("../subquery.cjs");
var import_count = require("./query-builders/count.cjs");
var import_query = require("./query-builders/query.cjs");
var import_raw = require("./query-builders/raw.cjs");
var import_refresh_materialized_view = require("./query-builders/refresh-materialized-view.cjs");
class PgDatabase {
  constructor(dialect, session, schema) {
    this.dialect = dialect;
    this.session = session;
    this._ = schema ? {
      schema: schema.schema,
      fullSchema: schema.fullSchema,
      tableNamesMap: schema.tableNamesMap,
      session
    } : {
      schema: void 0,
      fullSchema: {},
      tableNamesMap: {},
      session
    };
    this.query = {};
    if (this._.schema) {
      for (const [tableName, columns] of Object.entries(this._.schema)) {
        this.query[tableName] = new import_query.RelationalQueryBuilder(
          schema.fullSchema,
          this._.schema,
          this._.tableNamesMap,
          schema.fullSchema[tableName],
          columns,
          dialect,
          session
        );
      }
    }
    this.$cache = { invalidate: async (_params) => {
    } };
  }
  static [import_entity.entityKind] = "PgDatabase";
  query;
  /**
   * Creates a subquery that defines a temporary named result set as a CTE.
   *
   * It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
   *
   * @param alias The alias for the subquery.
   *
   * Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
   *
   * @example
   *
   * ```ts
   * // Create a subquery with alias 'sq' and use it in the select query
   * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
   *
   * const result = await db.with(sq).select().from(sq);
   * ```
   *
   * To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
   *
   * ```ts
   * // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
   * const sq = db.$with('sq').as(db.select({
   *   name: sql<string>`upper(${users.name})`.as('name'),
   * })
   * .from(users));
   *
   * const result = await db.with(sq).select({ name: sq.name }).from(sq);
   * ```
   */
  $with = (alias, selection) => {
    const self = this;
    const as = (qb) => {
      if (typeof qb === "function") {
        qb = qb(new import_query_builders.QueryBuilder(self.dialect));
      }
      return new Proxy(
        new import_subquery.WithSubquery(
          qb.getSQL(),
          selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}),
          alias,
          true
        ),
        new import_selection_proxy.SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
      );
    };
    return { as };
  };
  $count(source, filters) {
    return new import_count.PgCountBuilder({ source, filters, session: this.session });
  }
  $cache;
  /**
   * Incorporates a previously defined CTE (using `$with`) into the main query.
   *
   * This method allows the main query to reference a temporary named result set.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
   *
   * @param queries The CTEs to incorporate into the main query.
   *
   * @example
   *
   * ```ts
   * // Define a subquery 'sq' as a CTE using $with
   * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
   *
   * // Incorporate the CTE 'sq' into the main query and select from it
   * const result = await db.with(sq).select().from(sq);
   * ```
   */
  with(...queries) {
    const self = this;
    function select(fields) {
      return new import_query_builders.PgSelectBuilder({
        fields: fields ?? void 0,
        session: self.session,
        dialect: self.dialect,
        withList: queries
      });
    }
    function selectDistinct(fields) {
      return new import_query_builders.PgSelectBuilder({
        fields: fields ?? void 0,
        session: self.session,
        dialect: self.dialect,
        withList: queries,
        distinct: true
      });
    }
    function selectDistinctOn(on, fields) {
      return new import_query_builders.PgSelectBuilder({
        fields: fields ?? void 0,
        session: self.session,
        dialect: self.dialect,
        withList: queries,
        distinct: { on }
      });
    }
    function update(table) {
      return new import_query_builders.PgUpdateBuilder(table, self.session, self.dialect, queries);
    }
    function insert(table) {
      return new import_query_builders.PgInsertBuilder(table, self.session, self.dialect, queries);
    }
    function delete_(table) {
      return new import_query_builders.PgDeleteBase(table, self.session, self.dialect, queries);
    }
    return { select, selectDistinct, selectDistinctOn, update, insert, delete: delete_ };
  }
  select(fields) {
    return new import_query_builders.PgSelectBuilder({
      fields: fields ?? void 0,
      session: this.session,
      dialect: this.dialect
    });
  }
  selectDistinct(fields) {
    return new import_query_builders.PgSelectBuilder({
      fields: fields ?? void 0,
      session: this.session,
      dialect: this.dialect,
      distinct: true
    });
  }
  selectDistinctOn(on, fields) {
    return new import_query_builders.PgSelectBuilder({
      fields: fields ?? void 0,
      session: this.session,
      dialect: this.dialect,
      distinct: { on }
    });
  }
  /**
   * Creates an update query.
   *
   * Calling this method without `.where()` clause will update all rows in a table. The `.where()` clause specifies which rows should be updated.
   *
   * Use `.set()` method to specify which values to update.
   *
   * See docs: {@link https://orm.drizzle.team/docs/update}
   *
   * @param table The table to update.
   *
   * @example
   *
   * ```ts
   * // Update all rows in the 'cars' table
   * await db.update(cars).set({ color: 'red' });
   *
   * // Update rows with filters and conditions
   * await db.update(cars).set({ color: 'red' }).where(eq(cars.brand, 'BMW'));
   *
   * // Update with returning clause
   * const updatedCar: Car[] = await db.update(cars)
   *   .set({ color: 'red' })
   *   .where(eq(cars.id, 1))
   *   .returning();
   * ```
   */
  update(table) {
    return new import_query_builders.PgUpdateBuilder(table, this.session, this.dialect);
  }
  /**
   * Creates an insert query.
   *
   * Calling this method will create new rows in a table. Use `.values()` method to specify which values to insert.
   *
   * See docs: {@link https://orm.drizzle.team/docs/insert}
   *
   * @param table The table to insert into.
   *
   * @example
   *
   * ```ts
   * // Insert one row
   * await db.insert(cars).values({ brand: 'BMW' });
   *
   * // Insert multiple rows
   * await db.insert(cars).values([{ brand: 'BMW' }, { brand: 'Porsche' }]);
   *
   * // Insert with returning clause
   * const insertedCar: Car[] = await db.insert(cars)
   *   .values({ brand: 'BMW' })
   *   .returning();
   * ```
   */
  insert(table) {
    return new import_query_builders.PgInsertBuilder(table, this.session, this.dialect);
  }
  /**
   * Creates a delete query.
   *
   * Calling this method without `.where()` clause will delete all rows in a table. The `.where()` clause specifies which rows should be deleted.
   *
   * See docs: {@link https://orm.drizzle.team/docs/delete}
   *
   * @param table The table to delete from.
   *
   * @example
   *
   * ```ts
   * // Delete all rows in the 'cars' table
   * await db.delete(cars);
   *
   * // Delete rows with filters and conditions
   * await db.delete(cars).where(eq(cars.color, 'green'));
   *
   * // Delete with returning clause
   * const deletedCar: Car[] = await db.delete(cars)
   *   .where(eq(cars.id, 1))
   *   .returning();
   * ```
   */
  delete(table) {
    return new import_query_builders.PgDeleteBase(table, this.session, this.dialect);
  }
  refreshMaterializedView(view) {
    return new import_refresh_materialized_view.PgRefreshMaterializedView(view, this.session, this.dialect);
  }
  authToken;
  execute(query) {
    const sequel = typeof query === "string" ? import_sql.sql.raw(query) : query.getSQL();
    const builtQuery = this.dialect.sqlToQuery(sequel);
    const prepared = this.session.prepareQuery(
      builtQuery,
      void 0,
      void 0,
      false
    );
    return new import_raw.PgRaw(
      () => prepared.execute(void 0, this.authToken),
      sequel,
      builtQuery,
      (result) => prepared.mapResult(result, true)
    );
  }
  transaction(transaction, config) {
    return this.session.transaction(transaction, config);
  }
}
const withReplicas = (primary, replicas, getReplica = () => replicas[Math.floor(Math.random() * replicas.length)]) => {
  const select = (...args) => getReplica(replicas).select(...args);
  const selectDistinct = (...args) => getReplica(replicas).selectDistinct(...args);
  const selectDistinctOn = (...args) => getReplica(replicas).selectDistinctOn(...args);
  const $count = (...args) => getReplica(replicas).$count(...args);
  const _with = (...args) => getReplica(replicas).with(...args);
  const $with = (arg) => getReplica(replicas).$with(arg);
  const update = (...args) => primary.update(...args);
  const insert = (...args) => primary.insert(...args);
  const $delete = (...args) => primary.delete(...args);
  const execute = (...args) => primary.execute(...args);
  const transaction = (...args) => primary.transaction(...args);
  const refreshMaterializedView = (...args) => primary.refreshMaterializedView(...args);
  return {
    ...primary,
    update,
    insert,
    delete: $delete,
    execute,
    transaction,
    refreshMaterializedView,
    $primary: primary,
    $replicas: replicas,
    select,
    selectDistinct,
    selectDistinctOn,
    $count,
    $with,
    with: _with,
    get query() {
      return getReplica(replicas).query;
    }
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgDatabase,
  withReplicas
});
//# sourceMappingURL=db.cjs.map
},
"drizzle-orm/pg-core/query-builders/refresh-materialized-view.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var refresh_materialized_view_exports = {};
__export(refresh_materialized_view_exports, {
  PgRefreshMaterializedView: () => PgRefreshMaterializedView
});
module.exports = __toCommonJS(refresh_materialized_view_exports);
var import_entity = require("../../entity.cjs");
var import_query_promise = require("../../query-promise.cjs");
var import_tracing = require("../../tracing.cjs");
class PgRefreshMaterializedView extends import_query_promise.QueryPromise {
  constructor(view, session, dialect) {
    super();
    this.session = session;
    this.dialect = dialect;
    this.config = { view };
  }
  static [import_entity.entityKind] = "PgRefreshMaterializedView";
  config;
  concurrently() {
    if (this.config.withNoData !== void 0) {
      throw new Error("Cannot use concurrently and withNoData together");
    }
    this.config.concurrently = true;
    return this;
  }
  withNoData() {
    if (this.config.concurrently !== void 0) {
      throw new Error("Cannot use concurrently and withNoData together");
    }
    this.config.withNoData = true;
    return this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildRefreshMaterializedViewQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  /** @internal */
  _prepare(name) {
    return import_tracing.tracer.startActiveSpan("drizzle.prepareQuery", () => {
      return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), void 0, name, true);
    });
  }
  prepare(name) {
    return this._prepare(name);
  }
  authToken;
  /** @internal */
  setToken(token) {
    this.authToken = token;
    return this;
  }
  execute = (placeholderValues) => {
    return import_tracing.tracer.startActiveSpan("drizzle.operation", () => {
      return this._prepare().execute(placeholderValues, this.authToken);
    });
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgRefreshMaterializedView
});
//# sourceMappingURL=refresh-materialized-view.cjs.map
},
"drizzle-orm/query-promise.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var query_promise_exports = {};
__export(query_promise_exports, {
  QueryPromise: () => QueryPromise
});
module.exports = __toCommonJS(query_promise_exports);
var import_entity = require("./entity.cjs");
class QueryPromise {
  static [import_entity.entityKind] = "QueryPromise";
  [Symbol.toStringTag] = "QueryPromise";
  catch(onRejected) {
    return this.then(void 0, onRejected);
  }
  finally(onFinally) {
    return this.then(
      (value) => {
        onFinally?.();
        return value;
      },
      (reason) => {
        onFinally?.();
        throw reason;
      }
    );
  }
  then(onFulfilled, onRejected) {
    return this.execute().then(onFulfilled, onRejected);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  QueryPromise
});
//# sourceMappingURL=query-promise.cjs.map
},
"drizzle-orm/pg-core/query-builders/raw.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var raw_exports = {};
__export(raw_exports, {
  PgRaw: () => PgRaw
});
module.exports = __toCommonJS(raw_exports);
var import_entity = require("../../entity.cjs");
var import_query_promise = require("../../query-promise.cjs");
class PgRaw extends import_query_promise.QueryPromise {
  constructor(execute, sql, query, mapBatchResult) {
    super();
    this.execute = execute;
    this.sql = sql;
    this.query = query;
    this.mapBatchResult = mapBatchResult;
  }
  static [import_entity.entityKind] = "PgRaw";
  /** @internal */
  getSQL() {
    return this.sql;
  }
  getQuery() {
    return this.query;
  }
  mapResult(result, isFromBatch) {
    return isFromBatch ? this.mapBatchResult(result) : result;
  }
  _prepare() {
    return this;
  }
  /** @internal */
  isResponseInArrayMode() {
    return false;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgRaw
});
//# sourceMappingURL=raw.cjs.map
},
"drizzle-orm/pg-core/query-builders/query.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var query_exports = {};
__export(query_exports, {
  PgRelationalQuery: () => PgRelationalQuery,
  RelationalQueryBuilder: () => RelationalQueryBuilder
});
module.exports = __toCommonJS(query_exports);
var import_entity = require("../../entity.cjs");
var import_query_promise = require("../../query-promise.cjs");
var import_relations = require("../../relations.cjs");
var import_tracing = require("../../tracing.cjs");
class RelationalQueryBuilder {
  constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session) {
    this.fullSchema = fullSchema;
    this.schema = schema;
    this.tableNamesMap = tableNamesMap;
    this.table = table;
    this.tableConfig = tableConfig;
    this.dialect = dialect;
    this.session = session;
  }
  static [import_entity.entityKind] = "PgRelationalQueryBuilder";
  findMany(config) {
    return new PgRelationalQuery(
      this.fullSchema,
      this.schema,
      this.tableNamesMap,
      this.table,
      this.tableConfig,
      this.dialect,
      this.session,
      config ? config : {},
      "many"
    );
  }
  findFirst(config) {
    return new PgRelationalQuery(
      this.fullSchema,
      this.schema,
      this.tableNamesMap,
      this.table,
      this.tableConfig,
      this.dialect,
      this.session,
      config ? { ...config, limit: 1 } : { limit: 1 },
      "first"
    );
  }
}
class PgRelationalQuery extends import_query_promise.QueryPromise {
  constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session, config, mode) {
    super();
    this.fullSchema = fullSchema;
    this.schema = schema;
    this.tableNamesMap = tableNamesMap;
    this.table = table;
    this.tableConfig = tableConfig;
    this.dialect = dialect;
    this.session = session;
    this.config = config;
    this.mode = mode;
  }
  static [import_entity.entityKind] = "PgRelationalQuery";
  /** @internal */
  _prepare(name) {
    return import_tracing.tracer.startActiveSpan("drizzle.prepareQuery", () => {
      const { query, builtQuery } = this._toSQL();
      return this.session.prepareQuery(
        builtQuery,
        void 0,
        name,
        true,
        (rawRows, mapColumnValue) => {
          const rows = rawRows.map(
            (row) => (0, import_relations.mapRelationalRow)(this.schema, this.tableConfig, row, query.selection, mapColumnValue)
          );
          if (this.mode === "first") {
            return rows[0];
          }
          return rows;
        }
      );
    });
  }
  prepare(name) {
    return this._prepare(name);
  }
  _getQuery() {
    return this.dialect.buildRelationalQueryWithoutPK({
      fullSchema: this.fullSchema,
      schema: this.schema,
      tableNamesMap: this.tableNamesMap,
      table: this.table,
      tableConfig: this.tableConfig,
      queryConfig: this.config,
      tableAlias: this.tableConfig.tsName
    });
  }
  /** @internal */
  getSQL() {
    return this._getQuery().sql;
  }
  _toSQL() {
    const query = this._getQuery();
    const builtQuery = this.dialect.sqlToQuery(query.sql);
    return { query, builtQuery };
  }
  toSQL() {
    return this._toSQL().builtQuery;
  }
  authToken;
  /** @internal */
  setToken(token) {
    this.authToken = token;
    return this;
  }
  execute() {
    return import_tracing.tracer.startActiveSpan("drizzle.operation", () => {
      return this._prepare().execute(void 0, this.authToken);
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgRelationalQuery,
  RelationalQueryBuilder
});
//# sourceMappingURL=query.cjs.map
},
"drizzle-orm/relations.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc2) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc2 = __getOwnPropDesc(from, key)) || desc2.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var relations_exports = {};
__export(relations_exports, {
  Many: () => Many,
  One: () => One,
  Relation: () => Relation,
  Relations: () => Relations,
  createMany: () => createMany,
  createOne: () => createOne,
  createTableRelationsHelpers: () => createTableRelationsHelpers,
  extractTablesRelationalConfig: () => extractTablesRelationalConfig,
  getOperators: () => getOperators,
  getOrderByOperators: () => getOrderByOperators,
  mapRelationalRow: () => mapRelationalRow,
  normalizeRelation: () => normalizeRelation,
  relations: () => relations
});
module.exports = __toCommonJS(relations_exports);
var import_table = require("./table.cjs");
var import_column = require("./column.cjs");
var import_entity = require("./entity.cjs");
var import_primary_keys = require("./pg-core/primary-keys.cjs");
var import_expressions = require("./sql/expressions/index.cjs");
var import_sql = require("./sql/sql.cjs");
class Relation {
  constructor(sourceTable, referencedTable, relationName) {
    this.sourceTable = sourceTable;
    this.referencedTable = referencedTable;
    this.relationName = relationName;
    this.referencedTableName = referencedTable[import_table.Table.Symbol.Name];
  }
  static [import_entity.entityKind] = "Relation";
  referencedTableName;
  fieldName;
}
class Relations {
  constructor(table, config) {
    this.table = table;
    this.config = config;
  }
  static [import_entity.entityKind] = "Relations";
}
class One extends Relation {
  constructor(sourceTable, referencedTable, config, isNullable) {
    super(sourceTable, referencedTable, config?.relationName);
    this.config = config;
    this.isNullable = isNullable;
  }
  static [import_entity.entityKind] = "One";
  withFieldName(fieldName) {
    const relation = new One(
      this.sourceTable,
      this.referencedTable,
      this.config,
      this.isNullable
    );
    relation.fieldName = fieldName;
    return relation;
  }
}
class Many extends Relation {
  constructor(sourceTable, referencedTable, config) {
    super(sourceTable, referencedTable, config?.relationName);
    this.config = config;
  }
  static [import_entity.entityKind] = "Many";
  withFieldName(fieldName) {
    const relation = new Many(
      this.sourceTable,
      this.referencedTable,
      this.config
    );
    relation.fieldName = fieldName;
    return relation;
  }
}
function getOperators() {
  return {
    and: import_expressions.and,
    between: import_expressions.between,
    eq: import_expressions.eq,
    exists: import_expressions.exists,
    gt: import_expressions.gt,
    gte: import_expressions.gte,
    ilike: import_expressions.ilike,
    inArray: import_expressions.inArray,
    isNull: import_expressions.isNull,
    isNotNull: import_expressions.isNotNull,
    like: import_expressions.like,
    lt: import_expressions.lt,
    lte: import_expressions.lte,
    ne: import_expressions.ne,
    not: import_expressions.not,
    notBetween: import_expressions.notBetween,
    notExists: import_expressions.notExists,
    notLike: import_expressions.notLike,
    notIlike: import_expressions.notIlike,
    notInArray: import_expressions.notInArray,
    or: import_expressions.or,
    sql: import_sql.sql
  };
}
function getOrderByOperators() {
  return {
    sql: import_sql.sql,
    asc: import_expressions.asc,
    desc: import_expressions.desc
  };
}
function extractTablesRelationalConfig(schema, configHelpers) {
  if (Object.keys(schema).length === 1 && "default" in schema && !(0, import_entity.is)(schema["default"], import_table.Table)) {
    schema = schema["default"];
  }
  const tableNamesMap = {};
  const relationsBuffer = {};
  const tablesConfig = {};
  for (const [key, value] of Object.entries(schema)) {
    if ((0, import_entity.is)(value, import_table.Table)) {
      const dbName = (0, import_table.getTableUniqueName)(value);
      const bufferedRelations = relationsBuffer[dbName];
      tableNamesMap[dbName] = key;
      tablesConfig[key] = {
        tsName: key,
        dbName: value[import_table.Table.Symbol.Name],
        schema: value[import_table.Table.Symbol.Schema],
        columns: value[import_table.Table.Symbol.Columns],
        relations: bufferedRelations?.relations ?? {},
        primaryKey: bufferedRelations?.primaryKey ?? []
      };
      for (const column of Object.values(
        value[import_table.Table.Symbol.Columns]
      )) {
        if (column.primary) {
          tablesConfig[key].primaryKey.push(column);
        }
      }
      const extraConfig = value[import_table.Table.Symbol.ExtraConfigBuilder]?.(value[import_table.Table.Symbol.ExtraConfigColumns]);
      if (extraConfig) {
        for (const configEntry of Object.values(extraConfig)) {
          if ((0, import_entity.is)(configEntry, import_primary_keys.PrimaryKeyBuilder)) {
            tablesConfig[key].primaryKey.push(...configEntry.columns);
          }
        }
      }
    } else if ((0, import_entity.is)(value, Relations)) {
      const dbName = (0, import_table.getTableUniqueName)(value.table);
      const tableName = tableNamesMap[dbName];
      const relations2 = value.config(
        configHelpers(value.table)
      );
      let primaryKey;
      for (const [relationName, relation] of Object.entries(relations2)) {
        if (tableName) {
          const tableConfig = tablesConfig[tableName];
          tableConfig.relations[relationName] = relation;
          if (primaryKey) {
            tableConfig.primaryKey.push(...primaryKey);
          }
        } else {
          if (!(dbName in relationsBuffer)) {
            relationsBuffer[dbName] = {
              relations: {},
              primaryKey
            };
          }
          relationsBuffer[dbName].relations[relationName] = relation;
        }
      }
    }
  }
  return { tables: tablesConfig, tableNamesMap };
}
function relations(table, relations2) {
  return new Relations(
    table,
    (helpers) => Object.fromEntries(
      Object.entries(relations2(helpers)).map(([key, value]) => [
        key,
        value.withFieldName(key)
      ])
    )
  );
}
function createOne(sourceTable) {
  return function one(table, config) {
    return new One(
      sourceTable,
      table,
      config,
      config?.fields.reduce((res, f) => res && f.notNull, true) ?? false
    );
  };
}
function createMany(sourceTable) {
  return function many(referencedTable, config) {
    return new Many(sourceTable, referencedTable, config);
  };
}
function normalizeRelation(schema, tableNamesMap, relation) {
  if ((0, import_entity.is)(relation, One) && relation.config) {
    return {
      fields: relation.config.fields,
      references: relation.config.references
    };
  }
  const referencedTableTsName = tableNamesMap[(0, import_table.getTableUniqueName)(relation.referencedTable)];
  if (!referencedTableTsName) {
    throw new Error(
      `Table "${relation.referencedTable[import_table.Table.Symbol.Name]}" not found in schema`
    );
  }
  const referencedTableConfig = schema[referencedTableTsName];
  if (!referencedTableConfig) {
    throw new Error(`Table "${referencedTableTsName}" not found in schema`);
  }
  const sourceTable = relation.sourceTable;
  const sourceTableTsName = tableNamesMap[(0, import_table.getTableUniqueName)(sourceTable)];
  if (!sourceTableTsName) {
    throw new Error(
      `Table "${sourceTable[import_table.Table.Symbol.Name]}" not found in schema`
    );
  }
  const reverseRelations = [];
  for (const referencedTableRelation of Object.values(
    referencedTableConfig.relations
  )) {
    if (relation.relationName && relation !== referencedTableRelation && referencedTableRelation.relationName === relation.relationName || !relation.relationName && referencedTableRelation.referencedTable === relation.sourceTable) {
      reverseRelations.push(referencedTableRelation);
    }
  }
  if (reverseRelations.length > 1) {
    throw relation.relationName ? new Error(
      `There are multiple relations with name "${relation.relationName}" in table "${referencedTableTsName}"`
    ) : new Error(
      `There are multiple relations between "${referencedTableTsName}" and "${relation.sourceTable[import_table.Table.Symbol.Name]}". Please specify relation name`
    );
  }
  if (reverseRelations[0] && (0, import_entity.is)(reverseRelations[0], One) && reverseRelations[0].config) {
    return {
      fields: reverseRelations[0].config.references,
      references: reverseRelations[0].config.fields
    };
  }
  throw new Error(
    `There is not enough information to infer relation "${sourceTableTsName}.${relation.fieldName}"`
  );
}
function createTableRelationsHelpers(sourceTable) {
  return {
    one: createOne(sourceTable),
    many: createMany(sourceTable)
  };
}
function mapRelationalRow(tablesConfig, tableConfig, row, buildQueryResultSelection, mapColumnValue = (value) => value) {
  const result = {};
  for (const [
    selectionItemIndex,
    selectionItem
  ] of buildQueryResultSelection.entries()) {
    if (selectionItem.isJson) {
      const relation = tableConfig.relations[selectionItem.tsKey];
      const rawSubRows = row[selectionItemIndex];
      const subRows = typeof rawSubRows === "string" ? JSON.parse(rawSubRows) : rawSubRows;
      result[selectionItem.tsKey] = (0, import_entity.is)(relation, One) ? subRows && mapRelationalRow(
        tablesConfig,
        tablesConfig[selectionItem.relationTableTsKey],
        subRows,
        selectionItem.selection,
        mapColumnValue
      ) : subRows.map(
        (subRow) => mapRelationalRow(
          tablesConfig,
          tablesConfig[selectionItem.relationTableTsKey],
          subRow,
          selectionItem.selection,
          mapColumnValue
        )
      );
    } else {
      const value = mapColumnValue(row[selectionItemIndex]);
      const field = selectionItem.field;
      let decoder;
      if ((0, import_entity.is)(field, import_column.Column)) {
        decoder = field;
      } else if ((0, import_entity.is)(field, import_sql.SQL)) {
        decoder = field.decoder;
      } else {
        decoder = field.sql.decoder;
      }
      result[selectionItem.tsKey] = value === null ? null : decoder.mapFromDriverValue(value);
    }
  }
  return result;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Many,
  One,
  Relation,
  Relations,
  createMany,
  createOne,
  createTableRelationsHelpers,
  extractTablesRelationalConfig,
  getOperators,
  getOrderByOperators,
  mapRelationalRow,
  normalizeRelation,
  relations
});
//# sourceMappingURL=relations.cjs.map
},
"drizzle-orm/sql/expressions/index.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var expressions_exports = {};
module.exports = __toCommonJS(expressions_exports);
__reExport(expressions_exports, require("./conditions.cjs"), module.exports);
__reExport(expressions_exports, require("./select.cjs"), module.exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ...require("./conditions.cjs"),
  ...require("./select.cjs")
});
//# sourceMappingURL=index.cjs.map
},
"drizzle-orm/sql/expressions/select.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc2) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc2 = __getOwnPropDesc(from, key)) || desc2.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var select_exports = {};
__export(select_exports, {
  asc: () => asc,
  desc: () => desc
});
module.exports = __toCommonJS(select_exports);
var import_sql = require("../sql.cjs");
function asc(column) {
  return import_sql.sql`${column} asc`;
}
function desc(column) {
  return import_sql.sql`${column} desc`;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  asc,
  desc
});
//# sourceMappingURL=select.cjs.map
},
"drizzle-orm/sql/expressions/conditions.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var conditions_exports = {};
__export(conditions_exports, {
  and: () => and,
  arrayContained: () => arrayContained,
  arrayContains: () => arrayContains,
  arrayOverlaps: () => arrayOverlaps,
  between: () => between,
  bindIfParam: () => bindIfParam,
  eq: () => eq,
  exists: () => exists,
  gt: () => gt,
  gte: () => gte,
  ilike: () => ilike,
  inArray: () => inArray,
  isNotNull: () => isNotNull,
  isNull: () => isNull,
  like: () => like,
  lt: () => lt,
  lte: () => lte,
  ne: () => ne,
  not: () => not,
  notBetween: () => notBetween,
  notExists: () => notExists,
  notIlike: () => notIlike,
  notInArray: () => notInArray,
  notLike: () => notLike,
  or: () => or
});
module.exports = __toCommonJS(conditions_exports);
var import_column = require("../../column.cjs");
var import_entity = require("../../entity.cjs");
var import_table = require("../../table.cjs");
var import_sql = require("../sql.cjs");
function bindIfParam(value, column) {
  if ((0, import_sql.isDriverValueEncoder)(column) && !(0, import_sql.isSQLWrapper)(value) && !(0, import_entity.is)(value, import_sql.Param) && !(0, import_entity.is)(value, import_sql.Placeholder) && !(0, import_entity.is)(value, import_column.Column) && !(0, import_entity.is)(value, import_table.Table) && !(0, import_entity.is)(value, import_sql.View)) {
    return new import_sql.Param(value, column);
  }
  return value;
}
const eq = (left, right) => {
  return import_sql.sql`${left} = ${bindIfParam(right, left)}`;
};
const ne = (left, right) => {
  return import_sql.sql`${left} <> ${bindIfParam(right, left)}`;
};
function and(...unfilteredConditions) {
  const conditions = unfilteredConditions.filter(
    (c) => c !== void 0
  );
  if (conditions.length === 0) {
    return void 0;
  }
  if (conditions.length === 1) {
    return new import_sql.SQL(conditions);
  }
  return new import_sql.SQL([
    new import_sql.StringChunk("("),
    import_sql.sql.join(conditions, new import_sql.StringChunk(" and ")),
    new import_sql.StringChunk(")")
  ]);
}
function or(...unfilteredConditions) {
  const conditions = unfilteredConditions.filter(
    (c) => c !== void 0
  );
  if (conditions.length === 0) {
    return void 0;
  }
  if (conditions.length === 1) {
    return new import_sql.SQL(conditions);
  }
  return new import_sql.SQL([
    new import_sql.StringChunk("("),
    import_sql.sql.join(conditions, new import_sql.StringChunk(" or ")),
    new import_sql.StringChunk(")")
  ]);
}
function not(condition) {
  return import_sql.sql`not ${condition}`;
}
const gt = (left, right) => {
  return import_sql.sql`${left} > ${bindIfParam(right, left)}`;
};
const gte = (left, right) => {
  return import_sql.sql`${left} >= ${bindIfParam(right, left)}`;
};
const lt = (left, right) => {
  return import_sql.sql`${left} < ${bindIfParam(right, left)}`;
};
const lte = (left, right) => {
  return import_sql.sql`${left} <= ${bindIfParam(right, left)}`;
};
function inArray(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      return import_sql.sql`false`;
    }
    return import_sql.sql`${column} in ${values.map((v) => bindIfParam(v, column))}`;
  }
  return import_sql.sql`${column} in ${bindIfParam(values, column)}`;
}
function notInArray(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      return import_sql.sql`true`;
    }
    return import_sql.sql`${column} not in ${values.map((v) => bindIfParam(v, column))}`;
  }
  return import_sql.sql`${column} not in ${bindIfParam(values, column)}`;
}
function isNull(value) {
  return import_sql.sql`${value} is null`;
}
function isNotNull(value) {
  return import_sql.sql`${value} is not null`;
}
function exists(subquery) {
  return import_sql.sql`exists ${subquery}`;
}
function notExists(subquery) {
  return import_sql.sql`not exists ${subquery}`;
}
function between(column, min, max) {
  return import_sql.sql`${column} between ${bindIfParam(min, column)} and ${bindIfParam(
    max,
    column
  )}`;
}
function notBetween(column, min, max) {
  return import_sql.sql`${column} not between ${bindIfParam(
    min,
    column
  )} and ${bindIfParam(max, column)}`;
}
function like(column, value) {
  return import_sql.sql`${column} like ${value}`;
}
function notLike(column, value) {
  return import_sql.sql`${column} not like ${value}`;
}
function ilike(column, value) {
  return import_sql.sql`${column} ilike ${value}`;
}
function notIlike(column, value) {
  return import_sql.sql`${column} not ilike ${value}`;
}
function arrayContains(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      throw new Error("arrayContains requires at least one value");
    }
    const array = import_sql.sql`${bindIfParam(values, column)}`;
    return import_sql.sql`${column} @> ${array}`;
  }
  return import_sql.sql`${column} @> ${bindIfParam(values, column)}`;
}
function arrayContained(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      throw new Error("arrayContained requires at least one value");
    }
    const array = import_sql.sql`${bindIfParam(values, column)}`;
    return import_sql.sql`${column} <@ ${array}`;
  }
  return import_sql.sql`${column} <@ ${bindIfParam(values, column)}`;
}
function arrayOverlaps(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      throw new Error("arrayOverlaps requires at least one value");
    }
    const array = import_sql.sql`${bindIfParam(values, column)}`;
    return import_sql.sql`${column} && ${array}`;
  }
  return import_sql.sql`${column} && ${bindIfParam(values, column)}`;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  and,
  arrayContained,
  arrayContains,
  arrayOverlaps,
  between,
  bindIfParam,
  eq,
  exists,
  gt,
  gte,
  ilike,
  inArray,
  isNotNull,
  isNull,
  like,
  lt,
  lte,
  ne,
  not,
  notBetween,
  notExists,
  notIlike,
  notInArray,
  notLike,
  or
});
//# sourceMappingURL=conditions.cjs.map
},
"drizzle-orm/pg-core/primary-keys.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var primary_keys_exports = {};
__export(primary_keys_exports, {
  PrimaryKey: () => PrimaryKey,
  PrimaryKeyBuilder: () => PrimaryKeyBuilder,
  primaryKey: () => primaryKey
});
module.exports = __toCommonJS(primary_keys_exports);
var import_entity = require("../entity.cjs");
var import_table = require("./table.cjs");
function primaryKey(...config) {
  if (config[0].columns) {
    return new PrimaryKeyBuilder(config[0].columns, config[0].name);
  }
  return new PrimaryKeyBuilder(config);
}
class PrimaryKeyBuilder {
  static [import_entity.entityKind] = "PgPrimaryKeyBuilder";
  /** @internal */
  columns;
  /** @internal */
  name;
  constructor(columns, name) {
    this.columns = columns;
    this.name = name;
  }
  /** @internal */
  build(table) {
    return new PrimaryKey(table, this.columns, this.name);
  }
}
class PrimaryKey {
  constructor(table, columns, name) {
    this.table = table;
    this.columns = columns;
    this.name = name;
  }
  static [import_entity.entityKind] = "PgPrimaryKey";
  columns;
  name;
  getName() {
    return this.name ?? `${this.table[import_table.PgTable.Symbol.Name]}_${this.columns.map((column) => column.name).join("_")}_pk`;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PrimaryKey,
  PrimaryKeyBuilder,
  primaryKey
});
//# sourceMappingURL=primary-keys.cjs.map
},
"drizzle-orm/pg-core/table.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var table_exports = {};
__export(table_exports, {
  EnableRLS: () => EnableRLS,
  InlineForeignKeys: () => InlineForeignKeys,
  PgTable: () => PgTable,
  pgTable: () => pgTable,
  pgTableCreator: () => pgTableCreator,
  pgTableWithSchema: () => pgTableWithSchema
});
module.exports = __toCommonJS(table_exports);
var import_entity = require("../entity.cjs");
var import_table = require("../table.cjs");
var import_all = require("./columns/all.cjs");
const InlineForeignKeys = Symbol.for("drizzle:PgInlineForeignKeys");
const EnableRLS = Symbol.for("drizzle:EnableRLS");
class PgTable extends import_table.Table {
  static [import_entity.entityKind] = "PgTable";
  /** @internal */
  static Symbol = Object.assign({}, import_table.Table.Symbol, {
    InlineForeignKeys,
    EnableRLS
  });
  /**@internal */
  [InlineForeignKeys] = [];
  /** @internal */
  [EnableRLS] = false;
  /** @internal */
  [import_table.Table.Symbol.ExtraConfigBuilder] = void 0;
  /** @internal */
  [import_table.Table.Symbol.ExtraConfigColumns] = {};
}
function pgTableWithSchema(name, columns, extraConfig, schema, baseName = name) {
  const rawTable = new PgTable(name, schema, baseName);
  const parsedColumns = typeof columns === "function" ? columns((0, import_all.getPgColumnBuilders)()) : columns;
  const builtColumns = Object.fromEntries(
    Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
      const colBuilder = colBuilderBase;
      colBuilder.setName(name2);
      const column = colBuilder.build(rawTable);
      rawTable[InlineForeignKeys].push(...colBuilder.buildForeignKeys(column, rawTable));
      return [name2, column];
    })
  );
  const builtColumnsForExtraConfig = Object.fromEntries(
    Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
      const colBuilder = colBuilderBase;
      colBuilder.setName(name2);
      const column = colBuilder.buildExtraConfigColumn(rawTable);
      return [name2, column];
    })
  );
  const table = Object.assign(rawTable, builtColumns);
  table[import_table.Table.Symbol.Columns] = builtColumns;
  table[import_table.Table.Symbol.ExtraConfigColumns] = builtColumnsForExtraConfig;
  if (extraConfig) {
    table[PgTable.Symbol.ExtraConfigBuilder] = extraConfig;
  }
  return Object.assign(table, {
    enableRLS: () => {
      table[PgTable.Symbol.EnableRLS] = true;
      return table;
    }
  });
}
const pgTable = (name, columns, extraConfig) => {
  return pgTableWithSchema(name, columns, extraConfig, void 0);
};
function pgTableCreator(customizeTableName) {
  return (name, columns, extraConfig) => {
    return pgTableWithSchema(customizeTableName(name), columns, extraConfig, void 0, name);
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  EnableRLS,
  InlineForeignKeys,
  PgTable,
  pgTable,
  pgTableCreator,
  pgTableWithSchema
});
//# sourceMappingURL=table.cjs.map
},
"drizzle-orm/pg-core/columns/all.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var all_exports = {};
__export(all_exports, {
  getPgColumnBuilders: () => getPgColumnBuilders
});
module.exports = __toCommonJS(all_exports);
var import_bigint = require("./bigint.cjs");
var import_bigserial = require("./bigserial.cjs");
var import_boolean = require("./boolean.cjs");
var import_char = require("./char.cjs");
var import_cidr = require("./cidr.cjs");
var import_custom = require("./custom.cjs");
var import_date = require("./date.cjs");
var import_double_precision = require("./double-precision.cjs");
var import_inet = require("./inet.cjs");
var import_integer = require("./integer.cjs");
var import_interval = require("./interval.cjs");
var import_json = require("./json.cjs");
var import_jsonb = require("./jsonb.cjs");
var import_line = require("./line.cjs");
var import_macaddr = require("./macaddr.cjs");
var import_macaddr8 = require("./macaddr8.cjs");
var import_numeric = require("./numeric.cjs");
var import_point = require("./point.cjs");
var import_geometry = require("./postgis_extension/geometry.cjs");
var import_real = require("./real.cjs");
var import_serial = require("./serial.cjs");
var import_smallint = require("./smallint.cjs");
var import_smallserial = require("./smallserial.cjs");
var import_text = require("./text.cjs");
var import_time = require("./time.cjs");
var import_timestamp = require("./timestamp.cjs");
var import_uuid = require("./uuid.cjs");
var import_varchar = require("./varchar.cjs");
var import_bit = require("./vector_extension/bit.cjs");
var import_halfvec = require("./vector_extension/halfvec.cjs");
var import_sparsevec = require("./vector_extension/sparsevec.cjs");
var import_vector = require("./vector_extension/vector.cjs");
function getPgColumnBuilders() {
  return {
    bigint: import_bigint.bigint,
    bigserial: import_bigserial.bigserial,
    boolean: import_boolean.boolean,
    char: import_char.char,
    cidr: import_cidr.cidr,
    customType: import_custom.customType,
    date: import_date.date,
    doublePrecision: import_double_precision.doublePrecision,
    inet: import_inet.inet,
    integer: import_integer.integer,
    interval: import_interval.interval,
    json: import_json.json,
    jsonb: import_jsonb.jsonb,
    line: import_line.line,
    macaddr: import_macaddr.macaddr,
    macaddr8: import_macaddr8.macaddr8,
    numeric: import_numeric.numeric,
    point: import_point.point,
    geometry: import_geometry.geometry,
    real: import_real.real,
    serial: import_serial.serial,
    smallint: import_smallint.smallint,
    smallserial: import_smallserial.smallserial,
    text: import_text.text,
    time: import_time.time,
    timestamp: import_timestamp.timestamp,
    uuid: import_uuid.uuid,
    varchar: import_varchar.varchar,
    bit: import_bit.bit,
    halfvec: import_halfvec.halfvec,
    sparsevec: import_sparsevec.sparsevec,
    vector: import_vector.vector
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getPgColumnBuilders
});
//# sourceMappingURL=all.cjs.map
},
"drizzle-orm/pg-core/columns/vector_extension/vector.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var vector_exports = {};
__export(vector_exports, {
  PgVector: () => PgVector,
  PgVectorBuilder: () => PgVectorBuilder,
  vector: () => vector
});
module.exports = __toCommonJS(vector_exports);
var import_entity = require("../../../entity.cjs");
var import_utils = require("../../../utils.cjs");
var import_common = require("../common.cjs");
class PgVectorBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgVectorBuilder";
  constructor(name, config) {
    super(name, "array", "PgVector");
    this.config.dimensions = config.dimensions;
  }
  /** @internal */
  build(table) {
    return new PgVector(
      table,
      this.config
    );
  }
}
class PgVector extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgVector";
  dimensions = this.config.dimensions;
  getSQLType() {
    return `vector(${this.dimensions})`;
  }
  mapToDriverValue(value) {
    return JSON.stringify(value);
  }
  mapFromDriverValue(value) {
    return value.slice(1, -1).split(",").map((v) => Number.parseFloat(v));
  }
}
function vector(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  return new PgVectorBuilder(name, config);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgVector,
  PgVectorBuilder,
  vector
});
//# sourceMappingURL=vector.cjs.map
},
"drizzle-orm/pg-core/columns/vector_extension/sparsevec.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var sparsevec_exports = {};
__export(sparsevec_exports, {
  PgSparseVector: () => PgSparseVector,
  PgSparseVectorBuilder: () => PgSparseVectorBuilder,
  sparsevec: () => sparsevec
});
module.exports = __toCommonJS(sparsevec_exports);
var import_entity = require("../../../entity.cjs");
var import_utils = require("../../../utils.cjs");
var import_common = require("../common.cjs");
class PgSparseVectorBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgSparseVectorBuilder";
  constructor(name, config) {
    super(name, "string", "PgSparseVector");
    this.config.dimensions = config.dimensions;
  }
  /** @internal */
  build(table) {
    return new PgSparseVector(
      table,
      this.config
    );
  }
}
class PgSparseVector extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgSparseVector";
  dimensions = this.config.dimensions;
  getSQLType() {
    return `sparsevec(${this.dimensions})`;
  }
}
function sparsevec(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  return new PgSparseVectorBuilder(name, config);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgSparseVector,
  PgSparseVectorBuilder,
  sparsevec
});
//# sourceMappingURL=sparsevec.cjs.map
},
"drizzle-orm/pg-core/columns/vector_extension/halfvec.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var halfvec_exports = {};
__export(halfvec_exports, {
  PgHalfVector: () => PgHalfVector,
  PgHalfVectorBuilder: () => PgHalfVectorBuilder,
  halfvec: () => halfvec
});
module.exports = __toCommonJS(halfvec_exports);
var import_entity = require("../../../entity.cjs");
var import_utils = require("../../../utils.cjs");
var import_common = require("../common.cjs");
class PgHalfVectorBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgHalfVectorBuilder";
  constructor(name, config) {
    super(name, "array", "PgHalfVector");
    this.config.dimensions = config.dimensions;
  }
  /** @internal */
  build(table) {
    return new PgHalfVector(
      table,
      this.config
    );
  }
}
class PgHalfVector extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgHalfVector";
  dimensions = this.config.dimensions;
  getSQLType() {
    return `halfvec(${this.dimensions})`;
  }
  mapToDriverValue(value) {
    return JSON.stringify(value);
  }
  mapFromDriverValue(value) {
    return value.slice(1, -1).split(",").map((v) => Number.parseFloat(v));
  }
}
function halfvec(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  return new PgHalfVectorBuilder(name, config);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgHalfVector,
  PgHalfVectorBuilder,
  halfvec
});
//# sourceMappingURL=halfvec.cjs.map
},
"drizzle-orm/pg-core/columns/vector_extension/bit.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bit_exports = {};
__export(bit_exports, {
  PgBinaryVector: () => PgBinaryVector,
  PgBinaryVectorBuilder: () => PgBinaryVectorBuilder,
  bit: () => bit
});
module.exports = __toCommonJS(bit_exports);
var import_entity = require("../../../entity.cjs");
var import_utils = require("../../../utils.cjs");
var import_common = require("../common.cjs");
class PgBinaryVectorBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgBinaryVectorBuilder";
  constructor(name, config) {
    super(name, "string", "PgBinaryVector");
    this.config.dimensions = config.dimensions;
  }
  /** @internal */
  build(table) {
    return new PgBinaryVector(
      table,
      this.config
    );
  }
}
class PgBinaryVector extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgBinaryVector";
  dimensions = this.config.dimensions;
  getSQLType() {
    return `bit(${this.dimensions})`;
  }
}
function bit(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  return new PgBinaryVectorBuilder(name, config);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgBinaryVector,
  PgBinaryVectorBuilder,
  bit
});
//# sourceMappingURL=bit.cjs.map
},
"drizzle-orm/pg-core/columns/varchar.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var varchar_exports = {};
__export(varchar_exports, {
  PgVarchar: () => PgVarchar,
  PgVarcharBuilder: () => PgVarcharBuilder,
  varchar: () => varchar
});
module.exports = __toCommonJS(varchar_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
class PgVarcharBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgVarcharBuilder";
  constructor(name, config) {
    super(name, "string", "PgVarchar");
    this.config.length = config.length;
    this.config.enumValues = config.enum;
  }
  /** @internal */
  build(table) {
    return new PgVarchar(
      table,
      this.config
    );
  }
}
class PgVarchar extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgVarchar";
  length = this.config.length;
  enumValues = this.config.enumValues;
  getSQLType() {
    return this.length === void 0 ? `varchar` : `varchar(${this.length})`;
  }
}
function varchar(a, b = {}) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  return new PgVarcharBuilder(name, config);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgVarchar,
  PgVarcharBuilder,
  varchar
});
//# sourceMappingURL=varchar.cjs.map
},
"drizzle-orm/pg-core/columns/uuid.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var uuid_exports = {};
__export(uuid_exports, {
  PgUUID: () => PgUUID,
  PgUUIDBuilder: () => PgUUIDBuilder,
  uuid: () => uuid
});
module.exports = __toCommonJS(uuid_exports);
var import_entity = require("../../entity.cjs");
var import_sql = require("../../sql/sql.cjs");
var import_common = require("./common.cjs");
class PgUUIDBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgUUIDBuilder";
  constructor(name) {
    super(name, "string", "PgUUID");
  }
  /**
   * Adds `default gen_random_uuid()` to the column definition.
   */
  defaultRandom() {
    return this.default(import_sql.sql`gen_random_uuid()`);
  }
  /** @internal */
  build(table) {
    return new PgUUID(table, this.config);
  }
}
class PgUUID extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgUUID";
  getSQLType() {
    return "uuid";
  }
}
function uuid(name) {
  return new PgUUIDBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgUUID,
  PgUUIDBuilder,
  uuid
});
//# sourceMappingURL=uuid.cjs.map
},
"drizzle-orm/pg-core/columns/timestamp.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var timestamp_exports = {};
__export(timestamp_exports, {
  PgTimestamp: () => PgTimestamp,
  PgTimestampBuilder: () => PgTimestampBuilder,
  PgTimestampString: () => PgTimestampString,
  PgTimestampStringBuilder: () => PgTimestampStringBuilder,
  timestamp: () => timestamp
});
module.exports = __toCommonJS(timestamp_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
var import_date_common = require("./date.common.cjs");
class PgTimestampBuilder extends import_date_common.PgDateColumnBaseBuilder {
  static [import_entity.entityKind] = "PgTimestampBuilder";
  constructor(name, withTimezone, precision) {
    super(name, "date", "PgTimestamp");
    this.config.withTimezone = withTimezone;
    this.config.precision = precision;
  }
  /** @internal */
  build(table) {
    return new PgTimestamp(table, this.config);
  }
}
class PgTimestamp extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgTimestamp";
  withTimezone;
  precision;
  constructor(table, config) {
    super(table, config);
    this.withTimezone = config.withTimezone;
    this.precision = config.precision;
  }
  getSQLType() {
    const precision = this.precision === void 0 ? "" : ` (${this.precision})`;
    return `timestamp${precision}${this.withTimezone ? " with time zone" : ""}`;
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") return new Date(this.withTimezone ? value : value + "+0000");
    return value;
  }
  mapToDriverValue = (value) => {
    return value.toISOString();
  };
}
class PgTimestampStringBuilder extends import_date_common.PgDateColumnBaseBuilder {
  static [import_entity.entityKind] = "PgTimestampStringBuilder";
  constructor(name, withTimezone, precision) {
    super(name, "string", "PgTimestampString");
    this.config.withTimezone = withTimezone;
    this.config.precision = precision;
  }
  /** @internal */
  build(table) {
    return new PgTimestampString(
      table,
      this.config
    );
  }
}
class PgTimestampString extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgTimestampString";
  withTimezone;
  precision;
  constructor(table, config) {
    super(table, config);
    this.withTimezone = config.withTimezone;
    this.precision = config.precision;
  }
  getSQLType() {
    const precision = this.precision === void 0 ? "" : `(${this.precision})`;
    return `timestamp${precision}${this.withTimezone ? " with time zone" : ""}`;
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") return value;
    const shortened = value.toISOString().slice(0, -1).replace("T", " ");
    if (this.withTimezone) {
      const offset = value.getTimezoneOffset();
      const sign = offset <= 0 ? "+" : "-";
      return `${shortened}${sign}${Math.floor(Math.abs(offset) / 60).toString().padStart(2, "0")}`;
    }
    return shortened;
  }
}
function timestamp(a, b = {}) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  if (config?.mode === "string") {
    return new PgTimestampStringBuilder(name, config.withTimezone ?? false, config.precision);
  }
  return new PgTimestampBuilder(name, config?.withTimezone ?? false, config?.precision);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgTimestamp,
  PgTimestampBuilder,
  PgTimestampString,
  PgTimestampStringBuilder,
  timestamp
});
//# sourceMappingURL=timestamp.cjs.map
},
"drizzle-orm/pg-core/columns/date.common.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var date_common_exports = {};
__export(date_common_exports, {
  PgDateColumnBaseBuilder: () => PgDateColumnBaseBuilder
});
module.exports = __toCommonJS(date_common_exports);
var import_entity = require("../../entity.cjs");
var import_sql = require("../../sql/sql.cjs");
var import_common = require("./common.cjs");
class PgDateColumnBaseBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgDateColumnBaseBuilder";
  defaultNow() {
    return this.default(import_sql.sql`now()`);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgDateColumnBaseBuilder
});
//# sourceMappingURL=date.common.cjs.map
},
"drizzle-orm/pg-core/columns/time.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var time_exports = {};
__export(time_exports, {
  PgTime: () => PgTime,
  PgTimeBuilder: () => PgTimeBuilder,
  time: () => time
});
module.exports = __toCommonJS(time_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
var import_date_common = require("./date.common.cjs");
class PgTimeBuilder extends import_date_common.PgDateColumnBaseBuilder {
  constructor(name, withTimezone, precision) {
    super(name, "string", "PgTime");
    this.withTimezone = withTimezone;
    this.precision = precision;
    this.config.withTimezone = withTimezone;
    this.config.precision = precision;
  }
  static [import_entity.entityKind] = "PgTimeBuilder";
  /** @internal */
  build(table) {
    return new PgTime(table, this.config);
  }
}
class PgTime extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgTime";
  withTimezone;
  precision;
  constructor(table, config) {
    super(table, config);
    this.withTimezone = config.withTimezone;
    this.precision = config.precision;
  }
  getSQLType() {
    const precision = this.precision === void 0 ? "" : `(${this.precision})`;
    return `time${precision}${this.withTimezone ? " with time zone" : ""}`;
  }
}
function time(a, b = {}) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  return new PgTimeBuilder(name, config.withTimezone ?? false, config.precision);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgTime,
  PgTimeBuilder,
  time
});
//# sourceMappingURL=time.cjs.map
},
"drizzle-orm/pg-core/columns/text.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var text_exports = {};
__export(text_exports, {
  PgText: () => PgText,
  PgTextBuilder: () => PgTextBuilder,
  text: () => text
});
module.exports = __toCommonJS(text_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
class PgTextBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgTextBuilder";
  constructor(name, config) {
    super(name, "string", "PgText");
    this.config.enumValues = config.enum;
  }
  /** @internal */
  build(table) {
    return new PgText(table, this.config);
  }
}
class PgText extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgText";
  enumValues = this.config.enumValues;
  getSQLType() {
    return "text";
  }
}
function text(a, b = {}) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  return new PgTextBuilder(name, config);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgText,
  PgTextBuilder,
  text
});
//# sourceMappingURL=text.cjs.map
},
"drizzle-orm/pg-core/columns/smallserial.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var smallserial_exports = {};
__export(smallserial_exports, {
  PgSmallSerial: () => PgSmallSerial,
  PgSmallSerialBuilder: () => PgSmallSerialBuilder,
  smallserial: () => smallserial
});
module.exports = __toCommonJS(smallserial_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgSmallSerialBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgSmallSerialBuilder";
  constructor(name) {
    super(name, "number", "PgSmallSerial");
    this.config.hasDefault = true;
    this.config.notNull = true;
  }
  /** @internal */
  build(table) {
    return new PgSmallSerial(
      table,
      this.config
    );
  }
}
class PgSmallSerial extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgSmallSerial";
  getSQLType() {
    return "smallserial";
  }
}
function smallserial(name) {
  return new PgSmallSerialBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgSmallSerial,
  PgSmallSerialBuilder,
  smallserial
});
//# sourceMappingURL=smallserial.cjs.map
},
"drizzle-orm/pg-core/columns/smallint.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var smallint_exports = {};
__export(smallint_exports, {
  PgSmallInt: () => PgSmallInt,
  PgSmallIntBuilder: () => PgSmallIntBuilder,
  smallint: () => smallint
});
module.exports = __toCommonJS(smallint_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
var import_int_common = require("./int.common.cjs");
class PgSmallIntBuilder extends import_int_common.PgIntColumnBaseBuilder {
  static [import_entity.entityKind] = "PgSmallIntBuilder";
  constructor(name) {
    super(name, "number", "PgSmallInt");
  }
  /** @internal */
  build(table) {
    return new PgSmallInt(table, this.config);
  }
}
class PgSmallInt extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgSmallInt";
  getSQLType() {
    return "smallint";
  }
  mapFromDriverValue = (value) => {
    if (typeof value === "string") {
      return Number(value);
    }
    return value;
  };
}
function smallint(name) {
  return new PgSmallIntBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgSmallInt,
  PgSmallIntBuilder,
  smallint
});
//# sourceMappingURL=smallint.cjs.map
},
"drizzle-orm/pg-core/columns/int.common.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var int_common_exports = {};
__export(int_common_exports, {
  PgIntColumnBaseBuilder: () => PgIntColumnBaseBuilder
});
module.exports = __toCommonJS(int_common_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgIntColumnBaseBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgIntColumnBaseBuilder";
  generatedAlwaysAsIdentity(sequence) {
    if (sequence) {
      const { name, ...options } = sequence;
      this.config.generatedIdentity = {
        type: "always",
        sequenceName: name,
        sequenceOptions: options
      };
    } else {
      this.config.generatedIdentity = {
        type: "always"
      };
    }
    this.config.hasDefault = true;
    this.config.notNull = true;
    return this;
  }
  generatedByDefaultAsIdentity(sequence) {
    if (sequence) {
      const { name, ...options } = sequence;
      this.config.generatedIdentity = {
        type: "byDefault",
        sequenceName: name,
        sequenceOptions: options
      };
    } else {
      this.config.generatedIdentity = {
        type: "byDefault"
      };
    }
    this.config.hasDefault = true;
    this.config.notNull = true;
    return this;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgIntColumnBaseBuilder
});
//# sourceMappingURL=int.common.cjs.map
},
"drizzle-orm/pg-core/columns/serial.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var serial_exports = {};
__export(serial_exports, {
  PgSerial: () => PgSerial,
  PgSerialBuilder: () => PgSerialBuilder,
  serial: () => serial
});
module.exports = __toCommonJS(serial_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgSerialBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgSerialBuilder";
  constructor(name) {
    super(name, "number", "PgSerial");
    this.config.hasDefault = true;
    this.config.notNull = true;
  }
  /** @internal */
  build(table) {
    return new PgSerial(table, this.config);
  }
}
class PgSerial extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgSerial";
  getSQLType() {
    return "serial";
  }
}
function serial(name) {
  return new PgSerialBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgSerial,
  PgSerialBuilder,
  serial
});
//# sourceMappingURL=serial.cjs.map
},
"drizzle-orm/pg-core/columns/real.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var real_exports = {};
__export(real_exports, {
  PgReal: () => PgReal,
  PgRealBuilder: () => PgRealBuilder,
  real: () => real
});
module.exports = __toCommonJS(real_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgRealBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgRealBuilder";
  constructor(name, length) {
    super(name, "number", "PgReal");
    this.config.length = length;
  }
  /** @internal */
  build(table) {
    return new PgReal(table, this.config);
  }
}
class PgReal extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgReal";
  constructor(table, config) {
    super(table, config);
  }
  getSQLType() {
    return "real";
  }
  mapFromDriverValue = (value) => {
    if (typeof value === "string") {
      return Number.parseFloat(value);
    }
    return value;
  };
}
function real(name) {
  return new PgRealBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgReal,
  PgRealBuilder,
  real
});
//# sourceMappingURL=real.cjs.map
},
"drizzle-orm/pg-core/columns/postgis_extension/geometry.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var geometry_exports = {};
__export(geometry_exports, {
  PgGeometry: () => PgGeometry,
  PgGeometryBuilder: () => PgGeometryBuilder,
  PgGeometryObject: () => PgGeometryObject,
  PgGeometryObjectBuilder: () => PgGeometryObjectBuilder,
  geometry: () => geometry
});
module.exports = __toCommonJS(geometry_exports);
var import_entity = require("../../../entity.cjs");
var import_utils = require("../../../utils.cjs");
var import_common = require("../common.cjs");
var import_utils2 = require("./utils.cjs");
class PgGeometryBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgGeometryBuilder";
  constructor(name) {
    super(name, "array", "PgGeometry");
  }
  /** @internal */
  build(table) {
    return new PgGeometry(
      table,
      this.config
    );
  }
}
class PgGeometry extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgGeometry";
  getSQLType() {
    return "geometry(point)";
  }
  mapFromDriverValue(value) {
    return (0, import_utils2.parseEWKB)(value);
  }
  mapToDriverValue(value) {
    return `point(${value[0]} ${value[1]})`;
  }
}
class PgGeometryObjectBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgGeometryObjectBuilder";
  constructor(name) {
    super(name, "json", "PgGeometryObject");
  }
  /** @internal */
  build(table) {
    return new PgGeometryObject(
      table,
      this.config
    );
  }
}
class PgGeometryObject extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgGeometryObject";
  getSQLType() {
    return "geometry(point)";
  }
  mapFromDriverValue(value) {
    const parsed = (0, import_utils2.parseEWKB)(value);
    return { x: parsed[0], y: parsed[1] };
  }
  mapToDriverValue(value) {
    return `point(${value.x} ${value.y})`;
  }
}
function geometry(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  if (!config?.mode || config.mode === "tuple") {
    return new PgGeometryBuilder(name);
  }
  return new PgGeometryObjectBuilder(name);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgGeometry,
  PgGeometryBuilder,
  PgGeometryObject,
  PgGeometryObjectBuilder,
  geometry
});
//# sourceMappingURL=geometry.cjs.map
},
"drizzle-orm/pg-core/columns/postgis_extension/utils.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var utils_exports = {};
__export(utils_exports, {
  parseEWKB: () => parseEWKB
});
module.exports = __toCommonJS(utils_exports);
function hexToBytes(hex) {
  const bytes = [];
  for (let c = 0; c < hex.length; c += 2) {
    bytes.push(Number.parseInt(hex.slice(c, c + 2), 16));
  }
  return new Uint8Array(bytes);
}
function bytesToFloat64(bytes, offset) {
  const buffer = new ArrayBuffer(8);
  const view = new DataView(buffer);
  for (let i = 0; i < 8; i++) {
    view.setUint8(i, bytes[offset + i]);
  }
  return view.getFloat64(0, true);
}
function parseEWKB(hex) {
  const bytes = hexToBytes(hex);
  let offset = 0;
  const byteOrder = bytes[offset];
  offset += 1;
  const view = new DataView(bytes.buffer);
  const geomType = view.getUint32(offset, byteOrder === 1);
  offset += 4;
  let _srid;
  if (geomType & 536870912) {
    _srid = view.getUint32(offset, byteOrder === 1);
    offset += 4;
  }
  if ((geomType & 65535) === 1) {
    const x = bytesToFloat64(bytes, offset);
    offset += 8;
    const y = bytesToFloat64(bytes, offset);
    offset += 8;
    return [x, y];
  }
  throw new Error("Unsupported geometry type");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  parseEWKB
});
//# sourceMappingURL=utils.cjs.map
},
"drizzle-orm/pg-core/columns/point.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var point_exports = {};
__export(point_exports, {
  PgPointObject: () => PgPointObject,
  PgPointObjectBuilder: () => PgPointObjectBuilder,
  PgPointTuple: () => PgPointTuple,
  PgPointTupleBuilder: () => PgPointTupleBuilder,
  point: () => point
});
module.exports = __toCommonJS(point_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
class PgPointTupleBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgPointTupleBuilder";
  constructor(name) {
    super(name, "array", "PgPointTuple");
  }
  /** @internal */
  build(table) {
    return new PgPointTuple(
      table,
      this.config
    );
  }
}
class PgPointTuple extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgPointTuple";
  getSQLType() {
    return "point";
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") {
      const [x, y] = value.slice(1, -1).split(",");
      return [Number.parseFloat(x), Number.parseFloat(y)];
    }
    return [value.x, value.y];
  }
  mapToDriverValue(value) {
    return `(${value[0]},${value[1]})`;
  }
}
class PgPointObjectBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgPointObjectBuilder";
  constructor(name) {
    super(name, "json", "PgPointObject");
  }
  /** @internal */
  build(table) {
    return new PgPointObject(
      table,
      this.config
    );
  }
}
class PgPointObject extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgPointObject";
  getSQLType() {
    return "point";
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") {
      const [x, y] = value.slice(1, -1).split(",");
      return { x: Number.parseFloat(x), y: Number.parseFloat(y) };
    }
    return value;
  }
  mapToDriverValue(value) {
    return `(${value.x},${value.y})`;
  }
}
function point(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  if (!config?.mode || config.mode === "tuple") {
    return new PgPointTupleBuilder(name);
  }
  return new PgPointObjectBuilder(name);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgPointObject,
  PgPointObjectBuilder,
  PgPointTuple,
  PgPointTupleBuilder,
  point
});
//# sourceMappingURL=point.cjs.map
},
"drizzle-orm/pg-core/columns/numeric.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var numeric_exports = {};
__export(numeric_exports, {
  PgNumeric: () => PgNumeric,
  PgNumericBigInt: () => PgNumericBigInt,
  PgNumericBigIntBuilder: () => PgNumericBigIntBuilder,
  PgNumericBuilder: () => PgNumericBuilder,
  PgNumericNumber: () => PgNumericNumber,
  PgNumericNumberBuilder: () => PgNumericNumberBuilder,
  decimal: () => decimal,
  numeric: () => numeric
});
module.exports = __toCommonJS(numeric_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
class PgNumericBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgNumericBuilder";
  constructor(name, precision, scale) {
    super(name, "string", "PgNumeric");
    this.config.precision = precision;
    this.config.scale = scale;
  }
  /** @internal */
  build(table) {
    return new PgNumeric(table, this.config);
  }
}
class PgNumeric extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgNumeric";
  precision;
  scale;
  constructor(table, config) {
    super(table, config);
    this.precision = config.precision;
    this.scale = config.scale;
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") return value;
    return String(value);
  }
  getSQLType() {
    if (this.precision !== void 0 && this.scale !== void 0) {
      return `numeric(${this.precision}, ${this.scale})`;
    } else if (this.precision === void 0) {
      return "numeric";
    } else {
      return `numeric(${this.precision})`;
    }
  }
}
class PgNumericNumberBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgNumericNumberBuilder";
  constructor(name, precision, scale) {
    super(name, "number", "PgNumericNumber");
    this.config.precision = precision;
    this.config.scale = scale;
  }
  /** @internal */
  build(table) {
    return new PgNumericNumber(
      table,
      this.config
    );
  }
}
class PgNumericNumber extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgNumericNumber";
  precision;
  scale;
  constructor(table, config) {
    super(table, config);
    this.precision = config.precision;
    this.scale = config.scale;
  }
  mapFromDriverValue(value) {
    if (typeof value === "number") return value;
    return Number(value);
  }
  mapToDriverValue = String;
  getSQLType() {
    if (this.precision !== void 0 && this.scale !== void 0) {
      return `numeric(${this.precision}, ${this.scale})`;
    } else if (this.precision === void 0) {
      return "numeric";
    } else {
      return `numeric(${this.precision})`;
    }
  }
}
class PgNumericBigIntBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgNumericBigIntBuilder";
  constructor(name, precision, scale) {
    super(name, "bigint", "PgNumericBigInt");
    this.config.precision = precision;
    this.config.scale = scale;
  }
  /** @internal */
  build(table) {
    return new PgNumericBigInt(
      table,
      this.config
    );
  }
}
class PgNumericBigInt extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgNumericBigInt";
  precision;
  scale;
  constructor(table, config) {
    super(table, config);
    this.precision = config.precision;
    this.scale = config.scale;
  }
  mapFromDriverValue = BigInt;
  mapToDriverValue = String;
  getSQLType() {
    if (this.precision !== void 0 && this.scale !== void 0) {
      return `numeric(${this.precision}, ${this.scale})`;
    } else if (this.precision === void 0) {
      return "numeric";
    } else {
      return `numeric(${this.precision})`;
    }
  }
}
function numeric(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  const mode = config?.mode;
  return mode === "number" ? new PgNumericNumberBuilder(name, config?.precision, config?.scale) : mode === "bigint" ? new PgNumericBigIntBuilder(name, config?.precision, config?.scale) : new PgNumericBuilder(name, config?.precision, config?.scale);
}
const decimal = numeric;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgNumeric,
  PgNumericBigInt,
  PgNumericBigIntBuilder,
  PgNumericBuilder,
  PgNumericNumber,
  PgNumericNumberBuilder,
  decimal,
  numeric
});
//# sourceMappingURL=numeric.cjs.map
},
"drizzle-orm/pg-core/columns/macaddr8.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var macaddr8_exports = {};
__export(macaddr8_exports, {
  PgMacaddr8: () => PgMacaddr8,
  PgMacaddr8Builder: () => PgMacaddr8Builder,
  macaddr8: () => macaddr8
});
module.exports = __toCommonJS(macaddr8_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgMacaddr8Builder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgMacaddr8Builder";
  constructor(name) {
    super(name, "string", "PgMacaddr8");
  }
  /** @internal */
  build(table) {
    return new PgMacaddr8(table, this.config);
  }
}
class PgMacaddr8 extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgMacaddr8";
  getSQLType() {
    return "macaddr8";
  }
}
function macaddr8(name) {
  return new PgMacaddr8Builder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgMacaddr8,
  PgMacaddr8Builder,
  macaddr8
});
//# sourceMappingURL=macaddr8.cjs.map
},
"drizzle-orm/pg-core/columns/macaddr.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var macaddr_exports = {};
__export(macaddr_exports, {
  PgMacaddr: () => PgMacaddr,
  PgMacaddrBuilder: () => PgMacaddrBuilder,
  macaddr: () => macaddr
});
module.exports = __toCommonJS(macaddr_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgMacaddrBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgMacaddrBuilder";
  constructor(name) {
    super(name, "string", "PgMacaddr");
  }
  /** @internal */
  build(table) {
    return new PgMacaddr(table, this.config);
  }
}
class PgMacaddr extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgMacaddr";
  getSQLType() {
    return "macaddr";
  }
}
function macaddr(name) {
  return new PgMacaddrBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgMacaddr,
  PgMacaddrBuilder,
  macaddr
});
//# sourceMappingURL=macaddr.cjs.map
},
"drizzle-orm/pg-core/columns/line.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var line_exports = {};
__export(line_exports, {
  PgLineABC: () => PgLineABC,
  PgLineABCBuilder: () => PgLineABCBuilder,
  PgLineBuilder: () => PgLineBuilder,
  PgLineTuple: () => PgLineTuple,
  line: () => line
});
module.exports = __toCommonJS(line_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
class PgLineBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgLineBuilder";
  constructor(name) {
    super(name, "array", "PgLine");
  }
  /** @internal */
  build(table) {
    return new PgLineTuple(
      table,
      this.config
    );
  }
}
class PgLineTuple extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgLine";
  getSQLType() {
    return "line";
  }
  mapFromDriverValue(value) {
    const [a, b, c] = value.slice(1, -1).split(",");
    return [Number.parseFloat(a), Number.parseFloat(b), Number.parseFloat(c)];
  }
  mapToDriverValue(value) {
    return `{${value[0]},${value[1]},${value[2]}}`;
  }
}
class PgLineABCBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgLineABCBuilder";
  constructor(name) {
    super(name, "json", "PgLineABC");
  }
  /** @internal */
  build(table) {
    return new PgLineABC(
      table,
      this.config
    );
  }
}
class PgLineABC extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgLineABC";
  getSQLType() {
    return "line";
  }
  mapFromDriverValue(value) {
    const [a, b, c] = value.slice(1, -1).split(",");
    return { a: Number.parseFloat(a), b: Number.parseFloat(b), c: Number.parseFloat(c) };
  }
  mapToDriverValue(value) {
    return `{${value.a},${value.b},${value.c}}`;
  }
}
function line(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  if (!config?.mode || config.mode === "tuple") {
    return new PgLineBuilder(name);
  }
  return new PgLineABCBuilder(name);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgLineABC,
  PgLineABCBuilder,
  PgLineBuilder,
  PgLineTuple,
  line
});
//# sourceMappingURL=line.cjs.map
},
"drizzle-orm/pg-core/columns/jsonb.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var jsonb_exports = {};
__export(jsonb_exports, {
  PgJsonb: () => PgJsonb,
  PgJsonbBuilder: () => PgJsonbBuilder,
  jsonb: () => jsonb
});
module.exports = __toCommonJS(jsonb_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgJsonbBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgJsonbBuilder";
  constructor(name) {
    super(name, "json", "PgJsonb");
  }
  /** @internal */
  build(table) {
    return new PgJsonb(table, this.config);
  }
}
class PgJsonb extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgJsonb";
  constructor(table, config) {
    super(table, config);
  }
  getSQLType() {
    return "jsonb";
  }
  mapToDriverValue(value) {
    return JSON.stringify(value);
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") {
      try {
        return JSON.parse(value);
      } catch {
        return value;
      }
    }
    return value;
  }
}
function jsonb(name) {
  return new PgJsonbBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgJsonb,
  PgJsonbBuilder,
  jsonb
});
//# sourceMappingURL=jsonb.cjs.map
},
"drizzle-orm/pg-core/columns/json.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var json_exports = {};
__export(json_exports, {
  PgJson: () => PgJson,
  PgJsonBuilder: () => PgJsonBuilder,
  json: () => json
});
module.exports = __toCommonJS(json_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgJsonBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgJsonBuilder";
  constructor(name) {
    super(name, "json", "PgJson");
  }
  /** @internal */
  build(table) {
    return new PgJson(table, this.config);
  }
}
class PgJson extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgJson";
  constructor(table, config) {
    super(table, config);
  }
  getSQLType() {
    return "json";
  }
  mapToDriverValue(value) {
    return JSON.stringify(value);
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") {
      try {
        return JSON.parse(value);
      } catch {
        return value;
      }
    }
    return value;
  }
}
function json(name) {
  return new PgJsonBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgJson,
  PgJsonBuilder,
  json
});
//# sourceMappingURL=json.cjs.map
},
"drizzle-orm/pg-core/columns/interval.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var interval_exports = {};
__export(interval_exports, {
  PgInterval: () => PgInterval,
  PgIntervalBuilder: () => PgIntervalBuilder,
  interval: () => interval
});
module.exports = __toCommonJS(interval_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
class PgIntervalBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgIntervalBuilder";
  constructor(name, intervalConfig) {
    super(name, "string", "PgInterval");
    this.config.intervalConfig = intervalConfig;
  }
  /** @internal */
  build(table) {
    return new PgInterval(table, this.config);
  }
}
class PgInterval extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgInterval";
  fields = this.config.intervalConfig.fields;
  precision = this.config.intervalConfig.precision;
  getSQLType() {
    const fields = this.fields ? ` ${this.fields}` : "";
    const precision = this.precision ? `(${this.precision})` : "";
    return `interval${fields}${precision}`;
  }
}
function interval(a, b = {}) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  return new PgIntervalBuilder(name, config);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgInterval,
  PgIntervalBuilder,
  interval
});
//# sourceMappingURL=interval.cjs.map
},
"drizzle-orm/pg-core/columns/integer.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var integer_exports = {};
__export(integer_exports, {
  PgInteger: () => PgInteger,
  PgIntegerBuilder: () => PgIntegerBuilder,
  integer: () => integer
});
module.exports = __toCommonJS(integer_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
var import_int_common = require("./int.common.cjs");
class PgIntegerBuilder extends import_int_common.PgIntColumnBaseBuilder {
  static [import_entity.entityKind] = "PgIntegerBuilder";
  constructor(name) {
    super(name, "number", "PgInteger");
  }
  /** @internal */
  build(table) {
    return new PgInteger(table, this.config);
  }
}
class PgInteger extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgInteger";
  getSQLType() {
    return "integer";
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") {
      return Number.parseInt(value);
    }
    return value;
  }
}
function integer(name) {
  return new PgIntegerBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgInteger,
  PgIntegerBuilder,
  integer
});
//# sourceMappingURL=integer.cjs.map
},
"drizzle-orm/pg-core/columns/inet.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var inet_exports = {};
__export(inet_exports, {
  PgInet: () => PgInet,
  PgInetBuilder: () => PgInetBuilder,
  inet: () => inet
});
module.exports = __toCommonJS(inet_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgInetBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgInetBuilder";
  constructor(name) {
    super(name, "string", "PgInet");
  }
  /** @internal */
  build(table) {
    return new PgInet(table, this.config);
  }
}
class PgInet extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgInet";
  getSQLType() {
    return "inet";
  }
}
function inet(name) {
  return new PgInetBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgInet,
  PgInetBuilder,
  inet
});
//# sourceMappingURL=inet.cjs.map
},
"drizzle-orm/pg-core/columns/double-precision.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var double_precision_exports = {};
__export(double_precision_exports, {
  PgDoublePrecision: () => PgDoublePrecision,
  PgDoublePrecisionBuilder: () => PgDoublePrecisionBuilder,
  doublePrecision: () => doublePrecision
});
module.exports = __toCommonJS(double_precision_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgDoublePrecisionBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgDoublePrecisionBuilder";
  constructor(name) {
    super(name, "number", "PgDoublePrecision");
  }
  /** @internal */
  build(table) {
    return new PgDoublePrecision(
      table,
      this.config
    );
  }
}
class PgDoublePrecision extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgDoublePrecision";
  getSQLType() {
    return "double precision";
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") {
      return Number.parseFloat(value);
    }
    return value;
  }
}
function doublePrecision(name) {
  return new PgDoublePrecisionBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgDoublePrecision,
  PgDoublePrecisionBuilder,
  doublePrecision
});
//# sourceMappingURL=double-precision.cjs.map
},
"drizzle-orm/pg-core/columns/date.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var date_exports = {};
__export(date_exports, {
  PgDate: () => PgDate,
  PgDateBuilder: () => PgDateBuilder,
  PgDateString: () => PgDateString,
  PgDateStringBuilder: () => PgDateStringBuilder,
  date: () => date
});
module.exports = __toCommonJS(date_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
var import_date_common = require("./date.common.cjs");
class PgDateBuilder extends import_date_common.PgDateColumnBaseBuilder {
  static [import_entity.entityKind] = "PgDateBuilder";
  constructor(name) {
    super(name, "date", "PgDate");
  }
  /** @internal */
  build(table) {
    return new PgDate(table, this.config);
  }
}
class PgDate extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgDate";
  getSQLType() {
    return "date";
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") return new Date(value);
    return value;
  }
  mapToDriverValue(value) {
    return value.toISOString();
  }
}
class PgDateStringBuilder extends import_date_common.PgDateColumnBaseBuilder {
  static [import_entity.entityKind] = "PgDateStringBuilder";
  constructor(name) {
    super(name, "string", "PgDateString");
  }
  /** @internal */
  build(table) {
    return new PgDateString(
      table,
      this.config
    );
  }
}
class PgDateString extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgDateString";
  getSQLType() {
    return "date";
  }
  mapFromDriverValue(value) {
    if (typeof value === "string") return value;
    return value.toISOString().slice(0, -14);
  }
}
function date(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  if (config?.mode === "date") {
    return new PgDateBuilder(name);
  }
  return new PgDateStringBuilder(name);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgDate,
  PgDateBuilder,
  PgDateString,
  PgDateStringBuilder,
  date
});
//# sourceMappingURL=date.cjs.map
},
"drizzle-orm/pg-core/columns/custom.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var custom_exports = {};
__export(custom_exports, {
  PgCustomColumn: () => PgCustomColumn,
  PgCustomColumnBuilder: () => PgCustomColumnBuilder,
  customType: () => customType
});
module.exports = __toCommonJS(custom_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
class PgCustomColumnBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgCustomColumnBuilder";
  constructor(name, fieldConfig, customTypeParams) {
    super(name, "custom", "PgCustomColumn");
    this.config.fieldConfig = fieldConfig;
    this.config.customTypeParams = customTypeParams;
  }
  /** @internal */
  build(table) {
    return new PgCustomColumn(
      table,
      this.config
    );
  }
}
class PgCustomColumn extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgCustomColumn";
  sqlName;
  mapTo;
  mapFrom;
  constructor(table, config) {
    super(table, config);
    this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
    this.mapTo = config.customTypeParams.toDriver;
    this.mapFrom = config.customTypeParams.fromDriver;
  }
  getSQLType() {
    return this.sqlName;
  }
  mapFromDriverValue(value) {
    return typeof this.mapFrom === "function" ? this.mapFrom(value) : value;
  }
  mapToDriverValue(value) {
    return typeof this.mapTo === "function" ? this.mapTo(value) : value;
  }
}
function customType(customTypeParams) {
  return (a, b) => {
    const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
    return new PgCustomColumnBuilder(name, config, customTypeParams);
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgCustomColumn,
  PgCustomColumnBuilder,
  customType
});
//# sourceMappingURL=custom.cjs.map
},
"drizzle-orm/pg-core/columns/cidr.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cidr_exports = {};
__export(cidr_exports, {
  PgCidr: () => PgCidr,
  PgCidrBuilder: () => PgCidrBuilder,
  cidr: () => cidr
});
module.exports = __toCommonJS(cidr_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgCidrBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgCidrBuilder";
  constructor(name) {
    super(name, "string", "PgCidr");
  }
  /** @internal */
  build(table) {
    return new PgCidr(table, this.config);
  }
}
class PgCidr extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgCidr";
  getSQLType() {
    return "cidr";
  }
}
function cidr(name) {
  return new PgCidrBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgCidr,
  PgCidrBuilder,
  cidr
});
//# sourceMappingURL=cidr.cjs.map
},
"drizzle-orm/pg-core/columns/char.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var char_exports = {};
__export(char_exports, {
  PgChar: () => PgChar,
  PgCharBuilder: () => PgCharBuilder,
  char: () => char
});
module.exports = __toCommonJS(char_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
class PgCharBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgCharBuilder";
  constructor(name, config) {
    super(name, "string", "PgChar");
    this.config.length = config.length;
    this.config.enumValues = config.enum;
  }
  /** @internal */
  build(table) {
    return new PgChar(
      table,
      this.config
    );
  }
}
class PgChar extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgChar";
  length = this.config.length;
  enumValues = this.config.enumValues;
  getSQLType() {
    return this.length === void 0 ? `char` : `char(${this.length})`;
  }
}
function char(a, b = {}) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  return new PgCharBuilder(name, config);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgChar,
  PgCharBuilder,
  char
});
//# sourceMappingURL=char.cjs.map
},
"drizzle-orm/pg-core/columns/boolean.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var boolean_exports = {};
__export(boolean_exports, {
  PgBoolean: () => PgBoolean,
  PgBooleanBuilder: () => PgBooleanBuilder,
  boolean: () => boolean
});
module.exports = __toCommonJS(boolean_exports);
var import_entity = require("../../entity.cjs");
var import_common = require("./common.cjs");
class PgBooleanBuilder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgBooleanBuilder";
  constructor(name) {
    super(name, "boolean", "PgBoolean");
  }
  /** @internal */
  build(table) {
    return new PgBoolean(table, this.config);
  }
}
class PgBoolean extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgBoolean";
  getSQLType() {
    return "boolean";
  }
}
function boolean(name) {
  return new PgBooleanBuilder(name ?? "");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgBoolean,
  PgBooleanBuilder,
  boolean
});
//# sourceMappingURL=boolean.cjs.map
},
"drizzle-orm/pg-core/columns/bigserial.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bigserial_exports = {};
__export(bigserial_exports, {
  PgBigSerial53: () => PgBigSerial53,
  PgBigSerial53Builder: () => PgBigSerial53Builder,
  PgBigSerial64: () => PgBigSerial64,
  PgBigSerial64Builder: () => PgBigSerial64Builder,
  bigserial: () => bigserial
});
module.exports = __toCommonJS(bigserial_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
class PgBigSerial53Builder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgBigSerial53Builder";
  constructor(name) {
    super(name, "number", "PgBigSerial53");
    this.config.hasDefault = true;
    this.config.notNull = true;
  }
  /** @internal */
  build(table) {
    return new PgBigSerial53(
      table,
      this.config
    );
  }
}
class PgBigSerial53 extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgBigSerial53";
  getSQLType() {
    return "bigserial";
  }
  mapFromDriverValue(value) {
    if (typeof value === "number") {
      return value;
    }
    return Number(value);
  }
}
class PgBigSerial64Builder extends import_common.PgColumnBuilder {
  static [import_entity.entityKind] = "PgBigSerial64Builder";
  constructor(name) {
    super(name, "bigint", "PgBigSerial64");
    this.config.hasDefault = true;
  }
  /** @internal */
  build(table) {
    return new PgBigSerial64(
      table,
      this.config
    );
  }
}
class PgBigSerial64 extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgBigSerial64";
  getSQLType() {
    return "bigserial";
  }
  // eslint-disable-next-line unicorn/prefer-native-coercion-functions
  mapFromDriverValue(value) {
    return BigInt(value);
  }
}
function bigserial(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  if (config.mode === "number") {
    return new PgBigSerial53Builder(name);
  }
  return new PgBigSerial64Builder(name);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgBigSerial53,
  PgBigSerial53Builder,
  PgBigSerial64,
  PgBigSerial64Builder,
  bigserial
});
//# sourceMappingURL=bigserial.cjs.map
},
"drizzle-orm/pg-core/columns/bigint.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bigint_exports = {};
__export(bigint_exports, {
  PgBigInt53: () => PgBigInt53,
  PgBigInt53Builder: () => PgBigInt53Builder,
  PgBigInt64: () => PgBigInt64,
  PgBigInt64Builder: () => PgBigInt64Builder,
  bigint: () => bigint
});
module.exports = __toCommonJS(bigint_exports);
var import_entity = require("../../entity.cjs");
var import_utils = require("../../utils.cjs");
var import_common = require("./common.cjs");
var import_int_common = require("./int.common.cjs");
class PgBigInt53Builder extends import_int_common.PgIntColumnBaseBuilder {
  static [import_entity.entityKind] = "PgBigInt53Builder";
  constructor(name) {
    super(name, "number", "PgBigInt53");
  }
  /** @internal */
  build(table) {
    return new PgBigInt53(table, this.config);
  }
}
class PgBigInt53 extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgBigInt53";
  getSQLType() {
    return "bigint";
  }
  mapFromDriverValue(value) {
    if (typeof value === "number") {
      return value;
    }
    return Number(value);
  }
}
class PgBigInt64Builder extends import_int_common.PgIntColumnBaseBuilder {
  static [import_entity.entityKind] = "PgBigInt64Builder";
  constructor(name) {
    super(name, "bigint", "PgBigInt64");
  }
  /** @internal */
  build(table) {
    return new PgBigInt64(
      table,
      this.config
    );
  }
}
class PgBigInt64 extends import_common.PgColumn {
  static [import_entity.entityKind] = "PgBigInt64";
  getSQLType() {
    return "bigint";
  }
  // eslint-disable-next-line unicorn/prefer-native-coercion-functions
  mapFromDriverValue(value) {
    return BigInt(value);
  }
}
function bigint(a, b) {
  const { name, config } = (0, import_utils.getColumnNameAndConfig)(a, b);
  if (config.mode === "number") {
    return new PgBigInt53Builder(name);
  }
  return new PgBigInt64Builder(name);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgBigInt53,
  PgBigInt53Builder,
  PgBigInt64,
  PgBigInt64Builder,
  bigint
});
//# sourceMappingURL=bigint.cjs.map
},
"drizzle-orm/pg-core/query-builders/count.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var count_exports = {};
__export(count_exports, {
  PgCountBuilder: () => PgCountBuilder
});
module.exports = __toCommonJS(count_exports);
var import_entity = require("../../entity.cjs");
var import_sql = require("../../sql/sql.cjs");
class PgCountBuilder extends import_sql.SQL {
  constructor(params) {
    super(PgCountBuilder.buildEmbeddedCount(params.source, params.filters).queryChunks);
    this.params = params;
    this.mapWith(Number);
    this.session = params.session;
    this.sql = PgCountBuilder.buildCount(
      params.source,
      params.filters
    );
  }
  sql;
  token;
  static [import_entity.entityKind] = "PgCountBuilder";
  [Symbol.toStringTag] = "PgCountBuilder";
  session;
  static buildEmbeddedCount(source, filters) {
    return import_sql.sql`(select count(*) from ${source}${import_sql.sql.raw(" where ").if(filters)}${filters})`;
  }
  static buildCount(source, filters) {
    return import_sql.sql`select count(*) as count from ${source}${import_sql.sql.raw(" where ").if(filters)}${filters};`;
  }
  /** @intrnal */
  setToken(token) {
    this.token = token;
    return this;
  }
  then(onfulfilled, onrejected) {
    return Promise.resolve(this.session.count(this.sql, this.token)).then(
      onfulfilled,
      onrejected
    );
  }
  catch(onRejected) {
    return this.then(void 0, onRejected);
  }
  finally(onFinally) {
    return this.then(
      (value) => {
        onFinally?.();
        return value;
      },
      (reason) => {
        onFinally?.();
        throw reason;
      }
    );
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgCountBuilder
});
//# sourceMappingURL=count.cjs.map
},
"drizzle-orm/selection-proxy.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var selection_proxy_exports = {};
__export(selection_proxy_exports, {
  SelectionProxyHandler: () => SelectionProxyHandler
});
module.exports = __toCommonJS(selection_proxy_exports);
var import_alias = require("./alias.cjs");
var import_column = require("./column.cjs");
var import_entity = require("./entity.cjs");
var import_sql = require("./sql/sql.cjs");
var import_subquery = require("./subquery.cjs");
var import_view_common = require("./view-common.cjs");
class SelectionProxyHandler {
  static [import_entity.entityKind] = "SelectionProxyHandler";
  config;
  constructor(config) {
    this.config = { ...config };
  }
  get(subquery, prop) {
    if (prop === "_") {
      return {
        ...subquery["_"],
        selectedFields: new Proxy(
          subquery._.selectedFields,
          this
        )
      };
    }
    if (prop === import_view_common.ViewBaseConfig) {
      return {
        ...subquery[import_view_common.ViewBaseConfig],
        selectedFields: new Proxy(
          subquery[import_view_common.ViewBaseConfig].selectedFields,
          this
        )
      };
    }
    if (typeof prop === "symbol") {
      return subquery[prop];
    }
    const columns = (0, import_entity.is)(subquery, import_subquery.Subquery) ? subquery._.selectedFields : (0, import_entity.is)(subquery, import_sql.View) ? subquery[import_view_common.ViewBaseConfig].selectedFields : subquery;
    const value = columns[prop];
    if ((0, import_entity.is)(value, import_sql.SQL.Aliased)) {
      if (this.config.sqlAliasedBehavior === "sql" && !value.isSelectionField) {
        return value.sql;
      }
      const newValue = value.clone();
      newValue.isSelectionField = true;
      return newValue;
    }
    if ((0, import_entity.is)(value, import_sql.SQL)) {
      if (this.config.sqlBehavior === "sql") {
        return value;
      }
      throw new Error(
        `You tried to reference "${prop}" field from a subquery, which is a raw SQL field, but it doesn't have an alias declared. Please add an alias to the field using ".as('alias')" method.`
      );
    }
    if ((0, import_entity.is)(value, import_column.Column)) {
      if (this.config.alias) {
        return new Proxy(
          value,
          new import_alias.ColumnAliasProxyHandler(
            new Proxy(
              value.table,
              new import_alias.TableAliasProxyHandler(this.config.alias, this.config.replaceOriginalName ?? false)
            )
          )
        );
      }
      return value;
    }
    if (typeof value !== "object" || value === null) {
      return value;
    }
    return new Proxy(value, new SelectionProxyHandler(this.config));
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SelectionProxyHandler
});
//# sourceMappingURL=selection-proxy.cjs.map
},
"drizzle-orm/alias.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var alias_exports = {};
__export(alias_exports, {
  ColumnAliasProxyHandler: () => ColumnAliasProxyHandler,
  RelationTableAliasProxyHandler: () => RelationTableAliasProxyHandler,
  TableAliasProxyHandler: () => TableAliasProxyHandler,
  aliasedRelation: () => aliasedRelation,
  aliasedTable: () => aliasedTable,
  aliasedTableColumn: () => aliasedTableColumn,
  mapColumnsInAliasedSQLToAlias: () => mapColumnsInAliasedSQLToAlias,
  mapColumnsInSQLToAlias: () => mapColumnsInSQLToAlias
});
module.exports = __toCommonJS(alias_exports);
var import_column = require("./column.cjs");
var import_entity = require("./entity.cjs");
var import_sql = require("./sql/sql.cjs");
var import_table = require("./table.cjs");
var import_view_common = require("./view-common.cjs");
class ColumnAliasProxyHandler {
  constructor(table) {
    this.table = table;
  }
  static [import_entity.entityKind] = "ColumnAliasProxyHandler";
  get(columnObj, prop) {
    if (prop === "table") {
      return this.table;
    }
    return columnObj[prop];
  }
}
class TableAliasProxyHandler {
  constructor(alias, replaceOriginalName) {
    this.alias = alias;
    this.replaceOriginalName = replaceOriginalName;
  }
  static [import_entity.entityKind] = "TableAliasProxyHandler";
  get(target, prop) {
    if (prop === import_table.Table.Symbol.IsAlias) {
      return true;
    }
    if (prop === import_table.Table.Symbol.Name) {
      return this.alias;
    }
    if (this.replaceOriginalName && prop === import_table.Table.Symbol.OriginalName) {
      return this.alias;
    }
    if (prop === import_view_common.ViewBaseConfig) {
      return {
        ...target[import_view_common.ViewBaseConfig],
        name: this.alias,
        isAlias: true
      };
    }
    if (prop === import_table.Table.Symbol.Columns) {
      const columns = target[import_table.Table.Symbol.Columns];
      if (!columns) {
        return columns;
      }
      const proxiedColumns = {};
      Object.keys(columns).map((key) => {
        proxiedColumns[key] = new Proxy(
          columns[key],
          new ColumnAliasProxyHandler(new Proxy(target, this))
        );
      });
      return proxiedColumns;
    }
    const value = target[prop];
    if ((0, import_entity.is)(value, import_column.Column)) {
      return new Proxy(value, new ColumnAliasProxyHandler(new Proxy(target, this)));
    }
    return value;
  }
}
class RelationTableAliasProxyHandler {
  constructor(alias) {
    this.alias = alias;
  }
  static [import_entity.entityKind] = "RelationTableAliasProxyHandler";
  get(target, prop) {
    if (prop === "sourceTable") {
      return aliasedTable(target.sourceTable, this.alias);
    }
    return target[prop];
  }
}
function aliasedTable(table, tableAlias) {
  return new Proxy(table, new TableAliasProxyHandler(tableAlias, false));
}
function aliasedRelation(relation, tableAlias) {
  return new Proxy(relation, new RelationTableAliasProxyHandler(tableAlias));
}
function aliasedTableColumn(column, tableAlias) {
  return new Proxy(
    column,
    new ColumnAliasProxyHandler(new Proxy(column.table, new TableAliasProxyHandler(tableAlias, false)))
  );
}
function mapColumnsInAliasedSQLToAlias(query, alias) {
  return new import_sql.SQL.Aliased(mapColumnsInSQLToAlias(query.sql, alias), query.fieldAlias);
}
function mapColumnsInSQLToAlias(query, alias) {
  return import_sql.sql.join(query.queryChunks.map((c) => {
    if ((0, import_entity.is)(c, import_column.Column)) {
      return aliasedTableColumn(c, alias);
    }
    if ((0, import_entity.is)(c, import_sql.SQL)) {
      return mapColumnsInSQLToAlias(c, alias);
    }
    if ((0, import_entity.is)(c, import_sql.SQL.Aliased)) {
      return mapColumnsInAliasedSQLToAlias(c, alias);
    }
    return c;
  }));
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ColumnAliasProxyHandler,
  RelationTableAliasProxyHandler,
  TableAliasProxyHandler,
  aliasedRelation,
  aliasedTable,
  aliasedTableColumn,
  mapColumnsInAliasedSQLToAlias,
  mapColumnsInSQLToAlias
});
//# sourceMappingURL=alias.cjs.map
},
"drizzle-orm/pg-core/query-builders/index.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var query_builders_exports = {};
module.exports = __toCommonJS(query_builders_exports);
__reExport(query_builders_exports, require("./delete.cjs"), module.exports);
__reExport(query_builders_exports, require("./insert.cjs"), module.exports);
__reExport(query_builders_exports, require("./query-builder.cjs"), module.exports);
__reExport(query_builders_exports, require("./refresh-materialized-view.cjs"), module.exports);
__reExport(query_builders_exports, require("./select.cjs"), module.exports);
__reExport(query_builders_exports, require("./select.types.cjs"), module.exports);
__reExport(query_builders_exports, require("./update.cjs"), module.exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ...require("./delete.cjs"),
  ...require("./insert.cjs"),
  ...require("./query-builder.cjs"),
  ...require("./refresh-materialized-view.cjs"),
  ...require("./select.cjs"),
  ...require("./select.types.cjs"),
  ...require("./update.cjs")
});
//# sourceMappingURL=index.cjs.map
},
"drizzle-orm/pg-core/query-builders/update.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var update_exports = {};
__export(update_exports, {
  PgUpdateBase: () => PgUpdateBase,
  PgUpdateBuilder: () => PgUpdateBuilder
});
module.exports = __toCommonJS(update_exports);
var import_entity = require("../../entity.cjs");
var import_table = require("../table.cjs");
var import_query_promise = require("../../query-promise.cjs");
var import_selection_proxy = require("../../selection-proxy.cjs");
var import_sql = require("../../sql/sql.cjs");
var import_subquery = require("../../subquery.cjs");
var import_table2 = require("../../table.cjs");
var import_utils = require("../../utils.cjs");
var import_view_common = require("../../view-common.cjs");
var import_utils2 = require("../utils.cjs");
class PgUpdateBuilder {
  constructor(table, session, dialect, withList) {
    this.table = table;
    this.session = session;
    this.dialect = dialect;
    this.withList = withList;
  }
  static [import_entity.entityKind] = "PgUpdateBuilder";
  authToken;
  setToken(token) {
    this.authToken = token;
    return this;
  }
  set(values) {
    return new PgUpdateBase(
      this.table,
      (0, import_utils.mapUpdateSet)(this.table, values),
      this.session,
      this.dialect,
      this.withList
    ).setToken(this.authToken);
  }
}
class PgUpdateBase extends import_query_promise.QueryPromise {
  constructor(table, set, session, dialect, withList) {
    super();
    this.session = session;
    this.dialect = dialect;
    this.config = { set, table, withList, joins: [] };
    this.tableName = (0, import_utils.getTableLikeName)(table);
    this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
  }
  static [import_entity.entityKind] = "PgUpdate";
  config;
  tableName;
  joinsNotNullableMap;
  cacheConfig;
  from(source) {
    const src = source;
    const tableName = (0, import_utils.getTableLikeName)(src);
    if (typeof tableName === "string") {
      this.joinsNotNullableMap[tableName] = true;
    }
    this.config.from = src;
    return this;
  }
  getTableLikeFields(table) {
    if ((0, import_entity.is)(table, import_table.PgTable)) {
      return table[import_table2.Table.Symbol.Columns];
    } else if ((0, import_entity.is)(table, import_subquery.Subquery)) {
      return table._.selectedFields;
    }
    return table[import_view_common.ViewBaseConfig].selectedFields;
  }
  createJoin(joinType) {
    return (table, on) => {
      const tableName = (0, import_utils.getTableLikeName)(table);
      if (typeof tableName === "string" && this.config.joins.some((join) => join.alias === tableName)) {
        throw new Error(`Alias "${tableName}" is already used in this query`);
      }
      if (typeof on === "function") {
        const from = this.config.from && !(0, import_entity.is)(this.config.from, import_sql.SQL) ? this.getTableLikeFields(this.config.from) : void 0;
        on = on(
          new Proxy(
            this.config.table[import_table2.Table.Symbol.Columns],
            new import_selection_proxy.SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
          ),
          from && new Proxy(
            from,
            new import_selection_proxy.SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
          )
        );
      }
      this.config.joins.push({ on, table, joinType, alias: tableName });
      if (typeof tableName === "string") {
        switch (joinType) {
          case "left": {
            this.joinsNotNullableMap[tableName] = false;
            break;
          }
          case "right": {
            this.joinsNotNullableMap = Object.fromEntries(
              Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
            );
            this.joinsNotNullableMap[tableName] = true;
            break;
          }
          case "inner": {
            this.joinsNotNullableMap[tableName] = true;
            break;
          }
          case "full": {
            this.joinsNotNullableMap = Object.fromEntries(
              Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
            );
            this.joinsNotNullableMap[tableName] = false;
            break;
          }
        }
      }
      return this;
    };
  }
  leftJoin = this.createJoin("left");
  rightJoin = this.createJoin("right");
  innerJoin = this.createJoin("inner");
  fullJoin = this.createJoin("full");
  /**
   * Adds a 'where' clause to the query.
   *
   * Calling this method will update only those rows that fulfill a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/update}
   *
   * @param where the 'where' clause.
   *
   * @example
   * You can use conditional operators and `sql function` to filter the rows to be updated.
   *
   * ```ts
   * // Update all cars with green color
   * await db.update(cars).set({ color: 'red' })
   *   .where(eq(cars.color, 'green'));
   * // or
   * await db.update(cars).set({ color: 'red' })
   *   .where(sql`${cars.color} = 'green'`)
   * ```
   *
   * You can logically combine conditional operators with `and()` and `or()` operators:
   *
   * ```ts
   * // Update all BMW cars with a green color
   * await db.update(cars).set({ color: 'red' })
   *   .where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
   *
   * // Update all cars with the green or blue color
   * await db.update(cars).set({ color: 'red' })
   *   .where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
   * ```
   */
  where(where) {
    this.config.where = where;
    return this;
  }
  returning(fields) {
    if (!fields) {
      fields = Object.assign({}, this.config.table[import_table2.Table.Symbol.Columns]);
      if (this.config.from) {
        const tableName = (0, import_utils.getTableLikeName)(this.config.from);
        if (typeof tableName === "string" && this.config.from && !(0, import_entity.is)(this.config.from, import_sql.SQL)) {
          const fromFields = this.getTableLikeFields(this.config.from);
          fields[tableName] = fromFields;
        }
        for (const join of this.config.joins) {
          const tableName2 = (0, import_utils.getTableLikeName)(join.table);
          if (typeof tableName2 === "string" && !(0, import_entity.is)(join.table, import_sql.SQL)) {
            const fromFields = this.getTableLikeFields(join.table);
            fields[tableName2] = fromFields;
          }
        }
      }
    }
    this.config.returningFields = fields;
    this.config.returning = (0, import_utils.orderSelectedFields)(fields);
    return this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildUpdateQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  /** @internal */
  _prepare(name) {
    const query = this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true, void 0, {
      type: "insert",
      tables: (0, import_utils2.extractUsedTable)(this.config.table)
    }, this.cacheConfig);
    query.joinsNotNullableMap = this.joinsNotNullableMap;
    return query;
  }
  prepare(name) {
    return this._prepare(name);
  }
  authToken;
  /** @internal */
  setToken(token) {
    this.authToken = token;
    return this;
  }
  execute = (placeholderValues) => {
    return this._prepare().execute(placeholderValues, this.authToken);
  };
  /** @internal */
  getSelectedFields() {
    return this.config.returningFields ? new Proxy(
      this.config.returningFields,
      new import_selection_proxy.SelectionProxyHandler({
        alias: (0, import_table2.getTableName)(this.config.table),
        sqlAliasedBehavior: "alias",
        sqlBehavior: "error"
      })
    ) : void 0;
  }
  $dynamic() {
    return this;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgUpdateBase,
  PgUpdateBuilder
});
//# sourceMappingURL=update.cjs.map
},
"drizzle-orm/pg-core/utils.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var utils_exports = {};
__export(utils_exports, {
  extractUsedTable: () => extractUsedTable,
  getMaterializedViewConfig: () => getMaterializedViewConfig,
  getTableConfig: () => getTableConfig,
  getViewConfig: () => getViewConfig
});
module.exports = __toCommonJS(utils_exports);
var import_entity = require("../entity.cjs");
var import_table = require("./table.cjs");
var import_sql = require("../sql/sql.cjs");
var import_subquery = require("../subquery.cjs");
var import_table2 = require("../table.cjs");
var import_view_common = require("../view-common.cjs");
var import_checks = require("./checks.cjs");
var import_foreign_keys = require("./foreign-keys.cjs");
var import_indexes = require("./indexes.cjs");
var import_policies = require("./policies.cjs");
var import_primary_keys = require("./primary-keys.cjs");
var import_unique_constraint = require("./unique-constraint.cjs");
var import_view_common2 = require("./view-common.cjs");
var import_view = require("./view.cjs");
function getTableConfig(table) {
  const columns = Object.values(table[import_table2.Table.Symbol.Columns]);
  const indexes = [];
  const checks = [];
  const primaryKeys = [];
  const foreignKeys = Object.values(table[import_table.PgTable.Symbol.InlineForeignKeys]);
  const uniqueConstraints = [];
  const name = table[import_table2.Table.Symbol.Name];
  const schema = table[import_table2.Table.Symbol.Schema];
  const policies = [];
  const enableRLS = table[import_table.PgTable.Symbol.EnableRLS];
  const extraConfigBuilder = table[import_table.PgTable.Symbol.ExtraConfigBuilder];
  if (extraConfigBuilder !== void 0) {
    const extraConfig = extraConfigBuilder(table[import_table2.Table.Symbol.ExtraConfigColumns]);
    const extraValues = Array.isArray(extraConfig) ? extraConfig.flat(1) : Object.values(extraConfig);
    for (const builder of extraValues) {
      if ((0, import_entity.is)(builder, import_indexes.IndexBuilder)) {
        indexes.push(builder.build(table));
      } else if ((0, import_entity.is)(builder, import_checks.CheckBuilder)) {
        checks.push(builder.build(table));
      } else if ((0, import_entity.is)(builder, import_unique_constraint.UniqueConstraintBuilder)) {
        uniqueConstraints.push(builder.build(table));
      } else if ((0, import_entity.is)(builder, import_primary_keys.PrimaryKeyBuilder)) {
        primaryKeys.push(builder.build(table));
      } else if ((0, import_entity.is)(builder, import_foreign_keys.ForeignKeyBuilder)) {
        foreignKeys.push(builder.build(table));
      } else if ((0, import_entity.is)(builder, import_policies.PgPolicy)) {
        policies.push(builder);
      }
    }
  }
  return {
    columns,
    indexes,
    foreignKeys,
    checks,
    primaryKeys,
    uniqueConstraints,
    name,
    schema,
    policies,
    enableRLS
  };
}
function extractUsedTable(table) {
  if ((0, import_entity.is)(table, import_table.PgTable)) {
    return [table[import_table2.Schema] ? `${table[import_table2.Schema]}.${table[import_table2.Table.Symbol.BaseName]}` : table[import_table2.Table.Symbol.BaseName]];
  }
  if ((0, import_entity.is)(table, import_subquery.Subquery)) {
    return table._.usedTables ?? [];
  }
  if ((0, import_entity.is)(table, import_sql.SQL)) {
    return table.usedTables ?? [];
  }
  return [];
}
function getViewConfig(view) {
  return {
    ...view[import_view_common.ViewBaseConfig],
    ...view[import_view_common2.PgViewConfig]
  };
}
function getMaterializedViewConfig(view) {
  return {
    ...view[import_view_common.ViewBaseConfig],
    ...view[import_view.PgMaterializedViewConfig]
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  extractUsedTable,
  getMaterializedViewConfig,
  getTableConfig,
  getViewConfig
});
//# sourceMappingURL=utils.cjs.map
},
"drizzle-orm/pg-core/view.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var view_exports = {};
__export(view_exports, {
  DefaultViewBuilderCore: () => DefaultViewBuilderCore,
  ManualMaterializedViewBuilder: () => ManualMaterializedViewBuilder,
  ManualViewBuilder: () => ManualViewBuilder,
  MaterializedViewBuilder: () => MaterializedViewBuilder,
  MaterializedViewBuilderCore: () => MaterializedViewBuilderCore,
  PgMaterializedView: () => PgMaterializedView,
  PgMaterializedViewConfig: () => PgMaterializedViewConfig,
  PgView: () => PgView,
  ViewBuilder: () => ViewBuilder,
  isPgMaterializedView: () => isPgMaterializedView,
  isPgView: () => isPgView,
  pgMaterializedView: () => pgMaterializedView,
  pgMaterializedViewWithSchema: () => pgMaterializedViewWithSchema,
  pgView: () => pgView,
  pgViewWithSchema: () => pgViewWithSchema
});
module.exports = __toCommonJS(view_exports);
var import_entity = require("../entity.cjs");
var import_selection_proxy = require("../selection-proxy.cjs");
var import_utils = require("../utils.cjs");
var import_query_builder = require("./query-builders/query-builder.cjs");
var import_table = require("./table.cjs");
var import_view_base = require("./view-base.cjs");
var import_view_common = require("./view-common.cjs");
class DefaultViewBuilderCore {
  constructor(name, schema) {
    this.name = name;
    this.schema = schema;
  }
  static [import_entity.entityKind] = "PgDefaultViewBuilderCore";
  config = {};
  with(config) {
    this.config.with = config;
    return this;
  }
}
class ViewBuilder extends DefaultViewBuilderCore {
  static [import_entity.entityKind] = "PgViewBuilder";
  as(qb) {
    if (typeof qb === "function") {
      qb = qb(new import_query_builder.QueryBuilder());
    }
    const selectionProxy = new import_selection_proxy.SelectionProxyHandler({
      alias: this.name,
      sqlBehavior: "error",
      sqlAliasedBehavior: "alias",
      replaceOriginalName: true
    });
    const aliasedSelection = new Proxy(qb.getSelectedFields(), selectionProxy);
    return new Proxy(
      new PgView({
        pgConfig: this.config,
        config: {
          name: this.name,
          schema: this.schema,
          selectedFields: aliasedSelection,
          query: qb.getSQL().inlineParams()
        }
      }),
      selectionProxy
    );
  }
}
class ManualViewBuilder extends DefaultViewBuilderCore {
  static [import_entity.entityKind] = "PgManualViewBuilder";
  columns;
  constructor(name, columns, schema) {
    super(name, schema);
    this.columns = (0, import_utils.getTableColumns)((0, import_table.pgTable)(name, columns));
  }
  existing() {
    return new Proxy(
      new PgView({
        pgConfig: void 0,
        config: {
          name: this.name,
          schema: this.schema,
          selectedFields: this.columns,
          query: void 0
        }
      }),
      new import_selection_proxy.SelectionProxyHandler({
        alias: this.name,
        sqlBehavior: "error",
        sqlAliasedBehavior: "alias",
        replaceOriginalName: true
      })
    );
  }
  as(query) {
    return new Proxy(
      new PgView({
        pgConfig: this.config,
        config: {
          name: this.name,
          schema: this.schema,
          selectedFields: this.columns,
          query: query.inlineParams()
        }
      }),
      new import_selection_proxy.SelectionProxyHandler({
        alias: this.name,
        sqlBehavior: "error",
        sqlAliasedBehavior: "alias",
        replaceOriginalName: true
      })
    );
  }
}
class MaterializedViewBuilderCore {
  constructor(name, schema) {
    this.name = name;
    this.schema = schema;
  }
  static [import_entity.entityKind] = "PgMaterializedViewBuilderCore";
  config = {};
  using(using) {
    this.config.using = using;
    return this;
  }
  with(config) {
    this.config.with = config;
    return this;
  }
  tablespace(tablespace) {
    this.config.tablespace = tablespace;
    return this;
  }
  withNoData() {
    this.config.withNoData = true;
    return this;
  }
}
class MaterializedViewBuilder extends MaterializedViewBuilderCore {
  static [import_entity.entityKind] = "PgMaterializedViewBuilder";
  as(qb) {
    if (typeof qb === "function") {
      qb = qb(new import_query_builder.QueryBuilder());
    }
    const selectionProxy = new import_selection_proxy.SelectionProxyHandler({
      alias: this.name,
      sqlBehavior: "error",
      sqlAliasedBehavior: "alias",
      replaceOriginalName: true
    });
    const aliasedSelection = new Proxy(qb.getSelectedFields(), selectionProxy);
    return new Proxy(
      new PgMaterializedView({
        pgConfig: {
          with: this.config.with,
          using: this.config.using,
          tablespace: this.config.tablespace,
          withNoData: this.config.withNoData
        },
        config: {
          name: this.name,
          schema: this.schema,
          selectedFields: aliasedSelection,
          query: qb.getSQL().inlineParams()
        }
      }),
      selectionProxy
    );
  }
}
class ManualMaterializedViewBuilder extends MaterializedViewBuilderCore {
  static [import_entity.entityKind] = "PgManualMaterializedViewBuilder";
  columns;
  constructor(name, columns, schema) {
    super(name, schema);
    this.columns = (0, import_utils.getTableColumns)((0, import_table.pgTable)(name, columns));
  }
  existing() {
    return new Proxy(
      new PgMaterializedView({
        pgConfig: {
          tablespace: this.config.tablespace,
          using: this.config.using,
          with: this.config.with,
          withNoData: this.config.withNoData
        },
        config: {
          name: this.name,
          schema: this.schema,
          selectedFields: this.columns,
          query: void 0
        }
      }),
      new import_selection_proxy.SelectionProxyHandler({
        alias: this.name,
        sqlBehavior: "error",
        sqlAliasedBehavior: "alias",
        replaceOriginalName: true
      })
    );
  }
  as(query) {
    return new Proxy(
      new PgMaterializedView({
        pgConfig: {
          tablespace: this.config.tablespace,
          using: this.config.using,
          with: this.config.with,
          withNoData: this.config.withNoData
        },
        config: {
          name: this.name,
          schema: this.schema,
          selectedFields: this.columns,
          query: query.inlineParams()
        }
      }),
      new import_selection_proxy.SelectionProxyHandler({
        alias: this.name,
        sqlBehavior: "error",
        sqlAliasedBehavior: "alias",
        replaceOriginalName: true
      })
    );
  }
}
class PgView extends import_view_base.PgViewBase {
  static [import_entity.entityKind] = "PgView";
  [import_view_common.PgViewConfig];
  constructor({ pgConfig, config }) {
    super(config);
    if (pgConfig) {
      this[import_view_common.PgViewConfig] = {
        with: pgConfig.with
      };
    }
  }
}
const PgMaterializedViewConfig = Symbol.for("drizzle:PgMaterializedViewConfig");
class PgMaterializedView extends import_view_base.PgViewBase {
  static [import_entity.entityKind] = "PgMaterializedView";
  [PgMaterializedViewConfig];
  constructor({ pgConfig, config }) {
    super(config);
    this[PgMaterializedViewConfig] = {
      with: pgConfig?.with,
      using: pgConfig?.using,
      tablespace: pgConfig?.tablespace,
      withNoData: pgConfig?.withNoData
    };
  }
}
function pgViewWithSchema(name, selection, schema) {
  if (selection) {
    return new ManualViewBuilder(name, selection, schema);
  }
  return new ViewBuilder(name, schema);
}
function pgMaterializedViewWithSchema(name, selection, schema) {
  if (selection) {
    return new ManualMaterializedViewBuilder(name, selection, schema);
  }
  return new MaterializedViewBuilder(name, schema);
}
function pgView(name, columns) {
  return pgViewWithSchema(name, columns, void 0);
}
function pgMaterializedView(name, columns) {
  return pgMaterializedViewWithSchema(name, columns, void 0);
}
function isPgView(obj) {
  return (0, import_entity.is)(obj, PgView);
}
function isPgMaterializedView(obj) {
  return (0, import_entity.is)(obj, PgMaterializedView);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DefaultViewBuilderCore,
  ManualMaterializedViewBuilder,
  ManualViewBuilder,
  MaterializedViewBuilder,
  MaterializedViewBuilderCore,
  PgMaterializedView,
  PgMaterializedViewConfig,
  PgView,
  ViewBuilder,
  isPgMaterializedView,
  isPgView,
  pgMaterializedView,
  pgMaterializedViewWithSchema,
  pgView,
  pgViewWithSchema
});
//# sourceMappingURL=view.cjs.map
},
"drizzle-orm/pg-core/view-base.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var view_base_exports = {};
__export(view_base_exports, {
  PgViewBase: () => PgViewBase
});
module.exports = __toCommonJS(view_base_exports);
var import_entity = require("../entity.cjs");
var import_sql = require("../sql/sql.cjs");
class PgViewBase extends import_sql.View {
  static [import_entity.entityKind] = "PgViewBase";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgViewBase
});
//# sourceMappingURL=view-base.cjs.map
},
"drizzle-orm/pg-core/view-common.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var view_common_exports = {};
__export(view_common_exports, {
  PgViewConfig: () => PgViewConfig
});
module.exports = __toCommonJS(view_common_exports);
const PgViewConfig = Symbol.for("drizzle:PgViewConfig");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgViewConfig
});
//# sourceMappingURL=view-common.cjs.map
},
"drizzle-orm/pg-core/policies.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var policies_exports = {};
__export(policies_exports, {
  PgPolicy: () => PgPolicy,
  pgPolicy: () => pgPolicy
});
module.exports = __toCommonJS(policies_exports);
var import_entity = require("../entity.cjs");
class PgPolicy {
  constructor(name, config) {
    this.name = name;
    if (config) {
      this.as = config.as;
      this.for = config.for;
      this.to = config.to;
      this.using = config.using;
      this.withCheck = config.withCheck;
    }
  }
  static [import_entity.entityKind] = "PgPolicy";
  as;
  for;
  to;
  using;
  withCheck;
  /** @internal */
  _linkedTable;
  link(table) {
    this._linkedTable = table;
    return this;
  }
}
function pgPolicy(name, config) {
  return new PgPolicy(name, config);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgPolicy,
  pgPolicy
});
//# sourceMappingURL=policies.cjs.map
},
"drizzle-orm/pg-core/indexes.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var indexes_exports = {};
__export(indexes_exports, {
  Index: () => Index,
  IndexBuilder: () => IndexBuilder,
  IndexBuilderOn: () => IndexBuilderOn,
  index: () => index,
  uniqueIndex: () => uniqueIndex
});
module.exports = __toCommonJS(indexes_exports);
var import_sql = require("../sql/sql.cjs");
var import_entity = require("../entity.cjs");
var import_columns = require("./columns/index.cjs");
class IndexBuilderOn {
  constructor(unique, name) {
    this.unique = unique;
    this.name = name;
  }
  static [import_entity.entityKind] = "PgIndexBuilderOn";
  on(...columns) {
    return new IndexBuilder(
      columns.map((it) => {
        if ((0, import_entity.is)(it, import_sql.SQL)) {
          return it;
        }
        it = it;
        const clonedIndexedColumn = new import_columns.IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
        it.indexConfig = JSON.parse(JSON.stringify(it.defaultConfig));
        return clonedIndexedColumn;
      }),
      this.unique,
      false,
      this.name
    );
  }
  onOnly(...columns) {
    return new IndexBuilder(
      columns.map((it) => {
        if ((0, import_entity.is)(it, import_sql.SQL)) {
          return it;
        }
        it = it;
        const clonedIndexedColumn = new import_columns.IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
        it.indexConfig = it.defaultConfig;
        return clonedIndexedColumn;
      }),
      this.unique,
      true,
      this.name
    );
  }
  /**
   * Specify what index method to use. Choices are `btree`, `hash`, `gist`, `spgist`, `gin`, `brin`, or user-installed access methods like `bloom`. The default method is `btree.
   *
   * If you have the `pg_vector` extension installed in your database, you can use the `hnsw` and `ivfflat` options, which are predefined types.
   *
   * **You can always specify any string you want in the method, in case Drizzle doesn't have it natively in its types**
   *
   * @param method The name of the index method to be used
   * @param columns
   * @returns
   */
  using(method, ...columns) {
    return new IndexBuilder(
      columns.map((it) => {
        if ((0, import_entity.is)(it, import_sql.SQL)) {
          return it;
        }
        it = it;
        const clonedIndexedColumn = new import_columns.IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
        it.indexConfig = JSON.parse(JSON.stringify(it.defaultConfig));
        return clonedIndexedColumn;
      }),
      this.unique,
      true,
      this.name,
      method
    );
  }
}
class IndexBuilder {
  static [import_entity.entityKind] = "PgIndexBuilder";
  /** @internal */
  config;
  constructor(columns, unique, only, name, method = "btree") {
    this.config = {
      name,
      columns,
      unique,
      only,
      method
    };
  }
  concurrently() {
    this.config.concurrently = true;
    return this;
  }
  with(obj) {
    this.config.with = obj;
    return this;
  }
  where(condition) {
    this.config.where = condition;
    return this;
  }
  /** @internal */
  build(table) {
    return new Index(this.config, table);
  }
}
class Index {
  static [import_entity.entityKind] = "PgIndex";
  config;
  constructor(config, table) {
    this.config = { ...config, table };
  }
}
function index(name) {
  return new IndexBuilderOn(false, name);
}
function uniqueIndex(name) {
  return new IndexBuilderOn(true, name);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Index,
  IndexBuilder,
  IndexBuilderOn,
  index,
  uniqueIndex
});
//# sourceMappingURL=indexes.cjs.map
},
"drizzle-orm/pg-core/columns/index.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var columns_exports = {};
module.exports = __toCommonJS(columns_exports);
__reExport(columns_exports, require("./bigint.cjs"), module.exports);
__reExport(columns_exports, require("./bigserial.cjs"), module.exports);
__reExport(columns_exports, require("./boolean.cjs"), module.exports);
__reExport(columns_exports, require("./char.cjs"), module.exports);
__reExport(columns_exports, require("./cidr.cjs"), module.exports);
__reExport(columns_exports, require("./common.cjs"), module.exports);
__reExport(columns_exports, require("./custom.cjs"), module.exports);
__reExport(columns_exports, require("./date.cjs"), module.exports);
__reExport(columns_exports, require("./double-precision.cjs"), module.exports);
__reExport(columns_exports, require("./enum.cjs"), module.exports);
__reExport(columns_exports, require("./inet.cjs"), module.exports);
__reExport(columns_exports, require("./int.common.cjs"), module.exports);
__reExport(columns_exports, require("./integer.cjs"), module.exports);
__reExport(columns_exports, require("./interval.cjs"), module.exports);
__reExport(columns_exports, require("./json.cjs"), module.exports);
__reExport(columns_exports, require("./jsonb.cjs"), module.exports);
__reExport(columns_exports, require("./line.cjs"), module.exports);
__reExport(columns_exports, require("./macaddr.cjs"), module.exports);
__reExport(columns_exports, require("./macaddr8.cjs"), module.exports);
__reExport(columns_exports, require("./numeric.cjs"), module.exports);
__reExport(columns_exports, require("./point.cjs"), module.exports);
__reExport(columns_exports, require("./postgis_extension/geometry.cjs"), module.exports);
__reExport(columns_exports, require("./real.cjs"), module.exports);
__reExport(columns_exports, require("./serial.cjs"), module.exports);
__reExport(columns_exports, require("./smallint.cjs"), module.exports);
__reExport(columns_exports, require("./smallserial.cjs"), module.exports);
__reExport(columns_exports, require("./text.cjs"), module.exports);
__reExport(columns_exports, require("./time.cjs"), module.exports);
__reExport(columns_exports, require("./timestamp.cjs"), module.exports);
__reExport(columns_exports, require("./uuid.cjs"), module.exports);
__reExport(columns_exports, require("./varchar.cjs"), module.exports);
__reExport(columns_exports, require("./vector_extension/bit.cjs"), module.exports);
__reExport(columns_exports, require("./vector_extension/halfvec.cjs"), module.exports);
__reExport(columns_exports, require("./vector_extension/sparsevec.cjs"), module.exports);
__reExport(columns_exports, require("./vector_extension/vector.cjs"), module.exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ...require("./bigint.cjs"),
  ...require("./bigserial.cjs"),
  ...require("./boolean.cjs"),
  ...require("./char.cjs"),
  ...require("./cidr.cjs"),
  ...require("./common.cjs"),
  ...require("./custom.cjs"),
  ...require("./date.cjs"),
  ...require("./double-precision.cjs"),
  ...require("./enum.cjs"),
  ...require("./inet.cjs"),
  ...require("./int.common.cjs"),
  ...require("./integer.cjs"),
  ...require("./interval.cjs"),
  ...require("./json.cjs"),
  ...require("./jsonb.cjs"),
  ...require("./line.cjs"),
  ...require("./macaddr.cjs"),
  ...require("./macaddr8.cjs"),
  ...require("./numeric.cjs"),
  ...require("./point.cjs"),
  ...require("./postgis_extension/geometry.cjs"),
  ...require("./real.cjs"),
  ...require("./serial.cjs"),
  ...require("./smallint.cjs"),
  ...require("./smallserial.cjs"),
  ...require("./text.cjs"),
  ...require("./time.cjs"),
  ...require("./timestamp.cjs"),
  ...require("./uuid.cjs"),
  ...require("./varchar.cjs"),
  ...require("./vector_extension/bit.cjs"),
  ...require("./vector_extension/halfvec.cjs"),
  ...require("./vector_extension/sparsevec.cjs"),
  ...require("./vector_extension/vector.cjs")
});
//# sourceMappingURL=index.cjs.map
},
"drizzle-orm/pg-core/checks.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var checks_exports = {};
__export(checks_exports, {
  Check: () => Check,
  CheckBuilder: () => CheckBuilder,
  check: () => check
});
module.exports = __toCommonJS(checks_exports);
var import_entity = require("../entity.cjs");
class CheckBuilder {
  constructor(name, value) {
    this.name = name;
    this.value = value;
  }
  static [import_entity.entityKind] = "PgCheckBuilder";
  brand;
  /** @internal */
  build(table) {
    return new Check(table, this);
  }
}
class Check {
  constructor(table, builder) {
    this.table = table;
    this.name = builder.name;
    this.value = builder.value;
  }
  static [import_entity.entityKind] = "PgCheck";
  name;
  value;
}
function check(name, value) {
  return new CheckBuilder(name, value);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Check,
  CheckBuilder,
  check
});
//# sourceMappingURL=checks.cjs.map
},
"drizzle-orm/pg-core/query-builders/select.types.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var select_types_exports = {};
module.exports = __toCommonJS(select_types_exports);
//# sourceMappingURL=select.types.cjs.map
},
"drizzle-orm/pg-core/query-builders/select.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except2, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except2)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var select_exports = {};
__export(select_exports, {
  PgSelectBase: () => PgSelectBase,
  PgSelectBuilder: () => PgSelectBuilder,
  PgSelectQueryBuilderBase: () => PgSelectQueryBuilderBase,
  except: () => except,
  exceptAll: () => exceptAll,
  intersect: () => intersect,
  intersectAll: () => intersectAll,
  union: () => union,
  unionAll: () => unionAll
});
module.exports = __toCommonJS(select_exports);
var import_entity = require("../../entity.cjs");
var import_view_base = require("../view-base.cjs");
var import_query_builder = require("../../query-builders/query-builder.cjs");
var import_query_promise = require("../../query-promise.cjs");
var import_selection_proxy = require("../../selection-proxy.cjs");
var import_sql = require("../../sql/sql.cjs");
var import_subquery = require("../../subquery.cjs");
var import_table = require("../../table.cjs");
var import_tracing = require("../../tracing.cjs");
var import_utils = require("../../utils.cjs");
var import_utils2 = require("../../utils.cjs");
var import_view_common = require("../../view-common.cjs");
var import_utils3 = require("../utils.cjs");
class PgSelectBuilder {
  static [import_entity.entityKind] = "PgSelectBuilder";
  fields;
  session;
  dialect;
  withList = [];
  distinct;
  constructor(config) {
    this.fields = config.fields;
    this.session = config.session;
    this.dialect = config.dialect;
    if (config.withList) {
      this.withList = config.withList;
    }
    this.distinct = config.distinct;
  }
  authToken;
  /** @internal */
  setToken(token) {
    this.authToken = token;
    return this;
  }
  /**
   * Specify the table, subquery, or other target that you're
   * building a select query against.
   *
   * {@link https://www.postgresql.org/docs/current/sql-select.html#SQL-FROM | Postgres from documentation}
   */
  from(source) {
    const isPartialSelect = !!this.fields;
    const src = source;
    let fields;
    if (this.fields) {
      fields = this.fields;
    } else if ((0, import_entity.is)(src, import_subquery.Subquery)) {
      fields = Object.fromEntries(
        Object.keys(src._.selectedFields).map((key) => [key, src[key]])
      );
    } else if ((0, import_entity.is)(src, import_view_base.PgViewBase)) {
      fields = src[import_view_common.ViewBaseConfig].selectedFields;
    } else if ((0, import_entity.is)(src, import_sql.SQL)) {
      fields = {};
    } else {
      fields = (0, import_utils.getTableColumns)(src);
    }
    return new PgSelectBase({
      table: src,
      fields,
      isPartialSelect,
      session: this.session,
      dialect: this.dialect,
      withList: this.withList,
      distinct: this.distinct
    }).setToken(this.authToken);
  }
}
class PgSelectQueryBuilderBase extends import_query_builder.TypedQueryBuilder {
  static [import_entity.entityKind] = "PgSelectQueryBuilder";
  _;
  config;
  joinsNotNullableMap;
  tableName;
  isPartialSelect;
  session;
  dialect;
  cacheConfig = void 0;
  usedTables = /* @__PURE__ */ new Set();
  constructor({ table, fields, isPartialSelect, session, dialect, withList, distinct }) {
    super();
    this.config = {
      withList,
      table,
      fields: { ...fields },
      distinct,
      setOperators: []
    };
    this.isPartialSelect = isPartialSelect;
    this.session = session;
    this.dialect = dialect;
    this._ = {
      selectedFields: fields,
      config: this.config
    };
    this.tableName = (0, import_utils.getTableLikeName)(table);
    this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
    for (const item of (0, import_utils3.extractUsedTable)(table)) this.usedTables.add(item);
  }
  /** @internal */
  getUsedTables() {
    return [...this.usedTables];
  }
  createJoin(joinType, lateral) {
    return (table, on) => {
      const baseTableName = this.tableName;
      const tableName = (0, import_utils.getTableLikeName)(table);
      for (const item of (0, import_utils3.extractUsedTable)(table)) this.usedTables.add(item);
      if (typeof tableName === "string" && this.config.joins?.some((join) => join.alias === tableName)) {
        throw new Error(`Alias "${tableName}" is already used in this query`);
      }
      if (!this.isPartialSelect) {
        if (Object.keys(this.joinsNotNullableMap).length === 1 && typeof baseTableName === "string") {
          this.config.fields = {
            [baseTableName]: this.config.fields
          };
        }
        if (typeof tableName === "string" && !(0, import_entity.is)(table, import_sql.SQL)) {
          const selection = (0, import_entity.is)(table, import_subquery.Subquery) ? table._.selectedFields : (0, import_entity.is)(table, import_sql.View) ? table[import_view_common.ViewBaseConfig].selectedFields : table[import_table.Table.Symbol.Columns];
          this.config.fields[tableName] = selection;
        }
      }
      if (typeof on === "function") {
        on = on(
          new Proxy(
            this.config.fields,
            new import_selection_proxy.SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
          )
        );
      }
      if (!this.config.joins) {
        this.config.joins = [];
      }
      this.config.joins.push({ on, table, joinType, alias: tableName, lateral });
      if (typeof tableName === "string") {
        switch (joinType) {
          case "left": {
            this.joinsNotNullableMap[tableName] = false;
            break;
          }
          case "right": {
            this.joinsNotNullableMap = Object.fromEntries(
              Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
            );
            this.joinsNotNullableMap[tableName] = true;
            break;
          }
          case "cross":
          case "inner": {
            this.joinsNotNullableMap[tableName] = true;
            break;
          }
          case "full": {
            this.joinsNotNullableMap = Object.fromEntries(
              Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
            );
            this.joinsNotNullableMap[tableName] = false;
            break;
          }
        }
      }
      return this;
    };
  }
  /**
   * Executes a `left join` operation by adding another table to the current query.
   *
   * Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#left-join}
   *
   * @param table the table to join.
   * @param on the `on` clause.
   *
   * @example
   *
   * ```ts
   * // Select all users and their pets
   * const usersWithPets: { user: User; pets: Pet | null; }[] = await db.select()
   *   .from(users)
   *   .leftJoin(pets, eq(users.id, pets.ownerId))
   *
   * // Select userId and petId
   * const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
   *   userId: users.id,
   *   petId: pets.id,
   * })
   *   .from(users)
   *   .leftJoin(pets, eq(users.id, pets.ownerId))
   * ```
   */
  leftJoin = this.createJoin("left", false);
  /**
   * Executes a `left join lateral` operation by adding subquery to the current query.
   *
   * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
   *
   * Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#left-join-lateral}
   *
   * @param table the subquery to join.
   * @param on the `on` clause.
   */
  leftJoinLateral = this.createJoin("left", true);
  /**
   * Executes a `right join` operation by adding another table to the current query.
   *
   * Calling this method associates each row of the joined table with the corresponding row from the main table, if a match is found. If no matching row exists, it sets all columns of the main table to null.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#right-join}
   *
   * @param table the table to join.
   * @param on the `on` clause.
   *
   * @example
   *
   * ```ts
   * // Select all users and their pets
   * const usersWithPets: { user: User | null; pets: Pet; }[] = await db.select()
   *   .from(users)
   *   .rightJoin(pets, eq(users.id, pets.ownerId))
   *
   * // Select userId and petId
   * const usersIdsAndPetIds: { userId: number | null; petId: number; }[] = await db.select({
   *   userId: users.id,
   *   petId: pets.id,
   * })
   *   .from(users)
   *   .rightJoin(pets, eq(users.id, pets.ownerId))
   * ```
   */
  rightJoin = this.createJoin("right", false);
  /**
   * Executes an `inner join` operation, creating a new table by combining rows from two tables that have matching values.
   *
   * Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#inner-join}
   *
   * @param table the table to join.
   * @param on the `on` clause.
   *
   * @example
   *
   * ```ts
   * // Select all users and their pets
   * const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
   *   .from(users)
   *   .innerJoin(pets, eq(users.id, pets.ownerId))
   *
   * // Select userId and petId
   * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
   *   userId: users.id,
   *   petId: pets.id,
   * })
   *   .from(users)
   *   .innerJoin(pets, eq(users.id, pets.ownerId))
   * ```
   */
  innerJoin = this.createJoin("inner", false);
  /**
   * Executes an `inner join lateral` operation, creating a new table by combining rows from two queries that have matching values.
   *
   * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
   *
   * Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#inner-join-lateral}
   *
   * @param table the subquery to join.
   * @param on the `on` clause.
   */
  innerJoinLateral = this.createJoin("inner", true);
  /**
   * Executes a `full join` operation by combining rows from two tables into a new table.
   *
   * Calling this method retrieves all rows from both main and joined tables, merging rows with matching values and filling in `null` for non-matching columns.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#full-join}
   *
   * @param table the table to join.
   * @param on the `on` clause.
   *
   * @example
   *
   * ```ts
   * // Select all users and their pets
   * const usersWithPets: { user: User | null; pets: Pet | null; }[] = await db.select()
   *   .from(users)
   *   .fullJoin(pets, eq(users.id, pets.ownerId))
   *
   * // Select userId and petId
   * const usersIdsAndPetIds: { userId: number | null; petId: number | null; }[] = await db.select({
   *   userId: users.id,
   *   petId: pets.id,
   * })
   *   .from(users)
   *   .fullJoin(pets, eq(users.id, pets.ownerId))
   * ```
   */
  fullJoin = this.createJoin("full", false);
  /**
   * Executes a `cross join` operation by combining rows from two tables into a new table.
   *
   * Calling this method retrieves all rows from both main and joined tables, merging all rows from each table.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#cross-join}
   *
   * @param table the table to join.
   *
   * @example
   *
   * ```ts
   * // Select all users, each user with every pet
   * const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
   *   .from(users)
   *   .crossJoin(pets)
   *
   * // Select userId and petId
   * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
   *   userId: users.id,
   *   petId: pets.id,
   * })
   *   .from(users)
   *   .crossJoin(pets)
   * ```
   */
  crossJoin = this.createJoin("cross", false);
  /**
   * Executes a `cross join lateral` operation by combining rows from two queries into a new table.
   *
   * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
   *
   * Calling this method retrieves all rows from both main and joined queries, merging all rows from each query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#cross-join-lateral}
   *
   * @param table the query to join.
   */
  crossJoinLateral = this.createJoin("cross", true);
  createSetOperator(type, isAll) {
    return (rightSelection) => {
      const rightSelect = typeof rightSelection === "function" ? rightSelection(getPgSetOperators()) : rightSelection;
      if (!(0, import_utils.haveSameKeys)(this.getSelectedFields(), rightSelect.getSelectedFields())) {
        throw new Error(
          "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
        );
      }
      this.config.setOperators.push({ type, isAll, rightSelect });
      return this;
    };
  }
  /**
   * Adds `union` set operator to the query.
   *
   * Calling this method will combine the result sets of the `select` statements and remove any duplicate rows that appear across them.
   *
   * See docs: {@link https://orm.drizzle.team/docs/set-operations#union}
   *
   * @example
   *
   * ```ts
   * // Select all unique names from customers and users tables
   * await db.select({ name: users.name })
   *   .from(users)
   *   .union(
   *     db.select({ name: customers.name }).from(customers)
   *   );
   * // or
   * import { union } from 'drizzle-orm/pg-core'
   *
   * await union(
   *   db.select({ name: users.name }).from(users),
   *   db.select({ name: customers.name }).from(customers)
   * );
   * ```
   */
  union = this.createSetOperator("union", false);
  /**
   * Adds `union all` set operator to the query.
   *
   * Calling this method will combine the result-set of the `select` statements and keep all duplicate rows that appear across them.
   *
   * See docs: {@link https://orm.drizzle.team/docs/set-operations#union-all}
   *
   * @example
   *
   * ```ts
   * // Select all transaction ids from both online and in-store sales
   * await db.select({ transaction: onlineSales.transactionId })
   *   .from(onlineSales)
   *   .unionAll(
   *     db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
   *   );
   * // or
   * import { unionAll } from 'drizzle-orm/pg-core'
   *
   * await unionAll(
   *   db.select({ transaction: onlineSales.transactionId }).from(onlineSales),
   *   db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
   * );
   * ```
   */
  unionAll = this.createSetOperator("union", true);
  /**
   * Adds `intersect` set operator to the query.
   *
   * Calling this method will retain only the rows that are present in both result sets and eliminate duplicates.
   *
   * See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect}
   *
   * @example
   *
   * ```ts
   * // Select course names that are offered in both departments A and B
   * await db.select({ courseName: depA.courseName })
   *   .from(depA)
   *   .intersect(
   *     db.select({ courseName: depB.courseName }).from(depB)
   *   );
   * // or
   * import { intersect } from 'drizzle-orm/pg-core'
   *
   * await intersect(
   *   db.select({ courseName: depA.courseName }).from(depA),
   *   db.select({ courseName: depB.courseName }).from(depB)
   * );
   * ```
   */
  intersect = this.createSetOperator("intersect", false);
  /**
   * Adds `intersect all` set operator to the query.
   *
   * Calling this method will retain only the rows that are present in both result sets including all duplicates.
   *
   * See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect-all}
   *
   * @example
   *
   * ```ts
   * // Select all products and quantities that are ordered by both regular and VIP customers
   * await db.select({
   *   productId: regularCustomerOrders.productId,
   *   quantityOrdered: regularCustomerOrders.quantityOrdered
   * })
   * .from(regularCustomerOrders)
   * .intersectAll(
   *   db.select({
   *     productId: vipCustomerOrders.productId,
   *     quantityOrdered: vipCustomerOrders.quantityOrdered
   *   })
   *   .from(vipCustomerOrders)
   * );
   * // or
   * import { intersectAll } from 'drizzle-orm/pg-core'
   *
   * await intersectAll(
   *   db.select({
   *     productId: regularCustomerOrders.productId,
   *     quantityOrdered: regularCustomerOrders.quantityOrdered
   *   })
   *   .from(regularCustomerOrders),
   *   db.select({
   *     productId: vipCustomerOrders.productId,
   *     quantityOrdered: vipCustomerOrders.quantityOrdered
   *   })
   *   .from(vipCustomerOrders)
   * );
   * ```
   */
  intersectAll = this.createSetOperator("intersect", true);
  /**
   * Adds `except` set operator to the query.
   *
   * Calling this method will retrieve all unique rows from the left query, except for the rows that are present in the result set of the right query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/set-operations#except}
   *
   * @example
   *
   * ```ts
   * // Select all courses offered in department A but not in department B
   * await db.select({ courseName: depA.courseName })
   *   .from(depA)
   *   .except(
   *     db.select({ courseName: depB.courseName }).from(depB)
   *   );
   * // or
   * import { except } from 'drizzle-orm/pg-core'
   *
   * await except(
   *   db.select({ courseName: depA.courseName }).from(depA),
   *   db.select({ courseName: depB.courseName }).from(depB)
   * );
   * ```
   */
  except = this.createSetOperator("except", false);
  /**
   * Adds `except all` set operator to the query.
   *
   * Calling this method will retrieve all rows from the left query, except for the rows that are present in the result set of the right query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/set-operations#except-all}
   *
   * @example
   *
   * ```ts
   * // Select all products that are ordered by regular customers but not by VIP customers
   * await db.select({
   *   productId: regularCustomerOrders.productId,
   *   quantityOrdered: regularCustomerOrders.quantityOrdered,
   * })
   * .from(regularCustomerOrders)
   * .exceptAll(
   *   db.select({
   *     productId: vipCustomerOrders.productId,
   *     quantityOrdered: vipCustomerOrders.quantityOrdered,
   *   })
   *   .from(vipCustomerOrders)
   * );
   * // or
   * import { exceptAll } from 'drizzle-orm/pg-core'
   *
   * await exceptAll(
   *   db.select({
   *     productId: regularCustomerOrders.productId,
   *     quantityOrdered: regularCustomerOrders.quantityOrdered
   *   })
   *   .from(regularCustomerOrders),
   *   db.select({
   *     productId: vipCustomerOrders.productId,
   *     quantityOrdered: vipCustomerOrders.quantityOrdered
   *   })
   *   .from(vipCustomerOrders)
   * );
   * ```
   */
  exceptAll = this.createSetOperator("except", true);
  /** @internal */
  addSetOperators(setOperators) {
    this.config.setOperators.push(...setOperators);
    return this;
  }
  /**
   * Adds a `where` clause to the query.
   *
   * Calling this method will select only those rows that fulfill a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#filtering}
   *
   * @param where the `where` clause.
   *
   * @example
   * You can use conditional operators and `sql function` to filter the rows to be selected.
   *
   * ```ts
   * // Select all cars with green color
   * await db.select().from(cars).where(eq(cars.color, 'green'));
   * // or
   * await db.select().from(cars).where(sql`${cars.color} = 'green'`)
   * ```
   *
   * You can logically combine conditional operators with `and()` and `or()` operators:
   *
   * ```ts
   * // Select all BMW cars with a green color
   * await db.select().from(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
   *
   * // Select all cars with the green or blue color
   * await db.select().from(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
   * ```
   */
  where(where) {
    if (typeof where === "function") {
      where = where(
        new Proxy(
          this.config.fields,
          new import_selection_proxy.SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
        )
      );
    }
    this.config.where = where;
    return this;
  }
  /**
   * Adds a `having` clause to the query.
   *
   * Calling this method will select only those rows that fulfill a specified condition. It is typically used with aggregate functions to filter the aggregated data based on a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#aggregations}
   *
   * @param having the `having` clause.
   *
   * @example
   *
   * ```ts
   * // Select all brands with more than one car
   * await db.select({
   * 	brand: cars.brand,
   * 	count: sql<number>`cast(count(${cars.id}) as int)`,
   * })
   *   .from(cars)
   *   .groupBy(cars.brand)
   *   .having(({ count }) => gt(count, 1));
   * ```
   */
  having(having) {
    if (typeof having === "function") {
      having = having(
        new Proxy(
          this.config.fields,
          new import_selection_proxy.SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
        )
      );
    }
    this.config.having = having;
    return this;
  }
  groupBy(...columns) {
    if (typeof columns[0] === "function") {
      const groupBy = columns[0](
        new Proxy(
          this.config.fields,
          new import_selection_proxy.SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
        )
      );
      this.config.groupBy = Array.isArray(groupBy) ? groupBy : [groupBy];
    } else {
      this.config.groupBy = columns;
    }
    return this;
  }
  orderBy(...columns) {
    if (typeof columns[0] === "function") {
      const orderBy = columns[0](
        new Proxy(
          this.config.fields,
          new import_selection_proxy.SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
        )
      );
      const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
      if (this.config.setOperators.length > 0) {
        this.config.setOperators.at(-1).orderBy = orderByArray;
      } else {
        this.config.orderBy = orderByArray;
      }
    } else {
      const orderByArray = columns;
      if (this.config.setOperators.length > 0) {
        this.config.setOperators.at(-1).orderBy = orderByArray;
      } else {
        this.config.orderBy = orderByArray;
      }
    }
    return this;
  }
  /**
   * Adds a `limit` clause to the query.
   *
   * Calling this method will set the maximum number of rows that will be returned by this query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
   *
   * @param limit the `limit` clause.
   *
   * @example
   *
   * ```ts
   * // Get the first 10 people from this query.
   * await db.select().from(people).limit(10);
   * ```
   */
  limit(limit) {
    if (this.config.setOperators.length > 0) {
      this.config.setOperators.at(-1).limit = limit;
    } else {
      this.config.limit = limit;
    }
    return this;
  }
  /**
   * Adds an `offset` clause to the query.
   *
   * Calling this method will skip a number of rows when returning results from this query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
   *
   * @param offset the `offset` clause.
   *
   * @example
   *
   * ```ts
   * // Get the 10th-20th people from this query.
   * await db.select().from(people).offset(10).limit(10);
   * ```
   */
  offset(offset) {
    if (this.config.setOperators.length > 0) {
      this.config.setOperators.at(-1).offset = offset;
    } else {
      this.config.offset = offset;
    }
    return this;
  }
  /**
   * Adds a `for` clause to the query.
   *
   * Calling this method will specify a lock strength for this query that controls how strictly it acquires exclusive access to the rows being queried.
   *
   * See docs: {@link https://www.postgresql.org/docs/current/sql-select.html#SQL-FOR-UPDATE-SHARE}
   *
   * @param strength the lock strength.
   * @param config the lock configuration.
   */
  for(strength, config = {}) {
    this.config.lockingClause = { strength, config };
    return this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildSelectQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  as(alias) {
    const usedTables = [];
    usedTables.push(...(0, import_utils3.extractUsedTable)(this.config.table));
    if (this.config.joins) {
      for (const it of this.config.joins) usedTables.push(...(0, import_utils3.extractUsedTable)(it.table));
    }
    return new Proxy(
      new import_subquery.Subquery(this.getSQL(), this.config.fields, alias, false, [...new Set(usedTables)]),
      new import_selection_proxy.SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
    );
  }
  /** @internal */
  getSelectedFields() {
    return new Proxy(
      this.config.fields,
      new import_selection_proxy.SelectionProxyHandler({ alias: this.tableName, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
    );
  }
  $dynamic() {
    return this;
  }
  $withCache(config) {
    this.cacheConfig = config === void 0 ? { config: {}, enable: true, autoInvalidate: true } : config === false ? { enable: false } : { enable: true, autoInvalidate: true, ...config };
    return this;
  }
}
class PgSelectBase extends PgSelectQueryBuilderBase {
  static [import_entity.entityKind] = "PgSelect";
  /** @internal */
  _prepare(name) {
    const { session, config, dialect, joinsNotNullableMap, authToken, cacheConfig, usedTables } = this;
    if (!session) {
      throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
    }
    const { fields } = config;
    return import_tracing.tracer.startActiveSpan("drizzle.prepareQuery", () => {
      const fieldsList = (0, import_utils2.orderSelectedFields)(fields);
      const query = session.prepareQuery(dialect.sqlToQuery(this.getSQL()), fieldsList, name, true, void 0, {
        type: "select",
        tables: [...usedTables]
      }, cacheConfig);
      query.joinsNotNullableMap = joinsNotNullableMap;
      return query.setToken(authToken);
    });
  }
  /**
   * Create a prepared statement for this query. This allows
   * the database to remember this query for the given session
   * and call it by name, rather than specifying the full query.
   *
   * {@link https://www.postgresql.org/docs/current/sql-prepare.html | Postgres prepare documentation}
   */
  prepare(name) {
    return this._prepare(name);
  }
  authToken;
  /** @internal */
  setToken(token) {
    this.authToken = token;
    return this;
  }
  execute = (placeholderValues) => {
    return import_tracing.tracer.startActiveSpan("drizzle.operation", () => {
      return this._prepare().execute(placeholderValues, this.authToken);
    });
  };
}
(0, import_utils.applyMixins)(PgSelectBase, [import_query_promise.QueryPromise]);
function createSetOperator(type, isAll) {
  return (leftSelect, rightSelect, ...restSelects) => {
    const setOperators = [rightSelect, ...restSelects].map((select) => ({
      type,
      isAll,
      rightSelect: select
    }));
    for (const setOperator of setOperators) {
      if (!(0, import_utils.haveSameKeys)(leftSelect.getSelectedFields(), setOperator.rightSelect.getSelectedFields())) {
        throw new Error(
          "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
        );
      }
    }
    return leftSelect.addSetOperators(setOperators);
  };
}
const getPgSetOperators = () => ({
  union,
  unionAll,
  intersect,
  intersectAll,
  except,
  exceptAll
});
const union = createSetOperator("union", false);
const unionAll = createSetOperator("union", true);
const intersect = createSetOperator("intersect", false);
const intersectAll = createSetOperator("intersect", true);
const except = createSetOperator("except", false);
const exceptAll = createSetOperator("except", true);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgSelectBase,
  PgSelectBuilder,
  PgSelectQueryBuilderBase,
  except,
  exceptAll,
  intersect,
  intersectAll,
  union,
  unionAll
});
//# sourceMappingURL=select.cjs.map
},
"drizzle-orm/query-builders/query-builder.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var query_builder_exports = {};
__export(query_builder_exports, {
  TypedQueryBuilder: () => TypedQueryBuilder
});
module.exports = __toCommonJS(query_builder_exports);
var import_entity = require("../entity.cjs");
class TypedQueryBuilder {
  static [import_entity.entityKind] = "TypedQueryBuilder";
  /** @internal */
  getSelectedFields() {
    return this._.selectedFields;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TypedQueryBuilder
});
//# sourceMappingURL=query-builder.cjs.map
},
"drizzle-orm/pg-core/query-builders/query-builder.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var query_builder_exports = {};
__export(query_builder_exports, {
  QueryBuilder: () => QueryBuilder
});
module.exports = __toCommonJS(query_builder_exports);
var import_entity = require("../../entity.cjs");
var import_dialect = require("../dialect.cjs");
var import_selection_proxy = require("../../selection-proxy.cjs");
var import_subquery = require("../../subquery.cjs");
var import_select = require("./select.cjs");
class QueryBuilder {
  static [import_entity.entityKind] = "PgQueryBuilder";
  dialect;
  dialectConfig;
  constructor(dialect) {
    this.dialect = (0, import_entity.is)(dialect, import_dialect.PgDialect) ? dialect : void 0;
    this.dialectConfig = (0, import_entity.is)(dialect, import_dialect.PgDialect) ? void 0 : dialect;
  }
  $with = (alias, selection) => {
    const queryBuilder = this;
    const as = (qb) => {
      if (typeof qb === "function") {
        qb = qb(queryBuilder);
      }
      return new Proxy(
        new import_subquery.WithSubquery(
          qb.getSQL(),
          selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}),
          alias,
          true
        ),
        new import_selection_proxy.SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
      );
    };
    return { as };
  };
  with(...queries) {
    const self = this;
    function select(fields) {
      return new import_select.PgSelectBuilder({
        fields: fields ?? void 0,
        session: void 0,
        dialect: self.getDialect(),
        withList: queries
      });
    }
    function selectDistinct(fields) {
      return new import_select.PgSelectBuilder({
        fields: fields ?? void 0,
        session: void 0,
        dialect: self.getDialect(),
        distinct: true
      });
    }
    function selectDistinctOn(on, fields) {
      return new import_select.PgSelectBuilder({
        fields: fields ?? void 0,
        session: void 0,
        dialect: self.getDialect(),
        distinct: { on }
      });
    }
    return { select, selectDistinct, selectDistinctOn };
  }
  select(fields) {
    return new import_select.PgSelectBuilder({
      fields: fields ?? void 0,
      session: void 0,
      dialect: this.getDialect()
    });
  }
  selectDistinct(fields) {
    return new import_select.PgSelectBuilder({
      fields: fields ?? void 0,
      session: void 0,
      dialect: this.getDialect(),
      distinct: true
    });
  }
  selectDistinctOn(on, fields) {
    return new import_select.PgSelectBuilder({
      fields: fields ?? void 0,
      session: void 0,
      dialect: this.getDialect(),
      distinct: { on }
    });
  }
  // Lazy load dialect to avoid circular dependency
  getDialect() {
    if (!this.dialect) {
      this.dialect = new import_dialect.PgDialect(this.dialectConfig);
    }
    return this.dialect;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  QueryBuilder
});
//# sourceMappingURL=query-builder.cjs.map
},
"drizzle-orm/pg-core/dialect.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var dialect_exports = {};
__export(dialect_exports, {
  PgDialect: () => PgDialect
});
module.exports = __toCommonJS(dialect_exports);
var import_alias = require("../alias.cjs");
var import_casing = require("../casing.cjs");
var import_column = require("../column.cjs");
var import_entity = require("../entity.cjs");
var import_errors = require("../errors.cjs");
var import_columns = require("./columns/index.cjs");
var import_table = require("./table.cjs");
var import_relations = require("../relations.cjs");
var import_sql = require("../sql/index.cjs");
var import_sql2 = require("../sql/sql.cjs");
var import_subquery = require("../subquery.cjs");
var import_table2 = require("../table.cjs");
var import_utils = require("../utils.cjs");
var import_view_common = require("../view-common.cjs");
var import_view_base = require("./view-base.cjs");
class PgDialect {
  static [import_entity.entityKind] = "PgDialect";
  /** @internal */
  casing;
  constructor(config) {
    this.casing = new import_casing.CasingCache(config?.casing);
  }
  async migrate(migrations, session, config) {
    const migrationsTable = typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
    const migrationsSchema = typeof config === "string" ? "drizzle" : config.migrationsSchema ?? "drizzle";
    const migrationTableCreate = import_sql2.sql`
			CREATE TABLE IF NOT EXISTS ${import_sql2.sql.identifier(migrationsSchema)}.${import_sql2.sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at bigint
			)
		`;
    await session.execute(import_sql2.sql`CREATE SCHEMA IF NOT EXISTS ${import_sql2.sql.identifier(migrationsSchema)}`);
    await session.execute(migrationTableCreate);
    const dbMigrations = await session.all(
      import_sql2.sql`select id, hash, created_at from ${import_sql2.sql.identifier(migrationsSchema)}.${import_sql2.sql.identifier(migrationsTable)} order by created_at desc limit 1`
    );
    const lastDbMigration = dbMigrations[0];
    await session.transaction(async (tx) => {
      for await (const migration of migrations) {
        if (!lastDbMigration || Number(lastDbMigration.created_at) < migration.folderMillis) {
          for (const stmt of migration.sql) {
            await tx.execute(import_sql2.sql.raw(stmt));
          }
          await tx.execute(
            import_sql2.sql`insert into ${import_sql2.sql.identifier(migrationsSchema)}.${import_sql2.sql.identifier(migrationsTable)} ("hash", "created_at") values(${migration.hash}, ${migration.folderMillis})`
          );
        }
      }
    });
  }
  escapeName(name) {
    return `"${name.replace(/"/g, '""')}"`;
  }
  escapeParam(num) {
    return `$${num + 1}`;
  }
  escapeString(str) {
    return `'${str.replace(/'/g, "''")}'`;
  }
  buildWithCTE(queries) {
    if (!queries?.length) return void 0;
    const withSqlChunks = [import_sql2.sql`with `];
    for (const [i, w] of queries.entries()) {
      withSqlChunks.push(import_sql2.sql`${import_sql2.sql.identifier(w._.alias)} as (${w._.sql})`);
      if (i < queries.length - 1) {
        withSqlChunks.push(import_sql2.sql`, `);
      }
    }
    withSqlChunks.push(import_sql2.sql` `);
    return import_sql2.sql.join(withSqlChunks);
  }
  buildDeleteQuery({ table, where, returning, withList }) {
    const withSql = this.buildWithCTE(withList);
    const returningSql = returning ? import_sql2.sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
    const whereSql = where ? import_sql2.sql` where ${where}` : void 0;
    return import_sql2.sql`${withSql}delete from ${table}${whereSql}${returningSql}`;
  }
  buildUpdateSet(table, set) {
    const tableColumns = table[import_table2.Table.Symbol.Columns];
    const columnNames = Object.keys(tableColumns).filter(
      (colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0
    );
    const setSize = columnNames.length;
    return import_sql2.sql.join(columnNames.flatMap((colName, i) => {
      const col = tableColumns[colName];
      const onUpdateFnResult = col.onUpdateFn?.();
      const value = set[colName] ?? ((0, import_entity.is)(onUpdateFnResult, import_sql2.SQL) ? onUpdateFnResult : import_sql2.sql.param(onUpdateFnResult, col));
      const res = import_sql2.sql`${import_sql2.sql.identifier(this.casing.getColumnCasing(col))} = ${value}`;
      if (i < setSize - 1) {
        return [res, import_sql2.sql.raw(", ")];
      }
      return [res];
    }));
  }
  buildUpdateQuery({ table, set, where, returning, withList, from, joins }) {
    const withSql = this.buildWithCTE(withList);
    const tableName = table[import_table.PgTable.Symbol.Name];
    const tableSchema = table[import_table.PgTable.Symbol.Schema];
    const origTableName = table[import_table.PgTable.Symbol.OriginalName];
    const alias = tableName === origTableName ? void 0 : tableName;
    const tableSql = import_sql2.sql`${tableSchema ? import_sql2.sql`${import_sql2.sql.identifier(tableSchema)}.` : void 0}${import_sql2.sql.identifier(origTableName)}${alias && import_sql2.sql` ${import_sql2.sql.identifier(alias)}`}`;
    const setSql = this.buildUpdateSet(table, set);
    const fromSql = from && import_sql2.sql.join([import_sql2.sql.raw(" from "), this.buildFromTable(from)]);
    const joinsSql = this.buildJoins(joins);
    const returningSql = returning ? import_sql2.sql` returning ${this.buildSelection(returning, { isSingleTable: !from })}` : void 0;
    const whereSql = where ? import_sql2.sql` where ${where}` : void 0;
    return import_sql2.sql`${withSql}update ${tableSql} set ${setSql}${fromSql}${joinsSql}${whereSql}${returningSql}`;
  }
  /**
   * Builds selection SQL with provided fields/expressions
   *
   * Examples:
   *
   * `select <selection> from`
   *
   * `insert ... returning <selection>`
   *
   * If `isSingleTable` is true, then columns won't be prefixed with table name
   */
  buildSelection(fields, { isSingleTable = false } = {}) {
    const columnsLen = fields.length;
    const chunks = fields.flatMap(({ field }, i) => {
      const chunk = [];
      if ((0, import_entity.is)(field, import_sql2.SQL.Aliased) && field.isSelectionField) {
        chunk.push(import_sql2.sql.identifier(field.fieldAlias));
      } else if ((0, import_entity.is)(field, import_sql2.SQL.Aliased) || (0, import_entity.is)(field, import_sql2.SQL)) {
        const query = (0, import_entity.is)(field, import_sql2.SQL.Aliased) ? field.sql : field;
        if (isSingleTable) {
          chunk.push(
            new import_sql2.SQL(
              query.queryChunks.map((c) => {
                if ((0, import_entity.is)(c, import_columns.PgColumn)) {
                  return import_sql2.sql.identifier(this.casing.getColumnCasing(c));
                }
                return c;
              })
            )
          );
        } else {
          chunk.push(query);
        }
        if ((0, import_entity.is)(field, import_sql2.SQL.Aliased)) {
          chunk.push(import_sql2.sql` as ${import_sql2.sql.identifier(field.fieldAlias)}`);
        }
      } else if ((0, import_entity.is)(field, import_column.Column)) {
        if (isSingleTable) {
          chunk.push(import_sql2.sql.identifier(this.casing.getColumnCasing(field)));
        } else {
          chunk.push(field);
        }
      } else if ((0, import_entity.is)(field, import_subquery.Subquery)) {
        const entries = Object.entries(field._.selectedFields);
        if (entries.length === 1) {
          const entry = entries[0][1];
          const fieldDecoder = (0, import_entity.is)(entry, import_sql2.SQL) ? entry.decoder : (0, import_entity.is)(entry, import_column.Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
          if (fieldDecoder) {
            field._.sql.decoder = fieldDecoder;
          }
        }
        chunk.push(field);
      }
      if (i < columnsLen - 1) {
        chunk.push(import_sql2.sql`, `);
      }
      return chunk;
    });
    return import_sql2.sql.join(chunks);
  }
  buildJoins(joins) {
    if (!joins || joins.length === 0) {
      return void 0;
    }
    const joinsArray = [];
    for (const [index, joinMeta] of joins.entries()) {
      if (index === 0) {
        joinsArray.push(import_sql2.sql` `);
      }
      const table = joinMeta.table;
      const lateralSql = joinMeta.lateral ? import_sql2.sql` lateral` : void 0;
      const onSql = joinMeta.on ? import_sql2.sql` on ${joinMeta.on}` : void 0;
      if ((0, import_entity.is)(table, import_table.PgTable)) {
        const tableName = table[import_table.PgTable.Symbol.Name];
        const tableSchema = table[import_table.PgTable.Symbol.Schema];
        const origTableName = table[import_table.PgTable.Symbol.OriginalName];
        const alias = tableName === origTableName ? void 0 : joinMeta.alias;
        joinsArray.push(
          import_sql2.sql`${import_sql2.sql.raw(joinMeta.joinType)} join${lateralSql} ${tableSchema ? import_sql2.sql`${import_sql2.sql.identifier(tableSchema)}.` : void 0}${import_sql2.sql.identifier(origTableName)}${alias && import_sql2.sql` ${import_sql2.sql.identifier(alias)}`}${onSql}`
        );
      } else if ((0, import_entity.is)(table, import_sql.View)) {
        const viewName = table[import_view_common.ViewBaseConfig].name;
        const viewSchema = table[import_view_common.ViewBaseConfig].schema;
        const origViewName = table[import_view_common.ViewBaseConfig].originalName;
        const alias = viewName === origViewName ? void 0 : joinMeta.alias;
        joinsArray.push(
          import_sql2.sql`${import_sql2.sql.raw(joinMeta.joinType)} join${lateralSql} ${viewSchema ? import_sql2.sql`${import_sql2.sql.identifier(viewSchema)}.` : void 0}${import_sql2.sql.identifier(origViewName)}${alias && import_sql2.sql` ${import_sql2.sql.identifier(alias)}`}${onSql}`
        );
      } else {
        joinsArray.push(
          import_sql2.sql`${import_sql2.sql.raw(joinMeta.joinType)} join${lateralSql} ${table}${onSql}`
        );
      }
      if (index < joins.length - 1) {
        joinsArray.push(import_sql2.sql` `);
      }
    }
    return import_sql2.sql.join(joinsArray);
  }
  buildFromTable(table) {
    if ((0, import_entity.is)(table, import_table2.Table) && table[import_table2.Table.Symbol.IsAlias]) {
      let fullName = import_sql2.sql`${import_sql2.sql.identifier(table[import_table2.Table.Symbol.OriginalName])}`;
      if (table[import_table2.Table.Symbol.Schema]) {
        fullName = import_sql2.sql`${import_sql2.sql.identifier(table[import_table2.Table.Symbol.Schema])}.${fullName}`;
      }
      return import_sql2.sql`${fullName} ${import_sql2.sql.identifier(table[import_table2.Table.Symbol.Name])}`;
    }
    return table;
  }
  buildSelectQuery({
    withList,
    fields,
    fieldsFlat,
    where,
    having,
    table,
    joins,
    orderBy,
    groupBy,
    limit,
    offset,
    lockingClause,
    distinct,
    setOperators
  }) {
    const fieldsList = fieldsFlat ?? (0, import_utils.orderSelectedFields)(fields);
    for (const f of fieldsList) {
      if ((0, import_entity.is)(f.field, import_column.Column) && (0, import_table2.getTableName)(f.field.table) !== ((0, import_entity.is)(table, import_subquery.Subquery) ? table._.alias : (0, import_entity.is)(table, import_view_base.PgViewBase) ? table[import_view_common.ViewBaseConfig].name : (0, import_entity.is)(table, import_sql2.SQL) ? void 0 : (0, import_table2.getTableName)(table)) && !((table2) => joins?.some(
        ({ alias }) => alias === (table2[import_table2.Table.Symbol.IsAlias] ? (0, import_table2.getTableName)(table2) : table2[import_table2.Table.Symbol.BaseName])
      ))(f.field.table)) {
        const tableName = (0, import_table2.getTableName)(f.field.table);
        throw new Error(
          `Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`
        );
      }
    }
    const isSingleTable = !joins || joins.length === 0;
    const withSql = this.buildWithCTE(withList);
    let distinctSql;
    if (distinct) {
      distinctSql = distinct === true ? import_sql2.sql` distinct` : import_sql2.sql` distinct on (${import_sql2.sql.join(distinct.on, import_sql2.sql`, `)})`;
    }
    const selection = this.buildSelection(fieldsList, { isSingleTable });
    const tableSql = this.buildFromTable(table);
    const joinsSql = this.buildJoins(joins);
    const whereSql = where ? import_sql2.sql` where ${where}` : void 0;
    const havingSql = having ? import_sql2.sql` having ${having}` : void 0;
    let orderBySql;
    if (orderBy && orderBy.length > 0) {
      orderBySql = import_sql2.sql` order by ${import_sql2.sql.join(orderBy, import_sql2.sql`, `)}`;
    }
    let groupBySql;
    if (groupBy && groupBy.length > 0) {
      groupBySql = import_sql2.sql` group by ${import_sql2.sql.join(groupBy, import_sql2.sql`, `)}`;
    }
    const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? import_sql2.sql` limit ${limit}` : void 0;
    const offsetSql = offset ? import_sql2.sql` offset ${offset}` : void 0;
    const lockingClauseSql = import_sql2.sql.empty();
    if (lockingClause) {
      const clauseSql = import_sql2.sql` for ${import_sql2.sql.raw(lockingClause.strength)}`;
      if (lockingClause.config.of) {
        clauseSql.append(
          import_sql2.sql` of ${import_sql2.sql.join(
            Array.isArray(lockingClause.config.of) ? lockingClause.config.of : [lockingClause.config.of],
            import_sql2.sql`, `
          )}`
        );
      }
      if (lockingClause.config.noWait) {
        clauseSql.append(import_sql2.sql` nowait`);
      } else if (lockingClause.config.skipLocked) {
        clauseSql.append(import_sql2.sql` skip locked`);
      }
      lockingClauseSql.append(clauseSql);
    }
    const finalQuery = import_sql2.sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}${lockingClauseSql}`;
    if (setOperators.length > 0) {
      return this.buildSetOperations(finalQuery, setOperators);
    }
    return finalQuery;
  }
  buildSetOperations(leftSelect, setOperators) {
    const [setOperator, ...rest] = setOperators;
    if (!setOperator) {
      throw new Error("Cannot pass undefined values to any set operator");
    }
    if (rest.length === 0) {
      return this.buildSetOperationQuery({ leftSelect, setOperator });
    }
    return this.buildSetOperations(
      this.buildSetOperationQuery({ leftSelect, setOperator }),
      rest
    );
  }
  buildSetOperationQuery({
    leftSelect,
    setOperator: { type, isAll, rightSelect, limit, orderBy, offset }
  }) {
    const leftChunk = import_sql2.sql`(${leftSelect.getSQL()}) `;
    const rightChunk = import_sql2.sql`(${rightSelect.getSQL()})`;
    let orderBySql;
    if (orderBy && orderBy.length > 0) {
      const orderByValues = [];
      for (const singleOrderBy of orderBy) {
        if ((0, import_entity.is)(singleOrderBy, import_columns.PgColumn)) {
          orderByValues.push(import_sql2.sql.identifier(singleOrderBy.name));
        } else if ((0, import_entity.is)(singleOrderBy, import_sql2.SQL)) {
          for (let i = 0; i < singleOrderBy.queryChunks.length; i++) {
            const chunk = singleOrderBy.queryChunks[i];
            if ((0, import_entity.is)(chunk, import_columns.PgColumn)) {
              singleOrderBy.queryChunks[i] = import_sql2.sql.identifier(chunk.name);
            }
          }
          orderByValues.push(import_sql2.sql`${singleOrderBy}`);
        } else {
          orderByValues.push(import_sql2.sql`${singleOrderBy}`);
        }
      }
      orderBySql = import_sql2.sql` order by ${import_sql2.sql.join(orderByValues, import_sql2.sql`, `)} `;
    }
    const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? import_sql2.sql` limit ${limit}` : void 0;
    const operatorChunk = import_sql2.sql.raw(`${type} ${isAll ? "all " : ""}`);
    const offsetSql = offset ? import_sql2.sql` offset ${offset}` : void 0;
    return import_sql2.sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
  }
  buildInsertQuery({ table, values: valuesOrSelect, onConflict, returning, withList, select, overridingSystemValue_ }) {
    const valuesSqlList = [];
    const columns = table[import_table2.Table.Symbol.Columns];
    const colEntries = Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
    const insertOrder = colEntries.map(
      ([, column]) => import_sql2.sql.identifier(this.casing.getColumnCasing(column))
    );
    if (select) {
      const select2 = valuesOrSelect;
      if ((0, import_entity.is)(select2, import_sql2.SQL)) {
        valuesSqlList.push(select2);
      } else {
        valuesSqlList.push(select2.getSQL());
      }
    } else {
      const values = valuesOrSelect;
      valuesSqlList.push(import_sql2.sql.raw("values "));
      for (const [valueIndex, value] of values.entries()) {
        const valueList = [];
        for (const [fieldName, col] of colEntries) {
          const colValue = value[fieldName];
          if (colValue === void 0 || (0, import_entity.is)(colValue, import_sql2.Param) && colValue.value === void 0) {
            if (col.defaultFn !== void 0) {
              const defaultFnResult = col.defaultFn();
              const defaultValue = (0, import_entity.is)(defaultFnResult, import_sql2.SQL) ? defaultFnResult : import_sql2.sql.param(defaultFnResult, col);
              valueList.push(defaultValue);
            } else if (!col.default && col.onUpdateFn !== void 0) {
              const onUpdateFnResult = col.onUpdateFn();
              const newValue = (0, import_entity.is)(onUpdateFnResult, import_sql2.SQL) ? onUpdateFnResult : import_sql2.sql.param(onUpdateFnResult, col);
              valueList.push(newValue);
            } else {
              valueList.push(import_sql2.sql`default`);
            }
          } else {
            valueList.push(colValue);
          }
        }
        valuesSqlList.push(valueList);
        if (valueIndex < values.length - 1) {
          valuesSqlList.push(import_sql2.sql`, `);
        }
      }
    }
    const withSql = this.buildWithCTE(withList);
    const valuesSql = import_sql2.sql.join(valuesSqlList);
    const returningSql = returning ? import_sql2.sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
    const onConflictSql = onConflict ? import_sql2.sql` on conflict ${onConflict}` : void 0;
    const overridingSql = overridingSystemValue_ === true ? import_sql2.sql`overriding system value ` : void 0;
    return import_sql2.sql`${withSql}insert into ${table} ${insertOrder} ${overridingSql}${valuesSql}${onConflictSql}${returningSql}`;
  }
  buildRefreshMaterializedViewQuery({ view, concurrently, withNoData }) {
    const concurrentlySql = concurrently ? import_sql2.sql` concurrently` : void 0;
    const withNoDataSql = withNoData ? import_sql2.sql` with no data` : void 0;
    return import_sql2.sql`refresh materialized view${concurrentlySql} ${view}${withNoDataSql}`;
  }
  prepareTyping(encoder) {
    if ((0, import_entity.is)(encoder, import_columns.PgJsonb) || (0, import_entity.is)(encoder, import_columns.PgJson)) {
      return "json";
    } else if ((0, import_entity.is)(encoder, import_columns.PgNumeric)) {
      return "decimal";
    } else if ((0, import_entity.is)(encoder, import_columns.PgTime)) {
      return "time";
    } else if ((0, import_entity.is)(encoder, import_columns.PgTimestamp) || (0, import_entity.is)(encoder, import_columns.PgTimestampString)) {
      return "timestamp";
    } else if ((0, import_entity.is)(encoder, import_columns.PgDate) || (0, import_entity.is)(encoder, import_columns.PgDateString)) {
      return "date";
    } else if ((0, import_entity.is)(encoder, import_columns.PgUUID)) {
      return "uuid";
    } else {
      return "none";
    }
  }
  sqlToQuery(sql2, invokeSource) {
    return sql2.toQuery({
      casing: this.casing,
      escapeName: this.escapeName,
      escapeParam: this.escapeParam,
      escapeString: this.escapeString,
      prepareTyping: this.prepareTyping,
      invokeSource
    });
  }
  // buildRelationalQueryWithPK({
  // 	fullSchema,
  // 	schema,
  // 	tableNamesMap,
  // 	table,
  // 	tableConfig,
  // 	queryConfig: config,
  // 	tableAlias,
  // 	isRoot = false,
  // 	joinOn,
  // }: {
  // 	fullSchema: Record<string, unknown>;
  // 	schema: TablesRelationalConfig;
  // 	tableNamesMap: Record<string, string>;
  // 	table: PgTable;
  // 	tableConfig: TableRelationalConfig;
  // 	queryConfig: true | DBQueryConfig<'many', true>;
  // 	tableAlias: string;
  // 	isRoot?: boolean;
  // 	joinOn?: SQL;
  // }): BuildRelationalQueryResult<PgTable, PgColumn> {
  // 	// For { "<relation>": true }, return a table with selection of all columns
  // 	if (config === true) {
  // 		const selectionEntries = Object.entries(tableConfig.columns);
  // 		const selection: BuildRelationalQueryResult<PgTable, PgColumn>['selection'] = selectionEntries.map((
  // 			[key, value],
  // 		) => ({
  // 			dbKey: value.name,
  // 			tsKey: key,
  // 			field: value as PgColumn,
  // 			relationTableTsKey: undefined,
  // 			isJson: false,
  // 			selection: [],
  // 		}));
  // 		return {
  // 			tableTsKey: tableConfig.tsName,
  // 			sql: table,
  // 			selection,
  // 		};
  // 	}
  // 	// let selection: BuildRelationalQueryResult<PgTable, PgColumn>['selection'] = [];
  // 	// let selectionForBuild = selection;
  // 	const aliasedColumns = Object.fromEntries(
  // 		Object.entries(tableConfig.columns).map(([key, value]) => [key, aliasedTableColumn(value, tableAlias)]),
  // 	);
  // 	const aliasedRelations = Object.fromEntries(
  // 		Object.entries(tableConfig.relations).map(([key, value]) => [key, aliasedRelation(value, tableAlias)]),
  // 	);
  // 	const aliasedFields = Object.assign({}, aliasedColumns, aliasedRelations);
  // 	let where, hasUserDefinedWhere;
  // 	if (config.where) {
  // 		const whereSql = typeof config.where === 'function' ? config.where(aliasedFields, operators) : config.where;
  // 		where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
  // 		hasUserDefinedWhere = !!where;
  // 	}
  // 	where = and(joinOn, where);
  // 	// const fieldsSelection: { tsKey: string; value: PgColumn | SQL.Aliased; isExtra?: boolean }[] = [];
  // 	let joins: Join[] = [];
  // 	let selectedColumns: string[] = [];
  // 	// Figure out which columns to select
  // 	if (config.columns) {
  // 		let isIncludeMode = false;
  // 		for (const [field, value] of Object.entries(config.columns)) {
  // 			if (value === undefined) {
  // 				continue;
  // 			}
  // 			if (field in tableConfig.columns) {
  // 				if (!isIncludeMode && value === true) {
  // 					isIncludeMode = true;
  // 				}
  // 				selectedColumns.push(field);
  // 			}
  // 		}
  // 		if (selectedColumns.length > 0) {
  // 			selectedColumns = isIncludeMode
  // 				? selectedColumns.filter((c) => config.columns?.[c] === true)
  // 				: Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
  // 		}
  // 	} else {
  // 		// Select all columns if selection is not specified
  // 		selectedColumns = Object.keys(tableConfig.columns);
  // 	}
  // 	// for (const field of selectedColumns) {
  // 	// 	const column = tableConfig.columns[field]! as PgColumn;
  // 	// 	fieldsSelection.push({ tsKey: field, value: column });
  // 	// }
  // 	let initiallySelectedRelations: {
  // 		tsKey: string;
  // 		queryConfig: true | DBQueryConfig<'many', false>;
  // 		relation: Relation;
  // 	}[] = [];
  // 	// let selectedRelations: BuildRelationalQueryResult<PgTable, PgColumn>['selection'] = [];
  // 	// Figure out which relations to select
  // 	if (config.with) {
  // 		initiallySelectedRelations = Object.entries(config.with)
  // 			.filter((entry): entry is [typeof entry[0], NonNullable<typeof entry[1]>] => !!entry[1])
  // 			.map(([tsKey, queryConfig]) => ({ tsKey, queryConfig, relation: tableConfig.relations[tsKey]! }));
  // 	}
  // 	const manyRelations = initiallySelectedRelations.filter((r) =>
  // 		is(r.relation, Many)
  // 		&& (schema[tableNamesMap[r.relation.referencedTable[Table.Symbol.Name]]!]?.primaryKey.length ?? 0) > 0
  // 	);
  // 	// If this is the last Many relation (or there are no Many relations), we are on the innermost subquery level
  // 	const isInnermostQuery = manyRelations.length < 2;
  // 	const selectedExtras: {
  // 		tsKey: string;
  // 		value: SQL.Aliased;
  // 	}[] = [];
  // 	// Figure out which extras to select
  // 	if (isInnermostQuery && config.extras) {
  // 		const extras = typeof config.extras === 'function'
  // 			? config.extras(aliasedFields, { sql })
  // 			: config.extras;
  // 		for (const [tsKey, value] of Object.entries(extras)) {
  // 			selectedExtras.push({
  // 				tsKey,
  // 				value: mapColumnsInAliasedSQLToAlias(value, tableAlias),
  // 			});
  // 		}
  // 	}
  // 	// Transform `fieldsSelection` into `selection`
  // 	// `fieldsSelection` shouldn't be used after this point
  // 	// for (const { tsKey, value, isExtra } of fieldsSelection) {
  // 	// 	selection.push({
  // 	// 		dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey]!.name,
  // 	// 		tsKey,
  // 	// 		field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
  // 	// 		relationTableTsKey: undefined,
  // 	// 		isJson: false,
  // 	// 		isExtra,
  // 	// 		selection: [],
  // 	// 	});
  // 	// }
  // 	let orderByOrig = typeof config.orderBy === 'function'
  // 		? config.orderBy(aliasedFields, orderByOperators)
  // 		: config.orderBy ?? [];
  // 	if (!Array.isArray(orderByOrig)) {
  // 		orderByOrig = [orderByOrig];
  // 	}
  // 	const orderBy = orderByOrig.map((orderByValue) => {
  // 		if (is(orderByValue, Column)) {
  // 			return aliasedTableColumn(orderByValue, tableAlias) as PgColumn;
  // 		}
  // 		return mapColumnsInSQLToAlias(orderByValue, tableAlias);
  // 	});
  // 	const limit = isInnermostQuery ? config.limit : undefined;
  // 	const offset = isInnermostQuery ? config.offset : undefined;
  // 	// For non-root queries without additional config except columns, return a table with selection
  // 	if (
  // 		!isRoot
  // 		&& initiallySelectedRelations.length === 0
  // 		&& selectedExtras.length === 0
  // 		&& !where
  // 		&& orderBy.length === 0
  // 		&& limit === undefined
  // 		&& offset === undefined
  // 	) {
  // 		return {
  // 			tableTsKey: tableConfig.tsName,
  // 			sql: table,
  // 			selection: selectedColumns.map((key) => ({
  // 				dbKey: tableConfig.columns[key]!.name,
  // 				tsKey: key,
  // 				field: tableConfig.columns[key] as PgColumn,
  // 				relationTableTsKey: undefined,
  // 				isJson: false,
  // 				selection: [],
  // 			})),
  // 		};
  // 	}
  // 	const selectedRelationsWithoutPK:
  // 	// Process all relations without primary keys, because they need to be joined differently and will all be on the same query level
  // 	for (
  // 		const {
  // 			tsKey: selectedRelationTsKey,
  // 			queryConfig: selectedRelationConfigValue,
  // 			relation,
  // 		} of initiallySelectedRelations
  // 	) {
  // 		const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
  // 		const relationTableName = relation.referencedTable[Table.Symbol.Name];
  // 		const relationTableTsName = tableNamesMap[relationTableName]!;
  // 		const relationTable = schema[relationTableTsName]!;
  // 		if (relationTable.primaryKey.length > 0) {
  // 			continue;
  // 		}
  // 		const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
  // 		const joinOn = and(
  // 			...normalizedRelation.fields.map((field, i) =>
  // 				eq(
  // 					aliasedTableColumn(normalizedRelation.references[i]!, relationTableAlias),
  // 					aliasedTableColumn(field, tableAlias),
  // 				)
  // 			),
  // 		);
  // 		const builtRelation = this.buildRelationalQueryWithoutPK({
  // 			fullSchema,
  // 			schema,
  // 			tableNamesMap,
  // 			table: fullSchema[relationTableTsName] as PgTable,
  // 			tableConfig: schema[relationTableTsName]!,
  // 			queryConfig: selectedRelationConfigValue,
  // 			tableAlias: relationTableAlias,
  // 			joinOn,
  // 			nestedQueryRelation: relation,
  // 		});
  // 		const field = sql`${sql.identifier(relationTableAlias)}.${sql.identifier('data')}`.as(selectedRelationTsKey);
  // 		joins.push({
  // 			on: sql`true`,
  // 			table: new Subquery(builtRelation.sql as SQL, {}, relationTableAlias),
  // 			alias: relationTableAlias,
  // 			joinType: 'left',
  // 			lateral: true,
  // 		});
  // 		selectedRelations.push({
  // 			dbKey: selectedRelationTsKey,
  // 			tsKey: selectedRelationTsKey,
  // 			field,
  // 			relationTableTsKey: relationTableTsName,
  // 			isJson: true,
  // 			selection: builtRelation.selection,
  // 		});
  // 	}
  // 	const oneRelations = initiallySelectedRelations.filter((r): r is typeof r & { relation: One } =>
  // 		is(r.relation, One)
  // 	);
  // 	// Process all One relations with PKs, because they can all be joined on the same level
  // 	for (
  // 		const {
  // 			tsKey: selectedRelationTsKey,
  // 			queryConfig: selectedRelationConfigValue,
  // 			relation,
  // 		} of oneRelations
  // 	) {
  // 		const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
  // 		const relationTableName = relation.referencedTable[Table.Symbol.Name];
  // 		const relationTableTsName = tableNamesMap[relationTableName]!;
  // 		const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
  // 		const relationTable = schema[relationTableTsName]!;
  // 		if (relationTable.primaryKey.length === 0) {
  // 			continue;
  // 		}
  // 		const joinOn = and(
  // 			...normalizedRelation.fields.map((field, i) =>
  // 				eq(
  // 					aliasedTableColumn(normalizedRelation.references[i]!, relationTableAlias),
  // 					aliasedTableColumn(field, tableAlias),
  // 				)
  // 			),
  // 		);
  // 		const builtRelation = this.buildRelationalQueryWithPK({
  // 			fullSchema,
  // 			schema,
  // 			tableNamesMap,
  // 			table: fullSchema[relationTableTsName] as PgTable,
  // 			tableConfig: schema[relationTableTsName]!,
  // 			queryConfig: selectedRelationConfigValue,
  // 			tableAlias: relationTableAlias,
  // 			joinOn,
  // 		});
  // 		const field = sql`case when ${sql.identifier(relationTableAlias)} is null then null else json_build_array(${
  // 			sql.join(
  // 				builtRelation.selection.map(({ field }) =>
  // 					is(field, SQL.Aliased)
  // 						? sql`${sql.identifier(relationTableAlias)}.${sql.identifier(field.fieldAlias)}`
  // 						: is(field, Column)
  // 						? aliasedTableColumn(field, relationTableAlias)
  // 						: field
  // 				),
  // 				sql`, `,
  // 			)
  // 		}) end`.as(selectedRelationTsKey);
  // 		const isLateralJoin = is(builtRelation.sql, SQL);
  // 		joins.push({
  // 			on: isLateralJoin ? sql`true` : joinOn,
  // 			table: is(builtRelation.sql, SQL)
  // 				? new Subquery(builtRelation.sql, {}, relationTableAlias)
  // 				: aliasedTable(builtRelation.sql, relationTableAlias),
  // 			alias: relationTableAlias,
  // 			joinType: 'left',
  // 			lateral: is(builtRelation.sql, SQL),
  // 		});
  // 		selectedRelations.push({
  // 			dbKey: selectedRelationTsKey,
  // 			tsKey: selectedRelationTsKey,
  // 			field,
  // 			relationTableTsKey: relationTableTsName,
  // 			isJson: true,
  // 			selection: builtRelation.selection,
  // 		});
  // 	}
  // 	let distinct: PgSelectConfig['distinct'];
  // 	let tableFrom: PgTable | Subquery = table;
  // 	// Process first Many relation - each one requires a nested subquery
  // 	const manyRelation = manyRelations[0];
  // 	if (manyRelation) {
  // 		const {
  // 			tsKey: selectedRelationTsKey,
  // 			queryConfig: selectedRelationQueryConfig,
  // 			relation,
  // 		} = manyRelation;
  // 		distinct = {
  // 			on: tableConfig.primaryKey.map((c) => aliasedTableColumn(c as PgColumn, tableAlias)),
  // 		};
  // 		const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
  // 		const relationTableName = relation.referencedTable[Table.Symbol.Name];
  // 		const relationTableTsName = tableNamesMap[relationTableName]!;
  // 		const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
  // 		const joinOn = and(
  // 			...normalizedRelation.fields.map((field, i) =>
  // 				eq(
  // 					aliasedTableColumn(normalizedRelation.references[i]!, relationTableAlias),
  // 					aliasedTableColumn(field, tableAlias),
  // 				)
  // 			),
  // 		);
  // 		const builtRelationJoin = this.buildRelationalQueryWithPK({
  // 			fullSchema,
  // 			schema,
  // 			tableNamesMap,
  // 			table: fullSchema[relationTableTsName] as PgTable,
  // 			tableConfig: schema[relationTableTsName]!,
  // 			queryConfig: selectedRelationQueryConfig,
  // 			tableAlias: relationTableAlias,
  // 			joinOn,
  // 		});
  // 		const builtRelationSelectionField = sql`case when ${
  // 			sql.identifier(relationTableAlias)
  // 		} is null then '[]' else json_agg(json_build_array(${
  // 			sql.join(
  // 				builtRelationJoin.selection.map(({ field }) =>
  // 					is(field, SQL.Aliased)
  // 						? sql`${sql.identifier(relationTableAlias)}.${sql.identifier(field.fieldAlias)}`
  // 						: is(field, Column)
  // 						? aliasedTableColumn(field, relationTableAlias)
  // 						: field
  // 				),
  // 				sql`, `,
  // 			)
  // 		})) over (partition by ${sql.join(distinct.on, sql`, `)}) end`.as(selectedRelationTsKey);
  // 		const isLateralJoin = is(builtRelationJoin.sql, SQL);
  // 		joins.push({
  // 			on: isLateralJoin ? sql`true` : joinOn,
  // 			table: isLateralJoin
  // 				? new Subquery(builtRelationJoin.sql as SQL, {}, relationTableAlias)
  // 				: aliasedTable(builtRelationJoin.sql as PgTable, relationTableAlias),
  // 			alias: relationTableAlias,
  // 			joinType: 'left',
  // 			lateral: isLateralJoin,
  // 		});
  // 		// Build the "from" subquery with the remaining Many relations
  // 		const builtTableFrom = this.buildRelationalQueryWithPK({
  // 			fullSchema,
  // 			schema,
  // 			tableNamesMap,
  // 			table,
  // 			tableConfig,
  // 			queryConfig: {
  // 				...config,
  // 				where: undefined,
  // 				orderBy: undefined,
  // 				limit: undefined,
  // 				offset: undefined,
  // 				with: manyRelations.slice(1).reduce<NonNullable<typeof config['with']>>(
  // 					(result, { tsKey, queryConfig: configValue }) => {
  // 						result[tsKey] = configValue;
  // 						return result;
  // 					},
  // 					{},
  // 				),
  // 			},
  // 			tableAlias,
  // 		});
  // 		selectedRelations.push({
  // 			dbKey: selectedRelationTsKey,
  // 			tsKey: selectedRelationTsKey,
  // 			field: builtRelationSelectionField,
  // 			relationTableTsKey: relationTableTsName,
  // 			isJson: true,
  // 			selection: builtRelationJoin.selection,
  // 		});
  // 		// selection = builtTableFrom.selection.map((item) =>
  // 		// 	is(item.field, SQL.Aliased)
  // 		// 		? { ...item, field: sql`${sql.identifier(tableAlias)}.${sql.identifier(item.field.fieldAlias)}` }
  // 		// 		: item
  // 		// );
  // 		// selectionForBuild = [{
  // 		// 	dbKey: '*',
  // 		// 	tsKey: '*',
  // 		// 	field: sql`${sql.identifier(tableAlias)}.*`,
  // 		// 	selection: [],
  // 		// 	isJson: false,
  // 		// 	relationTableTsKey: undefined,
  // 		// }];
  // 		// const newSelectionItem: (typeof selection)[number] = {
  // 		// 	dbKey: selectedRelationTsKey,
  // 		// 	tsKey: selectedRelationTsKey,
  // 		// 	field,
  // 		// 	relationTableTsKey: relationTableTsName,
  // 		// 	isJson: true,
  // 		// 	selection: builtRelationJoin.selection,
  // 		// };
  // 		// selection.push(newSelectionItem);
  // 		// selectionForBuild.push(newSelectionItem);
  // 		tableFrom = is(builtTableFrom.sql, PgTable)
  // 			? builtTableFrom.sql
  // 			: new Subquery(builtTableFrom.sql, {}, tableAlias);
  // 	}
  // 	if (selectedColumns.length === 0 && selectedRelations.length === 0 && selectedExtras.length === 0) {
  // 		throw new DrizzleError(`No fields selected for table "${tableConfig.tsName}" ("${tableAlias}")`);
  // 	}
  // 	let selection: BuildRelationalQueryResult<PgTable, PgColumn>['selection'];
  // 	function prepareSelectedColumns() {
  // 		return selectedColumns.map((key) => ({
  // 			dbKey: tableConfig.columns[key]!.name,
  // 			tsKey: key,
  // 			field: tableConfig.columns[key] as PgColumn,
  // 			relationTableTsKey: undefined,
  // 			isJson: false,
  // 			selection: [],
  // 		}));
  // 	}
  // 	function prepareSelectedExtras() {
  // 		return selectedExtras.map((item) => ({
  // 			dbKey: item.value.fieldAlias,
  // 			tsKey: item.tsKey,
  // 			field: item.value,
  // 			relationTableTsKey: undefined,
  // 			isJson: false,
  // 			selection: [],
  // 		}));
  // 	}
  // 	if (isRoot) {
  // 		selection = [
  // 			...prepareSelectedColumns(),
  // 			...prepareSelectedExtras(),
  // 		];
  // 	}
  // 	if (hasUserDefinedWhere || orderBy.length > 0) {
  // 		tableFrom = new Subquery(
  // 			this.buildSelectQuery({
  // 				table: is(tableFrom, PgTable) ? aliasedTable(tableFrom, tableAlias) : tableFrom,
  // 				fields: {},
  // 				fieldsFlat: selectionForBuild.map(({ field }) => ({
  // 					path: [],
  // 					field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field,
  // 				})),
  // 				joins,
  // 				distinct,
  // 			}),
  // 			{},
  // 			tableAlias,
  // 		);
  // 		selectionForBuild = selection.map((item) =>
  // 			is(item.field, SQL.Aliased)
  // 				? { ...item, field: sql`${sql.identifier(tableAlias)}.${sql.identifier(item.field.fieldAlias)}` }
  // 				: item
  // 		);
  // 		joins = [];
  // 		distinct = undefined;
  // 	}
  // 	const result = this.buildSelectQuery({
  // 		table: is(tableFrom, PgTable) ? aliasedTable(tableFrom, tableAlias) : tableFrom,
  // 		fields: {},
  // 		fieldsFlat: selectionForBuild.map(({ field }) => ({
  // 			path: [],
  // 			field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field,
  // 		})),
  // 		where,
  // 		limit,
  // 		offset,
  // 		joins,
  // 		orderBy,
  // 		distinct,
  // 	});
  // 	return {
  // 		tableTsKey: tableConfig.tsName,
  // 		sql: result,
  // 		selection,
  // 	};
  // }
  buildRelationalQueryWithoutPK({
    fullSchema,
    schema,
    tableNamesMap,
    table,
    tableConfig,
    queryConfig: config,
    tableAlias,
    nestedQueryRelation,
    joinOn
  }) {
    let selection = [];
    let limit, offset, orderBy = [], where;
    const joins = [];
    if (config === true) {
      const selectionEntries = Object.entries(tableConfig.columns);
      selection = selectionEntries.map(([key, value]) => ({
        dbKey: value.name,
        tsKey: key,
        field: (0, import_alias.aliasedTableColumn)(value, tableAlias),
        relationTableTsKey: void 0,
        isJson: false,
        selection: []
      }));
    } else {
      const aliasedColumns = Object.fromEntries(
        Object.entries(tableConfig.columns).map(([key, value]) => [key, (0, import_alias.aliasedTableColumn)(value, tableAlias)])
      );
      if (config.where) {
        const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, (0, import_relations.getOperators)()) : config.where;
        where = whereSql && (0, import_alias.mapColumnsInSQLToAlias)(whereSql, tableAlias);
      }
      const fieldsSelection = [];
      let selectedColumns = [];
      if (config.columns) {
        let isIncludeMode = false;
        for (const [field, value] of Object.entries(config.columns)) {
          if (value === void 0) {
            continue;
          }
          if (field in tableConfig.columns) {
            if (!isIncludeMode && value === true) {
              isIncludeMode = true;
            }
            selectedColumns.push(field);
          }
        }
        if (selectedColumns.length > 0) {
          selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
        }
      } else {
        selectedColumns = Object.keys(tableConfig.columns);
      }
      for (const field of selectedColumns) {
        const column = tableConfig.columns[field];
        fieldsSelection.push({ tsKey: field, value: column });
      }
      let selectedRelations = [];
      if (config.with) {
        selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig]) => ({ tsKey, queryConfig, relation: tableConfig.relations[tsKey] }));
      }
      let extras;
      if (config.extras) {
        extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql: import_sql2.sql }) : config.extras;
        for (const [tsKey, value] of Object.entries(extras)) {
          fieldsSelection.push({
            tsKey,
            value: (0, import_alias.mapColumnsInAliasedSQLToAlias)(value, tableAlias)
          });
        }
      }
      for (const { tsKey, value } of fieldsSelection) {
        selection.push({
          dbKey: (0, import_entity.is)(value, import_sql2.SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
          tsKey,
          field: (0, import_entity.is)(value, import_column.Column) ? (0, import_alias.aliasedTableColumn)(value, tableAlias) : value,
          relationTableTsKey: void 0,
          isJson: false,
          selection: []
        });
      }
      let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, (0, import_relations.getOrderByOperators)()) : config.orderBy ?? [];
      if (!Array.isArray(orderByOrig)) {
        orderByOrig = [orderByOrig];
      }
      orderBy = orderByOrig.map((orderByValue) => {
        if ((0, import_entity.is)(orderByValue, import_column.Column)) {
          return (0, import_alias.aliasedTableColumn)(orderByValue, tableAlias);
        }
        return (0, import_alias.mapColumnsInSQLToAlias)(orderByValue, tableAlias);
      });
      limit = config.limit;
      offset = config.offset;
      for (const {
        tsKey: selectedRelationTsKey,
        queryConfig: selectedRelationConfigValue,
        relation
      } of selectedRelations) {
        const normalizedRelation = (0, import_relations.normalizeRelation)(schema, tableNamesMap, relation);
        const relationTableName = (0, import_table2.getTableUniqueName)(relation.referencedTable);
        const relationTableTsName = tableNamesMap[relationTableName];
        const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
        const joinOn2 = (0, import_sql.and)(
          ...normalizedRelation.fields.map(
            (field2, i) => (0, import_sql.eq)(
              (0, import_alias.aliasedTableColumn)(normalizedRelation.references[i], relationTableAlias),
              (0, import_alias.aliasedTableColumn)(field2, tableAlias)
            )
          )
        );
        const builtRelation = this.buildRelationalQueryWithoutPK({
          fullSchema,
          schema,
          tableNamesMap,
          table: fullSchema[relationTableTsName],
          tableConfig: schema[relationTableTsName],
          queryConfig: (0, import_entity.is)(relation, import_relations.One) ? selectedRelationConfigValue === true ? { limit: 1 } : { ...selectedRelationConfigValue, limit: 1 } : selectedRelationConfigValue,
          tableAlias: relationTableAlias,
          joinOn: joinOn2,
          nestedQueryRelation: relation
        });
        const field = import_sql2.sql`${import_sql2.sql.identifier(relationTableAlias)}.${import_sql2.sql.identifier("data")}`.as(selectedRelationTsKey);
        joins.push({
          on: import_sql2.sql`true`,
          table: new import_subquery.Subquery(builtRelation.sql, {}, relationTableAlias),
          alias: relationTableAlias,
          joinType: "left",
          lateral: true
        });
        selection.push({
          dbKey: selectedRelationTsKey,
          tsKey: selectedRelationTsKey,
          field,
          relationTableTsKey: relationTableTsName,
          isJson: true,
          selection: builtRelation.selection
        });
      }
    }
    if (selection.length === 0) {
      throw new import_errors.DrizzleError({ message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}")` });
    }
    let result;
    where = (0, import_sql.and)(joinOn, where);
    if (nestedQueryRelation) {
      let field = import_sql2.sql`json_build_array(${import_sql2.sql.join(
        selection.map(
          ({ field: field2, tsKey, isJson }) => isJson ? import_sql2.sql`${import_sql2.sql.identifier(`${tableAlias}_${tsKey}`)}.${import_sql2.sql.identifier("data")}` : (0, import_entity.is)(field2, import_sql2.SQL.Aliased) ? field2.sql : field2
        ),
        import_sql2.sql`, `
      )})`;
      if ((0, import_entity.is)(nestedQueryRelation, import_relations.Many)) {
        field = import_sql2.sql`coalesce(json_agg(${field}${orderBy.length > 0 ? import_sql2.sql` order by ${import_sql2.sql.join(orderBy, import_sql2.sql`, `)}` : void 0}), '[]'::json)`;
      }
      const nestedSelection = [{
        dbKey: "data",
        tsKey: "data",
        field: field.as("data"),
        isJson: true,
        relationTableTsKey: tableConfig.tsName,
        selection
      }];
      const needsSubquery = limit !== void 0 || offset !== void 0 || orderBy.length > 0;
      if (needsSubquery) {
        result = this.buildSelectQuery({
          table: (0, import_alias.aliasedTable)(table, tableAlias),
          fields: {},
          fieldsFlat: [{
            path: [],
            field: import_sql2.sql.raw("*")
          }],
          where,
          limit,
          offset,
          orderBy,
          setOperators: []
        });
        where = void 0;
        limit = void 0;
        offset = void 0;
        orderBy = [];
      } else {
        result = (0, import_alias.aliasedTable)(table, tableAlias);
      }
      result = this.buildSelectQuery({
        table: (0, import_entity.is)(result, import_table.PgTable) ? result : new import_subquery.Subquery(result, {}, tableAlias),
        fields: {},
        fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
          path: [],
          field: (0, import_entity.is)(field2, import_column.Column) ? (0, import_alias.aliasedTableColumn)(field2, tableAlias) : field2
        })),
        joins,
        where,
        limit,
        offset,
        orderBy,
        setOperators: []
      });
    } else {
      result = this.buildSelectQuery({
        table: (0, import_alias.aliasedTable)(table, tableAlias),
        fields: {},
        fieldsFlat: selection.map(({ field }) => ({
          path: [],
          field: (0, import_entity.is)(field, import_column.Column) ? (0, import_alias.aliasedTableColumn)(field, tableAlias) : field
        })),
        joins,
        where,
        limit,
        offset,
        orderBy,
        setOperators: []
      });
    }
    return {
      tableTsKey: tableConfig.tsName,
      sql: result,
      selection
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgDialect
});
//# sourceMappingURL=dialect.cjs.map
},
"drizzle-orm/casing.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var casing_exports = {};
__export(casing_exports, {
  CasingCache: () => CasingCache,
  toCamelCase: () => toCamelCase,
  toSnakeCase: () => toSnakeCase
});
module.exports = __toCommonJS(casing_exports);
var import_entity = require("./entity.cjs");
var import_table = require("./table.cjs");
function toSnakeCase(input) {
  const words = input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? [];
  return words.map((word) => word.toLowerCase()).join("_");
}
function toCamelCase(input) {
  const words = input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? [];
  return words.reduce((acc, word, i) => {
    const formattedWord = i === 0 ? word.toLowerCase() : `${word[0].toUpperCase()}${word.slice(1)}`;
    return acc + formattedWord;
  }, "");
}
function noopCase(input) {
  return input;
}
class CasingCache {
  static [import_entity.entityKind] = "CasingCache";
  /** @internal */
  cache = {};
  cachedTables = {};
  convert;
  constructor(casing) {
    this.convert = casing === "snake_case" ? toSnakeCase : casing === "camelCase" ? toCamelCase : noopCase;
  }
  getColumnCasing(column) {
    if (!column.keyAsName) return column.name;
    const schema = column.table[import_table.Table.Symbol.Schema] ?? "public";
    const tableName = column.table[import_table.Table.Symbol.OriginalName];
    const key = `${schema}.${tableName}.${column.name}`;
    if (!this.cache[key]) {
      this.cacheTable(column.table);
    }
    return this.cache[key];
  }
  cacheTable(table) {
    const schema = table[import_table.Table.Symbol.Schema] ?? "public";
    const tableName = table[import_table.Table.Symbol.OriginalName];
    const tableKey = `${schema}.${tableName}`;
    if (!this.cachedTables[tableKey]) {
      for (const column of Object.values(table[import_table.Table.Symbol.Columns])) {
        const columnKey = `${tableKey}.${column.name}`;
        this.cache[columnKey] = this.convert(column.name);
      }
      this.cachedTables[tableKey] = true;
    }
  }
  clearCache() {
    this.cache = {};
    this.cachedTables = {};
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CasingCache,
  toCamelCase,
  toSnakeCase
});
//# sourceMappingURL=casing.cjs.map
},
"drizzle-orm/pg-core/query-builders/insert.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var insert_exports = {};
__export(insert_exports, {
  PgInsertBase: () => PgInsertBase,
  PgInsertBuilder: () => PgInsertBuilder
});
module.exports = __toCommonJS(insert_exports);
var import_entity = require("../../entity.cjs");
var import_query_promise = require("../../query-promise.cjs");
var import_selection_proxy = require("../../selection-proxy.cjs");
var import_sql = require("../../sql/sql.cjs");
var import_table = require("../../table.cjs");
var import_tracing = require("../../tracing.cjs");
var import_utils = require("../../utils.cjs");
var import_utils2 = require("../utils.cjs");
var import_query_builder = require("./query-builder.cjs");
class PgInsertBuilder {
  constructor(table, session, dialect, withList, overridingSystemValue_) {
    this.table = table;
    this.session = session;
    this.dialect = dialect;
    this.withList = withList;
    this.overridingSystemValue_ = overridingSystemValue_;
  }
  static [import_entity.entityKind] = "PgInsertBuilder";
  authToken;
  /** @internal */
  setToken(token) {
    this.authToken = token;
    return this;
  }
  overridingSystemValue() {
    this.overridingSystemValue_ = true;
    return this;
  }
  values(values) {
    values = Array.isArray(values) ? values : [values];
    if (values.length === 0) {
      throw new Error("values() must be called with at least one value");
    }
    const mappedValues = values.map((entry) => {
      const result = {};
      const cols = this.table[import_table.Table.Symbol.Columns];
      for (const colKey of Object.keys(entry)) {
        const colValue = entry[colKey];
        result[colKey] = (0, import_entity.is)(colValue, import_sql.SQL) ? colValue : new import_sql.Param(colValue, cols[colKey]);
      }
      return result;
    });
    return new PgInsertBase(
      this.table,
      mappedValues,
      this.session,
      this.dialect,
      this.withList,
      false,
      this.overridingSystemValue_
    ).setToken(this.authToken);
  }
  select(selectQuery) {
    const select = typeof selectQuery === "function" ? selectQuery(new import_query_builder.QueryBuilder()) : selectQuery;
    if (!(0, import_entity.is)(select, import_sql.SQL) && !(0, import_utils.haveSameKeys)(this.table[import_table.Columns], select._.selectedFields)) {
      throw new Error(
        "Insert select error: selected fields are not the same or are in a different order compared to the table definition"
      );
    }
    return new PgInsertBase(this.table, select, this.session, this.dialect, this.withList, true);
  }
}
class PgInsertBase extends import_query_promise.QueryPromise {
  constructor(table, values, session, dialect, withList, select, overridingSystemValue_) {
    super();
    this.session = session;
    this.dialect = dialect;
    this.config = { table, values, withList, select, overridingSystemValue_ };
  }
  static [import_entity.entityKind] = "PgInsert";
  config;
  cacheConfig;
  returning(fields = this.config.table[import_table.Table.Symbol.Columns]) {
    this.config.returningFields = fields;
    this.config.returning = (0, import_utils.orderSelectedFields)(fields);
    return this;
  }
  /**
   * Adds an `on conflict do nothing` clause to the query.
   *
   * Calling this method simply avoids inserting a row as its alternative action.
   *
   * See docs: {@link https://orm.drizzle.team/docs/insert#on-conflict-do-nothing}
   *
   * @param config The `target` and `where` clauses.
   *
   * @example
   * ```ts
   * // Insert one row and cancel the insert if there's a conflict
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoNothing();
   *
   * // Explicitly specify conflict target
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoNothing({ target: cars.id });
   * ```
   */
  onConflictDoNothing(config = {}) {
    if (config.target === void 0) {
      this.config.onConflict = import_sql.sql`do nothing`;
    } else {
      let targetColumn = "";
      targetColumn = Array.isArray(config.target) ? config.target.map((it) => this.dialect.escapeName(this.dialect.casing.getColumnCasing(it))).join(",") : this.dialect.escapeName(this.dialect.casing.getColumnCasing(config.target));
      const whereSql = config.where ? import_sql.sql` where ${config.where}` : void 0;
      this.config.onConflict = import_sql.sql`(${import_sql.sql.raw(targetColumn)})${whereSql} do nothing`;
    }
    return this;
  }
  /**
   * Adds an `on conflict do update` clause to the query.
   *
   * Calling this method will update the existing row that conflicts with the row proposed for insertion as its alternative action.
   *
   * See docs: {@link https://orm.drizzle.team/docs/insert#upserts-and-conflicts}
   *
   * @param config The `target`, `set` and `where` clauses.
   *
   * @example
   * ```ts
   * // Update the row if there's a conflict
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoUpdate({
   *     target: cars.id,
   *     set: { brand: 'Porsche' }
   *   });
   *
   * // Upsert with 'where' clause
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoUpdate({
   *     target: cars.id,
   *     set: { brand: 'newBMW' },
   *     targetWhere: sql`${cars.createdAt} > '2023-01-01'::date`,
   *   });
   * ```
   */
  onConflictDoUpdate(config) {
    if (config.where && (config.targetWhere || config.setWhere)) {
      throw new Error(
        'You cannot use both "where" and "targetWhere"/"setWhere" at the same time - "where" is deprecated, use "targetWhere" or "setWhere" instead.'
      );
    }
    const whereSql = config.where ? import_sql.sql` where ${config.where}` : void 0;
    const targetWhereSql = config.targetWhere ? import_sql.sql` where ${config.targetWhere}` : void 0;
    const setWhereSql = config.setWhere ? import_sql.sql` where ${config.setWhere}` : void 0;
    const setSql = this.dialect.buildUpdateSet(this.config.table, (0, import_utils.mapUpdateSet)(this.config.table, config.set));
    let targetColumn = "";
    targetColumn = Array.isArray(config.target) ? config.target.map((it) => this.dialect.escapeName(this.dialect.casing.getColumnCasing(it))).join(",") : this.dialect.escapeName(this.dialect.casing.getColumnCasing(config.target));
    this.config.onConflict = import_sql.sql`(${import_sql.sql.raw(targetColumn)})${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`;
    return this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildInsertQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  /** @internal */
  _prepare(name) {
    return import_tracing.tracer.startActiveSpan("drizzle.prepareQuery", () => {
      return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true, void 0, {
        type: "insert",
        tables: (0, import_utils2.extractUsedTable)(this.config.table)
      }, this.cacheConfig);
    });
  }
  prepare(name) {
    return this._prepare(name);
  }
  authToken;
  /** @internal */
  setToken(token) {
    this.authToken = token;
    return this;
  }
  execute = (placeholderValues) => {
    return import_tracing.tracer.startActiveSpan("drizzle.operation", () => {
      return this._prepare().execute(placeholderValues, this.authToken);
    });
  };
  /** @internal */
  getSelectedFields() {
    return this.config.returningFields ? new Proxy(
      this.config.returningFields,
      new import_selection_proxy.SelectionProxyHandler({
        alias: (0, import_table.getTableName)(this.config.table),
        sqlAliasedBehavior: "alias",
        sqlBehavior: "error"
      })
    ) : void 0;
  }
  $dynamic() {
    return this;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgInsertBase,
  PgInsertBuilder
});
//# sourceMappingURL=insert.cjs.map
},
"drizzle-orm/pg-core/query-builders/delete.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var delete_exports = {};
__export(delete_exports, {
  PgDeleteBase: () => PgDeleteBase
});
module.exports = __toCommonJS(delete_exports);
var import_entity = require("../../entity.cjs");
var import_query_promise = require("../../query-promise.cjs");
var import_selection_proxy = require("../../selection-proxy.cjs");
var import_table = require("../../table.cjs");
var import_tracing = require("../../tracing.cjs");
var import_utils = require("../../utils.cjs");
var import_utils2 = require("../utils.cjs");
class PgDeleteBase extends import_query_promise.QueryPromise {
  constructor(table, session, dialect, withList) {
    super();
    this.session = session;
    this.dialect = dialect;
    this.config = { table, withList };
  }
  static [import_entity.entityKind] = "PgDelete";
  config;
  cacheConfig;
  /**
   * Adds a `where` clause to the query.
   *
   * Calling this method will delete only those rows that fulfill a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/delete}
   *
   * @param where the `where` clause.
   *
   * @example
   * You can use conditional operators and `sql function` to filter the rows to be deleted.
   *
   * ```ts
   * // Delete all cars with green color
   * await db.delete(cars).where(eq(cars.color, 'green'));
   * // or
   * await db.delete(cars).where(sql`${cars.color} = 'green'`)
   * ```
   *
   * You can logically combine conditional operators with `and()` and `or()` operators:
   *
   * ```ts
   * // Delete all BMW cars with a green color
   * await db.delete(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
   *
   * // Delete all cars with the green or blue color
   * await db.delete(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
   * ```
   */
  where(where) {
    this.config.where = where;
    return this;
  }
  returning(fields = this.config.table[import_table.Table.Symbol.Columns]) {
    this.config.returningFields = fields;
    this.config.returning = (0, import_utils.orderSelectedFields)(fields);
    return this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildDeleteQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  /** @internal */
  _prepare(name) {
    return import_tracing.tracer.startActiveSpan("drizzle.prepareQuery", () => {
      return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true, void 0, {
        type: "delete",
        tables: (0, import_utils2.extractUsedTable)(this.config.table)
      }, this.cacheConfig);
    });
  }
  prepare(name) {
    return this._prepare(name);
  }
  authToken;
  /** @internal */
  setToken(token) {
    this.authToken = token;
    return this;
  }
  execute = (placeholderValues) => {
    return import_tracing.tracer.startActiveSpan("drizzle.operation", () => {
      return this._prepare().execute(placeholderValues, this.authToken);
    });
  };
  /** @internal */
  getSelectedFields() {
    return this.config.returningFields ? new Proxy(
      this.config.returningFields,
      new import_selection_proxy.SelectionProxyHandler({
        alias: (0, import_table.getTableName)(this.config.table),
        sqlAliasedBehavior: "alias",
        sqlBehavior: "error"
      })
    ) : void 0;
  }
  $dynamic() {
    return this;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgDeleteBase
});
//# sourceMappingURL=delete.cjs.map
},
"drizzle-orm/sql/index.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var sql_exports = {};
module.exports = __toCommonJS(sql_exports);
__reExport(sql_exports, require("./expressions/index.cjs"), module.exports);
__reExport(sql_exports, require("./functions/index.cjs"), module.exports);
__reExport(sql_exports, require("./sql.cjs"), module.exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ...require("./expressions/index.cjs"),
  ...require("./functions/index.cjs"),
  ...require("./sql.cjs")
});
//# sourceMappingURL=index.cjs.map
},
"drizzle-orm/sql/functions/index.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var functions_exports = {};
module.exports = __toCommonJS(functions_exports);
__reExport(functions_exports, require("./aggregate.cjs"), module.exports);
__reExport(functions_exports, require("./vector.cjs"), module.exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ...require("./aggregate.cjs"),
  ...require("./vector.cjs")
});
//# sourceMappingURL=index.cjs.map
},
"drizzle-orm/sql/functions/vector.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var vector_exports = {};
__export(vector_exports, {
  cosineDistance: () => cosineDistance,
  hammingDistance: () => hammingDistance,
  innerProduct: () => innerProduct,
  jaccardDistance: () => jaccardDistance,
  l1Distance: () => l1Distance,
  l2Distance: () => l2Distance
});
module.exports = __toCommonJS(vector_exports);
var import_sql = require("../sql.cjs");
function toSql(value) {
  return JSON.stringify(value);
}
function l2Distance(column, value) {
  if (Array.isArray(value)) {
    return import_sql.sql`${column} <-> ${toSql(value)}`;
  }
  return import_sql.sql`${column} <-> ${value}`;
}
function l1Distance(column, value) {
  if (Array.isArray(value)) {
    return import_sql.sql`${column} <+> ${toSql(value)}`;
  }
  return import_sql.sql`${column} <+> ${value}`;
}
function innerProduct(column, value) {
  if (Array.isArray(value)) {
    return import_sql.sql`${column} <#> ${toSql(value)}`;
  }
  return import_sql.sql`${column} <#> ${value}`;
}
function cosineDistance(column, value) {
  if (Array.isArray(value)) {
    return import_sql.sql`${column} <=> ${toSql(value)}`;
  }
  return import_sql.sql`${column} <=> ${value}`;
}
function hammingDistance(column, value) {
  if (Array.isArray(value)) {
    return import_sql.sql`${column} <~> ${toSql(value)}`;
  }
  return import_sql.sql`${column} <~> ${value}`;
}
function jaccardDistance(column, value) {
  if (Array.isArray(value)) {
    return import_sql.sql`${column} <%> ${toSql(value)}`;
  }
  return import_sql.sql`${column} <%> ${value}`;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  cosineDistance,
  hammingDistance,
  innerProduct,
  jaccardDistance,
  l1Distance,
  l2Distance
});
//# sourceMappingURL=vector.cjs.map
},
"drizzle-orm/sql/functions/aggregate.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var aggregate_exports = {};
__export(aggregate_exports, {
  avg: () => avg,
  avgDistinct: () => avgDistinct,
  count: () => count,
  countDistinct: () => countDistinct,
  max: () => max,
  min: () => min,
  sum: () => sum,
  sumDistinct: () => sumDistinct
});
module.exports = __toCommonJS(aggregate_exports);
var import_column = require("../../column.cjs");
var import_entity = require("../../entity.cjs");
var import_sql = require("../sql.cjs");
function count(expression) {
  return import_sql.sql`count(${expression || import_sql.sql.raw("*")})`.mapWith(Number);
}
function countDistinct(expression) {
  return import_sql.sql`count(distinct ${expression})`.mapWith(Number);
}
function avg(expression) {
  return import_sql.sql`avg(${expression})`.mapWith(String);
}
function avgDistinct(expression) {
  return import_sql.sql`avg(distinct ${expression})`.mapWith(String);
}
function sum(expression) {
  return import_sql.sql`sum(${expression})`.mapWith(String);
}
function sumDistinct(expression) {
  return import_sql.sql`sum(distinct ${expression})`.mapWith(String);
}
function max(expression) {
  return import_sql.sql`max(${expression})`.mapWith((0, import_entity.is)(expression, import_column.Column) ? expression : String);
}
function min(expression) {
  return import_sql.sql`min(${expression})`.mapWith((0, import_entity.is)(expression, import_column.Column) ? expression : String);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  avg,
  avgDistinct,
  count,
  countDistinct,
  max,
  min,
  sum,
  sumDistinct
});
//# sourceMappingURL=aggregate.cjs.map
},
"drizzle-orm/errors.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var errors_exports = {};
__export(errors_exports, {
  DrizzleError: () => DrizzleError,
  DrizzleQueryError: () => DrizzleQueryError,
  TransactionRollbackError: () => TransactionRollbackError
});
module.exports = __toCommonJS(errors_exports);
var import_entity = require("./entity.cjs");
class DrizzleError extends Error {
  static [import_entity.entityKind] = "DrizzleError";
  constructor({ message, cause }) {
    super(message);
    this.name = "DrizzleError";
    this.cause = cause;
  }
}
class DrizzleQueryError extends Error {
  constructor(query, params, cause) {
    super(`Failed query: ${query}
params: ${params}`);
    this.query = query;
    this.params = params;
    this.cause = cause;
    Error.captureStackTrace(this, DrizzleQueryError);
    if (cause) this.cause = cause;
  }
}
class TransactionRollbackError extends DrizzleError {
  static [import_entity.entityKind] = "TransactionRollbackError";
  constructor() {
    super({ message: "Rollback" });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DrizzleError,
  DrizzleQueryError,
  TransactionRollbackError
});
//# sourceMappingURL=errors.cjs.map
},
"drizzle-orm/cache/core/cache.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cache_exports = {};
__export(cache_exports, {
  Cache: () => Cache,
  NoopCache: () => NoopCache,
  hashQuery: () => hashQuery
});
module.exports = __toCommonJS(cache_exports);
var import_entity = require("../../entity.cjs");
class Cache {
  static [import_entity.entityKind] = "Cache";
}
class NoopCache extends Cache {
  strategy() {
    return "all";
  }
  static [import_entity.entityKind] = "NoopCache";
  async get(_key) {
    return void 0;
  }
  async put(_hashedQuery, _response, _tables, _config) {
  }
  async onMutate(_params) {
  }
}
async function hashQuery(sql, params) {
  const dataToHash = `${sql}-${JSON.stringify(params)}`;
  const encoder = new TextEncoder();
  const data = encoder.encode(dataToHash);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = [...new Uint8Array(hashBuffer)];
  const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  return hashHex;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Cache,
  NoopCache,
  hashQuery
});
//# sourceMappingURL=cache.cjs.map
},
"drizzle-orm/pg-core/index.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var pg_core_exports = {};
module.exports = __toCommonJS(pg_core_exports);
__reExport(pg_core_exports, require("./alias.cjs"), module.exports);
__reExport(pg_core_exports, require("./checks.cjs"), module.exports);
__reExport(pg_core_exports, require("./columns/index.cjs"), module.exports);
__reExport(pg_core_exports, require("./db.cjs"), module.exports);
__reExport(pg_core_exports, require("./dialect.cjs"), module.exports);
__reExport(pg_core_exports, require("./foreign-keys.cjs"), module.exports);
__reExport(pg_core_exports, require("./indexes.cjs"), module.exports);
__reExport(pg_core_exports, require("./policies.cjs"), module.exports);
__reExport(pg_core_exports, require("./primary-keys.cjs"), module.exports);
__reExport(pg_core_exports, require("./query-builders/index.cjs"), module.exports);
__reExport(pg_core_exports, require("./roles.cjs"), module.exports);
__reExport(pg_core_exports, require("./schema.cjs"), module.exports);
__reExport(pg_core_exports, require("./sequence.cjs"), module.exports);
__reExport(pg_core_exports, require("./session.cjs"), module.exports);
__reExport(pg_core_exports, require("./subquery.cjs"), module.exports);
__reExport(pg_core_exports, require("./table.cjs"), module.exports);
__reExport(pg_core_exports, require("./unique-constraint.cjs"), module.exports);
__reExport(pg_core_exports, require("./utils.cjs"), module.exports);
__reExport(pg_core_exports, require("./utils/index.cjs"), module.exports);
__reExport(pg_core_exports, require("./view-common.cjs"), module.exports);
__reExport(pg_core_exports, require("./view.cjs"), module.exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ...require("./alias.cjs"),
  ...require("./checks.cjs"),
  ...require("./columns/index.cjs"),
  ...require("./db.cjs"),
  ...require("./dialect.cjs"),
  ...require("./foreign-keys.cjs"),
  ...require("./indexes.cjs"),
  ...require("./policies.cjs"),
  ...require("./primary-keys.cjs"),
  ...require("./query-builders/index.cjs"),
  ...require("./roles.cjs"),
  ...require("./schema.cjs"),
  ...require("./sequence.cjs"),
  ...require("./session.cjs"),
  ...require("./subquery.cjs"),
  ...require("./table.cjs"),
  ...require("./unique-constraint.cjs"),
  ...require("./utils.cjs"),
  ...require("./utils/index.cjs"),
  ...require("./view-common.cjs"),
  ...require("./view.cjs")
});
//# sourceMappingURL=index.cjs.map
},
"drizzle-orm/pg-core/utils/index.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var utils_exports = {};
module.exports = __toCommonJS(utils_exports);
__reExport(utils_exports, require("./array.cjs"), module.exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ...require("./array.cjs")
});
//# sourceMappingURL=index.cjs.map
},
"drizzle-orm/pg-core/subquery.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var subquery_exports = {};
module.exports = __toCommonJS(subquery_exports);
//# sourceMappingURL=subquery.cjs.map
},
"drizzle-orm/pg-core/sequence.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var sequence_exports = {};
__export(sequence_exports, {
  PgSequence: () => PgSequence,
  isPgSequence: () => isPgSequence,
  pgSequence: () => pgSequence,
  pgSequenceWithSchema: () => pgSequenceWithSchema
});
module.exports = __toCommonJS(sequence_exports);
var import_entity = require("../entity.cjs");
class PgSequence {
  constructor(seqName, seqOptions, schema) {
    this.seqName = seqName;
    this.seqOptions = seqOptions;
    this.schema = schema;
  }
  static [import_entity.entityKind] = "PgSequence";
}
function pgSequence(name, options) {
  return pgSequenceWithSchema(name, options, void 0);
}
function pgSequenceWithSchema(name, options, schema) {
  return new PgSequence(name, options, schema);
}
function isPgSequence(obj) {
  return (0, import_entity.is)(obj, PgSequence);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgSequence,
  isPgSequence,
  pgSequence,
  pgSequenceWithSchema
});
//# sourceMappingURL=sequence.cjs.map
},
"drizzle-orm/pg-core/schema.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var schema_exports = {};
__export(schema_exports, {
  PgSchema: () => PgSchema,
  isPgSchema: () => isPgSchema,
  pgSchema: () => pgSchema
});
module.exports = __toCommonJS(schema_exports);
var import_entity = require("../entity.cjs");
var import_sql = require("../sql/sql.cjs");
var import_enum = require("./columns/enum.cjs");
var import_sequence = require("./sequence.cjs");
var import_table = require("./table.cjs");
var import_view = require("./view.cjs");
class PgSchema {
  constructor(schemaName) {
    this.schemaName = schemaName;
  }
  static [import_entity.entityKind] = "PgSchema";
  table = (name, columns, extraConfig) => {
    return (0, import_table.pgTableWithSchema)(name, columns, extraConfig, this.schemaName);
  };
  view = (name, columns) => {
    return (0, import_view.pgViewWithSchema)(name, columns, this.schemaName);
  };
  materializedView = (name, columns) => {
    return (0, import_view.pgMaterializedViewWithSchema)(name, columns, this.schemaName);
  };
  enum(enumName, input) {
    return Array.isArray(input) ? (0, import_enum.pgEnumWithSchema)(
      enumName,
      [...input],
      this.schemaName
    ) : (0, import_enum.pgEnumObjectWithSchema)(enumName, input, this.schemaName);
  }
  sequence = (name, options) => {
    return (0, import_sequence.pgSequenceWithSchema)(name, options, this.schemaName);
  };
  getSQL() {
    return new import_sql.SQL([import_sql.sql.identifier(this.schemaName)]);
  }
  shouldOmitSQLParens() {
    return true;
  }
}
function isPgSchema(obj) {
  return (0, import_entity.is)(obj, PgSchema);
}
function pgSchema(name) {
  if (name === "public") {
    throw new Error(
      `You can't specify 'public' as schema name. Postgres is using public schema by default. If you want to use 'public' schema, just use pgTable() instead of creating a schema`
    );
  }
  return new PgSchema(name);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgSchema,
  isPgSchema,
  pgSchema
});
//# sourceMappingURL=schema.cjs.map
},
"drizzle-orm/pg-core/roles.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var roles_exports = {};
__export(roles_exports, {
  PgRole: () => PgRole,
  pgRole: () => pgRole
});
module.exports = __toCommonJS(roles_exports);
var import_entity = require("../entity.cjs");
class PgRole {
  constructor(name, config) {
    this.name = name;
    if (config) {
      this.createDb = config.createDb;
      this.createRole = config.createRole;
      this.inherit = config.inherit;
    }
  }
  static [import_entity.entityKind] = "PgRole";
  /** @internal */
  _existing;
  /** @internal */
  createDb;
  /** @internal */
  createRole;
  /** @internal */
  inherit;
  existing() {
    this._existing = true;
    return this;
  }
}
function pgRole(name, config) {
  return new PgRole(name, config);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PgRole,
  pgRole
});
//# sourceMappingURL=roles.cjs.map
},
"drizzle-orm/pg-core/alias.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var alias_exports = {};
__export(alias_exports, {
  alias: () => alias
});
module.exports = __toCommonJS(alias_exports);
var import_alias = require("../alias.cjs");
function alias(table, alias2) {
  return new Proxy(table, new import_alias.TableAliasProxyHandler(alias2, false));
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  alias
});
//# sourceMappingURL=alias.cjs.map
},
"drizzle-orm/logger.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var logger_exports = {};
__export(logger_exports, {
  ConsoleLogWriter: () => ConsoleLogWriter,
  DefaultLogger: () => DefaultLogger,
  NoopLogger: () => NoopLogger
});
module.exports = __toCommonJS(logger_exports);
var import_entity = require("./entity.cjs");
class ConsoleLogWriter {
  static [import_entity.entityKind] = "ConsoleLogWriter";
  write(message) {
    console.log(message);
  }
}
class DefaultLogger {
  static [import_entity.entityKind] = "DefaultLogger";
  writer;
  constructor(config) {
    this.writer = config?.writer ?? new ConsoleLogWriter();
  }
  logQuery(query, params) {
    const stringifiedParams = params.map((p) => {
      try {
        return JSON.stringify(p);
      } catch {
        return String(p);
      }
    });
    const paramsStr = stringifiedParams.length ? ` -- params: [${stringifiedParams.join(", ")}]` : "";
    this.writer.write(`Query: ${query}${paramsStr}`);
  }
}
class NoopLogger {
  static [import_entity.entityKind] = "NoopLogger";
  logQuery() {
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ConsoleLogWriter,
  DefaultLogger,
  NoopLogger
});
//# sourceMappingURL=logger.cjs.map
},
"drizzle-orm/entity.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var entity_exports = {};
__export(entity_exports, {
  entityKind: () => entityKind,
  hasOwnEntityKind: () => hasOwnEntityKind,
  is: () => is
});
module.exports = __toCommonJS(entity_exports);
const entityKind = Symbol.for("drizzle:entityKind");
const hasOwnEntityKind = Symbol.for("drizzle:hasOwnEntityKind");
function is(value, type) {
  if (!value || typeof value !== "object") {
    return false;
  }
  if (value instanceof type) {
    return true;
  }
  if (!Object.prototype.hasOwnProperty.call(type, entityKind)) {
    throw new Error(
      `Class "${type.name ?? "<unknown>"}" doesn't look like a Drizzle entity. If this is incorrect and the class is provided by Drizzle, please report this as a bug.`
    );
  }
  let cls = Object.getPrototypeOf(value).constructor;
  if (cls) {
    while (cls) {
      if (entityKind in cls && cls[entityKind] === type[entityKind]) {
        return true;
      }
      cls = Object.getPrototypeOf(cls);
    }
  }
  return false;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  entityKind,
  hasOwnEntityKind,
  is
});
//# sourceMappingURL=entity.cjs.map
},
"drizzle-orm/cache/core/index.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var core_exports = {};
module.exports = __toCommonJS(core_exports);
__reExport(core_exports, require("./cache.cjs"), module.exports);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ...require("./cache.cjs")
});
//# sourceMappingURL=index.cjs.map
},
"drizzle-orm/node-postgres/driver.cjs": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var driver_exports = {};
__export(driver_exports, {
  NodePgDatabase: () => NodePgDatabase,
  NodePgDriver: () => NodePgDriver,
  drizzle: () => drizzle
});
module.exports = __toCommonJS(driver_exports);
var import_pg = __toESM(require("pg"), 1);
var import_entity = require("../entity.cjs");
var import_logger = require("../logger.cjs");
var import_db = require("../pg-core/db.cjs");
var import_dialect = require("../pg-core/dialect.cjs");
var import_relations = require("../relations.cjs");
var import_utils = require("../utils.cjs");
var import_session = require("./session.cjs");
class NodePgDriver {
  constructor(client, dialect, options = {}) {
    this.client = client;
    this.dialect = dialect;
    this.options = options;
  }
  static [import_entity.entityKind] = "NodePgDriver";
  createSession(schema) {
    return new import_session.NodePgSession(this.client, this.dialect, schema, {
      logger: this.options.logger,
      cache: this.options.cache
    });
  }
}
class NodePgDatabase extends import_db.PgDatabase {
  static [import_entity.entityKind] = "NodePgDatabase";
}
function construct(client, config = {}) {
  const dialect = new import_dialect.PgDialect({ casing: config.casing });
  let logger;
  if (config.logger === true) {
    logger = new import_logger.DefaultLogger();
  } else if (config.logger !== false) {
    logger = config.logger;
  }
  let schema;
  if (config.schema) {
    const tablesConfig = (0, import_relations.extractTablesRelationalConfig)(
      config.schema,
      import_relations.createTableRelationsHelpers
    );
    schema = {
      fullSchema: config.schema,
      schema: tablesConfig.tables,
      tableNamesMap: tablesConfig.tableNamesMap
    };
  }
  const driver = new NodePgDriver(client, dialect, { logger, cache: config.cache });
  const session = driver.createSession(schema);
  const db = new NodePgDatabase(dialect, session, schema);
  db.$client = client;
  db.$cache = config.cache;
  if (db.$cache) {
    db.$cache["invalidate"] = config.cache?.onMutate;
  }
  return db;
}
function drizzle(...params) {
  if (typeof params[0] === "string") {
    const instance = new import_pg.default.Pool({
      connectionString: params[0]
    });
    return construct(instance, params[1]);
  }
  if ((0, import_utils.isConfig)(params[0])) {
    const { connection, client, ...drizzleConfig } = params[0];
    if (client) return construct(client, drizzleConfig);
    const instance = typeof connection === "string" ? new import_pg.default.Pool({
      connectionString: connection
    }) : new import_pg.default.Pool(connection);
    return construct(instance, drizzleConfig);
  }
  return construct(params[0], params[1]);
}
((drizzle2) => {
  function mock(config) {
    return construct({}, config);
  }
  drizzle2.mock = mock;
})(drizzle || (drizzle = {}));
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  NodePgDatabase,
  NodePgDriver,
  drizzle
});
//# sourceMappingURL=driver.cjs.map
},
};
var __thaw_bundle_import_maps = {
"drizzle-orm/./node-postgres/index.cjs": {},
"drizzle-orm/node-postgres/session.cjs": {},
"drizzle-orm/utils.cjs": {},
"drizzle-orm/view-common.cjs": {},
"drizzle-orm/table.cjs": {},
"drizzle-orm/table.utils.cjs": {},
"drizzle-orm/subquery.cjs": {},
"drizzle-orm/column.cjs": {},
"drizzle-orm/tracing.cjs": {},
"drizzle-orm/version.cjs": {},
"drizzle-orm/tracing-utils.cjs": {},
"drizzle-orm/sql/sql.cjs": {},
"drizzle-orm/pg-core/columns/enum.cjs": {},
"drizzle-orm/pg-core/columns/common.cjs": {},
"drizzle-orm/pg-core/utils/array.cjs": {},
"drizzle-orm/pg-core/unique-constraint.cjs": {},
"drizzle-orm/pg-core/foreign-keys.cjs": {},
"drizzle-orm/column-builder.cjs": {},
"drizzle-orm/pg-core/session.cjs": {},
"drizzle-orm/pg-core/db.cjs": {},
"drizzle-orm/pg-core/query-builders/refresh-materialized-view.cjs": {},
"drizzle-orm/query-promise.cjs": {},
"drizzle-orm/pg-core/query-builders/raw.cjs": {},
"drizzle-orm/pg-core/query-builders/query.cjs": {},
"drizzle-orm/relations.cjs": {},
"drizzle-orm/sql/expressions/index.cjs": {},
"drizzle-orm/sql/expressions/select.cjs": {},
"drizzle-orm/sql/expressions/conditions.cjs": {},
"drizzle-orm/pg-core/primary-keys.cjs": {},
"drizzle-orm/pg-core/table.cjs": {},
"drizzle-orm/pg-core/columns/all.cjs": {},
"drizzle-orm/pg-core/columns/vector_extension/vector.cjs": {},
"drizzle-orm/pg-core/columns/vector_extension/sparsevec.cjs": {},
"drizzle-orm/pg-core/columns/vector_extension/halfvec.cjs": {},
"drizzle-orm/pg-core/columns/vector_extension/bit.cjs": {},
"drizzle-orm/pg-core/columns/varchar.cjs": {},
"drizzle-orm/pg-core/columns/uuid.cjs": {},
"drizzle-orm/pg-core/columns/timestamp.cjs": {},
"drizzle-orm/pg-core/columns/date.common.cjs": {},
"drizzle-orm/pg-core/columns/time.cjs": {},
"drizzle-orm/pg-core/columns/text.cjs": {},
"drizzle-orm/pg-core/columns/smallserial.cjs": {},
"drizzle-orm/pg-core/columns/smallint.cjs": {},
"drizzle-orm/pg-core/columns/int.common.cjs": {},
"drizzle-orm/pg-core/columns/serial.cjs": {},
"drizzle-orm/pg-core/columns/real.cjs": {},
"drizzle-orm/pg-core/columns/postgis_extension/geometry.cjs": {},
"drizzle-orm/pg-core/columns/postgis_extension/utils.cjs": {},
"drizzle-orm/pg-core/columns/point.cjs": {},
"drizzle-orm/pg-core/columns/numeric.cjs": {},
"drizzle-orm/pg-core/columns/macaddr8.cjs": {},
"drizzle-orm/pg-core/columns/macaddr.cjs": {},
"drizzle-orm/pg-core/columns/line.cjs": {},
"drizzle-orm/pg-core/columns/jsonb.cjs": {},
"drizzle-orm/pg-core/columns/json.cjs": {},
"drizzle-orm/pg-core/columns/interval.cjs": {},
"drizzle-orm/pg-core/columns/integer.cjs": {},
"drizzle-orm/pg-core/columns/inet.cjs": {},
"drizzle-orm/pg-core/columns/double-precision.cjs": {},
"drizzle-orm/pg-core/columns/date.cjs": {},
"drizzle-orm/pg-core/columns/custom.cjs": {},
"drizzle-orm/pg-core/columns/cidr.cjs": {},
"drizzle-orm/pg-core/columns/char.cjs": {},
"drizzle-orm/pg-core/columns/boolean.cjs": {},
"drizzle-orm/pg-core/columns/bigserial.cjs": {},
"drizzle-orm/pg-core/columns/bigint.cjs": {},
"drizzle-orm/pg-core/query-builders/count.cjs": {},
"drizzle-orm/selection-proxy.cjs": {},
"drizzle-orm/alias.cjs": {},
"drizzle-orm/pg-core/query-builders/index.cjs": {},
"drizzle-orm/pg-core/query-builders/update.cjs": {},
"drizzle-orm/pg-core/utils.cjs": {},
"drizzle-orm/pg-core/view.cjs": {},
"drizzle-orm/pg-core/view-base.cjs": {},
"drizzle-orm/pg-core/view-common.cjs": {},
"drizzle-orm/pg-core/policies.cjs": {},
"drizzle-orm/pg-core/indexes.cjs": {},
"drizzle-orm/pg-core/columns/index.cjs": {},
"drizzle-orm/pg-core/checks.cjs": {},
"drizzle-orm/pg-core/query-builders/select.types.cjs": {},
"drizzle-orm/pg-core/query-builders/select.cjs": {},
"drizzle-orm/query-builders/query-builder.cjs": {},
"drizzle-orm/pg-core/query-builders/query-builder.cjs": {},
"drizzle-orm/pg-core/dialect.cjs": {},
"drizzle-orm/casing.cjs": {},
"drizzle-orm/pg-core/query-builders/insert.cjs": {},
"drizzle-orm/pg-core/query-builders/delete.cjs": {},
"drizzle-orm/sql/index.cjs": {},
"drizzle-orm/sql/functions/index.cjs": {},
"drizzle-orm/sql/functions/vector.cjs": {},
"drizzle-orm/sql/functions/aggregate.cjs": {},
"drizzle-orm/errors.cjs": {},
"drizzle-orm/cache/core/cache.cjs": {},
"drizzle-orm/pg-core/index.cjs": {},
"drizzle-orm/pg-core/utils/index.cjs": {},
"drizzle-orm/pg-core/subquery.cjs": {},
"drizzle-orm/pg-core/sequence.cjs": {},
"drizzle-orm/pg-core/schema.cjs": {},
"drizzle-orm/pg-core/roles.cjs": {},
"drizzle-orm/pg-core/alias.cjs": {},
"drizzle-orm/logger.cjs": {},
"drizzle-orm/entity.cjs": {},
"drizzle-orm/cache/core/index.cjs": {},
"drizzle-orm/node-postgres/driver.cjs": {},
};
var __thaw_bundle_known_package_maps = {
"drizzle-orm/./node-postgres/index.cjs": [],
"drizzle-orm/node-postgres/session.cjs": [],
"drizzle-orm/utils.cjs": [],
"drizzle-orm/view-common.cjs": [],
"drizzle-orm/table.cjs": [],
"drizzle-orm/table.utils.cjs": [],
"drizzle-orm/subquery.cjs": [],
"drizzle-orm/column.cjs": [],
"drizzle-orm/tracing.cjs": [],
"drizzle-orm/version.cjs": [],
"drizzle-orm/tracing-utils.cjs": [],
"drizzle-orm/sql/sql.cjs": [],
"drizzle-orm/pg-core/columns/enum.cjs": [],
"drizzle-orm/pg-core/columns/common.cjs": [],
"drizzle-orm/pg-core/utils/array.cjs": [],
"drizzle-orm/pg-core/unique-constraint.cjs": [],
"drizzle-orm/pg-core/foreign-keys.cjs": [],
"drizzle-orm/column-builder.cjs": [],
"drizzle-orm/pg-core/session.cjs": [],
"drizzle-orm/pg-core/db.cjs": [],
"drizzle-orm/pg-core/query-builders/refresh-materialized-view.cjs": [],
"drizzle-orm/query-promise.cjs": [],
"drizzle-orm/pg-core/query-builders/raw.cjs": [],
"drizzle-orm/pg-core/query-builders/query.cjs": [],
"drizzle-orm/relations.cjs": [],
"drizzle-orm/sql/expressions/index.cjs": [],
"drizzle-orm/sql/expressions/select.cjs": [],
"drizzle-orm/sql/expressions/conditions.cjs": [],
"drizzle-orm/pg-core/primary-keys.cjs": [],
"drizzle-orm/pg-core/table.cjs": [],
"drizzle-orm/pg-core/columns/all.cjs": [],
"drizzle-orm/pg-core/columns/vector_extension/vector.cjs": [],
"drizzle-orm/pg-core/columns/vector_extension/sparsevec.cjs": [],
"drizzle-orm/pg-core/columns/vector_extension/halfvec.cjs": [],
"drizzle-orm/pg-core/columns/vector_extension/bit.cjs": [],
"drizzle-orm/pg-core/columns/varchar.cjs": [],
"drizzle-orm/pg-core/columns/uuid.cjs": [],
"drizzle-orm/pg-core/columns/timestamp.cjs": [],
"drizzle-orm/pg-core/columns/date.common.cjs": [],
"drizzle-orm/pg-core/columns/time.cjs": [],
"drizzle-orm/pg-core/columns/text.cjs": [],
"drizzle-orm/pg-core/columns/smallserial.cjs": [],
"drizzle-orm/pg-core/columns/smallint.cjs": [],
"drizzle-orm/pg-core/columns/int.common.cjs": [],
"drizzle-orm/pg-core/columns/serial.cjs": [],
"drizzle-orm/pg-core/columns/real.cjs": [],
"drizzle-orm/pg-core/columns/postgis_extension/geometry.cjs": [],
"drizzle-orm/pg-core/columns/postgis_extension/utils.cjs": [],
"drizzle-orm/pg-core/columns/point.cjs": [],
"drizzle-orm/pg-core/columns/numeric.cjs": [],
"drizzle-orm/pg-core/columns/macaddr8.cjs": [],
"drizzle-orm/pg-core/columns/macaddr.cjs": [],
"drizzle-orm/pg-core/columns/line.cjs": [],
"drizzle-orm/pg-core/columns/jsonb.cjs": [],
"drizzle-orm/pg-core/columns/json.cjs": [],
"drizzle-orm/pg-core/columns/interval.cjs": [],
"drizzle-orm/pg-core/columns/integer.cjs": [],
"drizzle-orm/pg-core/columns/inet.cjs": [],
"drizzle-orm/pg-core/columns/double-precision.cjs": [],
"drizzle-orm/pg-core/columns/date.cjs": [],
"drizzle-orm/pg-core/columns/custom.cjs": [],
"drizzle-orm/pg-core/columns/cidr.cjs": [],
"drizzle-orm/pg-core/columns/char.cjs": [],
"drizzle-orm/pg-core/columns/boolean.cjs": [],
"drizzle-orm/pg-core/columns/bigserial.cjs": [],
"drizzle-orm/pg-core/columns/bigint.cjs": [],
"drizzle-orm/pg-core/query-builders/count.cjs": [],
"drizzle-orm/selection-proxy.cjs": [],
"drizzle-orm/alias.cjs": [],
"drizzle-orm/pg-core/query-builders/index.cjs": [],
"drizzle-orm/pg-core/query-builders/update.cjs": [],
"drizzle-orm/pg-core/utils.cjs": [],
"drizzle-orm/pg-core/view.cjs": [],
"drizzle-orm/pg-core/view-base.cjs": [],
"drizzle-orm/pg-core/view-common.cjs": [],
"drizzle-orm/pg-core/policies.cjs": [],
"drizzle-orm/pg-core/indexes.cjs": [],
"drizzle-orm/pg-core/columns/index.cjs": [],
"drizzle-orm/pg-core/checks.cjs": [],
"drizzle-orm/pg-core/query-builders/select.types.cjs": [],
"drizzle-orm/pg-core/query-builders/select.cjs": [],
"drizzle-orm/query-builders/query-builder.cjs": [],
"drizzle-orm/pg-core/query-builders/query-builder.cjs": [],
"drizzle-orm/pg-core/dialect.cjs": [],
"drizzle-orm/casing.cjs": [],
"drizzle-orm/pg-core/query-builders/insert.cjs": [],
"drizzle-orm/pg-core/query-builders/delete.cjs": [],
"drizzle-orm/sql/index.cjs": [],
"drizzle-orm/sql/functions/index.cjs": [],
"drizzle-orm/sql/functions/vector.cjs": [],
"drizzle-orm/sql/functions/aggregate.cjs": [],
"drizzle-orm/errors.cjs": [],
"drizzle-orm/cache/core/cache.cjs": [],
"drizzle-orm/pg-core/index.cjs": [],
"drizzle-orm/pg-core/utils/index.cjs": [],
"drizzle-orm/pg-core/subquery.cjs": [],
"drizzle-orm/pg-core/sequence.cjs": [],
"drizzle-orm/pg-core/schema.cjs": [],
"drizzle-orm/pg-core/roles.cjs": [],
"drizzle-orm/pg-core/alias.cjs": [],
"drizzle-orm/logger.cjs": [],
"drizzle-orm/entity.cjs": [],
"drizzle-orm/cache/core/index.cjs": [],
"drizzle-orm/node-postgres/driver.cjs": [],
};
var __thaw_bundle_require_maps = {
"drizzle-orm/./node-postgres/index.cjs": {"./driver.cjs": "drizzle-orm/node-postgres/driver.cjs", "./session.cjs": "drizzle-orm/node-postgres/session.cjs", },
"drizzle-orm/node-postgres/session.cjs": {"../cache/core/index.cjs": "drizzle-orm/cache/core/index.cjs", "../entity.cjs": "drizzle-orm/entity.cjs", "../logger.cjs": "drizzle-orm/logger.cjs", "../pg-core/index.cjs": "drizzle-orm/pg-core/index.cjs", "../pg-core/session.cjs": "drizzle-orm/pg-core/session.cjs", "../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "../tracing.cjs": "drizzle-orm/tracing.cjs", "../utils.cjs": "drizzle-orm/utils.cjs", },
"drizzle-orm/utils.cjs": {"./column.cjs": "drizzle-orm/column.cjs", "./entity.cjs": "drizzle-orm/entity.cjs", "./sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "./subquery.cjs": "drizzle-orm/subquery.cjs", "./table.cjs": "drizzle-orm/table.cjs", "./view-common.cjs": "drizzle-orm/view-common.cjs", },
"drizzle-orm/view-common.cjs": {},
"drizzle-orm/table.cjs": {"./entity.cjs": "drizzle-orm/entity.cjs", "./table.utils.cjs": "drizzle-orm/table.utils.cjs", },
"drizzle-orm/table.utils.cjs": {},
"drizzle-orm/subquery.cjs": {"./entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/column.cjs": {"./entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/tracing.cjs": {"./tracing-utils.cjs": "drizzle-orm/tracing-utils.cjs", "./version.cjs": "drizzle-orm/version.cjs", },
"drizzle-orm/version.cjs": {},
"drizzle-orm/tracing-utils.cjs": {},
"drizzle-orm/sql/sql.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "../pg-core/columns/enum.cjs": "drizzle-orm/pg-core/columns/enum.cjs", "../subquery.cjs": "drizzle-orm/subquery.cjs", "../tracing.cjs": "drizzle-orm/tracing.cjs", "../view-common.cjs": "drizzle-orm/view-common.cjs", "../column.cjs": "drizzle-orm/column.cjs", "../table.cjs": "drizzle-orm/table.cjs", },
"drizzle-orm/pg-core/columns/enum.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/common.cjs": {"../../column-builder.cjs": "drizzle-orm/column-builder.cjs", "../../column.cjs": "drizzle-orm/column.cjs", "../../entity.cjs": "drizzle-orm/entity.cjs", "../foreign-keys.cjs": "drizzle-orm/pg-core/foreign-keys.cjs", "../../tracing-utils.cjs": "drizzle-orm/tracing-utils.cjs", "../unique-constraint.cjs": "drizzle-orm/pg-core/unique-constraint.cjs", "../utils/array.cjs": "drizzle-orm/pg-core/utils/array.cjs", },
"drizzle-orm/pg-core/utils/array.cjs": {},
"drizzle-orm/pg-core/unique-constraint.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "../table.utils.cjs": "drizzle-orm/table.utils.cjs", },
"drizzle-orm/pg-core/foreign-keys.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "../table.utils.cjs": "drizzle-orm/table.utils.cjs", },
"drizzle-orm/column-builder.cjs": {"./entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/pg-core/session.cjs": {"../cache/core/cache.cjs": "drizzle-orm/cache/core/cache.cjs", "../entity.cjs": "drizzle-orm/entity.cjs", "../errors.cjs": "drizzle-orm/errors.cjs", "../sql/index.cjs": "drizzle-orm/sql/index.cjs", "../tracing.cjs": "drizzle-orm/tracing.cjs", "./db.cjs": "drizzle-orm/pg-core/db.cjs", },
"drizzle-orm/pg-core/db.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "./query-builders/index.cjs": "drizzle-orm/pg-core/query-builders/index.cjs", "../selection-proxy.cjs": "drizzle-orm/selection-proxy.cjs", "../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "../subquery.cjs": "drizzle-orm/subquery.cjs", "./query-builders/count.cjs": "drizzle-orm/pg-core/query-builders/count.cjs", "./query-builders/query.cjs": "drizzle-orm/pg-core/query-builders/query.cjs", "./query-builders/raw.cjs": "drizzle-orm/pg-core/query-builders/raw.cjs", "./query-builders/refresh-materialized-view.cjs": "drizzle-orm/pg-core/query-builders/refresh-materialized-view.cjs", },
"drizzle-orm/pg-core/query-builders/refresh-materialized-view.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../query-promise.cjs": "drizzle-orm/query-promise.cjs", "../../tracing.cjs": "drizzle-orm/tracing.cjs", },
"drizzle-orm/query-promise.cjs": {"./entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/pg-core/query-builders/raw.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../query-promise.cjs": "drizzle-orm/query-promise.cjs", },
"drizzle-orm/pg-core/query-builders/query.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../query-promise.cjs": "drizzle-orm/query-promise.cjs", "../../relations.cjs": "drizzle-orm/relations.cjs", "../../tracing.cjs": "drizzle-orm/tracing.cjs", },
"drizzle-orm/relations.cjs": {"./table.cjs": "drizzle-orm/table.cjs", "./column.cjs": "drizzle-orm/column.cjs", "./entity.cjs": "drizzle-orm/entity.cjs", "./pg-core/primary-keys.cjs": "drizzle-orm/pg-core/primary-keys.cjs", "./sql/expressions/index.cjs": "drizzle-orm/sql/expressions/index.cjs", "./sql/sql.cjs": "drizzle-orm/sql/sql.cjs", },
"drizzle-orm/sql/expressions/index.cjs": {"./conditions.cjs": "drizzle-orm/sql/expressions/conditions.cjs", "./select.cjs": "drizzle-orm/sql/expressions/select.cjs", },
"drizzle-orm/sql/expressions/select.cjs": {"../sql.cjs": "drizzle-orm/sql/sql.cjs", },
"drizzle-orm/sql/expressions/conditions.cjs": {"../../column.cjs": "drizzle-orm/column.cjs", "../../entity.cjs": "drizzle-orm/entity.cjs", "../../table.cjs": "drizzle-orm/table.cjs", "../sql.cjs": "drizzle-orm/sql/sql.cjs", },
"drizzle-orm/pg-core/primary-keys.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "./table.cjs": "drizzle-orm/pg-core/table.cjs", },
"drizzle-orm/pg-core/table.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "../table.cjs": "drizzle-orm/table.cjs", "./columns/all.cjs": "drizzle-orm/pg-core/columns/all.cjs", },
"drizzle-orm/pg-core/columns/all.cjs": {"./bigint.cjs": "drizzle-orm/pg-core/columns/bigint.cjs", "./bigserial.cjs": "drizzle-orm/pg-core/columns/bigserial.cjs", "./boolean.cjs": "drizzle-orm/pg-core/columns/boolean.cjs", "./char.cjs": "drizzle-orm/pg-core/columns/char.cjs", "./cidr.cjs": "drizzle-orm/pg-core/columns/cidr.cjs", "./custom.cjs": "drizzle-orm/pg-core/columns/custom.cjs", "./date.cjs": "drizzle-orm/pg-core/columns/date.cjs", "./double-precision.cjs": "drizzle-orm/pg-core/columns/double-precision.cjs", "./inet.cjs": "drizzle-orm/pg-core/columns/inet.cjs", "./integer.cjs": "drizzle-orm/pg-core/columns/integer.cjs", "./interval.cjs": "drizzle-orm/pg-core/columns/interval.cjs", "./json.cjs": "drizzle-orm/pg-core/columns/json.cjs", "./jsonb.cjs": "drizzle-orm/pg-core/columns/jsonb.cjs", "./line.cjs": "drizzle-orm/pg-core/columns/line.cjs", "./macaddr.cjs": "drizzle-orm/pg-core/columns/macaddr.cjs", "./macaddr8.cjs": "drizzle-orm/pg-core/columns/macaddr8.cjs", "./numeric.cjs": "drizzle-orm/pg-core/columns/numeric.cjs", "./point.cjs": "drizzle-orm/pg-core/columns/point.cjs", "./postgis_extension/geometry.cjs": "drizzle-orm/pg-core/columns/postgis_extension/geometry.cjs", "./real.cjs": "drizzle-orm/pg-core/columns/real.cjs", "./serial.cjs": "drizzle-orm/pg-core/columns/serial.cjs", "./smallint.cjs": "drizzle-orm/pg-core/columns/smallint.cjs", "./smallserial.cjs": "drizzle-orm/pg-core/columns/smallserial.cjs", "./text.cjs": "drizzle-orm/pg-core/columns/text.cjs", "./time.cjs": "drizzle-orm/pg-core/columns/time.cjs", "./timestamp.cjs": "drizzle-orm/pg-core/columns/timestamp.cjs", "./uuid.cjs": "drizzle-orm/pg-core/columns/uuid.cjs", "./varchar.cjs": "drizzle-orm/pg-core/columns/varchar.cjs", "./vector_extension/bit.cjs": "drizzle-orm/pg-core/columns/vector_extension/bit.cjs", "./vector_extension/halfvec.cjs": "drizzle-orm/pg-core/columns/vector_extension/halfvec.cjs", "./vector_extension/sparsevec.cjs": "drizzle-orm/pg-core/columns/vector_extension/sparsevec.cjs", "./vector_extension/vector.cjs": "drizzle-orm/pg-core/columns/vector_extension/vector.cjs", },
"drizzle-orm/pg-core/columns/vector_extension/vector.cjs": {"../../../entity.cjs": "drizzle-orm/entity.cjs", "../../../utils.cjs": "drizzle-orm/utils.cjs", "../common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/vector_extension/sparsevec.cjs": {"../../../entity.cjs": "drizzle-orm/entity.cjs", "../../../utils.cjs": "drizzle-orm/utils.cjs", "../common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/vector_extension/halfvec.cjs": {"../../../entity.cjs": "drizzle-orm/entity.cjs", "../../../utils.cjs": "drizzle-orm/utils.cjs", "../common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/vector_extension/bit.cjs": {"../../../entity.cjs": "drizzle-orm/entity.cjs", "../../../utils.cjs": "drizzle-orm/utils.cjs", "../common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/varchar.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/uuid.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/timestamp.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", "./date.common.cjs": "drizzle-orm/pg-core/columns/date.common.cjs", },
"drizzle-orm/pg-core/columns/date.common.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/time.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", "./date.common.cjs": "drizzle-orm/pg-core/columns/date.common.cjs", },
"drizzle-orm/pg-core/columns/text.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/smallserial.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/smallint.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", "./int.common.cjs": "drizzle-orm/pg-core/columns/int.common.cjs", },
"drizzle-orm/pg-core/columns/int.common.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/serial.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/real.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/postgis_extension/geometry.cjs": {"../../../entity.cjs": "drizzle-orm/entity.cjs", "../../../utils.cjs": "drizzle-orm/utils.cjs", "../common.cjs": "drizzle-orm/pg-core/columns/common.cjs", "./utils.cjs": "drizzle-orm/pg-core/columns/postgis_extension/utils.cjs", },
"drizzle-orm/pg-core/columns/postgis_extension/utils.cjs": {},
"drizzle-orm/pg-core/columns/point.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/numeric.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/macaddr8.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/macaddr.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/line.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/jsonb.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/json.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/interval.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/integer.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", "./int.common.cjs": "drizzle-orm/pg-core/columns/int.common.cjs", },
"drizzle-orm/pg-core/columns/inet.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/double-precision.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/date.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", "./date.common.cjs": "drizzle-orm/pg-core/columns/date.common.cjs", },
"drizzle-orm/pg-core/columns/custom.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/cidr.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/char.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/boolean.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/bigserial.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", },
"drizzle-orm/pg-core/columns/bigint.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", "./int.common.cjs": "drizzle-orm/pg-core/columns/int.common.cjs", },
"drizzle-orm/pg-core/query-builders/count.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", },
"drizzle-orm/selection-proxy.cjs": {"./alias.cjs": "drizzle-orm/alias.cjs", "./column.cjs": "drizzle-orm/column.cjs", "./entity.cjs": "drizzle-orm/entity.cjs", "./sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "./subquery.cjs": "drizzle-orm/subquery.cjs", "./view-common.cjs": "drizzle-orm/view-common.cjs", },
"drizzle-orm/alias.cjs": {"./column.cjs": "drizzle-orm/column.cjs", "./entity.cjs": "drizzle-orm/entity.cjs", "./sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "./table.cjs": "drizzle-orm/table.cjs", "./view-common.cjs": "drizzle-orm/view-common.cjs", },
"drizzle-orm/pg-core/query-builders/index.cjs": {"./delete.cjs": "drizzle-orm/pg-core/query-builders/delete.cjs", "./insert.cjs": "drizzle-orm/pg-core/query-builders/insert.cjs", "./query-builder.cjs": "drizzle-orm/pg-core/query-builders/query-builder.cjs", "./refresh-materialized-view.cjs": "drizzle-orm/pg-core/query-builders/refresh-materialized-view.cjs", "./select.cjs": "drizzle-orm/pg-core/query-builders/select.cjs", "./select.types.cjs": "drizzle-orm/pg-core/query-builders/select.types.cjs", "./update.cjs": "drizzle-orm/pg-core/query-builders/update.cjs", },
"drizzle-orm/pg-core/query-builders/update.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../table.cjs": "drizzle-orm/pg-core/table.cjs", "../../query-promise.cjs": "drizzle-orm/query-promise.cjs", "../../selection-proxy.cjs": "drizzle-orm/selection-proxy.cjs", "../../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "../../subquery.cjs": "drizzle-orm/subquery.cjs", "../../table.cjs": "drizzle-orm/table.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "../../view-common.cjs": "drizzle-orm/view-common.cjs", "../utils.cjs": "drizzle-orm/pg-core/utils.cjs", },
"drizzle-orm/pg-core/utils.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "./table.cjs": "drizzle-orm/pg-core/table.cjs", "../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "../subquery.cjs": "drizzle-orm/subquery.cjs", "../table.cjs": "drizzle-orm/table.cjs", "../view-common.cjs": "drizzle-orm/view-common.cjs", "./checks.cjs": "drizzle-orm/pg-core/checks.cjs", "./foreign-keys.cjs": "drizzle-orm/pg-core/foreign-keys.cjs", "./indexes.cjs": "drizzle-orm/pg-core/indexes.cjs", "./policies.cjs": "drizzle-orm/pg-core/policies.cjs", "./primary-keys.cjs": "drizzle-orm/pg-core/primary-keys.cjs", "./unique-constraint.cjs": "drizzle-orm/pg-core/unique-constraint.cjs", "./view-common.cjs": "drizzle-orm/pg-core/view-common.cjs", "./view.cjs": "drizzle-orm/pg-core/view.cjs", },
"drizzle-orm/pg-core/view.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "../selection-proxy.cjs": "drizzle-orm/selection-proxy.cjs", "../utils.cjs": "drizzle-orm/utils.cjs", "./query-builders/query-builder.cjs": "drizzle-orm/pg-core/query-builders/query-builder.cjs", "./table.cjs": "drizzle-orm/pg-core/table.cjs", "./view-base.cjs": "drizzle-orm/pg-core/view-base.cjs", "./view-common.cjs": "drizzle-orm/pg-core/view-common.cjs", },
"drizzle-orm/pg-core/view-base.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", },
"drizzle-orm/pg-core/view-common.cjs": {},
"drizzle-orm/pg-core/policies.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/pg-core/indexes.cjs": {"../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "../entity.cjs": "drizzle-orm/entity.cjs", "./columns/index.cjs": "drizzle-orm/pg-core/columns/index.cjs", },
"drizzle-orm/pg-core/columns/index.cjs": {"./bigint.cjs": "drizzle-orm/pg-core/columns/bigint.cjs", "./bigserial.cjs": "drizzle-orm/pg-core/columns/bigserial.cjs", "./boolean.cjs": "drizzle-orm/pg-core/columns/boolean.cjs", "./char.cjs": "drizzle-orm/pg-core/columns/char.cjs", "./cidr.cjs": "drizzle-orm/pg-core/columns/cidr.cjs", "./common.cjs": "drizzle-orm/pg-core/columns/common.cjs", "./custom.cjs": "drizzle-orm/pg-core/columns/custom.cjs", "./date.cjs": "drizzle-orm/pg-core/columns/date.cjs", "./double-precision.cjs": "drizzle-orm/pg-core/columns/double-precision.cjs", "./enum.cjs": "drizzle-orm/pg-core/columns/enum.cjs", "./inet.cjs": "drizzle-orm/pg-core/columns/inet.cjs", "./int.common.cjs": "drizzle-orm/pg-core/columns/int.common.cjs", "./integer.cjs": "drizzle-orm/pg-core/columns/integer.cjs", "./interval.cjs": "drizzle-orm/pg-core/columns/interval.cjs", "./json.cjs": "drizzle-orm/pg-core/columns/json.cjs", "./jsonb.cjs": "drizzle-orm/pg-core/columns/jsonb.cjs", "./line.cjs": "drizzle-orm/pg-core/columns/line.cjs", "./macaddr.cjs": "drizzle-orm/pg-core/columns/macaddr.cjs", "./macaddr8.cjs": "drizzle-orm/pg-core/columns/macaddr8.cjs", "./numeric.cjs": "drizzle-orm/pg-core/columns/numeric.cjs", "./point.cjs": "drizzle-orm/pg-core/columns/point.cjs", "./postgis_extension/geometry.cjs": "drizzle-orm/pg-core/columns/postgis_extension/geometry.cjs", "./real.cjs": "drizzle-orm/pg-core/columns/real.cjs", "./serial.cjs": "drizzle-orm/pg-core/columns/serial.cjs", "./smallint.cjs": "drizzle-orm/pg-core/columns/smallint.cjs", "./smallserial.cjs": "drizzle-orm/pg-core/columns/smallserial.cjs", "./text.cjs": "drizzle-orm/pg-core/columns/text.cjs", "./time.cjs": "drizzle-orm/pg-core/columns/time.cjs", "./timestamp.cjs": "drizzle-orm/pg-core/columns/timestamp.cjs", "./uuid.cjs": "drizzle-orm/pg-core/columns/uuid.cjs", "./varchar.cjs": "drizzle-orm/pg-core/columns/varchar.cjs", "./vector_extension/bit.cjs": "drizzle-orm/pg-core/columns/vector_extension/bit.cjs", "./vector_extension/halfvec.cjs": "drizzle-orm/pg-core/columns/vector_extension/halfvec.cjs", "./vector_extension/sparsevec.cjs": "drizzle-orm/pg-core/columns/vector_extension/sparsevec.cjs", "./vector_extension/vector.cjs": "drizzle-orm/pg-core/columns/vector_extension/vector.cjs", },
"drizzle-orm/pg-core/checks.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/pg-core/query-builders/select.types.cjs": {},
"drizzle-orm/pg-core/query-builders/select.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../view-base.cjs": "drizzle-orm/pg-core/view-base.cjs", "../../query-builders/query-builder.cjs": "drizzle-orm/query-builders/query-builder.cjs", "../../query-promise.cjs": "drizzle-orm/query-promise.cjs", "../../selection-proxy.cjs": "drizzle-orm/selection-proxy.cjs", "../../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "../../subquery.cjs": "drizzle-orm/subquery.cjs", "../../table.cjs": "drizzle-orm/table.cjs", "../../tracing.cjs": "drizzle-orm/tracing.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "../../view-common.cjs": "drizzle-orm/view-common.cjs", "../utils.cjs": "drizzle-orm/pg-core/utils.cjs", },
"drizzle-orm/query-builders/query-builder.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/pg-core/query-builders/query-builder.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../dialect.cjs": "drizzle-orm/pg-core/dialect.cjs", "../../selection-proxy.cjs": "drizzle-orm/selection-proxy.cjs", "../../subquery.cjs": "drizzle-orm/subquery.cjs", "./select.cjs": "drizzle-orm/pg-core/query-builders/select.cjs", },
"drizzle-orm/pg-core/dialect.cjs": {"../alias.cjs": "drizzle-orm/alias.cjs", "../casing.cjs": "drizzle-orm/casing.cjs", "../column.cjs": "drizzle-orm/column.cjs", "../entity.cjs": "drizzle-orm/entity.cjs", "../errors.cjs": "drizzle-orm/errors.cjs", "./columns/index.cjs": "drizzle-orm/pg-core/columns/index.cjs", "./table.cjs": "drizzle-orm/pg-core/table.cjs", "../relations.cjs": "drizzle-orm/relations.cjs", "../sql/index.cjs": "drizzle-orm/sql/index.cjs", "../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "../subquery.cjs": "drizzle-orm/subquery.cjs", "../table.cjs": "drizzle-orm/table.cjs", "../utils.cjs": "drizzle-orm/utils.cjs", "../view-common.cjs": "drizzle-orm/view-common.cjs", "./view-base.cjs": "drizzle-orm/pg-core/view-base.cjs", },
"drizzle-orm/casing.cjs": {"./entity.cjs": "drizzle-orm/entity.cjs", "./table.cjs": "drizzle-orm/table.cjs", },
"drizzle-orm/pg-core/query-builders/insert.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../query-promise.cjs": "drizzle-orm/query-promise.cjs", "../../selection-proxy.cjs": "drizzle-orm/selection-proxy.cjs", "../../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "../../table.cjs": "drizzle-orm/table.cjs", "../../tracing.cjs": "drizzle-orm/tracing.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "../utils.cjs": "drizzle-orm/pg-core/utils.cjs", "./query-builder.cjs": "drizzle-orm/pg-core/query-builders/query-builder.cjs", },
"drizzle-orm/pg-core/query-builders/delete.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", "../../query-promise.cjs": "drizzle-orm/query-promise.cjs", "../../selection-proxy.cjs": "drizzle-orm/selection-proxy.cjs", "../../table.cjs": "drizzle-orm/table.cjs", "../../tracing.cjs": "drizzle-orm/tracing.cjs", "../../utils.cjs": "drizzle-orm/utils.cjs", "../utils.cjs": "drizzle-orm/pg-core/utils.cjs", },
"drizzle-orm/sql/index.cjs": {"./expressions/index.cjs": "drizzle-orm/sql/expressions/index.cjs", "./functions/index.cjs": "drizzle-orm/sql/functions/index.cjs", "./sql.cjs": "drizzle-orm/sql/sql.cjs", },
"drizzle-orm/sql/functions/index.cjs": {"./aggregate.cjs": "drizzle-orm/sql/functions/aggregate.cjs", "./vector.cjs": "drizzle-orm/sql/functions/vector.cjs", },
"drizzle-orm/sql/functions/vector.cjs": {"../sql.cjs": "drizzle-orm/sql/sql.cjs", },
"drizzle-orm/sql/functions/aggregate.cjs": {"../../column.cjs": "drizzle-orm/column.cjs", "../../entity.cjs": "drizzle-orm/entity.cjs", "../sql.cjs": "drizzle-orm/sql/sql.cjs", },
"drizzle-orm/errors.cjs": {"./entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/cache/core/cache.cjs": {"../../entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/pg-core/index.cjs": {"./alias.cjs": "drizzle-orm/pg-core/alias.cjs", "./checks.cjs": "drizzle-orm/pg-core/checks.cjs", "./columns/index.cjs": "drizzle-orm/pg-core/columns/index.cjs", "./db.cjs": "drizzle-orm/pg-core/db.cjs", "./dialect.cjs": "drizzle-orm/pg-core/dialect.cjs", "./foreign-keys.cjs": "drizzle-orm/pg-core/foreign-keys.cjs", "./indexes.cjs": "drizzle-orm/pg-core/indexes.cjs", "./policies.cjs": "drizzle-orm/pg-core/policies.cjs", "./primary-keys.cjs": "drizzle-orm/pg-core/primary-keys.cjs", "./query-builders/index.cjs": "drizzle-orm/pg-core/query-builders/index.cjs", "./roles.cjs": "drizzle-orm/pg-core/roles.cjs", "./schema.cjs": "drizzle-orm/pg-core/schema.cjs", "./sequence.cjs": "drizzle-orm/pg-core/sequence.cjs", "./session.cjs": "drizzle-orm/pg-core/session.cjs", "./subquery.cjs": "drizzle-orm/pg-core/subquery.cjs", "./table.cjs": "drizzle-orm/pg-core/table.cjs", "./unique-constraint.cjs": "drizzle-orm/pg-core/unique-constraint.cjs", "./utils.cjs": "drizzle-orm/pg-core/utils.cjs", "./utils/index.cjs": "drizzle-orm/pg-core/utils/index.cjs", "./view-common.cjs": "drizzle-orm/pg-core/view-common.cjs", "./view.cjs": "drizzle-orm/pg-core/view.cjs", },
"drizzle-orm/pg-core/utils/index.cjs": {"./array.cjs": "drizzle-orm/pg-core/utils/array.cjs", },
"drizzle-orm/pg-core/subquery.cjs": {},
"drizzle-orm/pg-core/sequence.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/pg-core/schema.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "../sql/sql.cjs": "drizzle-orm/sql/sql.cjs", "./columns/enum.cjs": "drizzle-orm/pg-core/columns/enum.cjs", "./sequence.cjs": "drizzle-orm/pg-core/sequence.cjs", "./table.cjs": "drizzle-orm/pg-core/table.cjs", "./view.cjs": "drizzle-orm/pg-core/view.cjs", },
"drizzle-orm/pg-core/roles.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/pg-core/alias.cjs": {"../alias.cjs": "drizzle-orm/alias.cjs", },
"drizzle-orm/logger.cjs": {"./entity.cjs": "drizzle-orm/entity.cjs", },
"drizzle-orm/entity.cjs": {},
"drizzle-orm/cache/core/index.cjs": {"./cache.cjs": "drizzle-orm/cache/core/cache.cjs", },
"drizzle-orm/node-postgres/driver.cjs": {"../entity.cjs": "drizzle-orm/entity.cjs", "../logger.cjs": "drizzle-orm/logger.cjs", "../pg-core/db.cjs": "drizzle-orm/pg-core/db.cjs", "../pg-core/dialect.cjs": "drizzle-orm/pg-core/dialect.cjs", "../relations.cjs": "drizzle-orm/relations.cjs", "../utils.cjs": "drizzle-orm/utils.cjs", "./session.cjs": "drizzle-orm/node-postgres/session.cjs", },
};
var __thaw_bundle_export_graphs = JSON.parse("{}");
var __thaw_bundle_commonjs_contexts = JSON.parse("{\"drizzle-orm/./node-postgres/index.cjs\":true,\"drizzle-orm/node-postgres/session.cjs\":true,\"drizzle-orm/utils.cjs\":true,\"drizzle-orm/view-common.cjs\":true,\"drizzle-orm/table.cjs\":true,\"drizzle-orm/table.utils.cjs\":true,\"drizzle-orm/subquery.cjs\":true,\"drizzle-orm/column.cjs\":true,\"drizzle-orm/tracing.cjs\":true,\"drizzle-orm/version.cjs\":true,\"drizzle-orm/tracing-utils.cjs\":true,\"drizzle-orm/sql/sql.cjs\":true,\"drizzle-orm/pg-core/columns/enum.cjs\":true,\"drizzle-orm/pg-core/columns/common.cjs\":true,\"drizzle-orm/pg-core/utils/array.cjs\":true,\"drizzle-orm/pg-core/unique-constraint.cjs\":true,\"drizzle-orm/pg-core/foreign-keys.cjs\":true,\"drizzle-orm/column-builder.cjs\":true,\"drizzle-orm/pg-core/session.cjs\":true,\"drizzle-orm/pg-core/db.cjs\":true,\"drizzle-orm/pg-core/query-builders/refresh-materialized-view.cjs\":true,\"drizzle-orm/query-promise.cjs\":true,\"drizzle-orm/pg-core/query-builders/raw.cjs\":true,\"drizzle-orm/pg-core/query-builders/query.cjs\":true,\"drizzle-orm/relations.cjs\":true,\"drizzle-orm/sql/expressions/index.cjs\":true,\"drizzle-orm/sql/expressions/select.cjs\":true,\"drizzle-orm/sql/expressions/conditions.cjs\":true,\"drizzle-orm/pg-core/primary-keys.cjs\":true,\"drizzle-orm/pg-core/table.cjs\":true,\"drizzle-orm/pg-core/columns/all.cjs\":true,\"drizzle-orm/pg-core/columns/vector_extension/vector.cjs\":true,\"drizzle-orm/pg-core/columns/vector_extension/sparsevec.cjs\":true,\"drizzle-orm/pg-core/columns/vector_extension/halfvec.cjs\":true,\"drizzle-orm/pg-core/columns/vector_extension/bit.cjs\":true,\"drizzle-orm/pg-core/columns/varchar.cjs\":true,\"drizzle-orm/pg-core/columns/uuid.cjs\":true,\"drizzle-orm/pg-core/columns/timestamp.cjs\":true,\"drizzle-orm/pg-core/columns/date.common.cjs\":true,\"drizzle-orm/pg-core/columns/time.cjs\":true,\"drizzle-orm/pg-core/columns/text.cjs\":true,\"drizzle-orm/pg-core/columns/smallserial.cjs\":true,\"drizzle-orm/pg-core/columns/smallint.cjs\":true,\"drizzle-orm/pg-core/columns/int.common.cjs\":true,\"drizzle-orm/pg-core/columns/serial.cjs\":true,\"drizzle-orm/pg-core/columns/real.cjs\":true,\"drizzle-orm/pg-core/columns/postgis_extension/geometry.cjs\":true,\"drizzle-orm/pg-core/columns/postgis_extension/utils.cjs\":true,\"drizzle-orm/pg-core/columns/point.cjs\":true,\"drizzle-orm/pg-core/columns/numeric.cjs\":true,\"drizzle-orm/pg-core/columns/macaddr8.cjs\":true,\"drizzle-orm/pg-core/columns/macaddr.cjs\":true,\"drizzle-orm/pg-core/columns/line.cjs\":true,\"drizzle-orm/pg-core/columns/jsonb.cjs\":true,\"drizzle-orm/pg-core/columns/json.cjs\":true,\"drizzle-orm/pg-core/columns/interval.cjs\":true,\"drizzle-orm/pg-core/columns/integer.cjs\":true,\"drizzle-orm/pg-core/columns/inet.cjs\":true,\"drizzle-orm/pg-core/columns/double-precision.cjs\":true,\"drizzle-orm/pg-core/columns/date.cjs\":true,\"drizzle-orm/pg-core/columns/custom.cjs\":true,\"drizzle-orm/pg-core/columns/cidr.cjs\":true,\"drizzle-orm/pg-core/columns/char.cjs\":true,\"drizzle-orm/pg-core/columns/boolean.cjs\":true,\"drizzle-orm/pg-core/columns/bigserial.cjs\":true,\"drizzle-orm/pg-core/columns/bigint.cjs\":true,\"drizzle-orm/pg-core/query-builders/count.cjs\":true,\"drizzle-orm/selection-proxy.cjs\":true,\"drizzle-orm/alias.cjs\":true,\"drizzle-orm/pg-core/query-builders/index.cjs\":true,\"drizzle-orm/pg-core/query-builders/update.cjs\":true,\"drizzle-orm/pg-core/utils.cjs\":true,\"drizzle-orm/pg-core/view.cjs\":true,\"drizzle-orm/pg-core/view-base.cjs\":true,\"drizzle-orm/pg-core/view-common.cjs\":true,\"drizzle-orm/pg-core/policies.cjs\":true,\"drizzle-orm/pg-core/indexes.cjs\":true,\"drizzle-orm/pg-core/columns/index.cjs\":true,\"drizzle-orm/pg-core/checks.cjs\":true,\"drizzle-orm/pg-core/query-builders/select.types.cjs\":true,\"drizzle-orm/pg-core/query-builders/select.cjs\":true,\"drizzle-orm/query-builders/query-builder.cjs\":true,\"drizzle-orm/pg-core/query-builders/query-builder.cjs\":true,\"drizzle-orm/pg-core/dialect.cjs\":true,\"drizzle-orm/casing.cjs\":true,\"drizzle-orm/pg-core/query-builders/insert.cjs\":true,\"drizzle-orm/pg-core/query-builders/delete.cjs\":true,\"drizzle-orm/sql/index.cjs\":true,\"drizzle-orm/sql/functions/index.cjs\":true,\"drizzle-orm/sql/functions/vector.cjs\":true,\"drizzle-orm/sql/functions/aggregate.cjs\":true,\"drizzle-orm/errors.cjs\":true,\"drizzle-orm/cache/core/cache.cjs\":true,\"drizzle-orm/pg-core/index.cjs\":true,\"drizzle-orm/pg-core/utils/index.cjs\":true,\"drizzle-orm/pg-core/subquery.cjs\":true,\"drizzle-orm/pg-core/sequence.cjs\":true,\"drizzle-orm/pg-core/schema.cjs\":true,\"drizzle-orm/pg-core/roles.cjs\":true,\"drizzle-orm/pg-core/alias.cjs\":true,\"drizzle-orm/logger.cjs\":true,\"drizzle-orm/entity.cjs\":true,\"drizzle-orm/cache/core/index.cjs\":true,\"drizzle-orm/node-postgres/driver.cjs\":true}");
var __thaw_bundle_cjs_export_names = JSON.parse("{\"drizzle-orm/./node-postgres/index.cjs\":[\"default\"],\"drizzle-orm/node-postgres/session.cjs\":[\"NodePgPreparedQuery\",\"NodePgSession\",\"NodePgTransaction\",\"default\"],\"drizzle-orm/utils.cjs\":[\"applyMixins\",\"default\",\"getColumnNameAndConfig\",\"getTableColumns\",\"getTableLikeName\",\"getViewSelectedFields\",\"haveSameKeys\",\"isConfig\",\"mapResultRow\",\"mapUpdateSet\",\"orderSelectedFields\",\"textDecoder\"],\"drizzle-orm/view-common.cjs\":[\"ViewBaseConfig\",\"default\"],\"drizzle-orm/table.cjs\":[\"BaseName\",\"Columns\",\"ExtraConfigBuilder\",\"ExtraConfigColumns\",\"IsAlias\",\"OriginalName\",\"Schema\",\"Table\",\"default\",\"getTableName\",\"getTableUniqueName\",\"isTable\"],\"drizzle-orm/table.utils.cjs\":[\"TableName\",\"default\"],\"drizzle-orm/subquery.cjs\":[\"Subquery\",\"WithSubquery\",\"default\"],\"drizzle-orm/column.cjs\":[\"Column\",\"default\"],\"drizzle-orm/tracing.cjs\":[\"default\",\"tracer\"],\"drizzle-orm/version.cjs\":[\"compatibilityVersion\",\"default\",\"npmVersion\"],\"drizzle-orm/tracing-utils.cjs\":[\"default\",\"iife\"],\"drizzle-orm/sql/sql.cjs\":[\"FakePrimitiveParam\",\"Name\",\"Param\",\"Placeholder\",\"SQL\",\"StringChunk\",\"View\",\"default\",\"fillPlaceholders\",\"getViewName\",\"isDriverValueEncoder\",\"isSQLWrapper\",\"isView\",\"name\",\"noopDecoder\",\"noopEncoder\",\"noopMapper\",\"param\",\"placeholder\",\"sql\"],\"drizzle-orm/pg-core/columns/enum.cjs\":[\"PgEnumColumn\",\"PgEnumColumnBuilder\",\"PgEnumObjectColumn\",\"PgEnumObjectColumnBuilder\",\"default\",\"isPgEnum\",\"pgEnum\",\"pgEnumObjectWithSchema\",\"pgEnumWithSchema\"],\"drizzle-orm/pg-core/columns/common.cjs\":[\"ExtraConfigColumn\",\"IndexedColumn\",\"PgArray\",\"PgArrayBuilder\",\"PgColumn\",\"PgColumnBuilder\",\"default\"],\"drizzle-orm/pg-core/utils/array.cjs\":[\"default\",\"makePgArray\",\"parsePgArray\",\"parsePgNestedArray\"],\"drizzle-orm/pg-core/unique-constraint.cjs\":[\"UniqueConstraint\",\"UniqueConstraintBuilder\",\"UniqueOnConstraintBuilder\",\"default\",\"unique\",\"uniqueKeyName\"],\"drizzle-orm/pg-core/foreign-keys.cjs\":[\"ForeignKey\",\"ForeignKeyBuilder\",\"default\",\"foreignKey\"],\"drizzle-orm/column-builder.cjs\":[\"ColumnBuilder\",\"default\"],\"drizzle-orm/pg-core/session.cjs\":[\"PgPreparedQuery\",\"PgSession\",\"PgTransaction\",\"default\"],\"drizzle-orm/pg-core/db.cjs\":[\"PgDatabase\",\"default\",\"withReplicas\"],\"drizzle-orm/pg-core/query-builders/refresh-materialized-view.cjs\":[\"PgRefreshMaterializedView\",\"default\"],\"drizzle-orm/query-promise.cjs\":[\"QueryPromise\",\"default\"],\"drizzle-orm/pg-core/query-builders/raw.cjs\":[\"PgRaw\",\"default\"],\"drizzle-orm/pg-core/query-builders/query.cjs\":[\"PgRelationalQuery\",\"RelationalQueryBuilder\",\"default\"],\"drizzle-orm/relations.cjs\":[\"Many\",\"One\",\"Relation\",\"Relations\",\"createMany\",\"createOne\",\"createTableRelationsHelpers\",\"default\",\"extractTablesRelationalConfig\",\"getOperators\",\"getOrderByOperators\",\"mapRelationalRow\",\"normalizeRelation\",\"relations\"],\"drizzle-orm/sql/expressions/index.cjs\":[\"default\"],\"drizzle-orm/sql/expressions/select.cjs\":[\"asc\",\"default\",\"desc\"],\"drizzle-orm/sql/expressions/conditions.cjs\":[\"and\",\"arrayContained\",\"arrayContains\",\"arrayOverlaps\",\"between\",\"bindIfParam\",\"default\",\"eq\",\"exists\",\"gt\",\"gte\",\"ilike\",\"inArray\",\"isNotNull\",\"isNull\",\"like\",\"lt\",\"lte\",\"ne\",\"not\",\"notBetween\",\"notExists\",\"notIlike\",\"notInArray\",\"notLike\",\"or\"],\"drizzle-orm/pg-core/primary-keys.cjs\":[\"PrimaryKey\",\"PrimaryKeyBuilder\",\"default\",\"primaryKey\"],\"drizzle-orm/pg-core/table.cjs\":[\"EnableRLS\",\"InlineForeignKeys\",\"PgTable\",\"default\",\"pgTable\",\"pgTableCreator\",\"pgTableWithSchema\"],\"drizzle-orm/pg-core/columns/all.cjs\":[\"default\",\"getPgColumnBuilders\"],\"drizzle-orm/pg-core/columns/vector_extension/vector.cjs\":[\"PgVector\",\"PgVectorBuilder\",\"default\",\"vector\"],\"drizzle-orm/pg-core/columns/vector_extension/sparsevec.cjs\":[\"PgSparseVector\",\"PgSparseVectorBuilder\",\"default\",\"sparsevec\"],\"drizzle-orm/pg-core/columns/vector_extension/halfvec.cjs\":[\"PgHalfVector\",\"PgHalfVectorBuilder\",\"default\",\"halfvec\"],\"drizzle-orm/pg-core/columns/vector_extension/bit.cjs\":[\"PgBinaryVector\",\"PgBinaryVectorBuilder\",\"bit\",\"default\"],\"drizzle-orm/pg-core/columns/varchar.cjs\":[\"PgVarchar\",\"PgVarcharBuilder\",\"default\",\"varchar\"],\"drizzle-orm/pg-core/columns/uuid.cjs\":[\"PgUUID\",\"PgUUIDBuilder\",\"default\",\"uuid\"],\"drizzle-orm/pg-core/columns/timestamp.cjs\":[\"PgTimestamp\",\"PgTimestampBuilder\",\"PgTimestampString\",\"PgTimestampStringBuilder\",\"default\",\"timestamp\"],\"drizzle-orm/pg-core/columns/date.common.cjs\":[\"PgDateColumnBaseBuilder\",\"default\"],\"drizzle-orm/pg-core/columns/time.cjs\":[\"PgTime\",\"PgTimeBuilder\",\"default\",\"time\"],\"drizzle-orm/pg-core/columns/text.cjs\":[\"PgText\",\"PgTextBuilder\",\"default\",\"text\"],\"drizzle-orm/pg-core/columns/smallserial.cjs\":[\"PgSmallSerial\",\"PgSmallSerialBuilder\",\"default\",\"smallserial\"],\"drizzle-orm/pg-core/columns/smallint.cjs\":[\"PgSmallInt\",\"PgSmallIntBuilder\",\"default\",\"smallint\"],\"drizzle-orm/pg-core/columns/int.common.cjs\":[\"PgIntColumnBaseBuilder\",\"default\"],\"drizzle-orm/pg-core/columns/serial.cjs\":[\"PgSerial\",\"PgSerialBuilder\",\"default\",\"serial\"],\"drizzle-orm/pg-core/columns/real.cjs\":[\"PgReal\",\"PgRealBuilder\",\"default\",\"real\"],\"drizzle-orm/pg-core/columns/postgis_extension/geometry.cjs\":[\"PgGeometry\",\"PgGeometryBuilder\",\"PgGeometryObject\",\"PgGeometryObjectBuilder\",\"default\",\"geometry\"],\"drizzle-orm/pg-core/columns/postgis_extension/utils.cjs\":[\"default\",\"parseEWKB\"],\"drizzle-orm/pg-core/columns/point.cjs\":[\"PgPointObject\",\"PgPointObjectBuilder\",\"PgPointTuple\",\"PgPointTupleBuilder\",\"default\",\"point\"],\"drizzle-orm/pg-core/columns/numeric.cjs\":[\"PgNumeric\",\"PgNumericBigInt\",\"PgNumericBigIntBuilder\",\"PgNumericBuilder\",\"PgNumericNumber\",\"PgNumericNumberBuilder\",\"decimal\",\"default\",\"numeric\"],\"drizzle-orm/pg-core/columns/macaddr8.cjs\":[\"PgMacaddr8\",\"PgMacaddr8Builder\",\"default\",\"macaddr8\"],\"drizzle-orm/pg-core/columns/macaddr.cjs\":[\"PgMacaddr\",\"PgMacaddrBuilder\",\"default\",\"macaddr\"],\"drizzle-orm/pg-core/columns/line.cjs\":[\"PgLineABC\",\"PgLineABCBuilder\",\"PgLineBuilder\",\"PgLineTuple\",\"default\",\"line\"],\"drizzle-orm/pg-core/columns/jsonb.cjs\":[\"PgJsonb\",\"PgJsonbBuilder\",\"default\",\"jsonb\"],\"drizzle-orm/pg-core/columns/json.cjs\":[\"PgJson\",\"PgJsonBuilder\",\"default\",\"json\"],\"drizzle-orm/pg-core/columns/interval.cjs\":[\"PgInterval\",\"PgIntervalBuilder\",\"default\",\"interval\"],\"drizzle-orm/pg-core/columns/integer.cjs\":[\"PgInteger\",\"PgIntegerBuilder\",\"default\",\"integer\"],\"drizzle-orm/pg-core/columns/inet.cjs\":[\"PgInet\",\"PgInetBuilder\",\"default\",\"inet\"],\"drizzle-orm/pg-core/columns/double-precision.cjs\":[\"PgDoublePrecision\",\"PgDoublePrecisionBuilder\",\"default\",\"doublePrecision\"],\"drizzle-orm/pg-core/columns/date.cjs\":[\"PgDate\",\"PgDateBuilder\",\"PgDateString\",\"PgDateStringBuilder\",\"date\",\"default\"],\"drizzle-orm/pg-core/columns/custom.cjs\":[\"PgCustomColumn\",\"PgCustomColumnBuilder\",\"customType\",\"default\"],\"drizzle-orm/pg-core/columns/cidr.cjs\":[\"PgCidr\",\"PgCidrBuilder\",\"cidr\",\"default\"],\"drizzle-orm/pg-core/columns/char.cjs\":[\"PgChar\",\"PgCharBuilder\",\"char\",\"default\"],\"drizzle-orm/pg-core/columns/boolean.cjs\":[\"PgBoolean\",\"PgBooleanBuilder\",\"boolean\",\"default\"],\"drizzle-orm/pg-core/columns/bigserial.cjs\":[\"PgBigSerial53\",\"PgBigSerial53Builder\",\"PgBigSerial64\",\"PgBigSerial64Builder\",\"bigserial\",\"default\"],\"drizzle-orm/pg-core/columns/bigint.cjs\":[\"PgBigInt53\",\"PgBigInt53Builder\",\"PgBigInt64\",\"PgBigInt64Builder\",\"bigint\",\"default\"],\"drizzle-orm/pg-core/query-builders/count.cjs\":[\"PgCountBuilder\",\"default\"],\"drizzle-orm/selection-proxy.cjs\":[\"SelectionProxyHandler\",\"default\"],\"drizzle-orm/alias.cjs\":[\"ColumnAliasProxyHandler\",\"RelationTableAliasProxyHandler\",\"TableAliasProxyHandler\",\"aliasedRelation\",\"aliasedTable\",\"aliasedTableColumn\",\"default\",\"mapColumnsInAliasedSQLToAlias\",\"mapColumnsInSQLToAlias\"],\"drizzle-orm/pg-core/query-builders/index.cjs\":[\"default\"],\"drizzle-orm/pg-core/query-builders/update.cjs\":[\"PgUpdateBase\",\"PgUpdateBuilder\",\"default\"],\"drizzle-orm/pg-core/utils.cjs\":[\"default\",\"extractUsedTable\",\"getMaterializedViewConfig\",\"getTableConfig\",\"getViewConfig\"],\"drizzle-orm/pg-core/view.cjs\":[\"DefaultViewBuilderCore\",\"ManualMaterializedViewBuilder\",\"ManualViewBuilder\",\"MaterializedViewBuilder\",\"MaterializedViewBuilderCore\",\"PgMaterializedView\",\"PgMaterializedViewConfig\",\"PgView\",\"ViewBuilder\",\"default\",\"isPgMaterializedView\",\"isPgView\",\"pgMaterializedView\",\"pgMaterializedViewWithSchema\",\"pgView\",\"pgViewWithSchema\"],\"drizzle-orm/pg-core/view-base.cjs\":[\"PgViewBase\",\"default\"],\"drizzle-orm/pg-core/view-common.cjs\":[\"PgViewConfig\",\"default\"],\"drizzle-orm/pg-core/policies.cjs\":[\"PgPolicy\",\"default\",\"pgPolicy\"],\"drizzle-orm/pg-core/indexes.cjs\":[\"Index\",\"IndexBuilder\",\"IndexBuilderOn\",\"default\",\"index\",\"uniqueIndex\"],\"drizzle-orm/pg-core/columns/index.cjs\":[\"default\"],\"drizzle-orm/pg-core/checks.cjs\":[\"Check\",\"CheckBuilder\",\"check\",\"default\"],\"drizzle-orm/pg-core/query-builders/select.types.cjs\":[\"default\"],\"drizzle-orm/pg-core/query-builders/select.cjs\":[\"PgSelectBase\",\"PgSelectBuilder\",\"PgSelectQueryBuilderBase\",\"default\",\"except\",\"exceptAll\",\"intersect\",\"intersectAll\",\"union\",\"unionAll\"],\"drizzle-orm/query-builders/query-builder.cjs\":[\"TypedQueryBuilder\",\"default\"],\"drizzle-orm/pg-core/query-builders/query-builder.cjs\":[\"QueryBuilder\",\"default\"],\"drizzle-orm/pg-core/dialect.cjs\":[\"PgDialect\",\"default\"],\"drizzle-orm/casing.cjs\":[\"CasingCache\",\"default\",\"toCamelCase\",\"toSnakeCase\"],\"drizzle-orm/pg-core/query-builders/insert.cjs\":[\"PgInsertBase\",\"PgInsertBuilder\",\"default\"],\"drizzle-orm/pg-core/query-builders/delete.cjs\":[\"PgDeleteBase\",\"default\"],\"drizzle-orm/sql/index.cjs\":[\"default\"],\"drizzle-orm/sql/functions/index.cjs\":[\"default\"],\"drizzle-orm/sql/functions/vector.cjs\":[\"cosineDistance\",\"default\",\"hammingDistance\",\"innerProduct\",\"jaccardDistance\",\"l1Distance\",\"l2Distance\"],\"drizzle-orm/sql/functions/aggregate.cjs\":[\"avg\",\"avgDistinct\",\"count\",\"countDistinct\",\"default\",\"max\",\"min\",\"sum\",\"sumDistinct\"],\"drizzle-orm/errors.cjs\":[\"DrizzleError\",\"DrizzleQueryError\",\"TransactionRollbackError\",\"default\"],\"drizzle-orm/cache/core/cache.cjs\":[\"Cache\",\"NoopCache\",\"default\",\"hashQuery\"],\"drizzle-orm/pg-core/index.cjs\":[\"default\"],\"drizzle-orm/pg-core/utils/index.cjs\":[\"default\"],\"drizzle-orm/pg-core/subquery.cjs\":[\"default\"],\"drizzle-orm/pg-core/sequence.cjs\":[\"PgSequence\",\"default\",\"isPgSequence\",\"pgSequence\",\"pgSequenceWithSchema\"],\"drizzle-orm/pg-core/schema.cjs\":[\"PgSchema\",\"default\",\"isPgSchema\",\"pgSchema\"],\"drizzle-orm/pg-core/roles.cjs\":[\"PgRole\",\"default\",\"pgRole\"],\"drizzle-orm/pg-core/alias.cjs\":[\"alias\",\"default\"],\"drizzle-orm/logger.cjs\":[\"ConsoleLogWriter\",\"DefaultLogger\",\"NoopLogger\",\"default\"],\"drizzle-orm/entity.cjs\":[\"default\",\"entityKind\",\"hasOwnEntityKind\",\"is\"],\"drizzle-orm/cache/core/index.cjs\":[\"default\"],\"drizzle-orm/node-postgres/driver.cjs\":[\"NodePgDatabase\",\"NodePgDriver\",\"default\",\"drizzle\"]}");
function __thaw_bundle_factory_of(key) {
  if (Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, key)) return key;
  var query = key.indexOf('?'), fragment = key.indexOf('#', 1);
  var at = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  return at < 0 ? key : key.slice(0, at);
}
function __thaw_bundle_validate_static(key, visited) {
  visited = visited || [];
  if (visited.indexOf(key) >= 0) return;
  var graph = __thaw_bundle_export_graphs[__thaw_bundle_factory_of(key)];
  if (!graph) return;
  var next = visited.concat(key), dependencies = graph.dependencies || [];
  var map = __thaw_bundle_import_maps[__thaw_bundle_factory_of(key)] || {};
  for (var i = 0; i < dependencies.length; i++) {
    var target = __thaw_bundle_target(map, dependencies[i]);
    if (!target) {
      var spec = dependencies[i], builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
      if (__thaw_bundle_builtin_names.indexOf(builtin) < 0 && !(String(spec).endsWith('.node') && typeof require.addon === 'function'))
        throw new SyntaxError('Cannot resolve import ' + spec);
    } else __thaw_bundle_validate_static(target.key, next);
  }
  var origin = __thaw_bundle_origin_for(key), requests = graph.requests || [];
  for (var j = 0; j < requests.length; j++)
    origin.validateKnownStatic(requests[j][0], requests[j][1]);
}
var __thaw_namespace_create = Object.create, __thaw_namespace_define = Object.defineProperty;
var __thaw_namespace_prevent = Object.preventExtensions, __thaw_namespace_own = Object.prototype.hasOwnProperty;
var __thaw_namespace_keys = Object.keys, __thaw_namespace_apply = Reflect.apply;
var __thaw_namespace_get = WeakMap.prototype.get, __thaw_namespace_set = WeakMap.prototype.set;
var __thaw_namespace_has = WeakMap.prototype.has, __thaw_namespace_tag = Symbol.toStringTag;
var __thaw_namespace_promise = Promise, __thaw_namespace_resolve = Promise.resolve;
var __thaw_namespace_reject = Promise.reject, __thaw_namespace_then = Promise.prototype.then;
var __thaw_bundle_cjs_namespaces = Object.create(null);
var __thaw_bundle_cjs_namespace_values = new WeakMap();
function __thaw_bundle_cjs_namespace(key, value, names) {
  if (__thaw_namespace_apply(__thaw_namespace_own, __thaw_bundle_cjs_namespaces, [key]))
    return __thaw_bundle_cjs_namespaces[key];
  var namespace = __thaw_namespace_create(null);
  __thaw_namespace_define(namespace, 'default', {value:value, enumerable:true});
  __thaw_namespace_define(namespace, 'module.exports', {value:value, enumerable:true});
  for (var index = 0; index < names.length; index++) {
    var name = names[index];
    if (!__thaw_namespace_apply(__thaw_namespace_own, namespace, [name]))
      __thaw_namespace_define(namespace, name, {value:value == null ? undefined : value[name], enumerable:true});
  }
  __thaw_namespace_define(namespace, __thaw_namespace_tag, {value:'Module'});
  __thaw_namespace_prevent(namespace);
  __thaw_namespace_apply(__thaw_namespace_set, __thaw_bundle_cjs_namespace_values, [namespace, value]);
  __thaw_bundle_cjs_namespaces[key] = namespace;
  return namespace;
}
function __thaw_bundle_cjs_fallback_namespace(spec, value) {
  var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
  var known = __thaw_bundle_builtin_names.indexOf(builtin) >= 0;
  return __thaw_bundle_cjs_namespace('external:' + (known ? 'node:' + builtin : spec),
    value, known && value != null ? __thaw_namespace_keys(value) : []);
}
function __thaw_bundle_origin_for(ownerKey) {
  var own = Object.prototype.hasOwnProperty;
  var ambiguous = {};
  function graphOf(key) { return __thaw_bundle_export_graphs[__thaw_bundle_factory_of(key)]; }
  function targetOf(key, spec) {
    return __thaw_bundle_target(__thaw_bundle_import_maps[__thaw_bundle_factory_of(key)] || {}, spec);
  }
  var enumerable = Object.prototype.propertyIsEnumerable;
  function valueOf(target, sourceKey, spec) {
    var edges = __thaw_bundle_edges[sourceKey];
    if (edges && own.call(edges, spec)) {
      var edgeTarget = targetOf(sourceKey, spec);
      // A CommonJS cycle initially exposes provisional exports. The cache
      // remains authoritative if its factory later replaces module.exports.
      if (edgeTarget && own.call(__thaw_bundle_cache, edgeTarget.key))
        return __thaw_bundle_cache[edgeTarget.key].exports;
      return edges[spec];
    }
    // A cycle may reach this edge before its owner executes the loader.
    // Export discovery must never evaluate a dependency ahead of that owner.
    return undefined;
  }
  function namesOf(key, visited, sourceKey, spec) {
    if (visited.indexOf(key) >= 0) return [];
    var graph = graphOf(key);
    if (!graph) {
      var value = valueOf({ key: key, factory: __thaw_bundle_factory_of(key) }, sourceKey, spec);
      return value == null ? [] : Object.keys(value).filter(function(name) { return name !== '__esModule'; });
    }
    var next = visited.concat(key);
    var names = Object.keys(graph.local).concat(Object.keys(graph.indirect));
    for (var index = 0; index < graph.stars.length; index++) {
      var target = targetOf(key, graph.stars[index]);
      if (!target) continue;
      var more = namesOf(target.key, next, key, graph.stars[index]);
      for (var j = 0; j < more.length; j++) {
        if (more[j] !== 'default' && names.indexOf(more[j]) < 0) names.push(more[j]);
      }
    }
    return names;
  }
  function retainedNativeEdge(key) {
    return typeof __thaw_bundle_native_keys !== 'undefined'
      && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(key))
      && !own.call(__thaw_bundle_mixed_keys, __thaw_bundle_factory_of(key));
  }
  function retainedNamespaceAnchor(key, name, targetKey, anchor) {
    if (!retainedNativeEdge(targetKey)) return null;
    // A rewritten mixed edge strips the importer's native export, but a
    // following pure-native edge retains the current module's own alias.
    return anchor || (typeof __thaw_bundle_native_keys !== 'undefined'
      && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(key)) ? { key: key, name: name } : null);
  }
  function resolve(key, name, visited, allowMissing, sourceKey, spec, anchor) {
    var visit = key + '\u0000' + name;
    if (visited.indexOf(visit) >= 0) return null;
    var graph = graphOf(key);
    if (!graph) {
      // Star exports skip the CommonJS interop marker; explicit named
      // reexports still resolve it through allowMissing.
      if (name === '__esModule' && !allowMissing) return null;
      var value = valueOf({ key: key, factory: __thaw_bundle_factory_of(key) }, sourceKey, spec);
      return (allowMissing || (value != null && enumerable.call(value, name))) ? { kind: 'cjs', key: key, sourceKey: sourceKey, spec: spec, name: name } : null;
    }
    var next = visited.concat(visit);
    if (own.call(graph.local, name)) {
      return { kind: 'esm', key: key, binding: graph.local[name], name: name };
    }
    if (own.call(graph.indirect, name)) {
      var indirect = graph.indirect[name];
      var source = targetOf(key, indirect[0]);
      if (!source) return null;
      if (indirect[1] === null) {
        return { kind: 'namespace', key: source.key, binding: '*namespace*', sourceKey: key,
          spec: indirect[0], name: name,
          anchor: retainedNamespaceAnchor(key, name, source.key, anchor) };
      }
      if (indirect[2] && !graphOf(source.key)) {
        return { kind: 'cjs-default', key: source.key, sourceKey: key, spec: indirect[0] };
      }
      return resolve(source.key, indirect[1], next, true, key, indirect[0],
        retainedNamespaceAnchor(key, name, source.key, anchor));
    }
    if (name === 'default') return null;
    var found = null;
    for (var index = 0; index < graph.stars.length; index++) {
      var star = targetOf(key, graph.stars[index]);
      if (!star) continue;
      var candidate = resolve(star.key, name, next, false, key, graph.stars[index],
        retainedNamespaceAnchor(key, name, star.key, anchor));
      if (candidate === ambiguous) return ambiguous;
      if (!candidate) continue;
      if (found && !sameBinding(found, candidate)) return ambiguous;
      found = candidate;
    }
    return found;
  }
  function sameBinding(left, right) {
    if (left.kind !== right.kind) return false;
    if (left.kind === 'cjs') return left.key === right.key && left.name === right.name;
    if (left.kind === 'cjs-default') return left.key === right.key;
    return left.key === right.key && left.binding === right.binding;
  }
  function read(resolution) {
    if (resolution.kind === 'cjs' || resolution.kind === 'cjs-default') {
      var edges = __thaw_bundle_edges[resolution.sourceKey];
      if (!edges || !own.call(edges, resolution.spec)) throw new ReferenceError("Cannot access '" + (resolution.name || 'default') + "' before initialization");
      var value = valueOf(null, resolution.sourceKey, resolution.spec);
      return resolution.kind === 'cjs' ? value[resolution.name] : value && value.__esModule ? value.default : value;
    }
    if (typeof __thaw_native_entry !== 'undefined' && __thaw_native_entry) {
      if (resolution.kind === 'namespace') {
        if (graphOf(resolution.key)) return __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(resolution.key)]
          ? __thaw_bundle_facade_for(resolution.key)
          : resolution.anchor
            ? __thaw_native_entry.readNative(resolution.anchor.key, resolution.anchor.name)
            : __thaw_native_entry.readNative(resolution.key);
        var edge = __thaw_bundle_edges[resolution.sourceKey];
        if (!edge || !own.call(edge, resolution.spec)) throw new ReferenceError('Import is not initialized');
        return edge[resolution.spec];
      }
      // `binding` is the local declaration used for diamond identity;
      // native namespaces expose the exported alias in `name` instead.
      return __thaw_native_entry.readNative(resolution.key, resolution.name);
    }
    var source = __thaw_bundle_require(resolution.key, __thaw_bundle_factory_of(resolution.key), true);
    return resolution.kind === 'namespace' ? source : source[resolution.name];
  }
  function linksReady(key, visited) {
    if (visited.indexOf(key) >= 0) return true;
    var graph = graphOf(key);
    if (!graph) return true;
    var next = visited.concat(key), edges = __thaw_bundle_edges[key];
    // Explicit named reexports cannot introduce a competing star binding.
    // Their names are static even if their opaque target has not run yet.
    var specs = graph.stars;
    for (var index = 0; index < specs.length; index++) {
      var spec = specs[index], target = targetOf(key, spec);
      if (!target) continue;
      // ESM names and terminal bindings are known from the source graph
      // before evaluation. Only opaque CJS/native targets need a loaded edge
      // to discover their exported names.
      if ((!graphOf(target.key) && (!edges || !own.call(edges, spec))) || !linksReady(target.key, next)) return false;
    }
    var indirectNames = Object.keys(graph.indirect);
    for (var n = 0; n < indirectNames.length; n++) {
      var indirect = graph.indirect[indirectNames[n]], target = targetOf(key, indirect[0]);
      // A direct opaque named reexport has a statically fixed name/binding.
      // An ESM target can itself resolve through unknown opaque stars.
      if (target && graphOf(target.key) && !linksReady(target.key, next)) return false;
    }
    return true;
  }
  return {
    validateStatic: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new SyntaxError('Cannot resolve import ' + spec);
      // CommonJS default is the established synthetic default interop. All
      // other requested names in this route have a statically known graph.
      if (name === 'default' && !graphOf(target.key)) return;
      var resolution = resolve(target.key, name, [], false, ownerKey, spec);
      if (!resolution || resolution === ambiguous)
        throw new SyntaxError('Missing or ambiguous export ' + name);
    },
    validateKnownStatic: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      // Opaque CommonJS stars are discovered only after their owner's load.
      // Do not execute that owner during source-graph validation.
      if (!target) {
        var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
        if (__thaw_bundle_builtin_names.indexOf(builtin) < 0 && !(String(spec).endsWith('.node') && typeof require.addon === 'function'))
          throw new SyntaxError('Cannot resolve import ' + spec);
        return;
      }
      if (graphOf(target.key) && linksReady(target.key, []))
        this.validateStatic(spec, name);
    },
    validateRequests: function() {
      var graph = graphOf(ownerKey), requests = graph && graph.requests || [];
      for (var index = 0; index < requests.length; index++)
        this.validateKnownStatic(requests[index][0], requests[index][1]);
    },
    validateDynamic: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (target) __thaw_validate_native_link(target.key);
    },
    completeDynamic: function(spec, promise) {
      var origin = this;
      return __thaw_native_apply(__thaw_native_then, promise,
        [function(namespace) { return origin.selectDynamic(spec, namespace); }]);
    },
    rejectDynamic: function(error) {
      return __thaw_native_apply(__thaw_native_reject, __thaw_native_promise, [error]);
    },
    edge: function(spec, value) {
      // Async static imports share the loader with dynamic import. Only our
      // own namespace wrappers unwrap here; user exports keep their identity.
      if (value != null && (typeof value === 'object' || typeof value === 'function')
          && __thaw_namespace_apply(__thaw_namespace_has, __thaw_bundle_cjs_namespace_values, [value]))
        value = __thaw_namespace_apply(__thaw_namespace_get, __thaw_bundle_cjs_namespace_values, [value]);
      var edges = __thaw_bundle_edges[ownerKey];
      if (!edges) edges = __thaw_bundle_edges[ownerKey] = Object.create(null);
      if (own.call(edges, spec) && edges[spec] === value) return;
      edges[spec] = value;
      __thaw_bundle_edge_version++;
      // A cycle can reach an ESM module before its later CJS/native loader.
      // Only link when its full transitive export graph is available.
      for (var key in __thaw_bundle_star_linkers) __thaw_bundle_star_linkers[key]();
    },
    track: function(exports) {
      var linked = false, linking = false;
      var link = function() {
        if (linked || linking || !linksReady(ownerKey, [])) return;
        linking = true;
        try {
          // A CJS Proxy ownKeys trap can record another edge while names are
          // discovered. Recompute before publication if the graph changed.
          var bindings, before;
          do {
            before = __thaw_bundle_edge_version;
            bindings = [];
            var graph = graphOf(ownerKey), names = [];
            for (var index = 0; index < graph.stars.length; index++) {
              var spec = graph.stars[index], target = targetOf(ownerKey, spec);
              if (!target) continue;
              var more = namesOf(target.key, [], ownerKey, spec);
              for (var j = 0; j < more.length; j++) {
                var name = more[j];
                if (name !== 'default' && names.indexOf(name) < 0) names.push(name);
              }
            }
            for (var n = 0; n < names.length; n++) {
              var name = names[n];
              if (own.call(graph.local, name) || own.call(graph.indirect, name) || (name !== '__esModule' && own.call(exports, name))) continue;
              var resolution = resolve(ownerKey, name, [], false, null, null,
                { key: ownerKey, name: name });
              if (resolution && resolution !== ambiguous) bindings.push([name, resolution]);
            }
          } while (before !== __thaw_bundle_edge_version && linksReady(ownerKey, []));
          if (!linksReady(ownerKey, [])) return;
          for (var b = 0; b < bindings.length; b++) {
            var binding = bindings[b];
            if (binding[0] !== '__esModule' && own.call(exports, binding[0])) continue;
            Object.defineProperty(exports, binding[0], { enumerable: true, get: function(r) { return function() { return read(r); }; }(binding[1]) });
          }
          linked = true;
          delete __thaw_bundle_star_linkers[ownerKey];
        } finally { linking = false; }
      };
      __thaw_bundle_star_linkers[ownerKey] = link;
      link();
    },
    defaultImport: function(spec, value) {
      var target = targetOf(ownerKey, spec);
      return target && graphOf(target.key) ? value.default : value && value.__esModule ? value.default : value;
    },
    readImport: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      var resolution = resolve(target.key, name, [], true, ownerKey, spec,
        typeof __thaw_bundle_native_keys !== 'undefined' && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(target.key))
          ? { key: target.key, name: name } : null);
      if (!resolution || resolution === ambiguous) throw new SyntaxError('Missing or ambiguous export ' + name);
      return read(resolution);
    },
    readDefault: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      if (!graphOf(target.key)) {
        var edges = __thaw_bundle_edges[ownerKey];
        if (!edges || !own.call(edges, spec)) throw new ReferenceError('Import is not initialized');
        return this.defaultImport(spec, edges[spec]);
      }
      var resolution = resolve(target.key, 'default', [], true, ownerKey, spec,
        typeof __thaw_bundle_native_keys !== 'undefined' && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(target.key))
          ? { key: target.key, name: 'default' } : null);
      if (!resolution || resolution === ambiguous) throw new SyntaxError('Missing or ambiguous default export');
      return read(resolution);
    },
    namespaceImport: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      if (!graphOf(target.key)) {
        var edges = __thaw_bundle_edges[ownerKey];
        if (!edges || !own.call(edges, spec)) throw new ReferenceError('Import is not initialized');
        // Keep the legacy CJS namespace-import object; only ESM targets
        // select the tracked facade.
        return edges[spec];
      }
      return typeof __thaw_native_entry === 'undefined' || !__thaw_native_entry || __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(target.key)]
        ? __thaw_bundle_facade_for(target.key) : __thaw_native_entry.readNative(target.key);
    },
    selectDynamic: function(spec, namespace) {
      var target = targetOf(ownerKey, spec);
      if (!target) return namespace;
      // The private shell's namespace contains no CJS exports. The existing
      // bundle contract returns that target's cached CommonJS value instead.
      if (!graphOf(target.key)) return __thaw_bundle_cjs_namespace(target.key, this.namespaceImport(spec), __thaw_bundle_cjs_export_names[target.factory] || []);
      return __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(target.key)]
        ? __thaw_bundle_facade_for(target.key) : namespace;
    },
    names: function(spec, value) {
      var target = targetOf(ownerKey, spec);
      return target && graphOf(target.key) ? namesOf(target.key, [], ownerKey, spec) : (value == null ? [] : Object.keys(value).filter(function(name) { return name !== '__esModule'; }));
    },
    resolve: function(name) { var found = resolve(ownerKey, name, [], false, null, null,
      { key: ownerKey, name: name }); return found === ambiguous ? null : found; },
    read: read
  };
}
function __thaw_bundle_target(map, spec) {
  if (Object.prototype.hasOwnProperty.call(map, spec)) return { key: map[spec], factory: map[spec] };
  var query = spec.indexOf('?');
  var fragment = spec.indexOf('#', 1);
  var suffixAt = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  if (suffixAt < 0) return null;
  var base = spec.slice(0, suffixAt);
  if (!Object.prototype.hasOwnProperty.call(map, base)) return null;
  var factory = map[base];
  return { key: factory + spec.slice(suffixAt), factory: factory };
}
function __thaw_bundle_import_missing(known, spec) {
  spec = String(spec);
  if (spec.charAt(0) === '#') return true;
  var query = spec.indexOf('?'), fragment = spec.indexOf('#', 1);
  var suffixAt = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  if (suffixAt >= 0) spec = spec.slice(0, suffixAt);
  var slash = spec.indexOf('/');
  var next = spec.charAt(0) === '@' && slash >= 0 ? spec.indexOf('/', slash + 1) : slash;
  var name = next < 0 ? spec : spec.slice(0, next);
  return known.indexOf(name) >= 0;
}
function __thaw_bundle_resolve(map, spec, keys, searchAll, allowExports) {
  spec = String(spec);
  if (allowExports && Object.prototype.hasOwnProperty.call(__thaw_bundle_exports, spec)) return spec;
  var target = __thaw_bundle_target(map, spec);
  if (!target && searchAll) for (var index = 0; index < keys.length && !target; index++) target = __thaw_bundle_target(__thaw_bundle_require_maps[keys[index]] || {}, spec);
  if (target) return target.key;
  var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
  if (__thaw_bundle_builtin_names.indexOf(builtin) >= 0) return spec;
  var error = new Error('Cannot find module ' + spec);
  error.code = 'MODULE_NOT_FOUND';
  throw error;
}
function __thaw_bundle_async_error(factoryKey) {
  var error = new Error('Cannot synchronously require an async module: ' + factoryKey);
  error.code = 'ERR_REQUIRE_ASYNC_MODULE';
  return error;
}
function __thaw_bundle_require(key, factoryKey, allowAsync) {
  factoryKey = factoryKey || key;
  if (!allowAsync && Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, factoryKey)) throw __thaw_bundle_async_error(factoryKey);
  if (String(factoryKey).endsWith('.node') && require.addon) return require.addon();
  if (typeof __thaw_bundle_native_keys !== 'undefined' && Object.prototype.hasOwnProperty.call(__thaw_bundle_native_keys, factoryKey)) {
    var namespace = __thaw_native_entry.evalNativeSync(key, factoryKey);
    return Object.prototype.hasOwnProperty.call(__thaw_bundle_mixed_keys, factoryKey) ? __thaw_bundle_facade_for(key) : namespace;
  }
  __thaw_bundle_validate_static(key);
  if (!(key in __thaw_bundle_cache)) {
    var mod = { exports: {}, filename: '/thaw_modules/' + (factoryKey || key) };
    __thaw_bundle_cache[key] = mod;
    var map = __thaw_bundle_require_maps[factoryKey] || {};
    var importMap = __thaw_bundle_import_maps[factoryKey] || {};
    var knownPackages = __thaw_bundle_known_package_maps[factoryKey] || [];
    var localRequire = function(spec) {
      if ((spec === 'bindings' || spec === 'node-gyp-build') && typeof require.addon === 'function') return require.addon;
      var target = __thaw_bundle_target(map, spec);
      if (target) return __thaw_bundle_require(target.key, target.factory);
      return require(spec);
    };
    localRequire.addon = typeof require === 'function' ? require.addon : undefined;
    localRequire.resolve = function(spec) { return __thaw_bundle_resolve(map, spec, null, false, false); };
    localRequire.cache = __thaw_bundle_cache;
    var localImport = function(spec) { var target = __thaw_bundle_target(importMap, spec); if (target) return __thaw_bundle_require(target.key, target.factory); if (__thaw_bundle_import_missing(knownPackages, spec)) throw new Error('Cannot resolve import ' + spec); return require(spec); };
    var localRequireAsync = __thaw_bundle_create_import_async(factoryKey, globalThis.__thaw_worker_module);
    var filename = '/thaw_modules/' + factoryKey, slash = filename.lastIndexOf('/'), dirname = slash < 0 ? '.' : filename.slice(0, slash);
    var initialized;
    try { var factory = __thaw_bundle_factories[factoryKey]; if (Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, factoryKey)) factory = factory(__thaw_bundle_origin_for(key)); initialized = Object.prototype.hasOwnProperty.call(__thaw_bundle_commonjs_contexts, factoryKey) ? factory.call(mod.exports, mod, mod.exports, localRequire, localRequireAsync, filename, dirname, localImport) : factory(mod, mod.exports, localRequire, localRequireAsync, filename, dirname, localImport); } catch (error) { delete __thaw_bundle_cache[key]; delete __thaw_bundle_edges[key]; delete __thaw_bundle_star_linkers[key]; throw error; }
    mod.ready = __thaw_namespace_apply(__thaw_namespace_then, __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, [Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, factoryKey) ? initialized : undefined]), [function() {}, function(error) { delete __thaw_bundle_cache[key]; delete __thaw_bundle_edges[key]; delete __thaw_bundle_star_linkers[key]; throw error; }]);
  }
  return __thaw_bundle_cache[key].exports;
}
function __thaw_bundle_create_require(base) {
  var text = String(base || '');
  var keys = Object.keys(__thaw_bundle_require_maps);
  var factoryKey = keys.indexOf(text) >= 0 ? text : keys.reduce(function(best, key) { return text.endsWith('/' + key) && (!best || key.length > best.length) ? key : best; }, null);
  var map = {}, staticMap = __thaw_bundle_import_maps[factoryKey] || {}, requireMap = __thaw_bundle_require_maps[factoryKey] || {};
  for (var staticSpec in staticMap) if (Object.prototype.hasOwnProperty.call(staticMap, staticSpec)) map[staticSpec] = staticMap[staticSpec];
  for (var requireSpec in requireMap) if (Object.prototype.hasOwnProperty.call(requireMap, requireSpec)) map[requireSpec] = requireMap[requireSpec];
  var created = function(spec) { if ((String(spec) === 'bindings' || String(spec) === 'node-gyp-build') && typeof require.addon === 'function') return require.addon; spec = String(spec); if (Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, spec)) throw __thaw_bundle_async_error(spec); if (Object.prototype.hasOwnProperty.call(__thaw_bundle_exports, spec)) return __thaw_bundle_exports[spec]; var target = __thaw_bundle_target(map, spec); if (!target && !factoryKey) { for (var index = 0; index < keys.length && !target; index++) target = __thaw_bundle_target(__thaw_bundle_require_maps[keys[index]] || {}, spec); } if (target) return __thaw_bundle_require(target.key, target.factory); return require(spec); };
  created.addon = typeof require === 'function' ? require.addon : undefined;
  created.resolve = function(spec) { return __thaw_bundle_resolve(map, spec, keys, !factoryKey, true); };
  created.cache = __thaw_bundle_cache; return created;
}
function __thaw_bundle_create_import(base) {
  var map = __thaw_bundle_import_maps[String(base)] || {};
  var known = __thaw_bundle_known_package_maps[String(base)] || [];
  return function(spec) { spec = String(spec); var target = __thaw_bundle_target(map, spec); if (target) return __thaw_bundle_require(target.key, target.factory); if (__thaw_bundle_import_missing(known, spec)) throw new Error('Cannot resolve import ' + spec); return require(spec); };
}
function __thaw_bundle_create_import_async(base, workerModule) {
  var map = __thaw_bundle_import_maps[String(base)] || {};
  var known = __thaw_bundle_known_package_maps[String(base)] || [];
  return function(spec) {
    try { spec = `${spec}`; } catch (error) { return __thaw_namespace_apply(__thaw_namespace_reject, __thaw_namespace_promise, [error]); }
    if (workerModule !== undefined && (spec === 'worker_threads' || spec === 'node:worker_threads')) { try { return __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, [__thaw_bundle_cjs_fallback_namespace(spec, workerModule)]); } catch (error) { return __thaw_namespace_apply(__thaw_namespace_reject, __thaw_namespace_promise, [error]); } }
  return new __thaw_namespace_promise(function(resolve, reject) {
   __thaw_namespace_apply(__thaw_namespace_then, __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, []), [function() {
    try {
     var target = __thaw_bundle_target(map, spec);
     if (target) {
      if (typeof __thaw_bundle_native_keys !== 'undefined' && Object.prototype.hasOwnProperty.call(__thaw_bundle_native_keys, target.factory)) {
       __thaw_native_apply(__thaw_native_then, __thaw_native_entry.evalNative(target.key, target.factory), [function(namespace) { try { resolve(__thaw_bundle_mixed_keys[target.factory] ? __thaw_bundle_facade_for(target.key) : namespace); } catch (error) { reject(error); } }, reject]);
       return;
      }
      __thaw_bundle_require(target.key, target.factory, true);
      __thaw_namespace_apply(__thaw_namespace_then, __thaw_bundle_cache[target.key].ready, [function() { try { var value = __thaw_bundle_cache[target.key].exports; resolve(Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, target.factory) ? value : __thaw_bundle_cjs_namespace(target.key, value, __thaw_bundle_cjs_export_names[target.factory] || [])); } catch (error) { reject(error); } }, reject]);
      return;
     }
     if (__thaw_bundle_import_missing(known, spec)) throw new Error('Cannot resolve import ' + spec);
     resolve(__thaw_bundle_cjs_fallback_namespace(spec, require(spec)));
    } catch (error) { reject(error); }
   }, reject]);
  });
  };
}
function __thaw_bundle_register_worker_main(key, mod) {
  __thaw_bundle_validate_static(key);
  if (Object.prototype.hasOwnProperty.call(__thaw_bundle_cache, key)) throw new Error('Worker entry already initialized');
  mod.filename = '/thaw_modules/' + key;
  var resolveReady, rejectReady;
  mod.ready = new __thaw_namespace_promise(function(resolve, reject) { resolveReady = resolve; rejectReady = reject; });
  __thaw_bundle_cache[key] = mod;
  return function(succeeded, error) { if (succeeded) resolveReady(); else rejectReady(error); };
}
globalThis.__thaw_bundle_create_require = __thaw_bundle_create_require;
globalThis.__thaw_bundle_create_import = __thaw_bundle_create_import;
globalThis.__thaw_bundle_create_import_async = __thaw_bundle_create_import_async;
var __thaw_worker_bundle_source =
  '(function() {\nvar __thaw_worker_bundle_source = globalThis.__thaw_worker_bundle_source;\nvar require = function(name) { if (name === "worker_threads" || name === "node:worker_threads") return globalThis.__thaw_worker_module; if (String(name).endsWith(".node") && typeof require.addon === "function") return require.addon(); var error = new Error("Cannot find module " + name); error.code = "MODULE_NOT_FOUND"; throw error; };\nrequire.addon = globalThis.require && globalThis.require.addon;\nvar __thaw_bundle_exports = globalThis.__thaw_bundle_exports || (globalThis.__thaw_bundle_exports = {});\nvar __thaw_bundle_builtin_names = Object.freeze(' + JSON.stringify(__thaw_bundle_builtin_names) + ');\nvar __thaw_bundle_cache = {};\nvar __thaw_bundle_async_keys = ' + JSON.stringify(__thaw_bundle_async_keys) + ';\nvar __thaw_bundle_edges = Object.create(null);\nvar __thaw_bundle_star_linkers = Object.create(null);\nvar __thaw_bundle_edge_version = 0;\nvar __thaw_bundle_factories = {' +
  Object.keys(__thaw_bundle_factories).map(function(key) { return JSON.stringify(key) + ': ' + __thaw_bundle_factories[key].toString(); }).join(',\n') +
  '};\nvar __thaw_bundle_require_maps = ' + JSON.stringify(__thaw_bundle_require_maps) + ';\n' +
  'var __thaw_bundle_import_maps = ' + JSON.stringify(__thaw_bundle_import_maps) + ';\n' +
  'var __thaw_bundle_known_package_maps = ' + JSON.stringify(__thaw_bundle_known_package_maps) + ';\n' +
  'var __thaw_bundle_export_graphs = JSON.parse(' + JSON.stringify(JSON.stringify(__thaw_bundle_export_graphs)) + ');\n' +
  'var __thaw_bundle_commonjs_contexts = JSON.parse(' + JSON.stringify(JSON.stringify(__thaw_bundle_commonjs_contexts)) + ');\n' +
  'var __thaw_namespace_create = Object.create, __thaw_namespace_define = Object.defineProperty;\nvar __thaw_namespace_prevent = Object.preventExtensions, __thaw_namespace_own = Object.prototype.hasOwnProperty;\nvar __thaw_namespace_keys = Object.keys, __thaw_namespace_apply = Reflect.apply;\nvar __thaw_namespace_get = WeakMap.prototype.get, __thaw_namespace_set = WeakMap.prototype.set;\nvar __thaw_namespace_has = WeakMap.prototype.has, __thaw_namespace_tag = Symbol.toStringTag;\nvar __thaw_namespace_promise = Promise, __thaw_namespace_resolve = Promise.resolve;\nvar __thaw_namespace_reject = Promise.reject, __thaw_namespace_then = Promise.prototype.then;\nvar __thaw_bundle_cjs_namespaces = Object.create(null);\nvar __thaw_bundle_cjs_namespace_values = new WeakMap();\nvar __thaw_bundle_cjs_export_names = ' + JSON.stringify(__thaw_bundle_cjs_export_names) + ';\n' +
  __thaw_bundle_cjs_namespace.toString() + '\n' + __thaw_bundle_cjs_fallback_namespace.toString() + '\n' + __thaw_bundle_factory_of.toString() + '\n' + __thaw_bundle_validate_static.toString() + '\n' + __thaw_bundle_origin_for.toString() + '\n' + __thaw_bundle_target.toString() + '\n' + __thaw_bundle_import_missing.toString() + '\n' + __thaw_bundle_resolve.toString() + '\n' + __thaw_bundle_async_error.toString() + '\n' + __thaw_bundle_require.toString() + '\n' + __thaw_bundle_create_require.toString() + '\n' + __thaw_bundle_create_import.toString() + '\n' + __thaw_bundle_create_import_async.toString() + '\n' + __thaw_bundle_register_worker_main.toString() + '\n' +
  'globalThis.__thaw_bundle_create_require = __thaw_bundle_create_require;\nglobalThis.__thaw_bundle_create_import = __thaw_bundle_create_import;\nglobalThis.__thaw_bundle_create_import_async = __thaw_bundle_create_import_async;\nglobalThis.__thaw_bundle_worker_origin = __thaw_bundle_origin_for;\nglobalThis.__thaw_bundle_register_worker_main = __thaw_bundle_register_worker_main;\n})();\n';
globalThis.__thaw_worker_bundle_source = __thaw_worker_bundle_source;
var __thaw_bundle_entry_key = "drizzle-orm/./node-postgres/index.cjs";
var __thaw_bundle_entry = __thaw_bundle_require(__thaw_bundle_entry_key, undefined, true);
__thaw_bundle_exports[__thaw_bundle_entry_key] = __thaw_bundle_entry;
globalThis.__thaw_module_ready = __thaw_bundle_cache[__thaw_bundle_entry_key].ready;
return __thaw_bundle_entry;
})(globalThis.require);
