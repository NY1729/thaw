module.exports = (function(require) {
if (typeof require !== 'function') require = function(name) { var error = new Error('Cannot find module ' + name); error.code = 'MODULE_NOT_FOUND'; throw error; };
var __thaw_bundle_exports = globalThis.__thaw_bundle_exports || (globalThis.__thaw_bundle_exports = {});
var __thaw_bundle_builtin_names = Object.freeze(["_http_agent","_http_client","_http_common","_http_incoming","_http_outgoing","_http_server","_stream_duplex","_stream_passthrough","_stream_readable","_stream_transform","_stream_wrap","_stream_writable","_tls_common","_tls_wrap","assert","assert/strict","async_hooks","buffer","child_process","cluster","console","constants","crypto","dgram","diagnostics_channel","dns","dns/promises","domain","events","fs","fs/promises","http","http2","https","inspector","inspector/promises","module","net","os","path","path/posix","path/win32","perf_hooks","process","punycode","querystring","readline","readline/promises","repl","stream","stream/consumers","stream/promises","stream/web","string_decoder","sys","test","test/reporters","timers","timers/promises","tls","trace_events","tty","url","util","util/types","v8","vm","wasi","worker_threads","zlib"]);
var __thaw_bundle_cache = {};
var __thaw_bundle_async_keys = JSON.parse("{}");
var __thaw_bundle_edges = Object.create(null);
var __thaw_bundle_star_linkers = Object.create(null);
var __thaw_bundle_edge_version = 0;
var __thaw_bundle_factories = {
"hono/./dist/cjs/middleware/cache/index.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cache_exports = {};
__export(cache_exports, {
  cache: () => cache
});
module.exports = __toCommonJS(cache_exports);
var import_request = require("../../request");
var import_crypto = require("../../utils/crypto");
const defaultCacheableStatusCodes = [200];
const defaultMaxQueryBodySize = 64 * 1024;
const cacheKeyPath = "/.hono/cache";
const cacheKeyParameter = "__hono_cache_key";
const cacheMethodKeyParameter = "__hono_cache_method";
const queryDigestKeyParameter = "__hono_query_digest";
const cacheVaryKeyParameter = "__hono_cache_vary";
const queryRepresentationMetadataHeaders = [
  "content-type",
  "content-encoding",
  "content-language",
  "content-location"
];
const shouldSkipCacheControl = (cacheControl) => !!cacheControl && /(?:^|,\s*)(?:private|no-(?:store|cache))(?:\s*(?:=|,|$))/i.test(cacheControl);
const parseVaryDirectives = (vary) => {
  if (vary == null) {
    return [];
  }
  return (Array.isArray(vary) ? vary : vary.split(",")).map((directive) => directive.trim().toLowerCase()).filter(Boolean);
};
const createCacheKey = (key, requestUrl, request, varyHeaders) => {
  const url = new URL(cacheKeyPath, requestUrl);
  url.searchParams.append(cacheKeyParameter, key);
  url.searchParams.append(cacheMethodKeyParameter, request.method);
  if (request.method === "QUERY") {
    url.searchParams.append(queryDigestKeyParameter, request.digest);
  }
  for (const header of varyHeaders) {
    url.searchParams.append(cacheVaryKeyParameter, JSON.stringify(header));
  }
  return url.href;
};
const shouldSkipCache = (res, optionsVaryDirectives, responseVary) => responseVary.length && (!optionsVaryDirectives || responseVary.some((name) => !optionsVaryDirectives.has(name))) || shouldSkipCacheControl(res.headers.get("Cache-Control")) || res.headers.has("Set-Cookie");
const reportCacheNotAvailable = (onCacheNotAvailable, reason) => {
  if (onCacheNotAvailable === false) {
  } else if (onCacheNotAvailable) {
    onCacheNotAvailable(reason);
  } else {
    console.log(reason);
  }
};
const createQueryDigest = async (c, maxQueryBodySize) => {
  if (!globalThis.crypto?.subtle) {
    return void 0;
  }
  if (c.req.raw.bodyUsed && Object.keys(c.req.bodyCache)[0] === "formData") {
    return void 0;
  }
  try {
    const requestHeaders = c.req.raw.headers;
    const metadata = new TextEncoder().encode(
      JSON.stringify(
        queryRepresentationMetadataHeaders.map((header) => [header, requestHeaders.get(header)])
      )
    );
    const body = (await (0, import_request.cloneRawRequest)(c.req)).body;
    const chunks = [];
    let bodySize = 0;
    if (body) {
      const reader = body.getReader();
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) {
          break;
        }
        bodySize += value.byteLength;
        if (bodySize > maxQueryBodySize) {
          void reader.cancel().catch(() => {
          });
          return void 0;
        }
        chunks.push(value);
      }
    }
    const data = new Uint8Array(metadata.byteLength + bodySize);
    data.set(metadata);
    let offset = metadata.byteLength;
    for (const chunk of chunks) {
      data.set(chunk, offset);
      offset += chunk.byteLength;
    }
    return await (0, import_crypto.sha256)(data) ?? void 0;
  } catch {
    return void 0;
  }
};
const cache = (options) => {
  if (!globalThis.caches) {
    reportCacheNotAvailable(
      options.onCacheNotAvailable,
      "Cache Middleware is not enabled because caches is not defined."
    );
    return async (_c, next) => await next();
  }
  if (!globalThis.crypto?.subtle) {
    reportCacheNotAvailable(
      options.onCacheNotAvailable,
      "Cache Middleware cannot cache QUERY requests because Web Crypto is not available."
    );
  }
  if (options.wait === void 0) {
    options.wait = false;
  }
  const cacheControlDirectives = options.cacheControl?.split(",").map((directive) => directive.toLowerCase());
  const optionsVaryList = parseVaryDirectives(options.vary);
  const varyDirectives = optionsVaryList.length ? new Set(optionsVaryList) : void 0;
  if (varyDirectives?.has("*")) {
    throw new Error(
      'Middleware vary configuration cannot include "*", as it disallows effective caching.'
    );
  }
  const cacheableStatusCodes = new Set(
    options.cacheableStatusCodes ?? defaultCacheableStatusCodes
  );
  const maxQueryBodySize = options.maxQueryBodySize ?? defaultMaxQueryBodySize;
  const addHeader = (c, responseVary) => {
    if (cacheControlDirectives) {
      const existingDirectives = c.res.headers.get("Cache-Control")?.split(",").map((d) => d.trim().split("=", 1)[0].toLowerCase()) ?? [];
      for (const directive of cacheControlDirectives) {
        let [name, value] = directive.trim().split("=", 2);
        name = name.toLowerCase();
        if (!existingDirectives.includes(name)) {
          c.header("Cache-Control", `${name}${value ? `=${value}` : ""}`, { append: true });
        }
      }
    }
    if (varyDirectives) {
      if (responseVary.length === 0) {
        c.header("Vary", Array.from(varyDirectives).join(", "));
      } else {
        const merged = new Set(varyDirectives);
        for (const directive of responseVary) {
          merged.add(directive);
        }
        if (merged.has("*")) {
          c.header("Vary", "*");
        } else {
          c.header("Vary", Array.from(merged).join(", "));
        }
      }
    }
  };
  return async function cache2(c, next) {
    if (c.req.method !== "GET" && c.req.method !== "QUERY" || c.req.raw.headers.has("Authorization")) {
      await next();
      return;
    }
    let cacheKeyRequest = { method: "GET" };
    if (c.req.method === "QUERY") {
      const digest = await createQueryDigest(c, maxQueryBodySize);
      if (digest === void 0) {
        await next();
        return;
      }
      cacheKeyRequest = { method: "QUERY", digest };
    }
    let key = c.req.url;
    if (options.keyGenerator) {
      key = await options.keyGenerator(c);
    }
    const varyHeaders = [];
    if (varyDirectives) {
      for (const directive of varyDirectives) {
        const value = c.req.raw.headers.get(directive) ?? "";
        varyHeaders.push([directive, value]);
      }
    }
    key = createCacheKey(key, c.req.url, cacheKeyRequest, varyHeaders);
    const cacheName = typeof options.cacheName === "function" ? await options.cacheName(c) : options.cacheName;
    const cache3 = await caches.open(cacheName);
    const response = await cache3.match(key);
    if (response) {
      return new Response(response.body, response);
    }
    await next();
    if (!cacheableStatusCodes.has(c.res.status)) {
      return;
    }
    const responseVary = parseVaryDirectives(c.res.headers.get("Vary"));
    addHeader(c, responseVary);
    if (shouldSkipCache(c.res, varyDirectives, responseVary)) {
      return;
    }
    const res = c.res.clone();
    if (options.wait) {
      await cache3.put(key, res);
    } else {
      c.executionCtx.waitUntil(cache3.put(key, res));
    }
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  cache
});

},
"hono/dist/cjs/utils/crypto.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var crypto_exports = {};
__export(crypto_exports, {
  createHash: () => createHash,
  md5: () => md5,
  sha1: () => sha1,
  sha256: () => sha256
});
module.exports = __toCommonJS(crypto_exports);
const sha256 = async (data) => {
  const algorithm = { name: "SHA-256", alias: "sha256" };
  const hash = await createHash(data, algorithm);
  return hash;
};
const sha1 = async (data) => {
  const algorithm = { name: "SHA-1", alias: "sha1" };
  const hash = await createHash(data, algorithm);
  return hash;
};
const md5 = async (data) => {
  const algorithm = { name: "MD5", alias: "md5" };
  const hash = await createHash(data, algorithm);
  return hash;
};
const createHash = async (data, algorithm) => {
  let sourceBuffer;
  if (ArrayBuffer.isView(data) || data instanceof ArrayBuffer) {
    sourceBuffer = data;
  } else {
    if (typeof data === "object") {
      data = JSON.stringify(data);
    }
    sourceBuffer = new TextEncoder().encode(String(data));
  }
  if (crypto && crypto.subtle) {
    const buffer = await crypto.subtle.digest(
      {
        name: algorithm.name
      },
      sourceBuffer
    );
    const hash = Array.prototype.map.call(new Uint8Array(buffer), (x) => ("00" + x.toString(16)).slice(-2)).join("");
    return hash;
  }
  return null;
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createHash,
  md5,
  sha1,
  sha256
});

},
"hono/dist/cjs/request.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var request_exports = {};
__export(request_exports, {
  HonoRequest: () => HonoRequest,
  cloneRawRequest: () => cloneRawRequest
});
module.exports = __toCommonJS(request_exports);
var import_http_exception = require("./http-exception");
var import_constants = require("./request/constants");
var import_body = require("./utils/body");
var import_url = require("./utils/url");
class HonoRequest {
  /**
   * `.raw` can get the raw Request object.
   *
   * @see {@link https://hono.dev/docs/api/request#raw}
   *
   * @example
   * ```ts
   * // For Cloudflare Workers
   * app.post('/', async (c) => {
   *   const metadata = c.req.raw.cf?.hostMetadata?
   *   ...
   * })
   * ```
   */
  raw;
  #validatedData;
  // Short name of validatedData
  #matchResult;
  routeIndex = 0;
  /**
   * `.path` can get the pathname of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#path}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const pathname = c.req.path // `/about/me`
   * })
   * ```
   */
  path;
  bodyCache = {};
  constructor(request, path = "/", matchResult = [[]]) {
    this.raw = request;
    this.path = path;
    this.#matchResult = matchResult;
  }
  param(key) {
    return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
  }
  #getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex]?.[1][key];
    const param = this.#getParamValue(paramKey);
    return param && (0, import_url.tryDecodeURIComponent)(param);
  }
  #getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex]?.[1] ?? {});
    for (const key of keys) {
      const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value !== void 0) {
        decoded[key] = (0, import_url.tryDecodeURIComponent)(value);
      }
    }
    return decoded;
  }
  #getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return (0, import_url.getQueryParam)(this.url, key);
  }
  queries(key) {
    return (0, import_url.getQueryParams)(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name) ?? void 0;
    }
    const headerData = /* @__PURE__ */ Object.create(null);
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options) {
    return (0, import_body.parseBody)(this, options);
  }
  #cachedBody = (key) => {
    const { bodyCache, raw } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    for (const anyCachedKey in bodyCache) {
      return bodyCache[anyCachedKey].then((body) => {
        if (anyCachedKey === "json") {
          body = JSON.stringify(body);
        }
        return new Response(body)[key]();
      });
    }
    return bodyCache[key] = raw[key]();
  };
  /**
   * `.json()` can parse Request body of type `application/json`
   *
   * @see {@link https://hono.dev/docs/api/request#json}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.json()
   * })
   * ```
   */
  json() {
    return this.#cachedBody("text").then((text) => JSON.parse(text));
  }
  /**
   * `.text()` can parse Request body of type `text/plain`
   *
   * @see {@link https://hono.dev/docs/api/request#text}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.text()
   * })
   * ```
   */
  text() {
    return this.#cachedBody("text");
  }
  /**
   * `.arrayBuffer()` parse Request body as an `ArrayBuffer`
   *
   * @see {@link https://hono.dev/docs/api/request#arraybuffer}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.arrayBuffer()
   * })
   * ```
   */
  arrayBuffer() {
    return this.#cachedBody("arrayBuffer");
  }
  /**
   * `.bytes()` parses the request body as a `Uint8Array`.
   *
   * @see {@link https://hono.dev/docs/api/request#bytes}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.bytes()
   * })
   * ```
   */
  bytes() {
    return this.#cachedBody("arrayBuffer").then((buffer) => new Uint8Array(buffer));
  }
  /**
   * Parses the request body as a `Blob`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.blob();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#blob
   */
  blob() {
    return this.#cachedBody("blob");
  }
  /**
   * Parses the request body as `FormData`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.formData();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#formdata
   */
  formData() {
    return this.#cachedBody("formData");
  }
  /**
   * Adds validated data to the request.
   *
   * @param target - The target of the validation.
   * @param data - The validated data to add.
   */
  addValidatedData(target, data) {
    ;
    (this.#validatedData ??= {})[target] = data;
  }
  valid(target) {
    return this.#validatedData?.[target];
  }
  /**
   * `.url()` can get the request url strings.
   *
   * @see {@link https://hono.dev/docs/api/request#url}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const url = c.req.url // `http://localhost:8787/about/me`
   *   ...
   * })
   * ```
   */
  get url() {
    return this.raw.url;
  }
  /**
   * `.method()` can get the method name of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#method}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const method = c.req.method // `GET`
   * })
   * ```
   */
  get method() {
    return this.raw.method;
  }
  get [import_constants.GET_MATCH_RESULT]() {
    return this.#matchResult;
  }
  /**
   * `.matchedRoutes()` can return a matched route in the handler
   *
   * @deprecated
   *
   * Use matchedRoutes helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#matchedroutes}
   *
   * @example
   * ```ts
   * app.use('*', async function logger(c, next) {
   *   await next()
   *   c.req.matchedRoutes.forEach(({ handler, method, path }, i) => {
   *     const name = handler.name || (handler.length < 2 ? '[handler]' : '[middleware]')
   *     console.log(
   *       method,
   *       ' ',
   *       path,
   *       ' '.repeat(Math.max(10 - path.length, 0)),
   *       name,
   *       i === c.req.routeIndex ? '<- respond from here' : ''
   *     )
   *   })
   * })
   * ```
   */
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  /**
   * `routePath()` can retrieve the path registered within the handler
   *
   * @deprecated
   *
   * Use routePath helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#routepath}
   *
   * @example
   * ```ts
   * app.get('/posts/:id', (c) => {
   *   return c.json({ path: c.req.routePath })
   * })
   * ```
   */
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
}
const cloneRawRequest = async (req) => {
  if (!req.raw.bodyUsed) {
    return req.raw.clone();
  }
  const cacheKey = Object.keys(req.bodyCache)[0];
  if (!cacheKey) {
    throw new import_http_exception.HTTPException(500, {
      message: "Cannot clone request: body was already consumed and not cached. Please use HonoRequest methods (e.g., req.json(), req.text()) instead of consuming req.raw directly."
    });
  }
  let body = await req[cacheKey]();
  const headers = req.header();
  if (cacheKey === "json") {
    body = JSON.stringify(body);
    delete headers["content-length"];
  } else if (body instanceof FormData) {
    delete headers["content-type"];
    delete headers["content-length"];
  }
  const requestInit = {
    body,
    cache: req.raw.cache,
    credentials: req.raw.credentials,
    headers,
    integrity: req.raw.integrity,
    keepalive: req.raw.keepalive,
    method: req.method,
    mode: req.raw.mode,
    redirect: req.raw.redirect,
    referrer: req.raw.referrer,
    referrerPolicy: req.raw.referrerPolicy,
    signal: req.raw.signal
  };
  return new Request(req.url, requestInit);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HonoRequest,
  cloneRawRequest
});

},
"hono/dist/cjs/utils/url.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var url_exports = {};
__export(url_exports, {
  checkOptionalParameter: () => checkOptionalParameter,
  decodeURIComponent_: () => decodeURIComponent_,
  getPath: () => getPath,
  getPathNoStrict: () => getPathNoStrict,
  getPattern: () => getPattern,
  getQueryParam: () => getQueryParam,
  getQueryParams: () => getQueryParams,
  getQueryStrings: () => getQueryStrings,
  mergePath: () => mergePath,
  splitPath: () => splitPath,
  splitRoutingPath: () => splitRoutingPath,
  tryDecode: () => tryDecode,
  tryDecodeURI: () => tryDecodeURI,
  tryDecodeURIComponent: () => tryDecodeURIComponent
});
module.exports = __toCommonJS(url_exports);
const splitPath = (path) => {
  const paths = path.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
const splitRoutingPath = (routePath) => {
  const { groups, path } = extractGroupsFromPath(routePath);
  const paths = splitPath(path);
  return replaceGroupMarks(paths, groups);
};
const extractGroupsFromPath = (path) => {
  const groups = [];
  path = path.replace(/\{[^}]+\}/g, (match, index) => {
    const mark = `@${index}`;
    groups.push([mark, match]);
    return mark;
  });
  return { groups, path };
};
const replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1; i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1; j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
const patternCache = {};
const getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match) {
    const cacheKey = `${label}#${next}`;
    if (!patternCache[cacheKey]) {
      if (match[2]) {
        patternCache[cacheKey] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey, match[1], new RegExp(`^${match[2]}(?=/${next})`)] : [label, match[1], new RegExp(`^${match[2]}$`)];
      } else {
        patternCache[cacheKey] = [label, match[1], true];
      }
    }
    return patternCache[cacheKey];
  }
  return null;
};
const tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match) => {
      try {
        return decoder(match);
      } catch {
        return match;
      }
    });
  }
};
const tryDecodeURI = (str) => tryDecode(str, decodeURI);
const getPath = (request) => {
  const url = request.url;
  const start = url.indexOf("/", url.indexOf(":") + 4);
  let i = start;
  for (; i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path = url.slice(start, end);
      return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start, i);
};
const getQueryStrings = (url) => {
  const queryIndex = url.indexOf("?", 8);
  if (queryIndex === -1) {
    return "";
  }
  const hashIndex = url.indexOf("#", 8);
  return hashIndex === -1 ? url.slice(queryIndex) : queryIndex < hashIndex ? url.slice(queryIndex, hashIndex) : "";
};
const getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
const mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
const checkOptionalParameter = (path) => {
  if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) {
    return null;
  }
  const segments = path.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (segment.charCodeAt(segment.length - 1) === 63) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.slice(0, -1);
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
const tryDecodeURIComponent = (str) => str.indexOf("%") !== -1 ? tryDecode(str, decodeURIComponent_) : str;
const _decodeURI = (value) => {
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return tryDecodeURIComponent(value);
};
const _getQueryParam = (url, key, multiple) => {
  const hashIndex = url.indexOf("#", 8);
  if (hashIndex !== -1) {
    url = url.slice(0, hashIndex);
  }
  let encoded;
  if (!multiple && key && key.indexOf("%") === -1 && key.indexOf("+") === -1) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return void 0;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return void 0;
    }
  }
  const results = /* @__PURE__ */ Object.create(null);
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(
      keyIndex + 1,
      valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex
    );
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      ;
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
const getQueryParam = _getQueryParam;
const getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
const decodeURIComponent_ = decodeURIComponent;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  checkOptionalParameter,
  decodeURIComponent_,
  getPath,
  getPathNoStrict,
  getPattern,
  getQueryParam,
  getQueryParams,
  getQueryStrings,
  mergePath,
  splitPath,
  splitRoutingPath,
  tryDecode,
  tryDecodeURI,
  tryDecodeURIComponent
});

},
"hono/dist/cjs/utils/body.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var body_exports = {};
__export(body_exports, {
  parseBody: () => parseBody
});
module.exports = __toCommonJS(body_exports);
var import_buffer = require("./buffer");
const MAX_NESTING_DEPTH = 32;
const MAX_NESTED_OBJECTS = 1e4;
const isRawRequest = (request) => "headers" in request;
const parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
  const { all = false, dot = false } = options;
  const headers = isRawRequest(request) ? request.headers : request.raw.headers;
  const contentType = headers.get("Content-Type");
  const mediaType = contentType?.split(";")[0].trim().toLowerCase();
  if (mediaType === "multipart/form-data" || mediaType === "application/x-www-form-urlencoded") {
    return parseFormData(request, { all, dot });
  }
  return {};
};
async function parseFormData(request, options) {
  if (!isRawRequest(request) && request.bodyCache.formData) {
    return convertFormDataToBodyData(
      await request.bodyCache.formData,
      options
    );
  }
  const headers = isRawRequest(request) ? request.headers : request.raw.headers;
  const arrayBuffer = await request.arrayBuffer();
  const formDataPromise = (0, import_buffer.bufferToFormData)(arrayBuffer, headers.get("Content-Type") || "");
  if (!isRawRequest(request)) {
    request.bodyCache.formData = formDataPromise;
  }
  const formData = await formDataPromise;
  if (formData) {
    return convertFormDataToBodyData(formData, options);
  }
  return {};
}
function convertFormDataToBodyData(formData, options) {
  const form = /* @__PURE__ */ Object.create(null);
  const nestingState = { count: 0 };
  formData.forEach((value, key) => {
    const shouldParseAllValues = options.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value, nestingState);
        delete form[key];
      }
    });
  }
  return form;
}
const handleParsingAllValues = (form, key, value) => {
  if (form[key] !== void 0) {
    if (Array.isArray(form[key])) {
      ;
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    if (!key.endsWith("[]")) {
      form[key] = value;
    } else {
      form[key] = [value];
    }
  }
};
const handleParsingNestedValues = (form, key, value, state) => {
  if (/(?:^|\.)__proto__\./.test(key)) {
    return;
  }
  let nestedForm = form;
  const keys = key.split(".", MAX_NESTING_DEPTH + 2);
  if (keys.length > MAX_NESTING_DEPTH + 1) {
    throwNestingLimitExceeded();
  }
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        if (state.count++ >= MAX_NESTED_OBJECTS) {
          throwNestingLimitExceeded();
        }
        nestedForm[key2] = /* @__PURE__ */ Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};
const throwNestingLimitExceeded = () => {
  throw new Error("Nesting limit exceeded");
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  parseBody
});

},
"hono/dist/cjs/utils/buffer.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var buffer_exports = {};
__export(buffer_exports, {
  bufferToFormData: () => bufferToFormData,
  bufferToString: () => bufferToString,
  equal: () => equal,
  timingSafeEqual: () => timingSafeEqual
});
module.exports = __toCommonJS(buffer_exports);
var import_crypto = require("./crypto");
const equal = (a, b) => {
  if (a === b) {
    return true;
  }
  if (a.byteLength !== b.byteLength) {
    return false;
  }
  const va = new DataView(a);
  const vb = new DataView(b);
  let i = va.byteLength;
  while (i--) {
    if (va.getUint8(i) !== vb.getUint8(i)) {
      return false;
    }
  }
  return true;
};
const constantTimeEqualString = (a, b) => {
  const aLen = a.length;
  const bLen = b.length;
  const maxLen = Math.max(aLen, bLen);
  let out = aLen ^ bLen;
  for (let i = 0; i < maxLen; i++) {
    const aChar = i < aLen ? a.charCodeAt(i) : 0;
    const bChar = i < bLen ? b.charCodeAt(i) : 0;
    out |= aChar ^ bChar;
  }
  return out === 0;
};
const timingSafeEqualString = async (a, b, hashFunction) => {
  if (!hashFunction) {
    hashFunction = import_crypto.sha256;
  }
  const [sa, sb] = await Promise.all([hashFunction(a), hashFunction(b)]);
  if (sa == null || sb == null || typeof sa !== "string" || typeof sb !== "string") {
    return false;
  }
  const hashEqual = constantTimeEqualString(sa, sb);
  const originalEqual = constantTimeEqualString(a, b);
  return hashEqual && originalEqual;
};
const timingSafeEqual = async (a, b, hashFunction) => {
  if (typeof a === "string" && typeof b === "string") {
    return timingSafeEqualString(a, b, hashFunction);
  }
  if (!hashFunction) {
    hashFunction = import_crypto.sha256;
  }
  const [sa, sb] = await Promise.all([hashFunction(a), hashFunction(b)]);
  if (!sa || !sb || typeof sa !== "string" || typeof sb !== "string") {
    return false;
  }
  return timingSafeEqualString(sa, sb);
};
const bufferToString = (buffer) => {
  if (buffer instanceof ArrayBuffer) {
    const enc = new TextDecoder("utf-8");
    return enc.decode(buffer);
  }
  return buffer;
};
const bufferToFormData = (arrayBuffer, contentType) => {
  const response = new Response(arrayBuffer, {
    headers: {
      // Normalize the media type (case-insensitive) while keeping parameters like the boundary
      "Content-Type": contentType.replace(/^[^;]+/, (mediaType) => mediaType.toLowerCase())
    }
  });
  return response.formData();
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  bufferToFormData,
  bufferToString,
  equal,
  timingSafeEqual
});

},
"hono/dist/cjs/request/constants.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var constants_exports = {};
__export(constants_exports, {
  GET_MATCH_RESULT: () => GET_MATCH_RESULT
});
module.exports = __toCommonJS(constants_exports);
const GET_MATCH_RESULT = /* @__PURE__ */ Symbol();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  GET_MATCH_RESULT
});

},
"hono/dist/cjs/http-exception.js": function(module, exports, require, requireAsync, __filename, __dirname, __thaw_require) {
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var http_exception_exports = {};
__export(http_exception_exports, {
  HTTPException: () => HTTPException
});
module.exports = __toCommonJS(http_exception_exports);
class HTTPException extends Error {
  res;
  status;
  /**
   * Creates an instance of `HTTPException`.
   * @param status - HTTP status code for the exception. Defaults to 500.
   * @param options - Additional options for the exception.
   */
  constructor(status = 500, options) {
    super(options?.message, { cause: options?.cause });
    this.res = options?.res;
    this.status = status;
  }
  /**
   * Returns the response object associated with the exception.
   * If a response object is not provided, a new response is created with the error message and status code.
   * @returns The response object.
   */
  getResponse() {
    if (this.res) {
      const newResponse = new Response(this.res.body, {
        status: this.status,
        headers: this.res.headers
      });
      return newResponse;
    }
    return new Response(this.message, {
      status: this.status
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HTTPException
});

},
};
var __thaw_bundle_import_maps = {
"hono/./dist/cjs/middleware/cache/index.js": {},
"hono/dist/cjs/utils/crypto.js": {},
"hono/dist/cjs/request.js": {},
"hono/dist/cjs/utils/url.js": {},
"hono/dist/cjs/utils/body.js": {},
"hono/dist/cjs/utils/buffer.js": {},
"hono/dist/cjs/request/constants.js": {},
"hono/dist/cjs/http-exception.js": {},
};
var __thaw_bundle_known_package_maps = {
"hono/./dist/cjs/middleware/cache/index.js": [],
"hono/dist/cjs/utils/crypto.js": [],
"hono/dist/cjs/request.js": [],
"hono/dist/cjs/utils/url.js": [],
"hono/dist/cjs/utils/body.js": [],
"hono/dist/cjs/utils/buffer.js": [],
"hono/dist/cjs/request/constants.js": [],
"hono/dist/cjs/http-exception.js": [],
};
var __thaw_bundle_require_maps = {
"hono/./dist/cjs/middleware/cache/index.js": {"../../request": "hono/dist/cjs/request.js", "../../utils/crypto": "hono/dist/cjs/utils/crypto.js", },
"hono/dist/cjs/utils/crypto.js": {},
"hono/dist/cjs/request.js": {"./http-exception": "hono/dist/cjs/http-exception.js", "./request/constants": "hono/dist/cjs/request/constants.js", "./utils/body": "hono/dist/cjs/utils/body.js", "./utils/url": "hono/dist/cjs/utils/url.js", },
"hono/dist/cjs/utils/url.js": {},
"hono/dist/cjs/utils/body.js": {"./buffer": "hono/dist/cjs/utils/buffer.js", },
"hono/dist/cjs/utils/buffer.js": {"./crypto": "hono/dist/cjs/utils/crypto.js", },
"hono/dist/cjs/request/constants.js": {},
"hono/dist/cjs/http-exception.js": {},
};
var __thaw_bundle_export_graphs = JSON.parse("{}");
var __thaw_bundle_commonjs_contexts = JSON.parse("{\"hono/./dist/cjs/middleware/cache/index.js\":true,\"hono/dist/cjs/utils/crypto.js\":true,\"hono/dist/cjs/request.js\":true,\"hono/dist/cjs/utils/url.js\":true,\"hono/dist/cjs/utils/body.js\":true,\"hono/dist/cjs/utils/buffer.js\":true,\"hono/dist/cjs/request/constants.js\":true,\"hono/dist/cjs/http-exception.js\":true}");
var __thaw_bundle_cjs_export_names = JSON.parse("{\"hono/./dist/cjs/middleware/cache/index.js\":[\"cache\",\"default\"],\"hono/dist/cjs/utils/crypto.js\":[\"createHash\",\"default\",\"md5\",\"sha1\",\"sha256\"],\"hono/dist/cjs/request.js\":[\"HonoRequest\",\"cloneRawRequest\",\"default\"],\"hono/dist/cjs/utils/url.js\":[\"checkOptionalParameter\",\"decodeURIComponent_\",\"default\",\"getPath\",\"getPathNoStrict\",\"getPattern\",\"getQueryParam\",\"getQueryParams\",\"getQueryStrings\",\"mergePath\",\"splitPath\",\"splitRoutingPath\",\"tryDecode\",\"tryDecodeURI\",\"tryDecodeURIComponent\"],\"hono/dist/cjs/utils/body.js\":[\"default\",\"parseBody\"],\"hono/dist/cjs/utils/buffer.js\":[\"bufferToFormData\",\"bufferToString\",\"default\",\"equal\",\"timingSafeEqual\"],\"hono/dist/cjs/request/constants.js\":[\"GET_MATCH_RESULT\",\"default\"],\"hono/dist/cjs/http-exception.js\":[\"HTTPException\",\"default\"]}");
function __thaw_bundle_factory_of(key) {
  if (Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, key)) return key;
  var query = key.indexOf('?'), fragment = key.indexOf('#', 1);
  var at = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  return at < 0 ? key : key.slice(0, at);
}
function __thaw_bundle_validate_static(key, visited) {
  visited = visited || [];
  if (visited.indexOf(key) >= 0) return;
  var graph = __thaw_bundle_export_graphs[__thaw_bundle_factory_of(key)];
  if (!graph) return;
  var next = visited.concat(key), dependencies = graph.dependencies || [];
  var map = __thaw_bundle_import_maps[__thaw_bundle_factory_of(key)] || {};
  for (var i = 0; i < dependencies.length; i++) {
    var target = __thaw_bundle_target(map, dependencies[i]);
    if (!target) {
      var spec = dependencies[i], builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
      if (__thaw_bundle_builtin_names.indexOf(builtin) < 0 && !(String(spec).endsWith('.node') && typeof require.addon === 'function'))
        throw new SyntaxError('Cannot resolve import ' + spec);
    } else __thaw_bundle_validate_static(target.key, next);
  }
  var origin = __thaw_bundle_origin_for(key), requests = graph.requests || [];
  for (var j = 0; j < requests.length; j++)
    origin.validateKnownStatic(requests[j][0], requests[j][1]);
}
var __thaw_namespace_create = Object.create, __thaw_namespace_define = Object.defineProperty;
var __thaw_namespace_prevent = Object.preventExtensions, __thaw_namespace_own = Object.prototype.hasOwnProperty;
var __thaw_namespace_keys = Object.keys, __thaw_namespace_apply = Reflect.apply;
var __thaw_namespace_get = WeakMap.prototype.get, __thaw_namespace_set = WeakMap.prototype.set;
var __thaw_namespace_has = WeakMap.prototype.has, __thaw_namespace_tag = Symbol.toStringTag;
var __thaw_namespace_promise = Promise, __thaw_namespace_resolve = Promise.resolve;
var __thaw_namespace_reject = Promise.reject, __thaw_namespace_then = Promise.prototype.then;
var __thaw_bundle_cjs_namespaces = Object.create(null);
var __thaw_bundle_cjs_namespace_values = new WeakMap();
function __thaw_bundle_cjs_namespace(key, value, names) {
  if (__thaw_namespace_apply(__thaw_namespace_own, __thaw_bundle_cjs_namespaces, [key]))
    return __thaw_bundle_cjs_namespaces[key];
  var namespace = __thaw_namespace_create(null);
  __thaw_namespace_define(namespace, 'default', {value:value, enumerable:true});
  __thaw_namespace_define(namespace, 'module.exports', {value:value, enumerable:true});
  for (var index = 0; index < names.length; index++) {
    var name = names[index];
    if (!__thaw_namespace_apply(__thaw_namespace_own, namespace, [name]))
      __thaw_namespace_define(namespace, name, {value:value == null ? undefined : value[name], enumerable:true});
  }
  __thaw_namespace_define(namespace, __thaw_namespace_tag, {value:'Module'});
  __thaw_namespace_prevent(namespace);
  __thaw_namespace_apply(__thaw_namespace_set, __thaw_bundle_cjs_namespace_values, [namespace, value]);
  __thaw_bundle_cjs_namespaces[key] = namespace;
  return namespace;
}
function __thaw_bundle_cjs_fallback_namespace(spec, value) {
  var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
  var known = __thaw_bundle_builtin_names.indexOf(builtin) >= 0;
  return __thaw_bundle_cjs_namespace('external:' + (known ? 'node:' + builtin : spec),
    value, known && value != null ? __thaw_namespace_keys(value) : []);
}
function __thaw_bundle_origin_for(ownerKey) {
  var own = Object.prototype.hasOwnProperty;
  var ambiguous = {};
  function graphOf(key) { return __thaw_bundle_export_graphs[__thaw_bundle_factory_of(key)]; }
  function targetOf(key, spec) {
    return __thaw_bundle_target(__thaw_bundle_import_maps[__thaw_bundle_factory_of(key)] || {}, spec);
  }
  var enumerable = Object.prototype.propertyIsEnumerable;
  function valueOf(target, sourceKey, spec) {
    var edges = __thaw_bundle_edges[sourceKey];
    if (edges && own.call(edges, spec)) {
      var edgeTarget = targetOf(sourceKey, spec);
      // A CommonJS cycle initially exposes provisional exports. The cache
      // remains authoritative if its factory later replaces module.exports.
      if (edgeTarget && own.call(__thaw_bundle_cache, edgeTarget.key))
        return __thaw_bundle_cache[edgeTarget.key].exports;
      return edges[spec];
    }
    // A cycle may reach this edge before its owner executes the loader.
    // Export discovery must never evaluate a dependency ahead of that owner.
    return undefined;
  }
  function namesOf(key, visited, sourceKey, spec) {
    if (visited.indexOf(key) >= 0) return [];
    var graph = graphOf(key);
    if (!graph) {
      var value = valueOf({ key: key, factory: __thaw_bundle_factory_of(key) }, sourceKey, spec);
      return value == null ? [] : Object.keys(value).filter(function(name) { return name !== '__esModule'; });
    }
    var next = visited.concat(key);
    var names = Object.keys(graph.local).concat(Object.keys(graph.indirect));
    for (var index = 0; index < graph.stars.length; index++) {
      var target = targetOf(key, graph.stars[index]);
      if (!target) continue;
      var more = namesOf(target.key, next, key, graph.stars[index]);
      for (var j = 0; j < more.length; j++) {
        if (more[j] !== 'default' && names.indexOf(more[j]) < 0) names.push(more[j]);
      }
    }
    return names;
  }
  function retainedNativeEdge(key) {
    return typeof __thaw_bundle_native_keys !== 'undefined'
      && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(key))
      && !own.call(__thaw_bundle_mixed_keys, __thaw_bundle_factory_of(key));
  }
  function retainedNamespaceAnchor(key, name, targetKey, anchor) {
    if (!retainedNativeEdge(targetKey)) return null;
    // A rewritten mixed edge strips the importer's native export, but a
    // following pure-native edge retains the current module's own alias.
    return anchor || (typeof __thaw_bundle_native_keys !== 'undefined'
      && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(key)) ? { key: key, name: name } : null);
  }
  function resolve(key, name, visited, allowMissing, sourceKey, spec, anchor) {
    var visit = key + '\u0000' + name;
    if (visited.indexOf(visit) >= 0) return null;
    var graph = graphOf(key);
    if (!graph) {
      // Star exports skip the CommonJS interop marker; explicit named
      // reexports still resolve it through allowMissing.
      if (name === '__esModule' && !allowMissing) return null;
      var value = valueOf({ key: key, factory: __thaw_bundle_factory_of(key) }, sourceKey, spec);
      return (allowMissing || (value != null && enumerable.call(value, name))) ? { kind: 'cjs', key: key, sourceKey: sourceKey, spec: spec, name: name } : null;
    }
    var next = visited.concat(visit);
    if (own.call(graph.local, name)) {
      return { kind: 'esm', key: key, binding: graph.local[name], name: name };
    }
    if (own.call(graph.indirect, name)) {
      var indirect = graph.indirect[name];
      var source = targetOf(key, indirect[0]);
      if (!source) return null;
      if (indirect[1] === null) {
        return { kind: 'namespace', key: source.key, binding: '*namespace*', sourceKey: key,
          spec: indirect[0], name: name,
          anchor: retainedNamespaceAnchor(key, name, source.key, anchor) };
      }
      if (indirect[2] && !graphOf(source.key)) {
        return { kind: 'cjs-default', key: source.key, sourceKey: key, spec: indirect[0] };
      }
      return resolve(source.key, indirect[1], next, true, key, indirect[0],
        retainedNamespaceAnchor(key, name, source.key, anchor));
    }
    if (name === 'default') return null;
    var found = null;
    for (var index = 0; index < graph.stars.length; index++) {
      var star = targetOf(key, graph.stars[index]);
      if (!star) continue;
      var candidate = resolve(star.key, name, next, false, key, graph.stars[index],
        retainedNamespaceAnchor(key, name, star.key, anchor));
      if (candidate === ambiguous) return ambiguous;
      if (!candidate) continue;
      if (found && !sameBinding(found, candidate)) return ambiguous;
      found = candidate;
    }
    return found;
  }
  function sameBinding(left, right) {
    if (left.kind !== right.kind) return false;
    if (left.kind === 'cjs') return left.key === right.key && left.name === right.name;
    if (left.kind === 'cjs-default') return left.key === right.key;
    return left.key === right.key && left.binding === right.binding;
  }
  function read(resolution) {
    if (resolution.kind === 'cjs' || resolution.kind === 'cjs-default') {
      var edges = __thaw_bundle_edges[resolution.sourceKey];
      if (!edges || !own.call(edges, resolution.spec)) throw new ReferenceError("Cannot access '" + (resolution.name || 'default') + "' before initialization");
      var value = valueOf(null, resolution.sourceKey, resolution.spec);
      return resolution.kind === 'cjs' ? value[resolution.name] : value && value.__esModule ? value.default : value;
    }
    if (typeof __thaw_native_entry !== 'undefined' && __thaw_native_entry) {
      if (resolution.kind === 'namespace') {
        if (graphOf(resolution.key)) return __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(resolution.key)]
          ? __thaw_bundle_facade_for(resolution.key)
          : resolution.anchor
            ? __thaw_native_entry.readNative(resolution.anchor.key, resolution.anchor.name)
            : __thaw_native_entry.readNative(resolution.key);
        var edge = __thaw_bundle_edges[resolution.sourceKey];
        if (!edge || !own.call(edge, resolution.spec)) throw new ReferenceError('Import is not initialized');
        return edge[resolution.spec];
      }
      // `binding` is the local declaration used for diamond identity;
      // native namespaces expose the exported alias in `name` instead.
      return __thaw_native_entry.readNative(resolution.key, resolution.name);
    }
    var source = __thaw_bundle_require(resolution.key, __thaw_bundle_factory_of(resolution.key), true);
    return resolution.kind === 'namespace' ? source : source[resolution.name];
  }
  function linksReady(key, visited) {
    if (visited.indexOf(key) >= 0) return true;
    var graph = graphOf(key);
    if (!graph) return true;
    var next = visited.concat(key), edges = __thaw_bundle_edges[key];
    // Explicit named reexports cannot introduce a competing star binding.
    // Their names are static even if their opaque target has not run yet.
    var specs = graph.stars;
    for (var index = 0; index < specs.length; index++) {
      var spec = specs[index], target = targetOf(key, spec);
      if (!target) continue;
      // ESM names and terminal bindings are known from the source graph
      // before evaluation. Only opaque CJS/native targets need a loaded edge
      // to discover their exported names.
      if ((!graphOf(target.key) && (!edges || !own.call(edges, spec))) || !linksReady(target.key, next)) return false;
    }
    var indirectNames = Object.keys(graph.indirect);
    for (var n = 0; n < indirectNames.length; n++) {
      var indirect = graph.indirect[indirectNames[n]], target = targetOf(key, indirect[0]);
      // A direct opaque named reexport has a statically fixed name/binding.
      // An ESM target can itself resolve through unknown opaque stars.
      if (target && graphOf(target.key) && !linksReady(target.key, next)) return false;
    }
    return true;
  }
  return {
    validateStatic: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new SyntaxError('Cannot resolve import ' + spec);
      // CommonJS default is the established synthetic default interop. All
      // other requested names in this route have a statically known graph.
      if (name === 'default' && !graphOf(target.key)) return;
      var resolution = resolve(target.key, name, [], false, ownerKey, spec);
      if (!resolution || resolution === ambiguous)
        throw new SyntaxError('Missing or ambiguous export ' + name);
    },
    validateKnownStatic: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      // Opaque CommonJS stars are discovered only after their owner's load.
      // Do not execute that owner during source-graph validation.
      if (!target) {
        var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
        if (__thaw_bundle_builtin_names.indexOf(builtin) < 0 && !(String(spec).endsWith('.node') && typeof require.addon === 'function'))
          throw new SyntaxError('Cannot resolve import ' + spec);
        return;
      }
      if (graphOf(target.key) && linksReady(target.key, []))
        this.validateStatic(spec, name);
    },
    validateRequests: function() {
      var graph = graphOf(ownerKey), requests = graph && graph.requests || [];
      for (var index = 0; index < requests.length; index++)
        this.validateKnownStatic(requests[index][0], requests[index][1]);
    },
    validateDynamic: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (target) __thaw_validate_native_link(target.key);
    },
    completeDynamic: function(spec, promise) {
      var origin = this;
      return __thaw_native_apply(__thaw_native_then, promise,
        [function(namespace) { return origin.selectDynamic(spec, namespace); }]);
    },
    rejectDynamic: function(error) {
      return __thaw_native_apply(__thaw_native_reject, __thaw_native_promise, [error]);
    },
    edge: function(spec, value) {
      // Async static imports share the loader with dynamic import. Only our
      // own namespace wrappers unwrap here; user exports keep their identity.
      if (value != null && (typeof value === 'object' || typeof value === 'function')
          && __thaw_namespace_apply(__thaw_namespace_has, __thaw_bundle_cjs_namespace_values, [value]))
        value = __thaw_namespace_apply(__thaw_namespace_get, __thaw_bundle_cjs_namespace_values, [value]);
      var edges = __thaw_bundle_edges[ownerKey];
      if (!edges) edges = __thaw_bundle_edges[ownerKey] = Object.create(null);
      if (own.call(edges, spec) && edges[spec] === value) return;
      edges[spec] = value;
      __thaw_bundle_edge_version++;
      // A cycle can reach an ESM module before its later CJS/native loader.
      // Only link when its full transitive export graph is available.
      for (var key in __thaw_bundle_star_linkers) __thaw_bundle_star_linkers[key]();
    },
    track: function(exports) {
      var linked = false, linking = false;
      var link = function() {
        if (linked || linking || !linksReady(ownerKey, [])) return;
        linking = true;
        try {
          // A CJS Proxy ownKeys trap can record another edge while names are
          // discovered. Recompute before publication if the graph changed.
          var bindings, before;
          do {
            before = __thaw_bundle_edge_version;
            bindings = [];
            var graph = graphOf(ownerKey), names = [];
            for (var index = 0; index < graph.stars.length; index++) {
              var spec = graph.stars[index], target = targetOf(ownerKey, spec);
              if (!target) continue;
              var more = namesOf(target.key, [], ownerKey, spec);
              for (var j = 0; j < more.length; j++) {
                var name = more[j];
                if (name !== 'default' && names.indexOf(name) < 0) names.push(name);
              }
            }
            for (var n = 0; n < names.length; n++) {
              var name = names[n];
              if (own.call(graph.local, name) || own.call(graph.indirect, name) || (name !== '__esModule' && own.call(exports, name))) continue;
              var resolution = resolve(ownerKey, name, [], false, null, null,
                { key: ownerKey, name: name });
              if (resolution && resolution !== ambiguous) bindings.push([name, resolution]);
            }
          } while (before !== __thaw_bundle_edge_version && linksReady(ownerKey, []));
          if (!linksReady(ownerKey, [])) return;
          for (var b = 0; b < bindings.length; b++) {
            var binding = bindings[b];
            if (binding[0] !== '__esModule' && own.call(exports, binding[0])) continue;
            Object.defineProperty(exports, binding[0], { enumerable: true, get: function(r) { return function() { return read(r); }; }(binding[1]) });
          }
          linked = true;
          delete __thaw_bundle_star_linkers[ownerKey];
        } finally { linking = false; }
      };
      __thaw_bundle_star_linkers[ownerKey] = link;
      link();
    },
    defaultImport: function(spec, value) {
      var target = targetOf(ownerKey, spec);
      return target && graphOf(target.key) ? value.default : value && value.__esModule ? value.default : value;
    },
    readImport: function(spec, name) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      var resolution = resolve(target.key, name, [], true, ownerKey, spec,
        typeof __thaw_bundle_native_keys !== 'undefined' && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(target.key))
          ? { key: target.key, name: name } : null);
      if (!resolution || resolution === ambiguous) throw new SyntaxError('Missing or ambiguous export ' + name);
      return read(resolution);
    },
    readDefault: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      if (!graphOf(target.key)) {
        var edges = __thaw_bundle_edges[ownerKey];
        if (!edges || !own.call(edges, spec)) throw new ReferenceError('Import is not initialized');
        return this.defaultImport(spec, edges[spec]);
      }
      var resolution = resolve(target.key, 'default', [], true, ownerKey, spec,
        typeof __thaw_bundle_native_keys !== 'undefined' && own.call(__thaw_bundle_native_keys, __thaw_bundle_factory_of(target.key))
          ? { key: target.key, name: 'default' } : null);
      if (!resolution || resolution === ambiguous) throw new SyntaxError('Missing or ambiguous default export');
      return read(resolution);
    },
    namespaceImport: function(spec) {
      var target = targetOf(ownerKey, spec);
      if (!target) throw new Error('Cannot resolve import ' + spec);
      if (!graphOf(target.key)) {
        var edges = __thaw_bundle_edges[ownerKey];
        if (!edges || !own.call(edges, spec)) throw new ReferenceError('Import is not initialized');
        // Keep the legacy CJS namespace-import object; only ESM targets
        // select the tracked facade.
        return edges[spec];
      }
      return typeof __thaw_native_entry === 'undefined' || !__thaw_native_entry || __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(target.key)]
        ? __thaw_bundle_facade_for(target.key) : __thaw_native_entry.readNative(target.key);
    },
    selectDynamic: function(spec, namespace) {
      var target = targetOf(ownerKey, spec);
      if (!target) return namespace;
      // The private shell's namespace contains no CJS exports. The existing
      // bundle contract returns that target's cached CommonJS value instead.
      if (!graphOf(target.key)) return __thaw_bundle_cjs_namespace(target.key, this.namespaceImport(spec), __thaw_bundle_cjs_export_names[target.factory] || []);
      return __thaw_bundle_mixed_keys[__thaw_bundle_factory_of(target.key)]
        ? __thaw_bundle_facade_for(target.key) : namespace;
    },
    names: function(spec, value) {
      var target = targetOf(ownerKey, spec);
      return target && graphOf(target.key) ? namesOf(target.key, [], ownerKey, spec) : (value == null ? [] : Object.keys(value).filter(function(name) { return name !== '__esModule'; }));
    },
    resolve: function(name) { var found = resolve(ownerKey, name, [], false, null, null,
      { key: ownerKey, name: name }); return found === ambiguous ? null : found; },
    read: read
  };
}
function __thaw_bundle_target(map, spec) {
  if (Object.prototype.hasOwnProperty.call(map, spec)) return { key: map[spec], factory: map[spec] };
  var query = spec.indexOf('?');
  var fragment = spec.indexOf('#', 1);
  var suffixAt = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  if (suffixAt < 0) return null;
  var base = spec.slice(0, suffixAt);
  if (!Object.prototype.hasOwnProperty.call(map, base)) return null;
  var factory = map[base];
  return { key: factory + spec.slice(suffixAt), factory: factory };
}
function __thaw_bundle_import_missing(known, spec) {
  spec = String(spec);
  if (spec.charAt(0) === '#') return true;
  var query = spec.indexOf('?'), fragment = spec.indexOf('#', 1);
  var suffixAt = query < 0 ? fragment : (fragment < 0 ? query : Math.min(query, fragment));
  if (suffixAt >= 0) spec = spec.slice(0, suffixAt);
  var slash = spec.indexOf('/');
  var next = spec.charAt(0) === '@' && slash >= 0 ? spec.indexOf('/', slash + 1) : slash;
  var name = next < 0 ? spec : spec.slice(0, next);
  return known.indexOf(name) >= 0;
}
function __thaw_bundle_resolve(map, spec, keys, searchAll, allowExports) {
  spec = String(spec);
  if (allowExports && Object.prototype.hasOwnProperty.call(__thaw_bundle_exports, spec)) return spec;
  var target = __thaw_bundle_target(map, spec);
  if (!target && searchAll) for (var index = 0; index < keys.length && !target; index++) target = __thaw_bundle_target(__thaw_bundle_require_maps[keys[index]] || {}, spec);
  if (target) return target.key;
  var builtin = spec.slice(0, 5) === 'node:' ? spec.slice(5) : spec;
  if (__thaw_bundle_builtin_names.indexOf(builtin) >= 0) return spec;
  var error = new Error('Cannot find module ' + spec);
  error.code = 'MODULE_NOT_FOUND';
  throw error;
}
function __thaw_bundle_async_error(factoryKey) {
  var error = new Error('Cannot synchronously require an async module: ' + factoryKey);
  error.code = 'ERR_REQUIRE_ASYNC_MODULE';
  return error;
}
function __thaw_bundle_require(key, factoryKey, allowAsync) {
  factoryKey = factoryKey || key;
  if (!allowAsync && Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, factoryKey)) throw __thaw_bundle_async_error(factoryKey);
  if (String(factoryKey).endsWith('.node') && require.addon) return require.addon();
  if (typeof __thaw_bundle_native_keys !== 'undefined' && Object.prototype.hasOwnProperty.call(__thaw_bundle_native_keys, factoryKey)) {
    var namespace = __thaw_native_entry.evalNativeSync(key, factoryKey);
    return Object.prototype.hasOwnProperty.call(__thaw_bundle_mixed_keys, factoryKey) ? __thaw_bundle_facade_for(key) : namespace;
  }
  __thaw_bundle_validate_static(key);
  if (!(key in __thaw_bundle_cache)) {
    var mod = { exports: {}, filename: '/thaw_modules/' + (factoryKey || key) };
    __thaw_bundle_cache[key] = mod;
    var map = __thaw_bundle_require_maps[factoryKey] || {};
    var importMap = __thaw_bundle_import_maps[factoryKey] || {};
    var knownPackages = __thaw_bundle_known_package_maps[factoryKey] || [];
    var localRequire = function(spec) {
      if ((spec === 'bindings' || spec === 'node-gyp-build') && typeof require.addon === 'function') return require.addon;
      var target = __thaw_bundle_target(map, spec);
      if (target) return __thaw_bundle_require(target.key, target.factory);
      return require(spec);
    };
    localRequire.addon = typeof require === 'function' ? require.addon : undefined;
    localRequire.resolve = function(spec) { return __thaw_bundle_resolve(map, spec, null, false, false); };
    localRequire.cache = __thaw_bundle_cache;
    var localImport = function(spec) { var target = __thaw_bundle_target(importMap, spec); if (target) return __thaw_bundle_require(target.key, target.factory); if (__thaw_bundle_import_missing(knownPackages, spec)) throw new Error('Cannot resolve import ' + spec); return require(spec); };
    var localRequireAsync = __thaw_bundle_create_import_async(factoryKey, globalThis.__thaw_worker_module);
    var filename = '/thaw_modules/' + factoryKey, slash = filename.lastIndexOf('/'), dirname = slash < 0 ? '.' : filename.slice(0, slash);
    var initialized;
    try { var factory = __thaw_bundle_factories[factoryKey]; if (Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, factoryKey)) factory = factory(__thaw_bundle_origin_for(key)); initialized = Object.prototype.hasOwnProperty.call(__thaw_bundle_commonjs_contexts, factoryKey) ? factory.call(mod.exports, mod, mod.exports, localRequire, localRequireAsync, filename, dirname, localImport) : factory(mod, mod.exports, localRequire, localRequireAsync, filename, dirname, localImport); } catch (error) { delete __thaw_bundle_cache[key]; delete __thaw_bundle_edges[key]; delete __thaw_bundle_star_linkers[key]; throw error; }
    mod.ready = __thaw_namespace_apply(__thaw_namespace_then, __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, [Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, factoryKey) ? initialized : undefined]), [function() {}, function(error) { delete __thaw_bundle_cache[key]; delete __thaw_bundle_edges[key]; delete __thaw_bundle_star_linkers[key]; throw error; }]);
  }
  return __thaw_bundle_cache[key].exports;
}
function __thaw_bundle_create_require(base) {
  var text = String(base || '');
  var keys = Object.keys(__thaw_bundle_require_maps);
  var factoryKey = keys.indexOf(text) >= 0 ? text : keys.reduce(function(best, key) { return text.endsWith('/' + key) && (!best || key.length > best.length) ? key : best; }, null);
  var map = {}, staticMap = __thaw_bundle_import_maps[factoryKey] || {}, requireMap = __thaw_bundle_require_maps[factoryKey] || {};
  for (var staticSpec in staticMap) if (Object.prototype.hasOwnProperty.call(staticMap, staticSpec)) map[staticSpec] = staticMap[staticSpec];
  for (var requireSpec in requireMap) if (Object.prototype.hasOwnProperty.call(requireMap, requireSpec)) map[requireSpec] = requireMap[requireSpec];
  var created = function(spec) { if ((String(spec) === 'bindings' || String(spec) === 'node-gyp-build') && typeof require.addon === 'function') return require.addon; spec = String(spec); if (Object.prototype.hasOwnProperty.call(__thaw_bundle_async_keys, spec)) throw __thaw_bundle_async_error(spec); if (Object.prototype.hasOwnProperty.call(__thaw_bundle_exports, spec)) return __thaw_bundle_exports[spec]; var target = __thaw_bundle_target(map, spec); if (!target && !factoryKey) { for (var index = 0; index < keys.length && !target; index++) target = __thaw_bundle_target(__thaw_bundle_require_maps[keys[index]] || {}, spec); } if (target) return __thaw_bundle_require(target.key, target.factory); return require(spec); };
  created.addon = typeof require === 'function' ? require.addon : undefined;
  created.resolve = function(spec) { return __thaw_bundle_resolve(map, spec, keys, !factoryKey, true); };
  created.cache = __thaw_bundle_cache; return created;
}
function __thaw_bundle_create_import(base) {
  var map = __thaw_bundle_import_maps[String(base)] || {};
  var known = __thaw_bundle_known_package_maps[String(base)] || [];
  return function(spec) { spec = String(spec); var target = __thaw_bundle_target(map, spec); if (target) return __thaw_bundle_require(target.key, target.factory); if (__thaw_bundle_import_missing(known, spec)) throw new Error('Cannot resolve import ' + spec); return require(spec); };
}
function __thaw_bundle_create_import_async(base, workerModule) {
  var map = __thaw_bundle_import_maps[String(base)] || {};
  var known = __thaw_bundle_known_package_maps[String(base)] || [];
  return function(spec) {
    try { spec = `${spec}`; } catch (error) { return __thaw_namespace_apply(__thaw_namespace_reject, __thaw_namespace_promise, [error]); }
    if (workerModule !== undefined && (spec === 'worker_threads' || spec === 'node:worker_threads')) { try { return __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, [__thaw_bundle_cjs_fallback_namespace(spec, workerModule)]); } catch (error) { return __thaw_namespace_apply(__thaw_namespace_reject, __thaw_namespace_promise, [error]); } }
  return new __thaw_namespace_promise(function(resolve, reject) {
   __thaw_namespace_apply(__thaw_namespace_then, __thaw_namespace_apply(__thaw_namespace_resolve, __thaw_namespace_promise, []), [function() {
    try {
     var target = __thaw_bundle_target(map, spec);
     if (target) {
      if (typeof __thaw_bundle_native_keys !== 'undefined' && Object.prototype.hasOwnProperty.call(__thaw_bundle_native_keys, target.factory)) {
       __thaw_native_apply(__thaw_native_then, __thaw_native_entry.evalNative(target.key, target.factory), [function(namespace) { try { resolve(__thaw_bundle_mixed_keys[target.factory] ? __thaw_bundle_facade_for(target.key) : namespace); } catch (error) { reject(error); } }, reject]);
       return;
      }
      __thaw_bundle_require(target.key, target.factory, true);
      __thaw_namespace_apply(__thaw_namespace_then, __thaw_bundle_cache[target.key].ready, [function() { try { var value = __thaw_bundle_cache[target.key].exports; resolve(Object.prototype.hasOwnProperty.call(__thaw_bundle_export_graphs, target.factory) ? value : __thaw_bundle_cjs_namespace(target.key, value, __thaw_bundle_cjs_export_names[target.factory] || [])); } catch (error) { reject(error); } }, reject]);
      return;
     }
     if (__thaw_bundle_import_missing(known, spec)) throw new Error('Cannot resolve import ' + spec);
     resolve(__thaw_bundle_cjs_fallback_namespace(spec, require(spec)));
    } catch (error) { reject(error); }
   }, reject]);
  });
  };
}
function __thaw_bundle_register_worker_main(key, mod) {
  __thaw_bundle_validate_static(key);
  if (Object.prototype.hasOwnProperty.call(__thaw_bundle_cache, key)) throw new Error('Worker entry already initialized');
  mod.filename = '/thaw_modules/' + key;
  var resolveReady, rejectReady;
  mod.ready = new __thaw_namespace_promise(function(resolve, reject) { resolveReady = resolve; rejectReady = reject; });
  __thaw_bundle_cache[key] = mod;
  return function(succeeded, error) { if (succeeded) resolveReady(); else rejectReady(error); };
}
globalThis.__thaw_bundle_create_require = __thaw_bundle_create_require;
globalThis.__thaw_bundle_create_import = __thaw_bundle_create_import;
globalThis.__thaw_bundle_create_import_async = __thaw_bundle_create_import_async;
var __thaw_worker_bundle_source =
  '(function() {\nvar __thaw_worker_bundle_source = globalThis.__thaw_worker_bundle_source;\nvar require = function(name) { if (name === "worker_threads" || name === "node:worker_threads") return globalThis.__thaw_worker_module; if (String(name).endsWith(".node") && typeof require.addon === "function") return require.addon(); var error = new Error("Cannot find module " + name); error.code = "MODULE_NOT_FOUND"; throw error; };\nrequire.addon = globalThis.require && globalThis.require.addon;\nvar __thaw_bundle_exports = globalThis.__thaw_bundle_exports || (globalThis.__thaw_bundle_exports = {});\nvar __thaw_bundle_builtin_names = Object.freeze(' + JSON.stringify(__thaw_bundle_builtin_names) + ');\nvar __thaw_bundle_cache = {};\nvar __thaw_bundle_async_keys = ' + JSON.stringify(__thaw_bundle_async_keys) + ';\nvar __thaw_bundle_edges = Object.create(null);\nvar __thaw_bundle_star_linkers = Object.create(null);\nvar __thaw_bundle_edge_version = 0;\nvar __thaw_bundle_factories = {' +
  Object.keys(__thaw_bundle_factories).map(function(key) { return JSON.stringify(key) + ': ' + __thaw_bundle_factories[key].toString(); }).join(',\n') +
  '};\nvar __thaw_bundle_require_maps = ' + JSON.stringify(__thaw_bundle_require_maps) + ';\n' +
  'var __thaw_bundle_import_maps = ' + JSON.stringify(__thaw_bundle_import_maps) + ';\n' +
  'var __thaw_bundle_known_package_maps = ' + JSON.stringify(__thaw_bundle_known_package_maps) + ';\n' +
  'var __thaw_bundle_export_graphs = JSON.parse(' + JSON.stringify(JSON.stringify(__thaw_bundle_export_graphs)) + ');\n' +
  'var __thaw_bundle_commonjs_contexts = JSON.parse(' + JSON.stringify(JSON.stringify(__thaw_bundle_commonjs_contexts)) + ');\n' +
  'var __thaw_namespace_create = Object.create, __thaw_namespace_define = Object.defineProperty;\nvar __thaw_namespace_prevent = Object.preventExtensions, __thaw_namespace_own = Object.prototype.hasOwnProperty;\nvar __thaw_namespace_keys = Object.keys, __thaw_namespace_apply = Reflect.apply;\nvar __thaw_namespace_get = WeakMap.prototype.get, __thaw_namespace_set = WeakMap.prototype.set;\nvar __thaw_namespace_has = WeakMap.prototype.has, __thaw_namespace_tag = Symbol.toStringTag;\nvar __thaw_namespace_promise = Promise, __thaw_namespace_resolve = Promise.resolve;\nvar __thaw_namespace_reject = Promise.reject, __thaw_namespace_then = Promise.prototype.then;\nvar __thaw_bundle_cjs_namespaces = Object.create(null);\nvar __thaw_bundle_cjs_namespace_values = new WeakMap();\nvar __thaw_bundle_cjs_export_names = ' + JSON.stringify(__thaw_bundle_cjs_export_names) + ';\n' +
  __thaw_bundle_cjs_namespace.toString() + '\n' + __thaw_bundle_cjs_fallback_namespace.toString() + '\n' + __thaw_bundle_factory_of.toString() + '\n' + __thaw_bundle_validate_static.toString() + '\n' + __thaw_bundle_origin_for.toString() + '\n' + __thaw_bundle_target.toString() + '\n' + __thaw_bundle_import_missing.toString() + '\n' + __thaw_bundle_resolve.toString() + '\n' + __thaw_bundle_async_error.toString() + '\n' + __thaw_bundle_require.toString() + '\n' + __thaw_bundle_create_require.toString() + '\n' + __thaw_bundle_create_import.toString() + '\n' + __thaw_bundle_create_import_async.toString() + '\n' + __thaw_bundle_register_worker_main.toString() + '\n' +
  'globalThis.__thaw_bundle_create_require = __thaw_bundle_create_require;\nglobalThis.__thaw_bundle_create_import = __thaw_bundle_create_import;\nglobalThis.__thaw_bundle_create_import_async = __thaw_bundle_create_import_async;\nglobalThis.__thaw_bundle_worker_origin = __thaw_bundle_origin_for;\nglobalThis.__thaw_bundle_register_worker_main = __thaw_bundle_register_worker_main;\n})();\n';
globalThis.__thaw_worker_bundle_source = __thaw_worker_bundle_source;
var __thaw_bundle_entry_key = "hono/./dist/cjs/middleware/cache/index.js";
var __thaw_bundle_entry = __thaw_bundle_require(__thaw_bundle_entry_key, undefined, true);
__thaw_bundle_exports[__thaw_bundle_entry_key] = __thaw_bundle_entry;
globalThis.__thaw_module_ready = __thaw_bundle_cache[__thaw_bundle_entry_key].ready;
return __thaw_bundle_entry;
})(globalThis.require);
